package com.brian.geoexponer;

import android.content.Context;
import android.content.SharedPreferences;

/** Ajustes del modo Exponer, guardados para la próxima vez. */
final class ExpoSettings {
    static final float[] SPEEDS = {0.25f, 0.50f, 0.625f, 0.75f, 1.0f, 1.25f, 1.50f};
    static final String[] SPEED_LABELS = {"0.25x", "0.50x", "0.625x", "0.75x", "1x", "1.25x", "1.50x"};

    /** -2 = pausa inteligente (según el largo de la frase). */
    static final int PAUSE_SMART = -2;
    static final int[] PAUSES_MS = {PAUSE_SMART, 0, 1000, 2000, 3000, 5000, 8000, 10000};
    static final String[] PAUSE_LABELS = {"Inteligente", "0s", "1s", "2s", "3s", "5s", "8s", "10s"};

    static final float[] SMART_FACTORS = {0.8f, 1.0f, 1.2f, 1.5f};
    static final String[] SMART_LABELS = {"0.8x", "1x", "1.2x", "1.5x"};

    private static final String K_MODE = "expo_mode";
    private static final String K_SPEED = "expo_speed_index";
    private static final String K_PAUSE = "expo_pause_index";
    private static final String K_SMART = "expo_smart_index";
    private static final String K_CUE_TONE = "expo_cue_tone";
    private static final String K_CUE_VOICE = "expo_cue_voice";
    private static final String K_VIBRATE = "expo_vibrate";
    private static final String K_TARGET_MIN = "expo_target_min";
    private static final String K_HINT_READ = "expo_hint_read";
    private static final String K_MULTI_TAP = "expo_multi_tap";

    private final SharedPreferences p;

    ExpoSettings(Context context) {
        p = context.getSharedPreferences(ScriptStore.PREFS, Context.MODE_PRIVATE);
    }

    String mode() {
        String m = p.getString(K_MODE, ExpoPlaybackService.MODE_MANUAL);
        if (ExpoPlaybackService.MODE_AUTO.equals(m) || ExpoPlaybackService.MODE_MIXED.equals(m)) return m;
        return ExpoPlaybackService.MODE_MANUAL;
    }

    void setMode(String mode) { p.edit().putString(K_MODE, mode).apply(); }

    int speedIndex() { return clamp(p.getInt(K_SPEED, 4), SPEEDS.length); }
    void setSpeedIndex(int i) { p.edit().putInt(K_SPEED, clamp(i, SPEEDS.length)).apply(); }
    float speed() { return SPEEDS[speedIndex()]; }

    int pauseIndex() { return clamp(p.getInt(K_PAUSE, 2), PAUSES_MS.length); }
    void setPauseIndex(int i) { p.edit().putInt(K_PAUSE, clamp(i, PAUSES_MS.length)).apply(); }
    int pauseMs() { return PAUSES_MS[pauseIndex()]; }

    int smartIndex() { return clamp(p.getInt(K_SMART, 1), SMART_FACTORS.length); }
    void setSmartIndex(int i) { p.edit().putInt(K_SMART, clamp(i, SMART_FACTORS.length)).apply(); }
    float smartFactor() { return SMART_FACTORS[smartIndex()]; }

    boolean cueTone() { return p.getBoolean(K_CUE_TONE, true); }
    void setCueTone(boolean v) { p.edit().putBoolean(K_CUE_TONE, v).apply(); }

    boolean cueVoice() { return p.getBoolean(K_CUE_VOICE, false); }
    void setCueVoice(boolean v) { p.edit().putBoolean(K_CUE_VOICE, v).apply(); }

    boolean vibrate() { return p.getBoolean(K_VIBRATE, true); }
    void setVibrate(boolean v) { p.edit().putBoolean(K_VIBRATE, v).apply(); }

    /** 0 = sin tiempo objetivo. */
    int targetMinutes() { return Math.max(0, Math.min(60, p.getInt(K_TARGET_MIN, 0))); }
    void setTargetMinutes(int v) { p.edit().putInt(K_TARGET_MIN, Math.max(0, Math.min(60, v))).apply(); }

    /** Lectura "pista": solo las primeras palabras de cada frase. */
    boolean hintRead() { return p.getBoolean(K_HINT_READ, false); }
    void setHintRead(boolean v) { p.edit().putBoolean(K_HINT_READ, v).apply(); }

    /** Doble toque del auricular = siguiente, triple = repetir. */
    boolean multiTap() { return p.getBoolean(K_MULTI_TAP, false); }
    void setMultiTap(boolean v) { p.edit().putBoolean(K_MULTI_TAP, v).apply(); }

    private static int clamp(int v, int size) {
        if (v < 0) return 0;
        if (v >= size) return size - 1;
        return v;
    }
}
