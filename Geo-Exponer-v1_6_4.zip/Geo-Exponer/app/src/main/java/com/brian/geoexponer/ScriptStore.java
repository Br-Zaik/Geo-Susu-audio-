package com.brian.geoexponer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Biblioteca de exposiciones guardadas (varias exposiciones con nombre).
 * Se guarda en SharedPreferences como JSON. Sin internet ni librerías extra.
 */
final class ScriptStore {
    static final String PREFS = "geo_exponer_prefs";
    private static final String KEY_SCRIPTS = "scripts_json";
    private static final String KEY_CURRENT = "current_script_id";
    private static final String KEY_OLD_TEXT = "last_text";

    static final class Script {
        String id;
        String name;
        String text;
        long updated;

        Script(String id, String name, String text) {
            this.id = id;
            this.name = name;
            this.text = text;
            this.updated = System.currentTimeMillis();
        }
    }

    private final SharedPreferences prefs;
    private final ArrayList<Script> scripts = new ArrayList<>();

    ScriptStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
    }

    private void load() {
        scripts.clear();
        String json = prefs.getString(KEY_SCRIPTS, "");
        if (json != null && !json.isEmpty()) {
            try {
                JSONArray array = new JSONArray(json);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject o = array.getJSONObject(i);
                    Script s = new Script(o.optString("id"), o.optString("name", "Exposición"), o.optString("text", ""));
                    s.updated = o.optLong("updated", 0L);
                    if (s.id != null && !s.id.isEmpty()) scripts.add(s);
                }
            } catch (Exception ignored) {
                scripts.clear();
            }
        }

        if (scripts.isEmpty()) {
            // Migración desde la versión 1.5.6 (un solo texto).
            String old = prefs.getString(KEY_OLD_TEXT, "");
            Script first = new Script(newId(), "Mi exposición", old == null ? "" : old);
            scripts.add(first);
            prefs.edit().putString(KEY_CURRENT, first.id).apply();
            persist();
        }
    }

    private void persist() {
        JSONArray array = new JSONArray();
        try {
            for (Script s : scripts) {
                JSONObject o = new JSONObject();
                o.put("id", s.id);
                o.put("name", s.name);
                o.put("text", s.text);
                o.put("updated", s.updated);
                array.put(o);
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(KEY_SCRIPTS, array.toString()).apply();
    }

    private static String newId() {
        return "s" + System.currentTimeMillis() + (int) (Math.random() * 1000);
    }

    List<Script> all() {
        return new ArrayList<>(scripts);
    }

    Script current() {
        String id = prefs.getString(KEY_CURRENT, "");
        Script found = find(id);
        if (found == null) {
            found = scripts.get(0);
            prefs.edit().putString(KEY_CURRENT, found.id).apply();
        }
        return found;
    }

    Script find(String id) {
        if (id == null) return null;
        for (Script s : scripts) {
            if (s.id.equals(id)) return s;
        }
        return null;
    }

    void select(String id) {
        if (find(id) != null) prefs.edit().putString(KEY_CURRENT, id).apply();
    }

    Script create(String name, String text) {
        Script s = new Script(newId(), name == null || name.trim().isEmpty() ? "Exposición " + (scripts.size() + 1) : name.trim(), text == null ? "" : text);
        scripts.add(0, s);
        persist();
        select(s.id);
        return s;
    }

    void updateText(String id, String text) {
        Script s = find(id);
        if (s == null) return;
        String value = text == null ? "" : text;
        if (value.equals(s.text)) return;
        s.text = value;
        s.updated = System.currentTimeMillis();
        persist();
        if (id.equals(current().id)) {
            // Compatibilidad: algunas partes antiguas leen "last_text".
            prefs.edit().putString(KEY_OLD_TEXT, value).apply();
        }
    }

    void rename(String id, String name) {
        Script s = find(id);
        if (s == null || name == null || name.trim().isEmpty()) return;
        s.name = name.trim();
        persist();
    }

    void delete(String id) {
        Script s = find(id);
        if (s == null) return;
        scripts.remove(s);
        if (scripts.isEmpty()) {
            Script empty = new Script(newId(), "Mi exposición", "");
            scripts.add(empty);
        }
        persist();
        if (id.equals(prefs.getString(KEY_CURRENT, ""))) {
            prefs.edit().putString(KEY_CURRENT, scripts.get(0).id).apply();
        }
    }

    // Estadísticas de ensayos: claves separadas para que el servicio y la pantalla
    // no se pisen al guardar.
    static void recordRehearsal(Context context, String id, long durationMs) {
        if (id == null || id.isEmpty() || durationMs < 5000L) return;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int count = p.getInt("stats_count_" + id, 0) + 1;
        p.edit()
                .putInt("stats_count_" + id, count)
                .putLong("stats_last_" + id, durationMs)
                .apply();
    }

    int rehearsals(String id) {
        return prefs.getInt("stats_count_" + id, 0);
    }

    long lastDurationMs(String id) {
        return prefs.getLong("stats_last_" + id, 0L);
    }
}
