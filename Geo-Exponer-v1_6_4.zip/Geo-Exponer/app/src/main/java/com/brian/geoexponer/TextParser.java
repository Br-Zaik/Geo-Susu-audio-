package com.brian.geoexponer;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Divide el texto de la exposición en diapositivas y frases.
 * Lo usan el modo Exponer y el modo Memorizar para que ambos lean igual.
 * Los encabezados ("Diapo 1. Portada.", "Frase final") no se leen.
 * Las palabras entre *asteriscos* se muestran resaltadas y se leen sin asteriscos.
 */
final class TextParser {
    private static final int MAX_CHUNK = 220;

    private static final Pattern SLIDE_HEADING = Pattern.compile(
            "(?i)^\\s*diapo(?:sitiva)?\\s*(\\d+)\\s*(?:[.\\-–—:]\\s*)?(.*)$"
    );
    private static final Pattern FINAL_HEADING = Pattern.compile(
            "(?i)^\\s*frase(?:\\s+final)?\\s*[.\\-–—:]?\\s*$"
    );

    static final class Section {
        final String title;
        final String number;
        final ArrayList<String> phrases = new ArrayList<>();

        Section(String title, String number) {
            this.title = title;
            this.number = number;
        }
    }

    static final class Item {
        final int slideIndex;       // 0-based
        final int slideCount;
        final String slideTitle;
        final String slideNumber;   // "3" o "" si no tiene número
        final int phraseInSlide;    // 1-based
        final int phrasesInSlide;
        final String raw;           // con *asteriscos*
        final String spoken;        // sin asteriscos

        Item(int slideIndex, int slideCount, String slideTitle, String slideNumber,
             int phraseInSlide, int phrasesInSlide, String raw) {
            this.slideIndex = slideIndex;
            this.slideCount = slideCount;
            this.slideTitle = slideTitle;
            this.slideNumber = slideNumber;
            this.phraseInSlide = phraseInSlide;
            this.phrasesInSlide = phrasesInSlide;
            this.raw = raw;
            this.spoken = clean(raw);
        }
    }

    private TextParser() {
    }

    static List<Section> parseSections(String source) {
        ArrayList<Section> parsed = new ArrayList<>();
        if (source == null) return parsed;

        String text = source.replace("\r\n", "\n").replace('\r', '\n').trim();
        if (text.isEmpty()) return parsed;

        Section current = null;
        String[] lines = text.split("\\n");
        for (String rawLine : lines) {
            String line = rawLine.replaceAll("[\\t ]+", " ").trim();
            if (line.isEmpty()) continue;

            Matcher slideMatcher = SLIDE_HEADING.matcher(line);
            if (slideMatcher.matches()) {
                String number = slideMatcher.group(1);
                String subtitle = cleanHeadingSubtitle(slideMatcher.group(2));
                String title = "Diapo " + number + (subtitle.isEmpty() ? "" : " · " + subtitle);
                current = new Section(title, number);
                parsed.add(current);
                continue;
            }

            if (FINAL_HEADING.matcher(line).matches()) {
                current = new Section("Frase final", "");
                parsed.add(current);
                continue;
            }

            if (current == null) {
                current = new Section("Todo el texto", "");
                parsed.add(current);
            }
            current.phrases.addAll(splitIntoPhrases(line));
        }

        for (int i = parsed.size() - 1; i >= 0; i--) {
            if (parsed.get(i).phrases.isEmpty()) parsed.remove(i);
        }
        return parsed;
    }

    static List<Item> flatten(List<Section> sections) {
        ArrayList<Item> items = new ArrayList<>();
        if (sections == null) return items;
        int count = sections.size();
        for (int s = 0; s < count; s++) {
            Section section = sections.get(s);
            int total = section.phrases.size();
            for (int p = 0; p < total; p++) {
                String raw = section.phrases.get(p);
                if (clean(raw).isEmpty()) continue;
                items.add(new Item(s, count, section.title, section.number, p + 1, total, raw));
            }
        }
        return items;
    }

    static List<Item> parseItems(String source) {
        return flatten(parseSections(source));
    }

    /** Quita los asteriscos de palabras clave. */
    static String clean(String raw) {
        if (raw == null) return "";
        return raw.replace("*", "").replaceAll("\\s+", " ").trim();
    }

    /** Convierte *palabra* en negrita (HTML) para mostrar en pantalla. */
    static String toHtml(String raw) {
        if (raw == null) return "";
        String escaped = raw.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        StringBuilder out = new StringBuilder();
        boolean bold = false;
        for (int i = 0; i < escaped.length(); i++) {
            char c = escaped.charAt(i);
            if (c == '*') {
                out.append(bold ? "</font></b>" : "<b><font color=\"#7BE6FF\">");
                bold = !bold;
            } else {
                out.append(c);
            }
        }
        if (bold) out.append("</font></b>");
        return out.toString();
    }

    static int wordCount(String text) {
        String t = clean(text);
        if (t.isEmpty()) return 0;
        return t.split("\\s+").length;
    }

    private static String cleanHeadingSubtitle(String subtitle) {
        if (subtitle == null) return "";
        return subtitle.trim()
                .replaceAll("^[.\\-–—:\\s]+", "")
                .replaceAll("[.\\-–—:\\s]+$", "")
                .trim();
    }

    private static List<String> splitIntoPhrases(String source) {
        ArrayList<String> result = new ArrayList<>();
        if (source == null) return result;
        String text = source.replaceAll("[\\t ]+", " ").trim();
        if (text.isEmpty()) return result;

        String[] sentenceCuts = text.split("(?<=[.!?])\\s+");
        for (String cut : sentenceCuts) {
            addReadableChunks(result, cut.trim());
        }
        if (result.isEmpty()) result.add(text);
        return result;
    }

    private static void addReadableChunks(List<String> result, String text) {
        if (text.isEmpty()) return;
        if (text.length() <= MAX_CHUNK) {
            result.add(text);
            return;
        }

        String[] pauseCuts = text.split("(?<=[,;:])\\s+");
        StringBuilder buffer = new StringBuilder();
        for (String part : pauseCuts) {
            part = part.trim();
            if (part.isEmpty()) continue;
            if (buffer.length() + part.length() + 1 <= MAX_CHUNK) {
                if (buffer.length() > 0) buffer.append(' ');
                buffer.append(part);
            } else {
                if (buffer.length() > 0) {
                    result.add(buffer.toString());
                    buffer.setLength(0);
                }
                if (part.length() <= MAX_CHUNK) {
                    buffer.append(part);
                } else {
                    addByLength(result, part);
                }
            }
        }
        if (buffer.length() > 0) result.add(buffer.toString());
    }

    private static void addByLength(List<String> result, String text) {
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + 180, text.length());
            if (end < text.length()) {
                int space = text.lastIndexOf(' ', end);
                if (space > start + 60) end = space;
            }
            String chunk = text.substring(start, end).trim();
            if (!chunk.isEmpty()) result.add(chunk);
            start = end;
        }
    }
}
