package com.brian.geoexponer;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Cuadro rápido para elegir un valor (como el menú de velocidad de un reproductor). */
final class ValuePicker {
    interface OnPick {
        void pick(int index);
    }

    private ValuePicker() {
    }

    static void show(Activity activity, String title, String[] labels, int selected, OnPick onPick) {
        if (activity == null || activity.isFinishing()) return;
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        float density = activity.getResources().getDisplayMetrics().density;
        int pad = Math.round(16 * density);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_panel);
        root.setPadding(pad, pad, pad, pad);

        TextView titleView = new TextView(activity);
        titleView.setText(title);
        titleView.setTextColor(activity.getResources().getColor(R.color.text_soft));
        titleView.setTextSize(14f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setPadding(0, 0, 0, Math.round(8 * density));
        root.addView(titleView);

        int columns = labels.length > 4 ? 2 : 1;
        LinearLayout row = null;
        for (int i = 0; i < labels.length; i++) {
            if (i % columns == 0) {
                row = new LinearLayout(activity);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            final int index = i;
            TextView item = new TextView(activity);
            boolean isSelected = i == selected;
            item.setText((isSelected ? "● " : "") + labels[i]);
            item.setTextSize(columns == 2 ? 26f : 22f);
            item.setTextColor(activity.getResources().getColor(isSelected ? R.color.primary_blue : R.color.text_main));
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, Math.round(12 * density), 0, Math.round(12 * density));
            item.setBackgroundResource(R.drawable.bg_nav_item);
            item.setOnClickListener(v -> {
                dialog.dismiss();
                onPick.pick(index);
            });
            row.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        // Completar la última fila para que las columnas queden parejas.
        if (row != null && labels.length % columns != 0) {
            row.addView(new TextView(activity), new LinearLayout.LayoutParams(0, 1, 1f));
        }

        dialog.setContentView(root);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x00000000));
            int width = Math.round(Math.min(activity.getResources().getDisplayMetrics().widthPixels * 0.86f, 420 * density));
            w.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }
}
