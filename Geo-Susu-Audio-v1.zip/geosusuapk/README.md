# Geo Susu Audio

APK base de repaso por voz.

## Qué hace
- Escucha preguntas por voz en español.
- Busca la mejor respuesta guardada en `app/src/main/assets/respuestas.json`.
- Responde con texto y voz.
- Reintenta escuchar automáticamente mientras el modo escuchar esté activo.

## Uso rápido
1. Instala la APK.
2. Abre la app.
3. Da permiso al micrófono.
4. Pulsa **Iniciar escucha**.
5. Habla o susurra la pregunta.
6. La app mostrará y leerá la respuesta.

## Archivo de respuestas
Edita `app/src/main/assets/respuestas.json`.

## Nota
Esta base usa el reconocimiento de voz del teléfono. Si el dispositivo tiene paquetes offline instalados, puede funcionar mejor sin conexión. Con internet normalmente reconoce mejor los susurros.
