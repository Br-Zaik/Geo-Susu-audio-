package com.bph.geosusuaudio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bph.geosusuaudio.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private lateinit var repository: ResponseRepository
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var keepListening = false
    private var restartRunnable: Runnable? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startListeningMode()
        } else {
            updateStatus("Permiso de micrófono denegado")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ResponseRepository(this)
        tts = TextToSpeech(this, this)

        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
        }

        setupRecognizer()
        setupUi()
        updateStatus("Estado: listo")
    }

    private fun setupUi() {
        binding.btnStart.setOnClickListener {
            if (hasAudioPermission()) {
                startListeningMode()
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        binding.btnStop.setOnClickListener {
            stopListeningMode()
        }
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Tu teléfono no tiene reconocimiento de voz disponible")
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    updateStatus("Escuchando...")
                }

                override fun onBeginningOfSpeech() {
                    updateStatus("Te escucho...")
                }

                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    updateStatus("Procesando...")
                }

                override fun onError(error: Int) {
                    updateStatus("Reintentando escuchar...")
                    if (keepListening) scheduleRestart(800)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val heard = matches?.firstOrNull().orEmpty()
                    processHeardText(heard)
                    if (keepListening) scheduleRestart(1200)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = partial?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) {
                        binding.tvHeard.text = text
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }
    }

    private fun processHeardText(heard: String) {
        val shown = heard.ifBlank { "No se entendió la pregunta." }
        binding.tvHeard.text = shown

        val answer = repository.findBestResponse(heard)
        binding.tvAnswer.text = answer
        updateStatus("Respuesta lista")
        speak(answer)
    }

    private fun startListeningMode() {
        keepListening = true
        updateStatus("Iniciando escucha...")
        binding.tvAnswer.text = "Esperando pregunta..."
        startOneShotListening()
    }

    private fun stopListeningMode() {
        keepListening = false
        restartRunnable?.let { handler.removeCallbacks(it) }
        speechRecognizer?.stopListening()
        speechRecognizer?.cancel()
        tts?.stop()
        updateStatus("Escucha detenida")
    }

    private fun startOneShotListening() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            updateStatus("No se pudo iniciar el micrófono")
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        restartRunnable?.let { handler.removeCallbacks(it) }
        restartRunnable = Runnable {
            if (keepListening) startOneShotListening()
        }
        handler.postDelayed(restartRunnable!!, delayMs)
    }

    private fun speak(text: String) {
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "geo_susu_answer")
    }

    private fun updateStatus(message: String) {
        binding.tvStatus.text = message
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "PE")) ?: TextToSpeech.ERROR
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "La voz en español no está disponible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        keepListening = false
        restartRunnable?.let { handler.removeCallbacks(it) }
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
