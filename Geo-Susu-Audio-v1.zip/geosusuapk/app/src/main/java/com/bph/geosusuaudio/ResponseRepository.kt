package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import java.text.Normalizer
import kotlin.math.max

class ResponseRepository(context: Context) {

    data class QaItem(
        val pregunta: String,
        val respuesta: String,
        val aliases: List<String>
    )

    private val items: List<QaItem> = loadItems(context)

    fun findBestResponse(input: String): String {
        val normalizedInput = normalize(input)
        if (normalizedInput.isBlank()) return DEFAULT_RESPONSE

        var bestItem: QaItem? = null
        var bestScore = 0

        for (item in items) {
            val candidates = buildList {
                add(item.pregunta)
                addAll(item.aliases)
            }

            val score = candidates.maxOf { candidate ->
                scoreMatch(normalizedInput, normalize(candidate))
            }

            if (score > bestScore) {
                bestScore = score
                bestItem = item
            }
        }

        return if (bestScore >= 45 && bestItem != null) bestItem!!.respuesta else DEFAULT_RESPONSE
    }

    private fun loadItems(context: Context): List<QaItem> {
        val json = context.assets.open("respuestas.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        val result = mutableListOf<QaItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val aliasesArray = obj.optJSONArray("aliases") ?: JSONArray()
            val aliases = mutableListOf<String>()
            for (j in 0 until aliasesArray.length()) {
                aliases.add(aliasesArray.getString(j))
            }
            result.add(
                QaItem(
                    pregunta = obj.getString("pregunta"),
                    respuesta = obj.getString("respuesta"),
                    aliases = aliases
                )
            )
        }
        return result
    }

    private fun scoreMatch(input: String, candidate: String): Int {
        if (input == candidate) return 100
        if (input.contains(candidate) || candidate.contains(input)) return 90

        val inputWords = input.split(" ").filter { it.isNotBlank() }
        val candidateWords = candidate.split(" ").filter { it.isNotBlank() }
        val intersection = inputWords.intersect(candidateWords.toSet()).size
        val overlap = if (candidateWords.isNotEmpty()) (intersection * 100) / candidateWords.size else 0

        val distanceScore = similarityPercent(input, candidate)
        return max(overlap, distanceScore)
    }

    private fun similarityPercent(a: String, b: String): Int {
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = max(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }

    companion object {
        private const val DEFAULT_RESPONSE = "No la reconocí bien. Prueba con una pregunta más corta."

        fun normalize(text: String): String {
            val cleaned = Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
                .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
                .replace("[^a-z0-9ñ ]".toRegex(), " ")
                .replace("\\s+".toRegex(), " ")
                .trim()
            return cleaned
        }
    }
}
