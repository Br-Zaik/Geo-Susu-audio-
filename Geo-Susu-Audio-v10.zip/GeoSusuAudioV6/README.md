# Geo Susu Audio v10

## Nuevas opciones
- Importar preguntas desde TXT.
- Pegar texto masivo dentro de la app.
- Abrir archivo TXT desde el celular.
- Elegir modo de respuesta:
  - Memoria + internet
  - Solo memoria / TXT
  - Solo internet
- El modo Vosk continuo también respeta el modo elegido.
- El comando de pausa/reanudar sigue configurable.

## Formato TXT
Una pregunta por línea:

pregunta | variantes | respuesta

Ejemplo:

ganga | gaga, aga, canga | La ganga es el material sin valor económico que acompaña a la mena.
mena | mema, mina, minea | La mena es el mineral del que se extrae un metal con valor económico.
prospección | prospeccion, exploración preliminar | La prospección busca zonas con posible mineralización.

## Cómo usar
1. Abre la app.
2. Pega el contenido TXT o toca Abrir TXT.
3. Toca Importar.
4. Elige modo:
   - Solo memoria si quieres usar tu TXT.
   - Memoria + internet si quieres que busque online cuando no encuentre.
   - Solo internet si quieres buscar todo online.
5. Usa Escuchar continuo Vosk.

## Recomendación para susurros
En variantes escribe todas las formas mal escuchadas.
Eso mejora mucho más que solo subir volumen.
