# Geo Susu Audio v11

## Corrección de compilación
Se corrigieron las referencias faltantes en VoskListenService:
- commandSettings
- modeSettings
- onlineProvider

## Mantiene lo pedido
- Importar TXT.
- Pegar texto masivo.
- Elegir modo:
  - Memoria + internet.
  - Solo memoria / TXT.
  - Solo internet.
- Comando configurable para pausa/reanudar.
- Vosk continuo con gramática basada en tus preguntas y variantes.

## Formato TXT
pregunta | variantes | respuesta

Ejemplo:
ganga | gaga, aga, canga | La ganga es el material sin valor económico que acompaña a la mena.
mena | mema, mina, minea | La mena es el mineral del que se extrae un metal con valor económico.
