package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

class VoskListenService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private lateinit var modelManager: VoskModelManager
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private val onlineProvider = OnlineAnswerProvider()
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    private var isReady = false
    private var isSpeaking = false
    private var pausedByGeo = false
    private var lastAnswered = ""
    private var lastAnswerTime = 0L

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Cargando escucha continua"))
        if (!isReady) startVosk()
        return START_STICKY
    }

    private fun startVosk() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "")
            stopSelf()
            return
        }

        if (!modelManager.isReady()) {
            sendUpdate("Falta descargar el modelo Vosk", "", "Pulsa Descargar modelo offline Vosk.")
            stopSelf()
            return
        }

        Thread {
            try {
                sendUpdate("Cargando modelo Vosk...", "", "")
                model = Model(modelManager.modelDir().absolutePath)
                recognizer = Recognizer(model, 16000.0f, repository.buildVoskGrammar(commandSettings.getCommandWord()))
                speechService = SpeechService(recognizer, 16000.0f)
                isReady = true
                startListeningAgain()
            } catch (e: Exception) {
                sendUpdate("Error iniciando Vosk: ${e.message ?: "sin detalle"}", "", "")
                stopSelf()
            }
        }.start()
    }

    private fun startListeningAgain() {
        if (!isReady || isSpeaking) return
        try {
            speechService?.startListening(this)
            sendUpdate("Listo para otra pregunta. Susurra cerca del Zync.", "", "Escuchando continuo...")
        } catch (e: Exception) {
            sendUpdate("Reintentando escucha: ${e.message ?: "sin detalle"}", "", "")
            handler.postDelayed({ startListeningAgain() }, 1200)
        }
    }

    override fun onPartialResult(hypothesis: String?) {
        if (isSpeaking) return
        val text = extractText(hypothesis)
        if (text.isNotBlank()) sendUpdate("Escuchando...", text, "")
    }

    override fun onResult(hypothesis: String?) {
        if (isSpeaking) return
        val text = extractText(hypothesis)
        if (text.isNotBlank()) processText(text)
    }

    override fun onFinalResult(hypothesis: String?) {
        if (isSpeaking) return
        val text = extractText(hypothesis)
        if (text.isNotBlank()) processText(text)
    }

    override fun onError(exception: Exception?) {
        if (isSpeaking) return
        sendUpdate("Error de Vosk. Reiniciando escucha", "", "")
        handler.postDelayed({ startListeningAgain() }, 1000)
    }

    override fun onTimeout() {
        if (!isSpeaking) {
            sendUpdate("Esperando pregunta...", "", "")
            handler.postDelayed({ startListeningAgain() }, 700)
        }
    }

    private fun processText(rawText: String) {
        val cleanRaw = ResponseRepository.normalize(rawText)
        val question = normalizeQuestion(rawText)

        if (isGeoToggle(cleanRaw, question)) {
            toggleGeoPause()
            return
        }

        if (pausedByGeo) {
            sendUpdate("Pausado. Di ${commandSettings.getCommandWord()} para reanudar.", rawText, "Modo pausa activo.")
            return
        }

        if (question.length < 3) return

        val now = System.currentTimeMillis()
        if (question == lastAnswered && now - lastAnswerTime < 6500) return

        lastAnswered = question
        lastAnswerTime = now

        val mode = modeSettings.getMode()
        val match = repository.findBest(question)

        when (mode) {
            AnswerModeSettings.Mode.LOCAL -> {
                memory.saveLast(question, match.answer, match.itemId, match.score)
                sendUpdate("Memoria local. Score ${match.score}%. Luego se reinicia.", question, match.answer)
                pauseListenAndSpeak(match.answer)
            }

            AnswerModeSettings.Mode.INTERNET -> {
                answerOnline(question)
            }

            AnswerModeSettings.Mode.HYBRID -> {
                if (match.score >= 48) {
                    memory.saveLast(question, match.answer, match.itemId, match.score)
                    sendUpdate("Memoria local. Score ${match.score}%. Luego se reinicia.", question, match.answer)
                    pauseListenAndSpeak(match.answer)
                } else {
                    answerOnline(question)
                }
            }
        }
    }

    private fun answerOnline(question: String) {
        sendUpdate("Buscando online. Luego se reinicia.", question, "Buscando respuesta simple...")
        isSpeaking = true
        try {
            speechService?.stop()
        } catch (_: Exception) {
        }

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré respuesta online. Guarda esa pregunta en memoria o TXT."
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                sendUpdate("Respuesta online. Luego se reinicia.", question, answer)
                tts?.stop()
                tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
            }
        }.start()
    }

    private fun isGeoToggle(cleanRaw: String, question: String): Boolean {
        return commandSettings.isToggleCommand(cleanRaw) || commandSettings.isToggleCommand(question)
    }

    private fun toggleGeoPause() {
        val command = commandSettings.getCommandWord()
        pausedByGeo = !pausedByGeo
        if (pausedByGeo) {
            sendUpdate("Pausado por voz. Di $command para reanudar.", command, "Pausa activa.")
            speakOnly("Pausado.")
        } else {
            sendUpdate("Reanudado. Listo para preguntar.", command, "Escuchando continuo...")
            speakOnly("Reanudado.")
        }
    }

    private fun speakOnly(text: String) {
        isSpeaking = true
        try {
            speechService?.stop()
        } catch (_: Exception) {
        }

        handler.postDelayed({
            tts?.stop()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
        }, 200)
    }

    private fun pauseListenAndSpeak(answer: String) {
        speakOnly(answer)
    }

    private fun normalizeQuestion(text: String): String {
        var q = ResponseRepository.normalize(text)
        val wakeWords = listOf("geo susu", "geosusu", "geo", "pregunta", "oye geo", "dime")
        for (word in wakeWords) {
            if (q.startsWith("$word ")) q = q.removePrefix("$word ").trim()
        }
        return q
    }

    private fun extractText(json: String?): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val obj = JSONObject(json)
            obj.optString("text").ifBlank { obj.optString("partial") }
        } catch (_: Exception) {
            ""
        }
    }

    private fun sendUpdate(status: String, heard: String, answer: String) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
        }
        sendBroadcast(intent)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu Vosk", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Audio Vosk")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::VoskWakeLock").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(1.05f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            if (pausedByGeo) {
                                sendUpdate("Pausado. Di ${commandSettings.getCommandWord()} para reanudar.", "", "Modo pausa activo.")
                            } else {
                                sendUpdate("Respuesta terminada. Listo para otra pregunta.", "", "Escuchando continuo...")
                            }
                            startListeningAgain()
                        }, 900)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    handler.postDelayed({ startListeningAgain() }, 900)
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isReady = false
        isSpeaking = false
        speechService?.stop()
        speechService?.shutdown()
        recognizer?.close()
        model?.close()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.VOSK_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        private const val CHANNEL_ID = "geo_susu_vosk_channel"
        private const val NOTIFICATION_ID = 2001
        private const val UTTERANCE_ID = "geo_susu_vosk_answer"
    }
}
