# Geo Susu Audio v12

## Cambios fuertes
- Interfaz compacta: ya no necesitas deslizar para lo principal.
- Medidor de voz tipo grabación: muestra si hablas muy bajo, correcto o muy fuerte.
- Vosk ahora usa AudioRecord directo para escuchar continuo.
- Después de cada respuesta reinicia el reconocedor para evitar repetir respuestas antiguas.
- Botón TXT visible para abrir archivo.
- Botón Pegar para importar texto masivo.
- Modos visibles:
  - Mixto: memoria + internet
  - TXT: solo memoria / texto cargado
  - Net: solo internet
- Respuestas online más cortas y con formato de definición.
- Protección para preguntas demasiado cortas como "q".

## Formato TXT
pregunta | variantes | respuesta

Ejemplo:
ganga | gaga, aga, canga | La ganga es el material sin valor económico que acompaña a la mena.
mena | mema, mina, minea | La mena es el mineral del que se extrae un metal con valor económico.

## Recomendación
Primero prueba el medidor de voz. Si marca menos de 15%, el susurro está demasiado bajo.
