# Geo Susu Audio v13

## Correcciones
- Botón Google ahora fuerza internet. Ya no usa memoria local cuando presionas Google.
- Vosk continuo ya no debe responderse a sí mismo:
  - detiene grabación mientras habla,
  - guarda la última respuesta,
  - ignora eco de su propia voz,
  - reinicia el reconocedor antes de volver a escuchar.
- Se mantiene el medidor de voz.
- Protección para preguntas muy cortas.

## Uso recomendado
1. Pulsa VOSK ON.
2. Haz una pregunta corta.
3. Espera que termine la respuesta.
4. Cuando diga/lista "Listo para otra pregunta", pregunta otra.
5. Para buscar directo en internet, usa el botón Google.

## Nota
Si usas altavoz del celular, puede captar eco. Mejor usa audífonos Bluetooth.
