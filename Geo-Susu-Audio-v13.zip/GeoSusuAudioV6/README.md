# Geo Susu Audio v13

## Corrección
Se agregó la constante faltante EXTRA_START_GOOGLE para evitar el error de compilación en VoskListenService.

## Mantiene
- Interfaz compacta.
- Medidor de voz.
- TXT / Pegar texto.
- Modo Mixto, TXT y Net.
- Vosk continuo.
- Reinicio del reconocedor después de cada respuesta.
