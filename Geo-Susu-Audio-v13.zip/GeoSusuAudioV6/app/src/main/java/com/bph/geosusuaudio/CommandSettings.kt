package com.bph.geosusuaudio

import android.content.Context

class CommandSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)

    fun getCommandWord(): String {
        val saved = prefs.getString(KEY_COMMAND, "geo") ?: "geo"
        return ResponseRepository.normalize(saved).ifBlank { "geo" }
    }

    fun saveCommandWord(word: String): String {
        val clean = ResponseRepository.normalize(word).ifBlank { "geo" }
        prefs.edit().putString(KEY_COMMAND, clean).apply()
        return clean
    }

    fun isToggleCommand(raw: String): Boolean {
        val clean = ResponseRepository.normalize(raw)
        if (clean.isBlank()) return false

        val command = getCommandWord()
        val words = clean.split(" ").filter { it.isNotBlank() }

        if (clean == command) return true
        if (words.size == 1 && areSimilar(words.first(), command)) return true

        // Compatibilidad si el usuario mantiene el comando por defecto.
        if (command == "geo") {
            val geoLike = setOf("geo", "jeo", "gio", "geos", "eo")
            if (clean in geoLike) return true
            if (words.size == 1 && words.first() in geoLike) return true
        }

        return false
    }

    private fun areSimilar(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 3 || b.length < 3) return false
        val distance = levenshtein(a, b)
        val maxLen = maxOf(a.length, b.length)
        val score = ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt()
        return score >= 78
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }

    companion object {
        private const val KEY_COMMAND = "pause_command_word"
    }
}
