package com.bph.geosusuaudio

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class VoskModelManager(private val context: Context) {

    private val modelName = "vosk-model-small-es-0.42"
    private val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"

    fun modelDir(): File = File(context.filesDir, modelName)

    fun isReady(): Boolean {
        val dir = modelDir()
        return dir.exists() && File(dir, "am").exists() && File(dir, "conf").exists()
    }

    fun downloadAndUnzip(onProgress: (String) -> Unit, onDone: (Boolean, String) -> Unit) {
        Thread {
            try {
                onProgress("Descargando modelo español offline. Pesa aprox. 39 MB...")
                val zipFile = File(context.cacheDir, "$modelName.zip")
                download(zipFile, onProgress)

                onProgress("Descomprimiendo modelo...")
                unzip(zipFile, context.filesDir)

                zipFile.delete()

                if (isReady()) {
                    onDone(true, "Modelo Vosk listo. Ya puedes usar escucha continua.")
                } else {
                    onDone(false, "Modelo descargado, pero no quedó completo.")
                }
            } catch (e: Exception) {
                onDone(false, "Error descargando modelo: ${e.message ?: "sin detalle"}")
            }
        }.start()
    }

    private fun download(target: File, onProgress: (String) -> Unit) {
        val connection = URL(modelUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "GeoSusuAudio/1.0")
        val total = connection.contentLengthLong.takeIf { it > 0 } ?: 1L
        var downloaded = 0L

        connection.inputStream.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var read: Int
                var lastPercent = -1
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    downloaded += read
                    val percent = ((downloaded * 100) / total).toInt()
                    if (percent != lastPercent && percent % 5 == 0) {
                        lastPercent = percent
                        onProgress("Descargando modelo: $percent%")
                    }
                }
            }
        }
    }

    private fun unzip(zipFile: File, outputDir: File) {
        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val outFile = File(outputDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { output ->
                        zip.copyTo(output)
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }
}
