package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class WhisperListenService : Service(), TextToSpeech.OnInitListener {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var keepListening = false
    private var restartRunnable: Runnable? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        tts = TextToSpeech(this, this)
        createChannel()
        setupIntent()
        setupRecognizer()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Escuchando en segundo plano"))
        keepListening = true
        sendUpdate("Servicio activo. ${memory.getSummary()}", "", "Esperando pregunta...")
        scheduleRestart(350)
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        keepListening = false
        restartRunnable?.let { handler.removeCallbacks(it) }
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun setupIntent() {
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 700L)
        }
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendUpdate("No hay reconocimiento de voz. Activa Google Speech Services.", "", "")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    sendUpdate("Escuchando...", "", "Habla o susurra cerca del Zync")
                }

                override fun onBeginningOfSpeech() {
                    sendUpdate("Te escucho...", "", "")
                }

                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    sendUpdate("Procesando...", "", "")
                }

                override fun onError(error: Int) {
                    val msg = errorMessage(error)
                    sendUpdate(msg, msg, "")
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        setupRecognizer()
                    }
                    if (keepListening) scheduleRestart(1100)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val heard = matches?.firstOrNull().orEmpty()
                    val match = repository.findBest(heard)
                    memory.saveLast(heard, match.answer, match.itemId, match.score)
                    sendUpdate("Respuesta lista. Score ${match.score}%. ${memory.getSummary()}", heard, match.answer)
                    speak(match.answer)
                    if (keepListening) scheduleRestart(1400)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = partial?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) sendUpdate("Escuchando...", text, "")
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "")
            return
        }

        try {
            recognizer?.cancel()
            handler.postDelayed({
                try {
                    recognizer?.startListening(recognizerIntent)
                } catch (_: Exception) {
                    sendUpdate("No se pudo iniciar escucha. Reintentando", "", "")
                    if (keepListening) scheduleRestart(1200)
                }
            }, 150)
        } catch (_: Exception) {
            sendUpdate("Error preparando micrófono. Reintentando", "", "")
            if (keepListening) scheduleRestart(1200)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        restartRunnable?.let { handler.removeCallbacks(it) }
        restartRunnable = Runnable {
            if (keepListening) startListening()
        }
        handler.postDelayed(restartRunnable!!, delayMs)
    }

    private fun speak(text: String) {
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "geo_susu_answer")
    }

    private fun sendUpdate(status: String, heard: String, answer: String) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
        }
        sendBroadcast(intent)
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Audio",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Audio activo")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::WakeLock").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Micrófono ocupado o error de audio"
        SpeechRecognizer.ERROR_CLIENT -> "Error del servicio de voz. Reintentando"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso de micrófono"
        SpeechRecognizer.ERROR_NETWORK -> "Error de red"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Tiempo agotado de red"
        SpeechRecognizer.ERROR_NO_MATCH -> "No reconocí la voz. Acerca el micrófono"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Reconocedor ocupado. Reintentando"
        SpeechRecognizer.ERROR_SERVER -> "Error del servidor de voz"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No escuché voz"
        else -> "Error de voz: $error"
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(1.08f)
        }
    }

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        private const val CHANNEL_ID = "geo_susu_audio_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
