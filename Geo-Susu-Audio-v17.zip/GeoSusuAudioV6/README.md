# Geo Susu Audio v17

## Cambio principal
Se quitó la carga manual pregunta por pregunta.

## Ahora se usan 2 TXT
1. TXT P/R: preguntas y respuestas.
2. TXT VAR: variantes de pronunciación.

## Formato TXT P/R
pregunta | respuesta

Ejemplo:
mineral oxidado | Mineral que sufrió cambios por el intemperismo y la acción del oxígeno.
mena | Mineral del que se puede extraer un metal con valor económico.

## Formato TXT VAR
pregunta | variante1, variante2, variante3

Ejemplo:
mineral oxidado | oxidado, mineral oxidao, meniral oxidado
mena | mema, mina, minea

## Uso
1. Toca TXT P/R y carga el archivo de preguntas y respuestas.
2. Toca TXT VAR y carga el archivo de variantes.
3. Usa modo TXT si quieres solo tus respuestas.
4. Usa Mixto si quieres tus respuestas y, si no encuentra, internet.
5. Usa Net si quieres solo internet.
