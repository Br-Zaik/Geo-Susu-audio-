package com.bph.geosusuaudio

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class OnlineAnswerProvider {

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val duckApi = fetchDuckDuckGoApi(query)
        if (isRelevant(query, duckApi)) return shorten(duckApi)

        val duckHtml = fetchDuckDuckGoHtmlSnippet(query)
        if (isRelevant(query, duckHtml)) return shorten(duckHtml)

        val wiki = fetchWikipediaBestSummary(query)
        if (isRelevant(query, wiki)) return shorten(wiki)

        return "No encontré una respuesta clara. Prueba con otra frase o carga esa respuesta en TXT."
    }

    private fun fetchDuckDuckGoApi(query: String): String {
        return try {
            val url = "https://api.duckduckgo.com/?q=" +
                URLEncoder.encode(query, "UTF-8") +
                "&format=json&no_html=1&skip_disambig=1&kl=es-es"
            val json = get(url)
            val root = JSONObject(json)
            val answer = root.optString("Answer", "")
            val abstractText = root.optString("AbstractText", "")
            when {
                answer.isNotBlank() -> answer
                abstractText.isNotBlank() -> abstractText
                else -> ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    private fun fetchDuckDuckGoHtmlSnippet(query: String): String {
        return try {
            val url = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(query, "UTF-8")
            val html = get(url)
            val snippetRegex = Regex(
                "<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>|<div[^>]*class=\"result__snippet\"[^>]*>(.*?)</div>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            val match = snippetRegex.find(html) ?: return ""
            val raw = match.groupValues.firstOrNull { it.isNotBlank() && !it.startsWith("<") }.orEmpty()
                .ifBlank { match.groupValues.drop(1).firstOrNull { it.isNotBlank() }.orEmpty() }
            htmlToText(raw)
        } catch (_: Exception) {
            ""
        }
    }

    private fun fetchWikipediaBestSummary(query: String): String {
        return try {
            val title = searchWikipediaTitle(query)
            if (title.isBlank()) return ""
            fetchWikipediaSummary(title)
        } catch (_: Exception) {
            ""
        }
    }

    private fun searchWikipediaTitle(query: String): String {
        val url = "https://es.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=3&srsearch=" +
            URLEncoder.encode(query, "UTF-8")
        val json = get(url)
        val root = JSONObject(json)
        val search = root.getJSONObject("query").getJSONArray("search")

        for (i in 0 until search.length()) {
            val obj = search.getJSONObject(i)
            val title = obj.getString("title")
            val snippet = htmlToText(obj.optString("snippet", ""))
            val combined = "$title $snippet"
            if (isRelevant(query, combined)) return title
        }

        return if (search.length() > 0) search.getJSONObject(0).getString("title") else ""
    }

    private fun fetchWikipediaSummary(title: String): String {
        val url = "https://es.wikipedia.org/api/rest_v1/page/summary/" +
            URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val json = get(url)
        val root = JSONObject(json)
        return root.optString("extract", "")
    }

    private fun isRelevant(query: String, answer: String): Boolean {
        if (answer.isBlank()) return false

        val qWords = keyWords(query)
        if (qWords.isEmpty()) return answer.length >= 20

        val a = ResponseRepository.normalize(answer)
        val matched = qWords.count { word -> a.contains(word) || qWords.any { similarity(word, it) >= 90 } }

        if (qWords.size == 1) return matched >= 1
        return matched >= minOf(2, qWords.size)
    }

    private fun keyWords(text: String): List<String> {
        val stop = setOf(
            "que", "es", "un", "una", "el", "la", "los", "las", "de", "del", "en",
            "por", "para", "como", "cual", "cuales", "dime", "google", "internet"
        )
        return ResponseRepository.normalize(text)
            .split(" ")
            .map { it.trim() }
            .filter { it.length >= 4 && it !in stop }
            .distinct()
    }

    private fun similarity(a: String, b: String): Int {
        if (a == b) return 100
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = maxOf(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }

    private fun get(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 9000
        connection.readTimeout = 9000
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 GeoSusuAudio/2.4 Android")
        return connection.inputStream.bufferedReader().use { it.readText() }
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
        val prefixes = listOf(
            "que es ",
            "que significa ",
            "dime que es ",
            "definicion de ",
            "definicion del ",
            "definicion de la ",
            "concepto de ",
            "concepto del ",
            "concepto de la ",
            "buscar ",
            "busca ",
            "google ",
            "en internet ",
            "simbolo quimico de ",
            "simbolo quimico del ",
            "simbolo quimico de la "
        )
        for (prefix in prefixes) {
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }
        return q
    }

    private fun shorten(text: String): String {
        val clean = htmlToText(text).replace("\\s+".toRegex(), " ").trim()
        val firstSentence = clean.split(". ").firstOrNull()?.trim().orEmpty()
        val candidate = if (firstSentence.length >= 25) firstSentence else clean
        return if (candidate.length > 210) candidate.take(210).trim() + "..." else candidate
    }

    private fun htmlToText(raw: String): String {
        return raw
            .replace("<[^>]+>".toRegex(), " ")
            .replace("&quot;", "\"")
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }
}
