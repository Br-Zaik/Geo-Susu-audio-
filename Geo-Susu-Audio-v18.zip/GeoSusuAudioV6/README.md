# Geo Susu Audio v18

## Correcciones principales
- G. ON fuerza internet y no usa memoria local.
- La palabra comando, por ejemplo "geo", ya no se busca en internet.
- Se mejoró la búsqueda online en español: primero Wikipedia en español, luego DuckDuckGo.
- Para palabras como "calcopirita", la app busca coincidencia exacta o muy cercana y evita confundir con "calcita".
- El modo por defecto ahora es TXT para evitar respuestas raras de Mixto.
- Se mejoró el filtro local para no confundir palabras parecidas.

## TXT
Cada botón TXT abre un menú:
- Crear TXT en blanco.
- Importar TXT existente.

## TXT P/R
Formato:
pregunta | respuesta

Ejemplo:
mineral oxidado | Mineral que sufrió cambios por el intemperismo y la acción del oxígeno.

## TXT VAR
Formato:
pregunta | variante1, variante2, variante3

Ejemplo:
mineral oxidado | oxidado, mineral oxidao, meniral oxidado

## Uso recomendado
- Para estudiar: modo TXT.
- Para internet: botón G. ON o modo Net.
- Para evitar errores: primero carga TXT P/R y luego TXT VAR.
