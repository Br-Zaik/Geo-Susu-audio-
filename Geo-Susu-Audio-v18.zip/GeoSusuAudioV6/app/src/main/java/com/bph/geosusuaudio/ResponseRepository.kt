package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import kotlin.math.max

class ResponseRepository(private val context: Context) {

    data class QaItem(
        val id: String,
        val tema: String,
        val pregunta: String,
        val respuesta: String,
        val aliases: List<String>
    )

    data class MatchResult(
        val answer: String,
        val itemId: String,
        val score: Int
    )

    private val items: List<QaItem> = loadItems(context)
    val totalItems: Int get() = items.size

    fun findBest(input: String): MatchResult {
        val normalizedInput = normalize(applyCommonCorrections(input))
        if (normalizedInput.isBlank()) return MatchResult(DEFAULT_RESPONSE, "none", 0)

        val inputCore = coreWords(normalizedInput)
        var bestItem: QaItem? = null
        var bestScore = 0

        for (item in items) {
            val candidates = buildList {
                add(item.id)
                add(item.pregunta)
                addAll(item.aliases)
            }.map { normalize(applyCommonCorrections(it)) }
                .filter { it.length >= 2 }
                .distinct()

            if (candidates.any { it == normalizedInput }) {
                return MatchResult(item.respuesta, item.id, 100)
            }

            val score = candidates.maxOfOrNull { candidate ->
                scoreCandidate(normalizedInput, inputCore, candidate)
            } ?: 0

            if (score > bestScore) {
                bestScore = score
                bestItem = item
            }
        }

        return if (bestScore >= 60 && bestItem != null) {
            MatchResult(bestItem!!.respuesta, bestItem!!.id, bestScore)
        } else {
            MatchResult(DEFAULT_RESPONSE, "none", bestScore)
        }
    }

    fun findBestResponse(input: String): String = findBest(input).answer

    fun buildVoskGrammar(commandWord: String): String {
        val phrases = linkedSetOf<String>()
        val cleanCommand = normalize(commandWord).ifBlank { "geo" }

        phrases.add(cleanCommand)
        if (cleanCommand == "geo") {
            phrases.add("jeo")
            phrases.add("gio")
            phrases.add("eo")
        }

        for (item in items) {
            phrases.add(normalize(item.id))
            phrases.add(normalize(item.pregunta))
            item.aliases.forEach { alias -> phrases.add(normalize(alias)) }

            val main = coreWords(normalize(item.pregunta)).joinToString(" ")
            if (main.isNotBlank()) phrases.add(main)
        }

        phrases.add("[unk]")

        val array = JSONArray()
        phrases.filter { it.isNotBlank() }.take(450).forEach { array.put(it) }
        return array.toString()
    }

    private fun loadItems(context: Context): List<QaItem> {
        val result = mutableListOf<QaItem>()
        result.addAll(readArray(context.assets.open("respuestas.json").bufferedReader().use { it.readText() }))
        result.addAll(readArray(getCustomJson(context)))
        return result
    }

    private fun readArray(json: String): List<QaItem> {
        val array = JSONArray(json)
        val result = mutableListOf<QaItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val aliasesArray = obj.optJSONArray("aliases") ?: JSONArray()
            val aliases = mutableListOf<String>()
            for (j in 0 until aliasesArray.length()) {
                aliases.add(aliasesArray.getString(j))
            }
            result.add(
                QaItem(
                    id = obj.optString("id", obj.optString("pregunta", "item_$i")),
                    tema = obj.optString("tema", ""),
                    pregunta = obj.getString("pregunta"),
                    respuesta = obj.getString("respuesta"),
                    aliases = aliases
                )
            )
        }
        return result
    }

    private fun scoreCandidate(input: String, inputCore: List<String>, candidate: String): Int {
        val candidateCore = coreWords(candidate)

        if (input == candidate) return 100
        if (candidateCore.isNotEmpty() && inputCore == candidateCore) return 98

        // Si la pregunta escuchada es una sola palabra, evita confundir nombres parecidos:
        // calcopirita no debe responder calcita.
        if (inputCore.size == 1) {
            val inputWord = inputCore.first()
            if (candidateCore.contains(inputWord)) return 100

            val best = candidateCore.maxOfOrNull { similarityPercent(inputWord, it) } ?: 0
            return if (best >= 88) best else 0
        }

        // Si el candidato es demasiado genérico, no lo uses para preguntas largas.
        if (candidateCore.size == 1 && inputCore.size > 1) {
            val word = candidateCore.first()
            return if (inputCore.contains(word) && word.length >= 6) 45 else 0
        }

        if (candidateCore.isNotEmpty() && inputCore.isNotEmpty()) {
            val intersection = inputCore.intersect(candidateCore.toSet()).size
            val overlap = (intersection * 100) / max(inputCore.size, candidateCore.size)

            val bestWordSimilarity = candidateCore.maxOfOrNull { cw ->
                inputCore.maxOfOrNull { iw -> similarityPercent(iw, cw) } ?: 0
            } ?: 0

            return max(overlap, if (bestWordSimilarity >= 88) bestWordSimilarity else 0)
        }

        return similarityPercent(input, candidate)
    }

    private fun coreWords(text: String): List<String> {
        val stop = setOf(
            "que", "es", "el", "la", "los", "las", "un", "una", "de", "del",
            "en", "por", "para", "dime", "define", "concepto", "significa",
            "significado", "simbolo", "quimico", "quimica"
        )
        return text.split(" ")
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stop }
    }

    private fun similarityPercent(a: String, b: String): Int {
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = max(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }

    private fun applyCommonCorrections(text: String): String {
        var output = normalize(text)
        val corrections = mapOf(
            "gaga" to "ganga",
            "aga" to "ganga",
            "canga" to "ganga",
            "mema" to "mena",
            "me na" to "mena",
            "mina" to "mena",
            "minea" to "mena",
            "kateo" to "cateo",
            "cateu" to "cateo",
            "cuota de geologo" to "picota de geologo",
            "picota de solomo" to "picota de geologo",
            "tipos de loca" to "tipos de roca",
            "loca" to "roca",
            "prospeccion" to "prospeccion",
            "prospeccion" to "prospeccion"
        )
        for ((bad, good) in corrections) {
            output = output.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }
        return output
    }

    companion object {
        private const val DEFAULT_RESPONSE = "No la reconocí bien. Repite solo la palabra clave."
        private const val PREFS = "geo_susu_memory"
        private const val CUSTOM_ITEMS = "custom_items"

        fun saveCustomItem(context: Context, pregunta: String, aliasesRaw: String, respuesta: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            val index = findIndex(array, pregunta)

            val aliases = JSONArray()
            pregunta.split(" ").filter { it.isNotBlank() }.forEach { aliases.put(it) }
            aliasesRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { aliases.put(it) }

            val item = if (index >= 0) array.getJSONObject(index) else JSONObject()
                .put("id", "custom_${System.currentTimeMillis()}")
                .put("tema", "Personalizado")
                .put("pregunta", pregunta)

            item.put("respuesta", respuesta)
            item.put("aliases", aliases)

            if (index < 0) array.put(item)
            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return array.length()
        }

        fun importQuestionsAnswers(context: Context, raw: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            var imported = 0

            raw.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val parts = line.split("|").map { it.trim() }
                    if (parts.size >= 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                        val pregunta = parts[0]
                        val respuesta = parts.subList(1, parts.size).joinToString(" | ").trim()
                        val index = findIndex(array, pregunta)

                        val item = if (index >= 0) array.getJSONObject(index) else JSONObject()
                            .put("id", "qa_${System.currentTimeMillis()}_$imported")
                            .put("tema", "TXT")
                            .put("pregunta", pregunta)
                            .put("aliases", JSONArray())

                        item.put("respuesta", respuesta)

                        val aliases = mergeAliases(
                            item.optJSONArray("aliases") ?: JSONArray(),
                            pregunta.split(" ")
                        )
                        item.put("aliases", aliases)

                        if (index < 0) array.put(item)
                        imported++
                    }
                }

            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return imported
        }

        fun importVariants(context: Context, raw: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            var imported = 0

            raw.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val parts = line.split("|").map { it.trim() }
                    if (parts.size >= 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                        val pregunta = parts[0]
                        val variantsRaw = parts.subList(1, parts.size).joinToString(",")
                        val variants = variantsRaw
                            .split(",", ";")
                            .map { it.trim() }
                            .filter { it.isNotBlank() }

                        val index = findIndex(array, pregunta)
                        if (index >= 0) {
                            val item = array.getJSONObject(index)
                            val aliases = mergeAliases(
                                item.optJSONArray("aliases") ?: JSONArray(),
                                pregunta.split(" ") + variants
                            )
                            item.put("aliases", aliases)
                            imported++
                        }
                    }
                }

            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return imported
        }

        fun importBulkText(context: Context, raw: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            var imported = 0

            raw.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val parts = line.split("|").map { it.trim() }
                    if (parts.size >= 3 && parts[0].isNotBlank() && parts[2].isNotBlank()) {
                        val pregunta = parts[0]
                        val respuesta = parts.subList(2, parts.size).joinToString(" | ")
                        val index = findIndex(array, pregunta)

                        val item = if (index >= 0) array.getJSONObject(index) else JSONObject()
                            .put("id", "txt_${System.currentTimeMillis()}_$imported")
                            .put("tema", "TXT")
                            .put("pregunta", pregunta)

                        item.put("respuesta", respuesta)
                        item.put(
                            "aliases",
                            mergeAliases(
                                item.optJSONArray("aliases") ?: JSONArray(),
                                pregunta.split(" ") + parts[1].split(",")
                            )
                        )

                        if (index < 0) array.put(item)
                        imported++
                    }
                }

            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return imported
        }

        fun getCustomJson(context: Context): String {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(CUSTOM_ITEMS, "[]") ?: "[]"
        }

        fun normalize(text: String): String {
            return Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
                .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
                .replace("[^a-z0-9ñ ]".toRegex(), " ")
                .replace("\\s+".toRegex(), " ")
                .trim()
        }

        private fun findIndex(array: JSONArray, pregunta: String): Int {
            val target = normalize(pregunta)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                if (normalize(item.optString("pregunta")) == target) return i
            }
            return -1
        }

        private fun mergeAliases(current: JSONArray, values: List<String>): JSONArray {
            val set = linkedSetOf<String>()

            for (i in 0 until current.length()) {
                val value = current.optString(i).trim()
                if (value.isNotBlank()) set.add(value)
            }

            values
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .forEach { set.add(it) }

            val out = JSONArray()
            set.forEach { out.put(it) }
            return out
        }
    }
}
