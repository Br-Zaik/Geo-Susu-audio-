# Geo Susu Audio v19

## Cambio principal
Los TXT ahora se editan dentro de la APK. Ya no tienes que ir a buscar el archivo para escribir.

## Botones
- TXT P/R: abre un editor dentro de la app para escribir preguntas y respuestas.
- TXT VAR: abre un editor dentro de la app para escribir variantes.

## Formato TXT P/R
pregunta | respuesta

Ejemplo:
epp | Equipo de Protección Personal usado para proteger al trabajador.
iperc | Identificación de Peligros, Evaluación de Riesgos y Controles.

## Formato TXT VAR
pregunta | variante1, variante2, variante3

Ejemplo:
epp | equipo de proteccion personal, e p p, epi
iperc | i perc, hiper, iper

## Notas
- Al guardar dentro de la app, se carga automáticamente.
- El modo se reinicia a TXT una vez para evitar que siga en Internet por configuración antigua.
- Siguen quedando plantillas dentro del ZIP por si quieres editarlas desde PC.
