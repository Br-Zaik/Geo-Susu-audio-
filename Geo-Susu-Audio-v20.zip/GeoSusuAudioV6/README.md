# Geo Susu Audio v20

## Corrección de compilación
Se quitó el manejo externo de crear/abrir TXT con archivos del sistema y se dejó solo el editor interno dentro de la APK.

## Uso
- TXT P/R: abre un cuadro dentro de la app para escribir preguntas y respuestas.
- TXT VAR: abre un cuadro dentro de la app para escribir variantes.
- Toca Guardar y cargar.

## Formato TXT P/R
pregunta | respuesta

Ejemplo:
epp | Equipo de Protección Personal usado para proteger al trabajador.

## Formato TXT VAR
pregunta | variante1, variante2

Ejemplo:
epp | equipo de proteccion personal, e p p, epi
