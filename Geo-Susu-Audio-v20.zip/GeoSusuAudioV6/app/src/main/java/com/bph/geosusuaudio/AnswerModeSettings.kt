package com.bph.geosusuaudio

import android.content.Context

class AnswerModeSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)

    enum class Mode {
        LOCAL,
        INTERNET,
        HYBRID
    }

    fun getMode(): Mode {
        return when (prefs.getString(KEY_MODE, Mode.LOCAL.name)) {
            Mode.LOCAL.name -> Mode.LOCAL
            Mode.INTERNET.name -> Mode.INTERNET
            else -> Mode.HYBRID
        }
    }

    fun setMode(mode: Mode) {
        prefs.edit().putString(KEY_MODE, mode.name).apply()
    }

    fun getLabel(): String {
        return when (getMode()) {
            Mode.LOCAL -> "TXT"
            Mode.INTERNET -> "Internet"
            Mode.HYBRID -> "Mixto"
        }
    }

    companion object {
        private const val KEY_MODE = "answer_mode"
    }
}
