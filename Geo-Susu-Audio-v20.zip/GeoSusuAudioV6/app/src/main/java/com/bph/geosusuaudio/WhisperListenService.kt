package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class WhisperListenService : Service(), TextToSpeech.OnInitListener {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var commandSettings: CommandSettings
    private val onlineProvider = OnlineAnswerProvider()

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var keepListening = false
    private var restartRunnable: Runnable? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var isSpeaking = false
    private var lastSpokenNormalized = ""
    private var ignoreUntil = 0L
    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var forceInternet = false

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modeSettings = AnswerModeSettings(this)
        commandSettings = CommandSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        setupIntent()
        setupRecognizer()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        forceInternet = intent?.getBooleanExtra(EXTRA_FORCE_INTERNET, false) ?: false
        startForeground(NOTIFICATION_ID, buildNotification("Google continuo activo"))
        keepListening = true
        sendUpdate("Google continuo activo", "", "", 0)
        scheduleRestart(450)
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        keepListening = false
        restartRunnable?.let { handler.removeCallbacks(it) }
        recognizer?.cancel()
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun setupIntent() {
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 600L)
        }
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendUpdate("No hay Google Speech activo", "", "Activa Speech Services by Google.", 0)
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    sendUpdate("Escuchando con Google...", "", "", -1)
                }

                override fun onBeginningOfSpeech() {
                    sendUpdate("Te escucho...", "", "", -1)
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
                    sendUpdate("", "", "", level)
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    sendUpdate("Procesando...", "", "", -1)
                }

                override fun onError(error: Int) {
                    if (!keepListening || isSpeaking) return
                    val msg = errorMessage(error)
                    sendUpdate(msg, "", "", -1)
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        setupRecognizer()
                    }
                    scheduleRestart(900)
                }

                override fun onResults(results: Bundle?) {
                    if (!keepListening || isSpeaking) return

                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val heard = matches?.firstOrNull().orEmpty().trim()

                    if (heard.isBlank()) {
                        scheduleRestart(700)
                        return
                    }

                    processQuestion(heard)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    if (isSpeaking) return
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = partial?.firstOrNull().orEmpty().trim()
                    if (text.isNotBlank()) sendUpdate("Escuchando...", text, "", -1)
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }
    }

    private fun processQuestion(raw: String) {
        val question = raw.trim()
        val normalized = ResponseRepository.normalize(question)

        if (normalized.length < 2) {
            sendUpdate("Pregunta muy corta", question, "", -1)
            scheduleRestart(700)
            return
        }

        if (commandSettings.isToggleCommand(normalized)) {
            sendUpdate("Comando detectado", commandSettings.getCommandWord(), "Comando de pausa. No se busca en internet.", -1)
            scheduleRestart(900)
            return
        }

        if (System.currentTimeMillis() < ignoreUntil || shouldIgnoreOwnVoice(normalized)) {
            sendUpdate("Ignorando eco. Listo.", "", "", -1)
            scheduleRestart(1200)
            return
        }

        val now = System.currentTimeMillis()
        if (normalized == lastHeard && now - lastHeardTime < 7000) {
            scheduleRestart(900)
            return
        }
        lastHeard = normalized
        lastHeardTime = now

        sendUpdate("Procesando pregunta...", question, "", -1)

        val mode = if (forceInternet) AnswerModeSettings.Mode.INTERNET else modeSettings.getMode()

        when (mode) {
            AnswerModeSettings.Mode.LOCAL -> {
                val match = repository.findBest(question)
                answerLocal(question, match)
            }

            AnswerModeSettings.Mode.INTERNET -> {
                answerOnline(question)
            }

            AnswerModeSettings.Mode.HYBRID -> {
                val match = repository.findBest(question)
                if (match.score >= 60) answerLocal(question, match) else answerOnline(question)
            }
        }
    }

    private fun answerLocal(question: String, match: ResponseRepository.MatchResult) {
        memory.saveLast(question, match.answer, match.itemId, match.score)
        sendUpdate("Respuesta local", question, match.answer, -1)
        speakThenRestart(match.answer)
    }

    private fun answerOnline(question: String) {
        sendUpdate("Buscando en internet...", question, "", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré una respuesta clara. Prueba con otra frase."
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                sendUpdate("Respuesta online", question, answer, -1)
                speakThenRestart(answer)
            }
        }.start()
    }

    private fun startListening() {
        if (!keepListening || isSpeaking) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "", -1)
            return
        }

        try {
            recognizer?.cancel()
            handler.postDelayed({
                try {
                    if (keepListening && !isSpeaking) {
                        recognizer?.startListening(recognizerIntent)
                    }
                } catch (_: Exception) {
                    sendUpdate("Reintentando escucha Google", "", "", -1)
                    if (keepListening) scheduleRestart(1100)
                }
            }, 200)
        } catch (_: Exception) {
            sendUpdate("Error preparando Google. Reintentando", "", "", -1)
            if (keepListening) scheduleRestart(1100)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        restartRunnable?.let { handler.removeCallbacks(it) }
        restartRunnable = Runnable {
            if (keepListening && !isSpeaking) startListening()
        }
        handler.postDelayed(restartRunnable!!, delayMs)
    }

    private fun speakThenRestart(text: String) {
        isSpeaking = true
        ignoreUntil = System.currentTimeMillis() + 5000L
        lastSpokenNormalized = ResponseRepository.normalize(text)
        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }
        tts?.stop()
        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            handler.postDelayed({
                isSpeaking = false
                sendUpdate("Listo para otra pregunta", "", "", -1)
                scheduleRestart(700)
            }, 1200)
        }
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val answer = lastSpokenNormalized
        if (question.isBlank() || answer.isBlank()) return false
        if (answer.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        val aWords = answer.split(" ").toSet()
        if (qWords.isEmpty()) return false

        val common = qWords.count { it in aWords }
        return common >= 2
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Google activo")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GoogleWakeLock").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Micrófono ocupado"
        SpeechRecognizer.ERROR_CLIENT -> "Reiniciando Google Speech"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso de micrófono"
        SpeechRecognizer.ERROR_NETWORK -> "Error de red"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Tiempo agotado"
        SpeechRecognizer.ERROR_NO_MATCH -> "No reconocí la voz"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Google ocupado"
        SpeechRecognizer.ERROR_SERVER -> "Error de Google Speech"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No escuché voz"
        else -> "Error de voz"
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(1.05f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            ignoreUntil = System.currentTimeMillis() + 3500L
                            sendUpdate("Listo para otra pregunta", "", "", -1)
                            scheduleRestart(700)
                        }, 900)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    ignoreUntil = System.currentTimeMillis() + 3500L
                    sendUpdate("Listo para otra pregunta", "", "", -1)
                    scheduleRestart(900)
                }
            })
        }
    }

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_FORCE_INTERNET = "forceInternet"
        private const val CHANNEL_ID = "geo_susu_google_channel"
        private const val NOTIFICATION_ID = 1001
        private const val UTTERANCE_ID = "geo_susu_google_answer"
    }
}
