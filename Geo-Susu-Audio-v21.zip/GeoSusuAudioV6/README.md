# Geo Susu Audio v21

## Corrección de compilación
Se corrigió el error:
MainActivity.kt:172:13 Val cannot be reassigned

## Cambio
El editor interno de TXT ahora usa correctamente la propiedad del EditText.

## Mantiene
- TXT P/R dentro de la app.
- TXT VAR dentro de la app.
- Guardar y cargar dentro de la app.
- Modo TXT, Mixto y Net.
