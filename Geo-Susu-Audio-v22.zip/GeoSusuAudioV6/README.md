# Geo Susu Audio v22

## Corrección importante
El botón Google ya no fuerza internet.

Ahora Google solo sirve como micrófono/reconocimiento de voz:
- Si está en modo TXT, responde con tu TXT.
- Si está en modo Mixto, usa TXT si coincide y si no internet.
- Si está en modo Net, usa internet.

## Cambio visual
El botón ahora dice G. MIC para entender que es micrófono de Google, no fuente de respuesta.

## Uso
1. Toca TXT P/R.
2. Edita dentro de la app.
3. Toca Guardar y cargar.
4. Deja modo TXT.
5. Usa G. MIC o VOSK ON.
