# Geo Susu Audio v25

## Interfaz simplificada
Botones principales:
- ESCUCHAR
- DETENER
- DESCARGAR OFFLINE

Modo de respuesta:
- TXT: usa solo la información que escribiste.
- Internet: busca solo en internet.

Edición:
- EDITAR TXT: preguntas y respuestas.
- VARIANTES: formas como puede escuchar mal.

## Cómo funciona ESCUCHAR
- Si ya descargaste offline, usa Vosk.
- Si no descargaste offline, usa el micrófono de Google.
- Responde según el modo elegido: TXT o Internet.

## Nombres corregidos
- G. MIC ya no aparece.
- VOSK ON ya no aparece.
- MODELO ahora es DESCARGAR OFFLINE.
- STOP ahora es DETENER.
- TXT P/R ahora es EDITAR TXT.
- TXT VAR ahora es VARIANTES.
