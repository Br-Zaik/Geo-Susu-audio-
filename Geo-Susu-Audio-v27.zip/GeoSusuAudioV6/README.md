# Geo Susu Audio v27

## Filtro profesional para TXT
En modo TXT la app busca dentro de tu TXT de forma más inteligente:

- Detecta palabras clave dentro de la pregunta.
- "qué es epp" busca "epp".
- "qué significa iperc" busca "iperc".
- "defíneme cateo" busca "cateo".
- Une siglas deletreadas: "e p p" -> "epp".
- Genera siglas desde preguntas largas:
  "Equipo de Protección Personal" también puede reconocer "epp".
- Evita confundir palabras parecidas como calcopirita y calcita.

## Net
En modo Internet la app no usa tu TXT.
Busca en internet con la frase reconocida.

## Regla simple
- TXT: solo tu información.
- Internet: solo internet.
