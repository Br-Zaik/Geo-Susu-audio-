# Geo Susu Audio v28

## Nuevo: Ajustes
Se agregó el botón AJUSTES.

### Enfoque Internet
Solo afecta al modo Internet:
- General: busca normal.
- Minería / Explotación minera: agrega contexto minero a las búsquedas.

### Velocidad de voz
- Lento
- Normal
- Rápido

## Regla
- TXT: solo usa tu información cargada.
- Internet: solo usa internet.
- Ajustes de enfoque solo se aplican en Internet.
