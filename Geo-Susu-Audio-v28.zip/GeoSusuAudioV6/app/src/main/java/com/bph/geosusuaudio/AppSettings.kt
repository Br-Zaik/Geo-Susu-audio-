package com.bph.geosusuaudio

import android.content.Context

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_settings", Context.MODE_PRIVATE)

    enum class NetFocus {
        GENERAL,
        MINING
    }

    enum class VoiceSpeed {
        SLOW,
        NORMAL,
        FAST
    }

    fun getNetFocus(): NetFocus {
        return when (prefs.getString(KEY_NET_FOCUS, NetFocus.GENERAL.name)) {
            NetFocus.MINING.name -> NetFocus.MINING
            else -> NetFocus.GENERAL
        }
    }

    fun setNetFocus(value: NetFocus) {
        prefs.edit().putString(KEY_NET_FOCUS, value.name).apply()
    }

    fun getVoiceSpeed(): VoiceSpeed {
        return when (prefs.getString(KEY_VOICE_SPEED, VoiceSpeed.NORMAL.name)) {
            VoiceSpeed.SLOW.name -> VoiceSpeed.SLOW
            VoiceSpeed.FAST.name -> VoiceSpeed.FAST
            else -> VoiceSpeed.NORMAL
        }
    }

    fun setVoiceSpeed(value: VoiceSpeed) {
        prefs.edit().putString(KEY_VOICE_SPEED, value.name).apply()
    }

    fun getVoiceRate(): Float {
        return when (getVoiceSpeed()) {
            VoiceSpeed.SLOW -> 0.85f
            VoiceSpeed.NORMAL -> 1.05f
            VoiceSpeed.FAST -> 1.25f
        }
    }

    fun getNetFocusLabel(): String {
        return when (getNetFocus()) {
            NetFocus.GENERAL -> "General"
            NetFocus.MINING -> "Minería"
        }
    }

    fun getVoiceSpeedLabel(): String {
        return when (getVoiceSpeed()) {
            VoiceSpeed.SLOW -> "Lento"
            VoiceSpeed.NORMAL -> "Normal"
            VoiceSpeed.FAST -> "Rápido"
        }
    }

    companion object {
        private const val KEY_NET_FOCUS = "net_focus"
        private const val KEY_VOICE_SPEED = "voice_speed"
    }
}
