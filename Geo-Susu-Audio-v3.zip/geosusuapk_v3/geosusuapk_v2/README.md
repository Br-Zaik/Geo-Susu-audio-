# Geo Susu Audio v3

APK de repaso por voz con memoria local.

## Objetivo
Escuchar preguntas cortas, incluso susurradas, buscar una respuesta guardada y responder por voz.

## Lo que incluye
- Servicio en primer plano para seguir escuchando en segundo plano.
- Notificación fija mientras escucha.
- WakeLock parcial para reducir cortes.
- Memoria local/cache con última pregunta, última respuesta, score y contador.
- Base de 47 respuestas iniciales de minería, topografía, geología, legislación minera y símbolos químicos.
- Corrección de palabras mal escuchadas:
  - gaga / aga / canga -> ganga
  - mema / mina -> mena
  - kateo / cateu -> cateo
  - cuota de geólogo -> picota de geólogo
  - loca -> roca
- Archivo `memoria_config.json` con reglas del asistente.
- Reintento automático de escucha.

## Uso recomendado
1. Conecta Redmi Buds para escuchar.
2. Conecta micrófono Zync Tipo C.
3. Coloca el micrófono a 5-8 cm de la boca.
4. Abre la app.
5. Da permisos de micrófono y notificación.
6. Toca Iniciar escucha.
7. Pregunta corto: "qué es ganga".

## Limitación honesta
Ninguna app garantiza 100% reconocer susurros. Esta versión mejora el flujo, pero la precisión depende del micrófono, ruido, Google Speech y distancia.
