# Geo Susu Audio v31

## Mejoras de ruido y sensibilidad
- Se agregó limpiador de ruido Normal / Fuerte en AJUSTES.
- Se subió la sensibilidad del micrófono.
- En Vosk/offline se aplica:
  - amplificación de voz baja,
  - filtro pasa-altos suave,
  - puerta suave de ruido,
  - cancelador de eco si el celular lo permite,
  - ganancia automática si el celular lo permite,
  - reducción de ruido si el celular lo permite.

## Recomendación para susurro
1. DESCARGAR OFFLINE.
2. AJUSTES > Sensibilidad micrófono: Susurro.
3. AJUSTES > Limpiador de ruido: Fuerte.
4. Usar Zync cerca de la boca.
5. Evitar parlante del celular; mejor audífonos.

## Nota
El limpiador fuerte ayuda con ruido bajo, pero si el ambiente tiene ruido alto o voces cercanas, puede confundirse.
