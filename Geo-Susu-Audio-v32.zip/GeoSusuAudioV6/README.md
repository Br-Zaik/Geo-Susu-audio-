# Geo Susu Audio v32

## Corrección Internet con enfoque Minería
- En modo Internet + Minería, ahora busca primero con contexto minero.
- Evita respuestas de desambiguación como: "Mena hace referencia a varios artículos".
- Rechaza páginas tipo lista/desambiguación.
- Limpia mejor títulos raros de Wikipedia.
- Si pregunta "qué es mena", busca mejor "mena mineral minería", "mena en minería", "mena definición minería", etc.

## Regla
- TXT: solo tu información.
- Internet: solo internet.
- Enfoque Minería: solo mejora la búsqueda de Internet.
