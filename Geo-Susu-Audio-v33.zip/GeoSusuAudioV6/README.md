# Geo Susu Audio v33

## Corrección Internet: definiciones concretas
- Internet ahora intenta responder solo con definiciones concretas.
- Rechaza respuestas que no tienen relación con la palabra preguntada.
- Rechaza respuestas raras como páginas de desambiguación o ejemplos de agua.
- Para "cuánto pesa el oro" cambia la búsqueda hacia "densidad del oro" y "peso específico".
- Para minería busca más directo: glosario minero, definición minería, explotación minera.

## Regla
- TXT: solo tu información.
- Internet: solo internet, pero filtrado para definición concreta.
- Enfoque Minería: mejora la búsqueda con contexto minero.
