package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class OnlineAnswerProvider(private val context: Context? = null) {

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val queries = buildSearchQueries(query)

        for (q in queries) {
            val wiki = fetchWikipediaBestSummary(q)
            if (isRelevant(query, wiki)) return makeConcreteAnswer(query, wiki)
        }

        for (q in queries) {
            val duckApi = fetchDuckDuckGoApi(q)
            if (isRelevant(query, duckApi)) return makeConcreteAnswer(query, duckApi)
        }

        for (q in queries) {
            val duckHtml = fetchDuckDuckGoHtmlSnippet(q)
            if (isRelevant(query, duckHtml)) return makeConcreteAnswer(query, duckHtml)
        }

        return "No encontré una definición concreta en internet. Prueba con: qué es + palabra clave."
    }

    private fun buildSearchQueries(query: String): List<String> {
        val clean = ResponseRepository.normalize(query)
        val subject = subjectWords(clean).joinToString(" ").ifBlank { clean }
        val focus = context?.let { AppSettings(it).getNetFocus() } ?: AppSettings.NetFocus.GENERAL

        val list = linkedSetOf<String>()

        if (isWeightQuestion(clean)) {
            list.add("densidad del $subject")
            list.add("$subject densidad g cm3")
            list.add("$subject peso especifico")
            list.add("$subject propiedades fisicas densidad")
        }

        if (focus == AppSettings.NetFocus.MINING) {
            list.add("definicion concreta $subject mineria")
            list.add("$subject glosario minero")
            list.add("$subject definicion mineria")
            list.add("$subject en mineria")
            list.add("$subject explotacion minera")
            list.add("$subject mineral metal valor economico")
            list.add("$subject seguridad minera")
        }

        list.add("definicion concreta $subject")
        list.add("$subject definicion")
        list.add("que es $subject")
        list.add(subject)

        return list.filter { it.isNotBlank() }
    }

    private fun fetchWikipediaBestSummary(query: String): String {
        return try {
            val title = searchWikipediaTitle(query)
            if (title.isBlank()) return ""
            fetchWikipediaSummary(title)
        } catch (_: Exception) {
            ""
        }
    }

    private fun searchWikipediaTitle(query: String): String {
        val url = "https://es.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=5&srsearch=" +
            URLEncoder.encode(query, "UTF-8")
        val json = get(url)
        val root = JSONObject(json)
        val search = root.getJSONObject("query").getJSONArray("search")
        if (search.length() == 0) return ""

        val qWords = keyWords(query)
        var bestTitle = ""
        var bestScore = -1

        for (i in 0 until search.length()) {
            val obj = search.getJSONObject(i)
            val title = obj.getString("title")
            val snippet = htmlToText(obj.optString("snippet", ""))
            val combined = ResponseRepository.normalize("$title $snippet")

            val titleScore = if (qWords.size <= 1) {
                val word = qWords.firstOrNull().orEmpty()
                maxOf(
                    similarity(word, ResponseRepository.normalize(title)),
                    if (combined.contains(word)) 95 else 0
                )
            } else {
                qWords.count { combined.contains(it) } * 100 / qWords.size
            }

            if (titleScore > bestScore) {
                bestScore = titleScore
                bestTitle = title
            }
        }

        return if (qWords.size == 1 && bestScore < 70) "" else bestTitle
    }

    private fun fetchWikipediaSummary(title: String): String {
        val url = "https://es.wikipedia.org/api/rest_v1/page/summary/" +
            URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val json = get(url)
        val root = JSONObject(json)
        return root.optString("extract", "")
    }

    private fun fetchDuckDuckGoApi(query: String): String {
        return try {
            val url = "https://api.duckduckgo.com/?q=" +
                URLEncoder.encode("$query español", "UTF-8") +
                "&format=json&no_html=1&skip_disambig=1&kl=es-es"
            val json = get(url)
            val root = JSONObject(json)
            val answer = root.optString("Answer", "")
            val abstractText = root.optString("AbstractText", "")
            when {
                answer.isNotBlank() -> answer
                abstractText.isNotBlank() -> abstractText
                else -> ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    private fun fetchDuckDuckGoHtmlSnippet(query: String): String {
        return try {
            val url = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode("$query español", "UTF-8")
            val html = get(url)
            val regex = Regex(
                "<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>|<div[^>]*class=\"result__snippet\"[^>]*>(.*?)</div>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            val match = regex.find(html) ?: return ""
            val raw = match.groupValues.drop(1).firstOrNull { it.isNotBlank() }.orEmpty()
            htmlToText(raw)
        } catch (_: Exception) {
            ""
        }
    }

    private fun isRelevant(query: String, answer: String): Boolean {
        if (answer.isBlank() || isBadInternetAnswer(answer)) return false

        val subjects = subjectWords(query)
        val a = ResponseRepository.normalize(answer)
        val answerWords = a.split(" ")

        if (subjects.isNotEmpty()) {
            val subjectMatches = subjects.count { word ->
                a.contains(word) || answerWords.any { similarity(word, it) >= 84 }
            }
            if (subjectMatches == 0) return false
        }

        if (isWeightQuestion(query)) {
            return a.contains("densidad") ||
                a.contains("g cm") ||
                a.contains("gramos por centimetro") ||
                a.contains("kg m") ||
                a.contains("peso especifico")
        }

        return true
    }

    private fun isBadInternetAnswer(answer: String): Boolean {
        val a = ResponseRepository.normalize(answer)
        val badPhrases = listOf(
            "hace referencia a varios",
            "puede referirse a",
            "puede hacer referencia",
            "varios articulos",
            "pagina de desambiguacion",
            "articulo de lista",
            "wikipedia no tiene",
            "no tiene una pagina",
            "eso significa que un litro de agua",
            "un litro de agua pesa",
            "facilmente levantarlo",
            "con una sola mano"
        )
        return badPhrases.any { a.contains(it) }
    }

    private fun keyWords(text: String): List<String> = subjectWords(text)

    private fun subjectWords(text: String): List<String> {
        val stop = setOf(
            "q", "que", "es", "son", "un", "una", "el", "la", "los", "las", "de", "del", "en",
            "por", "para", "como", "cual", "cuales", "dime", "google", "internet",
            "palabra", "significa", "significado", "definicion", "concepto",
            "concreta", "concreto", "breve", "cuanto", "cuanta", "cuantos", "cuantas", "pesa", "pesan", "peso",
            "tiene", "vale", "mineria", "minera", "minero", "explotacion"
        )
        return ResponseRepository.normalize(text)
            .split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
    }

    private fun isWeightQuestion(text: String): Boolean {
        val q = ResponseRepository.normalize(text)
        return q.contains("cuanto pesa") ||
            q.contains("cuanto peso") ||
            q.contains("peso del") ||
            q.contains("peso de") ||
            q.contains("densidad") ||
            q.contains("peso especifico")
    }

    private fun get(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 9000
        connection.readTimeout = 9000
        connection.setRequestProperty("Accept-Language", "es-PE,es;q=0.9")
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 GeoSusuAudio/3.1 Android")
        return connection.inputStream.bufferedReader().use { it.readText() }
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
            .replace(" y mineria", " en mineria")
            .replace(" y minera", " en mineria")
            .replace(" y minero", " en mineria")
        val prefixes = listOf(
            "q es ",
            "es ",
            "que es ",
            "que significa ",
            "dime que es ",
            "definicion de ",
            "definicion del ",
            "definicion de la ",
            "concepto de ",
            "concepto del ",
            "concepto de la ",
            "buscar ",
            "busca ",
            "google ",
            "en internet ",
            "la palabra ",
            "palabra ",
            "simbolo quimico de ",
            "simbolo quimico del ",
            "simbolo quimico de la "
        )
        for (prefix in prefixes) {
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }
        return q
    }

    private fun makeConcreteAnswer(query: String, text: String): String {
        val clean = cleanAnswer(text)
        if (clean.isBlank()) return ""

        val sentences = clean
            .split(". ")
            .map { it.trim() }
            .filter { it.length >= 20 && !isBadInternetAnswer(it) }

        val subject = subjectWords(query).firstOrNull().orEmpty()
        val best = when {
            isWeightQuestion(query) -> sentences.firstOrNull {
                val s = ResponseRepository.normalize(it)
                s.contains("densidad") || s.contains("g cm") ||
                    s.contains("gramos por centimetro") || s.contains("peso especifico")
            }
            subject.isNotBlank() -> sentences.firstOrNull {
                ResponseRepository.normalize(it).contains(subject)
            }
            else -> sentences.firstOrNull()
        } ?: sentences.firstOrNull() ?: clean

        return toShortDefinition(best)
    }

    private fun toShortDefinition(text: String): String {
        val clean = cleanAnswer(text)
        val cut = if (clean.length > 230) clean.take(230).trim() + "..." else clean
        return cut.removePrefix("Definición:").trim()
    }

    private fun cleanAnswer(text: String): String {
        val clean = htmlToText(text)
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (clean.isBlank()) return ""

        return clean
            .replace("^([A-ZÁÉÍÓÚÑ][\\wáéíóúñ]+\\s*\\([^)]*\\)\\s*)".toRegex(), "")
            .replace("^Definición\\s*:?\\s*".toRegex(RegexOption.IGNORE_CASE), "")
            .trim()
    }

    private fun shorten(text: String): String = cleanAnswer(text)

    private fun htmlToText(raw: String): String {
        return raw
            .replace("<[^>]+>".toRegex(), " ")
            .replace("&quot;", "\"")
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    private fun similarity(a: String, b: String): Int {
        if (a == b) return 100
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = maxOf(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }
}
