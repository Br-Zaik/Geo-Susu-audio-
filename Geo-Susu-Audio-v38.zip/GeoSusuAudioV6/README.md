# Geo Susu Audio v38

## Internet mejorado sin respuestas fijas
- Se quitó cualquier respaldo fijo.
- Internet busca más profundo con varias consultas de Google.
- En enfoque Minería prioriza consultas de minería y excluye Wikipedia en las primeras búsquedas.
- Filtra mejor textos basura, captions, desambiguación, publicidad y respuestas largas.
- Devuelve una definición corta, concreta y específica.
- Si no encuentra una definición limpia, avisa en vez de inventar.

## Regla
- TXT: solo tu información.
- Internet: Google/Internet, sin respuestas pregrabadas.
