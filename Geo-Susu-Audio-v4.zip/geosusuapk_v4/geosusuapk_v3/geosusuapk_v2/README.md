# Geo Susu Audio v4

Versión más práctica.

## Ahora dónde metes preguntas
En la misma APK:
1. Escribes pregunta o palabra clave.
2. Escribes variantes mal escuchadas.
3. Escribes respuesta corta.
4. Tocas Guardar.

También puedes meter carga masiva en:
`app/src/main/assets/respuestas.json`

## Mejoras v4
- Pantalla para agregar preguntas.
- Memoria local personalizada.
- Botón Probar texto para validar sin usar micrófono.
- Base inicial de respuestas.
- Cache de última pregunta, respuesta y score.
- Servicio en segundo plano con notificación.
- Correcciones de palabras parecidas.

## Importante
Si no escucha voz, no es la base de preguntas: es el reconocimiento de voz del celular o el micrófono. Primero prueba con Probar texto.
