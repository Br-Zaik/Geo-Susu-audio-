# Geo Susu Audio v41

## Sensibilidad y ruido
- Se subió la ganancia del modo Susurro.
- Se ajustó el limpiador fuerte para no cortar la voz baja.
- Se agregó compresión suave para evitar saturación.
- Vosk muestra mejor el nivel de voz.
- Google Speech espera un poco más antes de cerrar la pregunta.

## Estabilidad
- El loop del micrófono offline se recupera si ocurre un error.
- Servicios reforzados para seguir activos en segundo plano.
- WakeLock y servicio en primer plano se mantienen.

## TXT ampliado
- Se agregaron muchas preguntas y respuestas de minería, topografía, geología, seguridad y legislación minera.
- Si ya tenías TXT guardado, no se borra: se agregan las nuevas líneas una sola vez.
- Se agregó variante/corrección: "nena" -> "mena".
- Se amplió la gramática offline para reconocer más términos.

## Regla
- TXT: solo tu información.
- Internet: Google/Internet, sin respuestas pregrabadas.
