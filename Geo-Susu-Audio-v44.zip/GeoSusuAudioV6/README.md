# Geo Susu Audio v44

## Revisión del modo NET
- Se revisó el proveedor de Internet.
- Sigue usando Google/Internet, sin respuestas fijas.
- Lee más formatos de Google: normal, básico, idioma español y cliente Firefox.
- Extrae snippets por clases comunes de Google y texto cercano a la palabra preguntada.
- Bajó el filtro demasiado estricto que hacía que siempre diga "no encontré".
- Agregó filtro específico para "desmonte".
- Si Google bloquea/captcha o no entrega HTML legible, avisa que Google no entregó texto legible.

## Revisión de escucha
- Se conserva el bucle de Google preciso de la v43.
- ESCUCHAR abre Google, responde y vuelve a abrir para otra pregunta.
- DETENER corta el bucle.
