# Geo Susu Audio v46

## Nuevo: IA audio continuo
- Agrega modo de escucha: IA audio.
- IA audio funciona como servicio en primer plano para pantalla apagada.
- Graba una pregunta corta, detecta silencio, envía el audio WAV a Gemini y Gemini responde directamente.
- Usa la misma API Gemini guardada en Ajustes.
- Mejor para susurros que Vosk porque Gemini entiende el audio completo, no solo palabras del vocabulario.

## Modos de escucha
En AJUSTES > Modo escucha:
1. IA audio: pantalla apagada + Gemini escucha/responde.
2. Google preciso: mejor micrófono, pero requiere pantalla/ventana de Google.
3. Vosk offline: sin internet, continuo, menos preciso.

## Modos de respuesta
- TXT
- NET
- IA

## Importante
- IA audio necesita internet y API Gemini.
- Si Gemini llega al límite, avisará límite alcanzado.
- Para ahorrar API, habla preguntas cortas.
