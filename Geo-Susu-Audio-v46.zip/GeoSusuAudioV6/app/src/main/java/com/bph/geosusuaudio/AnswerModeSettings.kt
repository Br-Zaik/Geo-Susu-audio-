package com.bph.geosusuaudio

import android.content.Context

class AnswerModeSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)

    enum class Mode {
        LOCAL,
        INTERNET,
        AI
    }

    fun getMode(): Mode {
        return when (prefs.getString(KEY_MODE, Mode.LOCAL.name)) {
            Mode.INTERNET.name -> Mode.INTERNET
            Mode.AI.name -> Mode.AI
            else -> Mode.LOCAL
        }
    }

    fun setMode(mode: Mode) {
        prefs.edit().putString(KEY_MODE, mode.name).apply()
    }

    fun getLabel(): String {
        return when (getMode()) {
            Mode.INTERNET -> "Internet"
            Mode.AI -> "IA"
            else -> "TXT"
        }
    }

    companion object {
        private const val KEY_MODE = "answer_mode"
    }
}
