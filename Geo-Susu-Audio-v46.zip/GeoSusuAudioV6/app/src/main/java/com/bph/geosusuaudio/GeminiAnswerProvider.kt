package com.bph.geosusuaudio

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiAnswerProvider(private val context: Context) {

    fun fetchAnswer(question: String): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()
        if (apiKey.isBlank()) {
            return AiResult(
                text = "Falta API key de Gemini. En Ajustes pega tu API key.",
                limited = false,
                missingKey = true
            )
        }

        val prompt = buildPrompt(question)
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.15)
                    .put("topP", 0.8)
                    .put("maxOutputTokens", 90)
            )

        return postGemini(body)
    }

    fun fetchAnswerFromAudio(wavBytes: ByteArray): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()
        if (apiKey.isBlank()) {
            return AiResult(
                text = "Falta API key de Gemini. En Ajustes pega tu API key.",
                limited = false,
                missingKey = true
            )
        }

        val audioBase64 = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val prompt = """
Escucha el audio, entiende la pregunta y responde directamente.
Responde como estudiante de Explotación Minera.
Máximo 2 líneas.
Si no entiendes el audio, di: No entendí bien la pregunta.
Si la pregunta es de minería, topografía, geología, seguridad o legislación minera, usa enfoque técnico básico.
""".trimIndent()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "audio/wav")
                                        .put("data", audioBase64)
                                )
                            )
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.12)
                    .put("topP", 0.8)
                    .put("maxOutputTokens", 100)
            )

        return postGemini(body)
    }

    private fun buildPrompt(question: String): String {
        return """
Responde como estudiante de Explotación Minera.
Da una respuesta corta, clara y directa.
Máximo 2 líneas.
Si la pregunta es de minería, topografía, geología, seguridad o legislación minera, responde con enfoque técnico básico.
No inventes datos raros; si no sabes, dilo simple.

Pregunta: ${question.trim()}
""".trimIndent()
    }

    private fun postGemini(body: JSONObject): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()
        return try {
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"
            )
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 12000
            connection.readTimeout = 25000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true

            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val raw = if (code in 200..299) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            }

            when (code) {
                200 -> {
                    val answer = parseAnswer(raw)
                    AiResult(
                        text = answer.ifBlank { "IA no devolvió una respuesta clara." },
                        limited = false,
                        missingKey = false
                    )
                }
                400, 401, 403 -> AiResult(
                    text = "API key inválida o sin permiso. Cambia tu API key en Ajustes.",
                    limited = false,
                    missingKey = true
                )
                429 -> AiResult(
                    text = "Límite IA alcanzado. Usa TXT o cambia API key.",
                    limited = true,
                    missingKey = false
                )
                else -> AiResult(
                    text = "IA no respondió bien. Código $code.",
                    limited = false,
                    missingKey = false
                )
            }
        } catch (_: Exception) {
            AiResult(
                text = "No pude conectar con IA. Revisa internet o API key.",
                limited = false,
                missingKey = false
            )
        }
    }

    private fun parseAnswer(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""

        val content = candidates.optJSONObject(0)
            ?.optJSONObject("content")
            ?: return ""

        val parts = content.optJSONArray("parts") ?: return ""
        val out = StringBuilder()

        for (i in 0 until parts.length()) {
            val text = parts.optJSONObject(i)?.optString("text").orEmpty()
            if (text.isNotBlank()) {
                if (out.isNotBlank()) out.append(" ")
                out.append(text)
            }
        }

        return cleanAnswer(out.toString())
    }

    private fun cleanAnswer(value: String): String {
        val clean = value
            .replace("\\s+".toRegex(), " ")
            .trim()
            .removePrefix("Respuesta:")
            .trim()

        return if (clean.length > 240) clean.take(237).trim() + "..." else clean
    }

    data class AiResult(
        val text: String,
        val limited: Boolean,
        val missingKey: Boolean
    )

    companion object {
        private const val MODEL = "gemini-2.5-flash-lite"
    }
}
