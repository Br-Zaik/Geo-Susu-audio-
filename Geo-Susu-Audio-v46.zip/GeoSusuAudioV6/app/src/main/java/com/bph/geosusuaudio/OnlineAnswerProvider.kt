package com.bph.geosusuaudio

import android.content.Context
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import kotlin.math.min

class OnlineAnswerProvider(private val context: Context? = null) {

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val queries = buildGoogleQueries(query)

        for (q in queries) {
            val answer = fetchGoogleDefinition(q, query)
            if (answer.isNotBlank()) return answer
        }

        return "Google no entregó texto legible para esa pregunta. Prueba: qué es + palabra + en minería."
    }

    private fun buildGoogleQueries(query: String): List<String> {
        val clean = ResponseRepository.normalize(query)
        val subject = subjectWords(clean).joinToString(" ").ifBlank { clean }
        val focus = context?.let { AppSettings(it).getNetFocus() } ?: AppSettings.NetFocus.GENERAL

        val list = linkedSetOf<String>()

        if (focus == AppSettings.NetFocus.MINING) {
            list.add("que es $subject en mineria")
            list.add("definicion de $subject en mineria")
            list.add("$subject glosario minero")
            list.add("$subject explotacion minera")
            list.add("$subject significado mineria")
        }

        if (isWeightQuestion(clean)) {
            list.add("densidad del $subject")
            list.add("$subject peso especifico")
            list.add("cuanto pesa $subject")
        }

        list.add("que es $subject")
        list.add("definicion de $subject")
        list.add("$subject significado")
        list.add(subject)

        return list.filter { it.isNotBlank() }
    }

    private fun fetchGoogleDefinition(searchQuery: String, originalQuery: String): String {
        return try {
            val encoded = URLEncoder.encode(searchQuery, "UTF-8")
            val urls = listOf(
                "https://www.google.com/search?hl=es-419&gl=PE&pws=0&num=10&q=$encoded",
                "https://www.google.com/search?hl=es-419&gl=PE&pws=0&gbv=1&num=10&q=$encoded",
                "https://www.google.com/search?hl=es&lr=lang_es&pws=0&num=10&q=$encoded",
                "https://www.google.com/search?client=firefox-b-d&hl=es-419&q=$encoded"
            )

            val chunks = mutableListOf<String>()
            for (url in urls) {
                val html = get(url)
                chunks.addAll(extractGoogleStructuredChunks(html, originalQuery))
                chunks.addAll(extractGoogleTextChunks(html, originalQuery))
            }

            pickBestDefinition(originalQuery, chunks.distinct())
        } catch (_: Exception) {
            ""
        }
    }

    private fun extractGoogleStructuredChunks(html: String, query: String): List<String> {
        val result = mutableListOf<String>()

        val classHints = listOf(
            "BNeawe", "VwiC3b", "hgKElc", "kno-rdesc", "IZ6rdc",
            "ILfuVd", "LGOjhe", "vk_bk", "wDYxhc", "Z0LcW", "MUxGbd"
        )

        for (hint in classHints) {
            val regex = Regex(
                "<(div|span)[^>]*class=\"[^\"]*$hint[^\"]*\"[^>]*>(.*?)</\\1>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            regex.findAll(html).forEach { match ->
                val cleaned = htmlToText(match.groupValues[2])
                if (cleaned.length in 24..520) result.add(cleaned)
            }
        }

        val descRegex = Regex(
            "<meta[^>]+name=\"description\"[^>]+content=\"([^\"]+)\"",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        descRegex.findAll(html).forEach { match ->
            val cleaned = decodeHtml(match.groupValues[1])
            if (cleaned.length in 24..520) result.add(cleaned)
        }

        val subject = subjectWords(query).firstOrNull().orEmpty()
        if (subject.isNotBlank()) {
            val subjectRegex = Regex(
                "((?:[^.?!<>]|<[^>]+>){0,180}${Regex.escape(subject)}(?:[^.?!<>]|<[^>]+>){0,260})",
                RegexOption.IGNORE_CASE
            )
            subjectRegex.findAll(htmlToText(html)).take(12).forEach { match ->
                val cleaned = removeGoogleNoise(match.groupValues[1])
                if (cleaned.length in 24..520) result.add(cleaned)
            }
        }

        return result
            .map { removeGoogleNoise(it).trim() }
            .filter { it.length in 24..420 }
            .filter { !isBadInternetAnswer(it) }
            .distinct()
    }

    private fun extractGoogleTextChunks(html: String, query: String): List<String> {
        val text = htmlToText(html)
            .replace("Visión general creada por IA", ". ")
            .replace("Mostrar más", ". ")
            .replace("Más información", ". ")
            .replace("Wikipedia, la enciclopedia libre", ". ")
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (isBlockedGooglePage(text)) return emptyList()

        val rawChunks = text.split(". ", " · ", " | ", "\n", " - ", "  ")
            .map { removeGoogleNoise(it).trim() }
            .filter { it.length in 24..900 }
            .filter { !isBadInternetAnswer(it) }

        val sentenceChunks = rawChunks.flatMap { chunk ->
            chunk.split("; ", ": ")
                .map { it.trim() }
                .filter { it.length in 24..420 }
        }

        val subjectChunks = extractSubjectWindows(text, query)

        return (sentenceChunks + subjectChunks)
            .map { it.trim() }
            .filter { it.length in 24..420 }
            .filter { !isBadInternetAnswer(it) }
            .distinct()
    }

    private fun extractSubjectWindows(text: String, query: String): List<String> {
        val normalized = ResponseRepository.normalize(text)
        val subjects = subjectWords(query)
        val words = (subjects + listOf(
            "mineral", "mineria", "minera", "minero", "yacimiento",
            "explotacion", "roca", "material", "metal", "valor economico"
        )).distinct()

        val result = mutableListOf<String>()

        for (word in words) {
            var index = normalized.indexOf(word)
            var guard = 0
            while (index >= 0 && guard < 12) {
                val start = (index - 170).coerceAtLeast(0)
                val end = (index + 360).coerceAtMost(text.length)
                val chunk = text.substring(start, end)
                    .replace("\\s+".toRegex(), " ")
                    .trim()

                if (chunk.isNotBlank()) result.add(chunk)

                index = normalized.indexOf(word, index + word.length)
                guard++
            }
        }

        return result
    }

    private fun pickBestDefinition(query: String, chunks: List<String>): String {
        if (chunks.isEmpty()) return ""

        val scored = chunks
            .map { it to scoreDefinition(query, it) }
            .filter { it.second >= 32 }
            .sortedByDescending { it.second }

        val best = scored.firstOrNull()?.first ?: return ""
        return cleanFinalAnswer(best)
    }

    private fun scoreDefinition(query: String, text: String): Int {
        if (isBadInternetAnswer(text)) return 0

        val normalized = ResponseRepository.normalize(text)
        val subjects = subjectWords(query)
        val focus = context?.let { AppSettings(it).getNetFocus() } ?: AppSettings.NetFocus.GENERAL

        var score = 0

        if (subjects.isNotEmpty()) {
            val matched = subjects.count { word ->
                normalized.contains(word) ||
                    normalized.split(" ").any { similarity(word, it) >= 82 }
            }
            if (matched == 0) return 0
            score += matched * 35
        }

        val definitionMarks = listOf(
            " es ",
            " son ",
            " se define ",
            " se conoce ",
            " se denomina ",
            " consiste ",
            " corresponde ",
            " mineral ",
            " roca ",
            " material ",
            " del cual ",
            " de la cual ",
            " del que ",
            " elemento util ",
            " rentable ",
            " proceso ",
            " metodo ",
            " actividad ",
            " residuos ",
            " sin valor "
        )
        if (definitionMarks.any { normalized.contains(it) }) score += 28

        if (focus == AppSettings.NetFocus.MINING) {
            val miningMarks = listOf(
                "mineria", "minera", "minero", "mineral", "yacimiento",
                "explotacion", "metal", "mena", "ganga", "seguridad",
                "riesgo", "geologia", "desmonte", "esteril", "relave"
            )
            if (miningMarks.any { normalized.contains(it) }) score += 20
        }

        if (passesSpecificFilter(query, normalized)) score += 28 else score -= 12

        if (isWeightQuestion(query)) {
            val weightMarks = listOf("densidad", "g cm", "kg m", "peso especifico")
            if (weightMarks.any { normalized.contains(it) }) score += 45 else return 0
        }

        if (text.length in 35..240) score += 15
        if (text.length > 320) score -= 15

        return score.coerceIn(0, 100)
    }

    private fun passesSpecificFilter(query: String, answerNormalized: String): Boolean {
        val subject = subjectWords(query).firstOrNull().orEmpty()

        return when (subject) {
            "mena" -> answerNormalized.contains("mineral") &&
                (answerNormalized.contains("extraer") ||
                    answerNormalized.contains("metal") ||
                    answerNormalized.contains("valor economico") ||
                    answerNormalized.contains("elemento util") ||
                    answerNormalized.contains("rentable"))
            "ganga" -> answerNormalized.contains("material") &&
                (answerNormalized.contains("sin valor") ||
                    answerNormalized.contains("esteril") ||
                    answerNormalized.contains("mena"))
            "desmonte" -> answerNormalized.contains("material") ||
                answerNormalized.contains("roca") ||
                answerNormalized.contains("residuo") ||
                answerNormalized.contains("extraido") ||
                answerNormalized.contains("sin valor") ||
                answerNormalized.contains("esteril")
            "cateo" -> answerNormalized.contains("mineral") &&
                (answerNormalized.contains("buscar") ||
                    answerNormalized.contains("busqueda") ||
                    answerNormalized.contains("indicios") ||
                    answerNormalized.contains("exploracion"))
            "prospeccion" -> answerNormalized.contains("mineral") &&
                (answerNormalized.contains("busqueda") ||
                    answerNormalized.contains("yacimiento") ||
                    answerNormalized.contains("exploracion"))
            "epp" -> answerNormalized.contains("proteccion personal") ||
                answerNormalized.contains("equipo de proteccion")
            "iperc" -> answerNormalized.contains("peligros") &&
                answerNormalized.contains("riesgos")
            else -> true
        }
    }

    private fun isBlockedGooglePage(text: String): Boolean {
        val t = ResponseRepository.normalize(text)
        return t.contains("trafico inusual") ||
            t.contains("nuestros sistemas detectaron") ||
            t.contains("captcha") ||
            t.contains("no soy un robot")
    }

    private fun isBadInternetAnswer(answer: String): Boolean {
        val a = ResponseRepository.normalize(answer)
        val badPhrases = listOf(
            "hace referencia a varios",
            "puede referirse a",
            "puede hacer referencia",
            "varios articulos",
            "pagina de desambiguacion",
            "articulo de lista",
            "bad grund",
            "harz alemania",
            "veta de la antigua mina",
            "constituida por galena",
            "gris muy oscuro",
            "eso significa que un litro de agua",
            "un litro de agua pesa",
            "facilmente levantarlo",
            "con una sola mano",
            "mas informacion",
            "otras preguntas",
            "videos",
            "imagenes",
            "noticias",
            "resultados de busqueda",
            "iniciar sesion",
            "configuracion",
            "privacidad",
            "publicidad",
            "captcha",
            "trafico inusual",
            "nuestros sistemas detectaron"
        )
        return badPhrases.any { a.contains(it) }
    }

    private fun subjectWords(text: String): List<String> {
        val stop = setOf(
            "q", "que", "es", "son", "un", "una", "el", "la", "los", "las", "de", "del", "en",
            "por", "para", "como", "cual", "cuales", "dime", "google", "internet",
            "palabra", "significa", "significado", "definicion", "concepto",
            "concreta", "concreto", "breve", "corta", "corto", "cuanto", "cuanta",
            "cuantos", "cuantas", "pesa", "pesan", "peso", "tiene", "vale",
            "mineria", "minera", "minero", "explotacion"
        )
        return ResponseRepository.normalize(text)
            .split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
    }

    private fun isWeightQuestion(text: String): Boolean {
        val q = ResponseRepository.normalize(text)
        return q.contains("cuanto pesa") ||
            q.contains("cuanto peso") ||
            q.contains("peso del") ||
            q.contains("peso de") ||
            q.contains("densidad") ||
            q.contains("peso especifico")
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
            .replace(" y mineria", " en mineria")
            .replace(" y minera", " en mineria")
            .replace(" y minero", " en mineria")

        val prefixes = listOf(
            "q es ",
            "es ",
            "que es ",
            "que significa ",
            "dime que es ",
            "definicion de ",
            "definicion del ",
            "definicion de la ",
            "concepto de ",
            "concepto del ",
            "concepto de la ",
            "buscar ",
            "busca ",
            "google ",
            "en internet ",
            "la palabra ",
            "palabra "
        )

        for (prefix in prefixes) {
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }

        return q
    }

    private fun get(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 10000
        connection.setRequestProperty("Accept-Language", "es-PE,es;q=0.9,en;q=0.6")
        connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        connection.setRequestProperty("Referer", "https://www.google.com/")
        connection.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
        )

        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        }
    }

    private fun htmlToText(raw: String): String {
        return decodeHtml(raw)
            .replace("<script[\\s\\S]*?</script>".toRegex(RegexOption.IGNORE_CASE), " ")
            .replace("<style[\\s\\S]*?</style>".toRegex(RegexOption.IGNORE_CASE), " ")
            .replace("<br\\s*/?>".toRegex(RegexOption.IGNORE_CASE), ". ")
            .replace("</div>", ". ")
            .replace("</span>", ". ")
            .replace("</li>", ". ")
            .replace("</p>", ". ")
            .replace("<[^>]+>".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    private fun decodeHtml(raw: String): String {
        return raw
            .replace("&quot;", "\"")
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace("&aacute;", "á")
            .replace("&eacute;", "é")
            .replace("&iacute;", "í")
            .replace("&oacute;", "ó")
            .replace("&uacute;", "ú")
            .replace("&ntilde;", "ñ")
            .replace("&Aacute;", "Á")
            .replace("&Eacute;", "É")
            .replace("&Iacute;", "Í")
            .replace("&Oacute;", "Ó")
            .replace("&Uacute;", "Ú")
            .replace("&Ntilde;", "Ñ")
    }

    private fun removeGoogleNoise(text: String): String {
        return text
            .replace("^.*?Visión general creada por IA".toRegex(), "")
            .replace("^.*?Resultado de búsqueda".toRegex(), "")
            .replace("Más información", "")
            .replace("Mostrar más", "")
            .replace("Wikipedia", "")
            .replace("Diccionario", "")
            .trim()
    }

    private fun cleanFinalAnswer(text: String): String {
        val clean = removeGoogleNoise(text)
            .replace("\\s+".toRegex(), " ")
            .trim()
            .removePrefix("Respuesta:")
            .removePrefix("Definición:")
            .trim()

        val sentences = clean.split(". ")
            .map { it.trim() }
            .filter { it.length >= 20 && !isBadInternetAnswer(it) }

        val candidate = sentences.firstOrNull() ?: clean
        val limit = min(candidate.length, 185)
        val short = candidate.take(limit).trim()

        return if (candidate.length > 185) "$short..." else short
    }

    private fun similarity(a: String, b: String): Int {
        if (a == b) return 100
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = maxOf(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }
}
