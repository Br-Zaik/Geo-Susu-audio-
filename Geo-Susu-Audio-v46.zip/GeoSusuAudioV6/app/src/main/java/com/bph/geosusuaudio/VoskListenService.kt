package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class VoskListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private lateinit var modelManager: VoskModelManager
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }
    private val geminiProvider by lazy { GeminiAnswerProvider(this) }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var audioRecord: AudioRecord? = null
    private var listenThread: Thread? = null
    private var tts: TextToSpeech? = null
    private var acousticEchoCanceler: AcousticEchoCanceler? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizerLock = Any()

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var pausedByCommand = false

    private var lastAnswered = ""
    private var lastAnswerTime = 0L
    private var lastLevelUpdate = 0L
    private var lastPartial = ""
    private var lastSpokenNormalized = ""
    private var ignoreUntil = 0L
    private var highPassPrevInput = 0f
    private var highPassPrevOutput = 0f

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Preparando Vosk continuo"))
        if (!running) startVosk()
        return START_STICKY
    }

    private fun startVosk() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "", 0)
            stopSelf()
            return
        }

        if (!modelManager.isReady()) {
            sendUpdate("Falta descargar modelo Vosk", "", "Pulsa Modelo una vez con internet.", 0)
            stopSelf()
            return
        }

        Thread {
            try {
                sendUpdate("Cargando modelo Vosk...", "", "", 0)
                model = Model(modelManager.modelDir().absolutePath)
                resetRecognizer()
                startAudioLoop()
            } catch (e: Exception) {
                sendUpdate("Error Vosk: ${e.message ?: "sin detalle"}", "", "", 0)
                stopSelf()
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun startAudioLoop() {
        val sampleRate = 16000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuffer, 4096)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            sendUpdate("No se pudo abrir el micrófono", "", "Revisa permisos o si otra app usa el micrófono.", 0)
            stopSelf()
            return
        }

        setupAudioEffects(audioRecord?.audioSessionId ?: 0)

        running = true
        audioRecord?.startRecording()
        sendUpdate("Escucha continua activa. Di ${commandSettings.getCommandWord()} para pausar.", "", "", 0)

        listenThread = Thread {
            val buffer = ByteArray(bufferSize)

            while (running) {
                try {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read <= 0) {
                        Thread.sleep(60)
                        continue
                    }

                    cleanAndBoostAudio(buffer, read)
                    val level = calculateLevel(buffer, read)
                    sendLevel(level)

                    if (isSpeaking || System.currentTimeMillis() < ignoreUntil) continue

                    var resultJson: String? = null
                    var partialJson: String? = null

                    synchronized(recognizerLock) {
                        val rec = recognizer
                        if (rec != null) {
                            val isFinal = rec.acceptWaveForm(buffer, read)
                            if (isFinal) {
                                resultJson = rec.getResult()
                            } else {
                                partialJson = rec.getPartialResult()
                            }
                        }
                    }

                    val partial = extractText(partialJson)
                    if (partial.isNotBlank() && partial != lastPartial) {
                        lastPartial = partial
                        sendUpdate("Escuchando...", partial, "", level)
                    }

                    val finalText = extractText(resultJson)
                    if (finalText.isNotBlank()) {
                        val bestFinal = chooseBetterQuestion(lastPartial, finalText)
                        lastPartial = ""
                        processText(bestFinal)
                    }
                } catch (_: Exception) {
                    sendUpdate("Recuperando micrófono...", "", "", -1)
                    resetRecognizer()
                    Thread.sleep(180)
                }
            }
        }.apply {
            name = "GeoSusuVoskLoop"
            start()
        }
    }

    private fun setupAudioEffects(sessionId: Int) {
        if (sessionId <= 0) return

        try {
            if (AcousticEchoCanceler.isAvailable()) {
                acousticEchoCanceler = AcousticEchoCanceler.create(sessionId)?.apply {
                    enabled = true
                }
            }
        } catch (_: Exception) {
        }

        try {
            if (AutomaticGainControl.isAvailable()) {
                automaticGainControl = AutomaticGainControl.create(sessionId)?.apply {
                    enabled = true
                }
            }
        } catch (_: Exception) {
        }

        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                    enabled = true
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanAndBoostAudio(buffer: ByteArray, read: Int) {
        val gain = appSettings.getMicGain()
        val cleaner = appSettings.getNoiseCleaner()
        val whisper = appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER

        // No cortar el susurro: la puerta es suave y baja.
        val softGate = when {
            cleaner == AppSettings.NoiseCleaner.STRONG && whisper -> 55
            cleaner == AppSettings.NoiseCleaner.STRONG -> 75
            whisper -> 45
            else -> 65
        }
        val gateFactor = when {
            cleaner == AppSettings.NoiseCleaner.STRONG && whisper -> 0.72f
            cleaner == AppSettings.NoiseCleaner.STRONG -> 0.60f
            else -> 0.82f
        }
        val highPassAlpha = if (cleaner == AppSettings.NoiseCleaner.STRONG) 0.982f else 0.988f

        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()

            val highPassed = sample - highPassPrevInput + highPassAlpha * highPassPrevOutput
            highPassPrevInput = sample.toFloat()
            highPassPrevOutput = highPassed

            var cleaned = highPassed

            if (abs(cleaned) < softGate) {
                cleaned *= gateFactor
            }

            // Levanta voz baja sin destruir picos fuertes.
            var boosted = cleaned * gain
            val absBoosted = abs(boosted)
            if (absBoosted > 26000f) {
                boosted = if (boosted > 0) 26000f + (absBoosted - 26000f) * 0.18f
                else -26000f - (absBoosted - 26000f) * 0.18f
            }

            val out = boosted
                .toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()

            buffer[i] = (out.toInt() and 0xFF).toByte()
            buffer[i + 1] = ((out.toInt() shr 8) and 0xFF).toByte()
            i += 2
        }
    }

    private fun chooseBetterQuestion(previous: String, current: String): String {
        val old = previous.trim()
        val now = current.trim()
        if (old.isBlank()) return now
        if (now.isBlank()) return old
        return if (ResponseRepository.normalize(now).length >= ResponseRepository.normalize(old).length) now else old
    }

    private fun processText(rawText: String) {
        val question = normalizeQuestion(rawText)
        if (question.length < 2 || isIncompleteQuestion(question)) {
            sendUpdate("No escuché la pregunta completa", question, "Repite la pregunta completa.", -1)
            resetRecognizer()
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            resetRecognizer()
            sendUpdate("Ignorando eco. Listo para otra pregunta.", "", "", -1)
            return
        }

        if (commandSettings.isToggleCommand(question)) {
            togglePause()
            resetRecognizer()
            return
        }

        if (pausedByCommand) {
            sendUpdate("Pausado. Di ${commandSettings.getCommandWord()} para reanudar.", question, "Pausa activa.", -1)
            resetRecognizer()
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastAnswered && now - lastAnswerTime < 6500) {
            resetRecognizer()
            return
        }

        lastAnswered = question
        lastAnswerTime = now
        val mode = modeSettings.getMode()
        val match = repository.findBest(question)

        when (mode) {
            AnswerModeSettings.Mode.INTERNET -> answerOnline(question)
            AnswerModeSettings.Mode.AI -> answerAi(question, match)
            else -> answerLocal(question, match)
        }
    }

    private fun isIncompleteQuestion(question: String): Boolean {
        val normalized = ResponseRepository.normalize(question)
        val words = questionKeywords(normalized)
        if (words.isEmpty()) return true

        val incomplete = setOf(
            "que", "que es", "q", "q es", "dime", "define", "defineme",
            "la palabra", "palabra", "que significa", "significa"
        )
        return normalized in incomplete
    }

    private fun questionKeywords(normalized: String): List<String> {
        val stop = setOf(
            "q", "que", "es", "son", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "dime", "di", "define",
            "defineme", "concepto", "significa", "significado", "palabra"
        )
        return normalized.split(" ")
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stop }
            .distinct()
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val q = ResponseRepository.normalize(question)
        val a = lastSpokenNormalized
        if (q.isBlank() || a.isBlank()) return false
        if (a.contains(q) && q.length >= 8) return true

        val qWords = q.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val aWords = a.split(" ").toSet()
        val common = qWords.count { it in aWords }
        return common >= 2
    }

    private fun answerLocal(question: String, match: ResponseRepository.MatchResult) {
        memory.saveLast(question, match.answer, match.itemId, match.score)
        sendUpdate("Respuesta local. Reiniciando escucha.", question, match.answer, -1)
        speakAndReset(match.answer)
    }

    private fun answerAi(question: String, localMatch: ResponseRepository.MatchResult) {
        isSpeaking = true
        stopRecordingSafely()
        sendUpdate("Preguntando a IA...", question, "Consultando Gemini.", -1)

        Thread {
            val result = geminiProvider.fetchAnswer(question)
            val answer = if (result.limited && localMatch.itemId != "none") {
                "Límite IA alcanzado. TXT: ${localMatch.answer}"
            } else {
                result.text
            }

            memory.saveLast(question, answer, if (result.limited) localMatch.itemId else "gemini", localMatch.score)
            handler.post {
                sendUpdate(if (result.limited) "IA limitada. TXT." else "Respuesta IA", question, answer, -1)
                speakTracked(answer)
            }
        }.start()
    }

    private fun answerOnline(question: String) {
        isSpeaking = true
        stopRecordingSafely()
        sendUpdate("Buscando online...", question, "Buscando definición concreta.", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré una definición clara. Guarda esta pregunta en TXT."
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                sendUpdate("Respuesta online. Reiniciando escucha.", question, answer, -1)
                speakTracked(answer)
            }
        }.start()
    }

    private fun speakAndReset(answer: String) {
        isSpeaking = true
        stopRecordingSafely()
        resetRecognizer()
        handler.post {
            speakTracked(answer)
        }
    }

    private fun speakTracked(answer: String) {
        lastSpokenNormalized = ResponseRepository.normalize(answer)
        ignoreUntil = System.currentTimeMillis() + 5500L
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    private fun stopRecordingSafely() {
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
    }

    private fun startRecordingSafely() {
        try {
            if (running && audioRecord?.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                audioRecord?.startRecording()
            }
        } catch (_: Exception) {
        }
    }

    private fun togglePause() {
        pausedByCommand = !pausedByCommand
        val command = commandSettings.getCommandWord()
        val answer = if (pausedByCommand) "Pausado." else "Reanudado."
        val status = if (pausedByCommand) "Pausado. Di $command para reanudar." else "Reanudado. Listo para preguntar."
        sendUpdate(status, command, answer, -1)
        speakAndReset(answer)
    }

    private fun resetRecognizer() {
        synchronized(recognizerLock) {
            val currentModel = model ?: return
            recognizer?.close()
            val grammar = repository.buildVoskGrammar(commandSettings.getCommandWord())
            recognizer = Recognizer(currentModel, 16000.0f, grammar)
        }
    }

    private fun normalizeQuestion(text: String): String {
        var q = ResponseRepository.normalize(text)
        val command = commandSettings.getCommandWord()
        val wakeWords = listOf("pregunta", "oye", "dime")
        for (word in wakeWords) {
            if (q.startsWith("$word ")) q = q.removePrefix("$word ").trim()
        }
        if (q.startsWith("$command ") && q.split(" ").size > 1) {
            q = q.removePrefix("$command ").trim()
        }
        return q
    }

    private fun extractText(json: String?): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val obj = JSONObject(json)
            obj.optString("text").ifBlank { obj.optString("partial") }
        } catch (_: Exception) {
            ""
        }
    }

    private fun calculateLevel(buffer: ByteArray, read: Int): Int {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()
            sum += (sample * sample).toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0
        val rms = sqrt(sum / count)
        return ((rms / 32768.0) * 100.0 * 7.5).toInt().coerceIn(0, 100)
    }

    private fun sendLevel(level: Int) {
        val now = System.currentTimeMillis()
        if (now - lastLevelUpdate < 180) return
        lastLevelUpdate = now
        sendUpdate("", "", "", level)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)
        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu Vosk", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Audio activo")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::VoskWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            ignoreUntil = System.currentTimeMillis() + 4000L
                            resetRecognizer()
                            startRecordingSafely()
                            val status = if (pausedByCommand) {
                                "Pausado. Di ${commandSettings.getCommandWord()} para reanudar."
                            } else {
                                "Listo para otra pregunta."
                            }
                            sendUpdate(status, "", "", -1)
                        }, 750)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    ignoreUntil = System.currentTimeMillis() + 4000L
                    resetRecognizer()
                    startRecordingSafely()
                    sendUpdate("Listo para otra pregunta.", "", "", -1)
                }
            })
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (running) {
            try {
                val restart = Intent(applicationContext, VoskListenService::class.java)
                ContextCompat.startForegroundService(applicationContext, restart)
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        audioRecord?.release()
        recognizer?.close()
        model?.close()
        acousticEchoCanceler?.release()
        automaticGainControl?.release()
        noiseSuppressor?.release()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.VOSK_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_vosk_channel"
        private const val NOTIFICATION_ID = 2001
        private const val UTTERANCE_ID = "geo_susu_vosk_answer"
    }
}
