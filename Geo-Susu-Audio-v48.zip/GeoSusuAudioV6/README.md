# Geo Susu Audio v48

## Arreglo del escuchador IA audio
- IA audio ya no responde siempre "Gemini escuchando".
- Ahora funciona en 2 pasos:
  1. Gemini transcribe el audio y muestra lo que entendió.
  2. La app responde según el modo seleccionado: TXT, NET o IA.
- IA audio ahora sirve también para TXT y NET si hay API Gemini.
- Si no hay API, cambia automáticamente a escucha normal.

## Modelo de audio
- Para audio usa gemini-3.5-flash, recomendado en la documentación de audio de Gemini.
- Para texto usa gemini-2.5-flash-lite.

## Mejoras
- Detecta mejor inicio/fin de voz.
- Espera más silencio antes de cortar la pregunta.
- Evita procesar ruido muy pequeño.
- Muestra la pregunta transcrita en “Te escuché”.
- Funciona con pantalla apagada como servicio en primer plano.

## Uso recomendado
- Pega API Gemini en AJUSTES.
- En Modo escucha elige IA audio.
- Para respuesta:
  - TXT si quieres usar tus respuestas guardadas.
  - IA si quieres que Gemini responda.
  - NET queda como alternativa.
