package com.bph.geosusuaudio

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiAnswerProvider(private val context: Context) {

    fun fetchAnswer(question: String): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()
        if (apiKey.isBlank()) return missingKeyResult()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", buildPrompt(question)))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.15)
                    .put("topP", 0.8)
                    .put("maxOutputTokens", 90)
            )

        return postGemini(TEXT_MODEL, body)
    }

    fun fetchAnswerFromAudio(wavBytes: ByteArray): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()
        if (apiKey.isBlank()) return missingKeyResult()

        val audioBase64 = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val prompt = """
Escucha el audio, entiende la pregunta y responde directamente.
Responde como estudiante de Explotación Minera.
Máximo 2 líneas.
Si no entiendes el audio, di: No entendí bien la pregunta.
Si la pregunta es de minería, topografía, geología, seguridad o legislación minera, usa enfoque técnico básico.
""".trimIndent()

        val body = audioBody(prompt, audioBase64, 100)
        return postGemini(AUDIO_MODEL, body)
    }

    fun transcribeAudio(wavBytes: ByteArray): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()
        if (apiKey.isBlank()) return missingKeyResult()

        val audioBase64 = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val prompt = """
Transcribe solo la pregunta hablada en el audio.
Devuelve únicamente el texto de la pregunta en español.
No respondas la pregunta.
No agregues explicación.
Si no entiendes, responde exactamente: NO_ENTENDI
""".trimIndent()

        val body = audioBody(prompt, audioBase64, 60)
        val result = postGemini(AUDIO_MODEL, body)
        val clean = ResponseRepository.normalize(result.text)
        return if (!result.limited && !result.missingKey && (clean.contains("no entendi") || result.text.length < 2)) {
            AiResult("No entendí bien la pregunta. Repite más cerca del micrófono.", false, false)
        } else {
            result
        }
    }

    private fun audioBody(prompt: String, audioBase64: String, maxTokens: Int): JSONObject {
        return JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "audio/wav")
                                        .put("data", audioBase64)
                                )
                            )
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.05)
                    .put("topP", 0.8)
                    .put("maxOutputTokens", maxTokens)
            )
    }

    private fun buildPrompt(question: String): String {
        return """
Responde como estudiante de Explotación Minera.
Da una respuesta corta, clara y directa.
Máximo 2 líneas.
Si la pregunta es de minería, topografía, geología, seguridad o legislación minera, responde con enfoque técnico básico.
No inventes datos raros; si no sabes, dilo simple.

Pregunta: ${question.trim()}
""".trimIndent()
    }

    private fun postGemini(model: String, body: JSONObject): AiResult {
        val apiKey = AppSettings(context).getGeminiApiKey()

        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 12000
            connection.readTimeout = 30000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("x-goog-api-key", apiKey)
            connection.doOutput = true

            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val raw = if (code in 200..299) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            }

            when (code) {
                200 -> {
                    val answer = parseAnswer(raw)
                    AiResult(
                        text = cleanAnswer(answer).ifBlank { "IA no devolvió una respuesta clara." },
                        limited = false,
                        missingKey = false
                    )
                }
                400, 401, 403 -> AiResult(
                    text = "API key inválida, sin permiso o modelo no disponible. Revisa tu API key.",
                    limited = false,
                    missingKey = true
                )
                429 -> AiResult(
                    text = "Límite IA alcanzado. Usa TXT o cambia API key.",
                    limited = true,
                    missingKey = false
                )
                else -> AiResult(
                    text = "IA no respondió bien. Código $code.",
                    limited = false,
                    missingKey = false
                )
            }
        } catch (_: Exception) {
            AiResult(
                text = "No pude conectar con IA. Revisa internet o API key.",
                limited = false,
                missingKey = false
            )
        }
    }

    private fun parseAnswer(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""

        val content = candidates.optJSONObject(0)
            ?.optJSONObject("content")
            ?: return ""

        val parts = content.optJSONArray("parts") ?: return ""
        val out = StringBuilder()

        for (i in 0 until parts.length()) {
            val text = parts.optJSONObject(i)?.optString("text").orEmpty()
            if (text.isNotBlank()) {
                if (out.isNotBlank()) out.append(" ")
                out.append(text)
            }
        }

        return out.toString()
    }

    private fun cleanAnswer(value: String): String {
        val clean = value
            .replace("\\s+".toRegex(), " ")
            .trim()
            .removePrefix("Respuesta:")
            .trim()

        return if (clean.length > 260) clean.take(257).trim() + "..." else clean
    }

    private fun missingKeyResult(): AiResult {
        return AiResult(
            text = "Falta API key de Gemini. En Ajustes pega tu API key.",
            limited = false,
            missingKey = true
        )
    }

    data class AiResult(
        val text: String,
        val limited: Boolean,
        val missingKey: Boolean
    )

    companion object {
        private const val TEXT_MODEL = "gemini-2.5-flash-lite"
        private const val AUDIO_MODEL = "gemini-3.5-flash"
    }
}
