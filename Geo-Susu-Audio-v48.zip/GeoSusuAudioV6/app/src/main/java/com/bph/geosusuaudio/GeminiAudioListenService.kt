package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class GeminiAudioListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var appSettings: AppSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private val geminiProvider by lazy { GeminiAnswerProvider(this) }
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private var audioRecord: AudioRecord? = null
    private var listenThread: Thread? = null
    private var tts: TextToSpeech? = null
    private var acousticEchoCanceler: AcousticEchoCanceler? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var processing = false
    @Volatile private var isSpeaking = false

    private var lastLevelUpdate = 0L
    private var lastStatusTime = 0L
    private var highPassPrevInput = 0f
    private var highPassPrevOutput = 0f

    override fun onCreate() {
        super.onCreate()
        appSettings = AppSettings(this)
        modeSettings = AnswerModeSettings(this)
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("IA audio activa"))
        if (!running) startAudioLoop()
        return START_STICKY
    }

    private fun startAudioLoop() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "", 0)
            stopSelf()
            return
        }

        if (!appSettings.hasGeminiApiKey()) {
            sendUpdate("Falta API Gemini", "", "Pega tu API key o usa Google preciso/Vosk.", 0)
            stopSelf()
            return
        }

        val sampleRate = 16000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuffer, 4096)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            sendUpdate("No se pudo abrir micrófono IA", "", "Revisa permisos o cierra otra app que use micrófono.", 0)
            stopSelf()
            return
        }

        setupAudioEffects(audioRecord?.audioSessionId ?: 0)

        running = true
        startRecordingSafely()
        sendUpdate("IA audio escuchando con pantalla apagada", "", "Pregunta cuando quieras.", 0)

        listenThread = Thread {
            val buffer = ByteArray(bufferSize)
            val segment = ByteArrayOutputStream()
            var capturing = false
            var voiceStartedAt = 0L
            var lastVoiceAt = 0L
            var lastSegmentAt = 0L
            var voiceFrames = 0
            var maxLevel = 0

            while (running) {
                try {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read <= 0) {
                        Thread.sleep(50)
                        continue
                    }

                    cleanAndBoostAudio(buffer, read)
                    val level = calculateLevel(buffer, read)
                    sendLevel(level)

                    if (processing || isSpeaking) continue

                    val now = System.currentTimeMillis()
                    val hasVoice = level >= voiceThreshold()

                    if (hasVoice) {
                        if (!capturing) {
                            capturing = true
                            voiceStartedAt = now
                            segment.reset()
                            voiceFrames = 0
                            maxLevel = 0
                            sendUpdate("Te escucho con IA audio...", "", "", level)
                        }
                        voiceFrames++
                        maxLevel = maxOf(maxLevel, level)
                        lastVoiceAt = now
                    }

                    if (capturing) {
                        segment.write(buffer, 0, read)
                    } else if (now - lastStatusTime > 3500) {
                        lastStatusTime = now
                        sendUpdate("IA audio lista. Pregunta cuando quieras.", "", "", level)
                    }

                    val durationMs = now - voiceStartedAt
                    val silenceMs = now - lastVoiceAt
                    val enoughAudio = durationMs >= 1200 && voiceFrames >= 3 && maxLevel >= voiceThreshold() + 2
                    val finishedBySilence = capturing && enoughAudio && silenceMs >= 1700
                    val finishedByMax = capturing && durationMs >= 12000

                    if ((finishedBySilence || finishedByMax) && now - lastSegmentAt > 3000) {
                        lastSegmentAt = now
                        capturing = false
                        val pcm = segment.toByteArray()
                        segment.reset()

                        if (pcm.size > sampleRate * 2) {
                            processAudioSegment(pcm, sampleRate)
                        }
                    }
                } catch (_: Exception) {
                    sendUpdate("Recuperando IA audio...", "", "", -1)
                    Thread.sleep(250)
                }
            }
        }.apply {
            name = "GeoSusuGeminiAudioLoop"
            start()
        }
    }

    private fun processAudioSegment(pcm: ByteArray, sampleRate: Int) {
        processing = true
        stopRecordingSafely()
        sendUpdate("Transcribiendo audio con IA...", "Audio capturado", "Entendiendo tu pregunta.", -1)

        Thread {
            val wav = makeWav(pcm, sampleRate)
            val transcript = geminiProvider.transcribeAudio(wav)

            if (transcript.limited || transcript.missingKey || transcript.text.startsWith("No entendí")) {
                handler.post {
                    sendUpdate("No entendí bien", "Audio capturado", transcript.text, -1)
                    speakTracked(transcript.text)
                }
                return@Thread
            }

            val question = transcript.text.trim()
            val answer = answerBySelectedMode(question)

            memory.saveLast(question, answer, "gemini_audio", 0)
            handler.post {
                sendUpdate("Respuesta lista", question, answer, -1)
                speakTracked(answer)
            }
        }.start()
    }

    private fun answerBySelectedMode(question: String): String {
        return when (modeSettings.getMode()) {
            AnswerModeSettings.Mode.INTERNET -> {
                try {
                    onlineProvider.fetchShortAnswer(question)
                } catch (_: Exception) {
                    "No encontré respuesta online. Prueba en TXT o IA."
                }
            }

            AnswerModeSettings.Mode.AI -> {
                val local = repository.findBest(question)
                val result = geminiProvider.fetchAnswer(question)
                if (result.limited && local.itemId != "none") {
                    "Límite IA alcanzado. TXT: ${local.answer}"
                } else {
                    result.text
                }
            }

            else -> {
                repository.findBestResponse(question)
            }
        }
    }

    private fun setupAudioEffects(sessionId: Int) {
        if (sessionId <= 0) return

        try {
            if (AcousticEchoCanceler.isAvailable()) {
                acousticEchoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {
        }

        try {
            if (AutomaticGainControl.isAvailable()) {
                automaticGainControl = AutomaticGainControl.create(sessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {
        }

        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanAndBoostAudio(buffer: ByteArray, read: Int) {
        val gain = if (appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER) 4.6f else 2.0f
        val cleaner = appSettings.getNoiseCleaner()
        val softGate = if (cleaner == AppSettings.NoiseCleaner.STRONG) 48 else 36
        val gateFactor = if (cleaner == AppSettings.NoiseCleaner.STRONG) 0.74f else 0.84f
        val highPassAlpha = if (cleaner == AppSettings.NoiseCleaner.STRONG) 0.982f else 0.988f

        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()

            val highPassed = sample - highPassPrevInput + highPassAlpha * highPassPrevOutput
            highPassPrevInput = sample.toFloat()
            highPassPrevOutput = highPassed

            var cleaned = highPassed
            if (abs(cleaned) < softGate) cleaned *= gateFactor

            var boosted = cleaned * gain
            val absBoosted = abs(boosted)
            if (absBoosted > 26000f) {
                boosted = if (boosted > 0) 26000f + (absBoosted - 26000f) * 0.16f
                else -26000f - (absBoosted - 26000f) * 0.16f
            }

            val out = boosted.toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()

            buffer[i] = (out.toInt() and 0xFF).toByte()
            buffer[i + 1] = ((out.toInt() shr 8) and 0xFF).toByte()
            i += 2
        }
    }

    private fun voiceThreshold(): Int {
        return if (appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER) 9 else 14
    }

    private fun calculateLevel(buffer: ByteArray, read: Int): Int {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()
            sum += (sample * sample).toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0
        val rms = sqrt(sum / count)
        return ((rms / 32768.0) * 100.0 * 8.5).toInt().coerceIn(0, 100)
    }

    private fun makeWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val totalDataLen = pcm.size + 36
        val byteRate = sampleRate * 2
        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray(Charsets.US_ASCII))
        out.write(intLE(totalDataLen))
        out.write("WAVE".toByteArray(Charsets.US_ASCII))
        out.write("fmt ".toByteArray(Charsets.US_ASCII))
        out.write(intLE(16))
        out.write(shortLE(1))
        out.write(shortLE(1))
        out.write(intLE(sampleRate))
        out.write(intLE(byteRate))
        out.write(shortLE(2))
        out.write(shortLE(16))
        out.write("data".toByteArray(Charsets.US_ASCII))
        out.write(intLE(pcm.size))
        out.write(pcm)
        return out.toByteArray()
    }

    private fun intLE(value: Int): ByteArray {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array()
    }

    private fun shortLE(value: Int): ByteArray {
        return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value.toShort()).array()
    }

    private fun speakTracked(answer: String) {
        isSpeaking = true
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false
            processing = false
            startRecordingSafely()
        }
    }

    private fun sendLevel(level: Int) {
        val now = System.currentTimeMillis()
        if (now - lastLevelUpdate < 220) return
        lastLevelUpdate = now
        sendUpdate("", "", "", level)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun startRecordingSafely() {
        try {
            if (running && audioRecord?.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                audioRecord?.startRecording()
            }
        } catch (_: Exception) {
        }
    }

    private fun stopRecordingSafely() {
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu IA Audio", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu IA Audio activo")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GeminiAudioWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            processing = false
                            startRecordingSafely()
                            sendUpdate("IA audio lista para otra pregunta", "", "", -1)
                        }, 850)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    processing = false
                    startRecordingSafely()
                    sendUpdate("IA audio lista para otra pregunta", "", "", -1)
                }
            })
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (running) {
            try {
                val restart = Intent(applicationContext, GeminiAudioListenService::class.java)
                ContextCompat.startForegroundService(applicationContext, restart)
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        audioRecord?.release()
        acousticEchoCanceler?.release()
        automaticGainControl?.release()
        noiseSuppressor?.release()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GEMINI_AUDIO_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_gemini_audio_channel"
        private const val NOTIFICATION_ID = 3001
        private const val UTTERANCE_ID = "geo_susu_gemini_audio_answer"
    }
}
