# Geo Susu Audio v5

Versión corregida con modo confiable.

## Qué cambió
- Botón **Escuchar ahora**: usa el reconocimiento oficial de Google Speech. Es más confiable que el servicio continuo.
- Si no encuentra respuesta en memoria, usa internet con Wikipedia en español y responde por audio.
- Botón **Modo continuo experimental**: se mantiene, pero Android puede bloquearlo.
- Puedes agregar preguntas dentro de la app con Guardar.
- Puedes probar sin micrófono con Probar texto.

## Cómo usar
1. Conecta Redmi Buds.
2. Conecta Zync Tipo C.
3. Abre la app.
4. Pulsa **Escuchar ahora**.
5. Habla o susurra cerca del micrófono.
6. Si la pregunta no está en memoria, buscará online.

## Dónde meter preguntas
Dentro de la app: sección "Agregar pregunta a la memoria".

Para carga masiva en código:
`app/src/main/assets/respuestas.json`

## Nota honesta
El modo continuo no es 100% confiable en Android. El modo más estable es **Escuchar ahora**.
