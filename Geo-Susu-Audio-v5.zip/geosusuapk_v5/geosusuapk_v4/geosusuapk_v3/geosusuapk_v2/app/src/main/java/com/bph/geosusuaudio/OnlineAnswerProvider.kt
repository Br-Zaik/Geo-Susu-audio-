package com.bph.geosusuaudio

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class OnlineAnswerProvider {

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.isBlank()) return "No entendí la búsqueda."

        val title = searchWikipediaTitle(query)
        if (title.isBlank()) return "No encontré una respuesta online para esa pregunta."

        val summary = fetchWikipediaSummary(title)
        if (summary.isBlank()) return "Encontré el tema, pero no pude leer la respuesta."

        return shorten(summary)
    }

    private fun searchWikipediaTitle(query: String): String {
        val url = "https://es.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=1&srsearch=" +
            URLEncoder.encode(query, "UTF-8")
        val json = get(url)
        val root = JSONObject(json)
        val search = root.getJSONObject("query").getJSONArray("search")
        if (search.length() == 0) return ""
        return search.getJSONObject(0).getString("title")
    }

    private fun fetchWikipediaSummary(title: String): String {
        val url = "https://es.wikipedia.org/api/rest_v1/page/summary/" +
            URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val json = get(url)
        val root = JSONObject(json)
        return root.optString("extract", "")
    }

    private fun get(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("User-Agent", "GeoSusuAudio/1.0 Android")
        return connection.inputStream.bufferedReader().use { it.readText() }
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
        val prefixes = listOf(
            "que es ",
            "que significa ",
            "dime que es ",
            "definicion de ",
            "concepto de ",
            "simbolo quimico de ",
            "simbolo quimico del ",
            "simbolo quimico de la "
        )
        for (prefix in prefixes) {
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }
        return q
    }

    private fun shorten(text: String): String {
        val firstSentence = text.split(". ").firstOrNull()?.trim().orEmpty()
        val candidate = if (firstSentence.length >= 40) firstSentence else text.trim()
        return if (candidate.length > 230) candidate.take(230).trim() + "..." else candidate
    }
}
