package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import kotlin.math.max

class ResponseRepository(private val context: Context) {

    data class QaItem(
        val id: String,
        val tema: String,
        val pregunta: String,
        val respuesta: String,
        val aliases: List<String>
    )

    data class MatchResult(
        val answer: String,
        val itemId: String,
        val score: Int
    )

    private val items: List<QaItem> = loadItems(context)
    val totalItems: Int get() = items.size

    fun findBest(input: String): MatchResult {
        val normalizedInput = normalize(applyCommonCorrections(input))
        if (normalizedInput.isBlank()) return MatchResult(DEFAULT_RESPONSE, "none", 0)

        var bestItem: QaItem? = null
        var bestScore = 0

        for (item in items) {
            val candidates = buildList {
                add(item.id)
                add(item.pregunta)
                add(item.tema)
                addAll(item.aliases)
            }

            val score = candidates.maxOf { candidate ->
                scoreMatch(normalizedInput, normalize(applyCommonCorrections(candidate)))
            }

            if (score > bestScore) {
                bestScore = score
                bestItem = item
            }
        }

        return if (bestScore >= 32 && bestItem != null) {
            MatchResult(bestItem!!.respuesta, bestItem!!.id, bestScore)
        } else {
            MatchResult(DEFAULT_RESPONSE, "none", bestScore)
        }
    }

    fun findBestResponse(input: String): String = findBest(input).answer

    private fun loadItems(context: Context): List<QaItem> {
        val result = mutableListOf<QaItem>()
        result.addAll(readArray(context.assets.open("respuestas.json").bufferedReader().use { it.readText() }))
        result.addAll(readArray(getCustomJson(context)))
        return result
    }

    private fun readArray(json: String): List<QaItem> {
        val array = JSONArray(json)
        val result = mutableListOf<QaItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val aliasesArray = obj.optJSONArray("aliases") ?: JSONArray()
            val aliases = mutableListOf<String>()
            for (j in 0 until aliasesArray.length()) {
                aliases.add(aliasesArray.getString(j))
            }
            result.add(
                QaItem(
                    id = obj.optString("id", obj.optString("pregunta", "item_$i")),
                    tema = obj.optString("tema", ""),
                    pregunta = obj.getString("pregunta"),
                    respuesta = obj.getString("respuesta"),
                    aliases = aliases
                )
            )
        }
        return result
    }

    private fun scoreMatch(input: String, candidate: String): Int {
        if (input == candidate) return 100
        if (input.contains(candidate) || candidate.contains(input)) return 94

        val inputWords = input.split(" ").filter { it.isNotBlank() }
        val candidateWords = candidate.split(" ").filter { it.isNotBlank() }
        val intersection = inputWords.intersect(candidateWords.toSet()).size
        val overlap = if (candidateWords.isNotEmpty()) (intersection * 100) / candidateWords.size else 0

        val keywordBonus = candidateWords.maxOfOrNull { cw ->
            inputWords.maxOfOrNull { iw -> similarityPercent(iw, cw) } ?: 0
        } ?: 0

        val distanceScore = similarityPercent(input, candidate)
        return max(max(overlap, keywordBonus), distanceScore)
    }

    private fun similarityPercent(a: String, b: String): Int {
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = max(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }

    private fun applyCommonCorrections(text: String): String {
        var output = normalize(text)
        val corrections = mapOf(
            "gaga" to "ganga",
            "aga" to "ganga",
            "canga" to "ganga",
            "mema" to "mena",
            "me na" to "mena",
            "mina" to "mena",
            "kateo" to "cateo",
            "cateu" to "cateo",
            "cuota de geologo" to "picota de geologo",
            "picota de solomo" to "picota de geologo",
            "tipos de loca" to "tipos de roca",
            "loca" to "roca"
        )
        for ((bad, good) in corrections) {
            output = output.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }
        return output
    }

    companion object {
        private const val DEFAULT_RESPONSE = "No la reconocí bien. Repite solo la palabra clave."
        private const val PREFS = "geo_susu_memory"
        private const val CUSTOM_ITEMS = "custom_items"

        fun saveCustomItem(context: Context, pregunta: String, aliasesRaw: String, respuesta: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")

            val aliases = JSONArray()
            pregunta.split(" ").filter { it.isNotBlank() }.forEach { aliases.put(it) }
            aliasesRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { aliases.put(it) }

            val item = JSONObject()
                .put("id", "custom_${System.currentTimeMillis()}")
                .put("tema", "Personalizado")
                .put("pregunta", pregunta)
                .put("respuesta", respuesta)
                .put("aliases", aliases)

            array.put(item)
            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return array.length()
        }

        fun getCustomJson(context: Context): String {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(CUSTOM_ITEMS, "[]") ?: "[]"
        }

        fun normalize(text: String): String {
            return Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
                .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
                .replace("[^a-z0-9ñ ]".toRegex(), " ")
                .replace("\\s+".toRegex(), " ")
                .trim()
        }
    }
}
