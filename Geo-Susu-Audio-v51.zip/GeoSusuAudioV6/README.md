# Geo Susu Audio v51

## Sherpa ONNX experimental
- Se agregó motor de escucha Sherpa ONNX.
- Sherpa queda como motor principal para probar susurros.
- Vosk queda como respaldo.
- Se mantiene solo TXT y NET.
- No hay IA, no hay Gemini y no hay micrófono Google.

## Descarga offline
En AJUSTES puedes elegir motor:
- Sherpa ONNX pesado
- Vosk respaldo

Si está seleccionado Sherpa, el botón DESCARGAR OFFLINE baja:
- encoder_model.ort
- decoder_model_merged.ort
- tokens.txt

Modelo usado:
csukuangfj2/sherpa-onnx-moonshine-base-es-quantized-2026-02-27

## Importante
Sherpa pesa más y puede tardar más en cargar/procesar, pero debería reconocer mejor frases en español que Vosk.
Si Sherpa no carga en el celular, cambia motor a Vosk y seguimos con Whisper.cpp después.
