package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class SherpaListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private lateinit var modelManager: SherpaModelManager
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private var bridge: SherpaRecognizerBridge? = null
    private var audioRecord: AudioRecord? = null
    private var listenThread: Thread? = null
    private var tts: TextToSpeech? = null
    private var acousticEchoCanceler: AcousticEchoCanceler? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var processing = false
    @Volatile private var isSpeaking = false
    @Volatile private var pausedByCommand = false

    private var lastAnswered = ""
    private var lastAnswerTime = 0L
    private var lastLevelUpdate = 0L
    private var lastSpokenNormalized = ""
    private var highPassPrevInput = 0f
    private var highPassPrevOutput = 0f

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modelManager = SherpaModelManager(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Sherpa activo"))
        if (!running) startSherpaLoop()
        return START_STICKY
    }

    private fun startSherpaLoop() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "", 0)
            stopSelf()
            return
        }

        if (!modelManager.isReady()) {
            sendUpdate("Falta modelo Sherpa", "", "Pulsa DESCARGAR OFFLINE para bajar Sherpa.", 0)
            stopSelf()
            return
        }

        sendUpdate("Cargando Sherpa...", "", "Espera unos segundos.", -1)
        bridge = SherpaRecognizerBridge(modelManager.getModelDir())
        if (bridge?.init() != true) {
            sendUpdate("Sherpa no cargó", "", "Usa Vosk o revisa compilación Sherpa.", -1)
            stopSelf()
            return
        }

        val sampleRate = SherpaRecognizerBridge.SAMPLE_RATE
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuffer, 4096)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            sendUpdate("No se pudo abrir micrófono", "", "Cierra otra app que use micrófono.", 0)
            stopSelf()
            return
        }

        setupAudioEffects(audioRecord?.audioSessionId ?: 0)
        running = true
        startRecordingSafely()
        sendUpdate("Sherpa escuchando offline", "", "Habla o susurra cerca del micrófono.", 0)

        listenThread = Thread {
            val buffer = ByteArray(bufferSize)
            val segment = ByteArrayOutputStream()
            var capturing = false
            var voiceStartedAt = 0L
            var lastVoiceAt = 0L
            var lastSegmentAt = 0L
            var maxLevel = 0
            var voiceFrames = 0

            while (running) {
                try {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read <= 0) {
                        Thread.sleep(40)
                        continue
                    }

                    cleanAndBoostAudio(buffer, read)
                    val level = calculateLevel(buffer, read)
                    sendLevel(level)

                    if (processing || isSpeaking || pausedByCommand) continue

                    val now = System.currentTimeMillis()
                    val hasVoice = level >= voiceThreshold()

                    if (hasVoice) {
                        if (!capturing) {
                            capturing = true
                            voiceStartedAt = now
                            segment.reset()
                            maxLevel = 0
                            voiceFrames = 0
                            sendUpdate("Sherpa te escucha...", "", "", level)
                        }

                        lastVoiceAt = now
                        maxLevel = maxOf(maxLevel, level)
                        voiceFrames++
                    }

                    if (capturing) {
                        segment.write(buffer, 0, read)
                    }

                    val durationMs = now - voiceStartedAt
                    val silenceMs = now - lastVoiceAt
                    val enoughAudio = durationMs >= 900 && voiceFrames >= 3 && maxLevel >= voiceThreshold() + 1
                    val finishedBySilence = capturing && enoughAudio && silenceMs >= 1450
                    val finishedByMax = capturing && durationMs >= 11000

                    if ((finishedBySilence || finishedByMax) && now - lastSegmentAt > 2600) {
                        lastSegmentAt = now
                        capturing = false
                        val pcm = segment.toByteArray()
                        segment.reset()

                        if (pcm.size > sampleRate * 2) {
                            processSegment(pcm)
                        }
                    }
                } catch (_: Exception) {
                    sendUpdate("Recuperando Sherpa...", "", "", -1)
                    Thread.sleep(250)
                }
            }
        }.apply {
            name = "GeoSusuSherpaLoop"
            start()
        }
    }

    private fun processSegment(pcm: ByteArray) {
        processing = true
        stopRecordingSafely()
        sendUpdate("Sherpa procesando...", "", "", -1)

        Thread {
            val samples = pcmToFloatArray(pcm)
            val heard = bridge?.recognize(samples).orEmpty()
                .replace("\\s+".toRegex(), " ")
                .trim()

            handler.post {
                if (heard.length < 2) {
                    sendUpdate("No entendí bien", "", "Repite más cerca del micrófono.", -1)
                    speakThenRestart("No entendí bien. Repite más cerca.")
                } else {
                    handleQuestion(heard)
                }
            }
        }.start()
    }

    private fun handleQuestion(questionRaw: String) {
        val question = questionRaw.trim()
        val normalized = ResponseRepository.normalize(question)

        if (commandSettings.isToggleCommand(question)) {
            pausedByCommand = !pausedByCommand
            val answer = if (pausedByCommand) "Pausado." else "Reanudado."
            sendUpdate(if (pausedByCommand) "Pausado" else "Reanudado", question, answer, -1)
            speakThenRestart(answer)
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            finishProcessing()
            return
        }

        val now = System.currentTimeMillis()
        if (normalized == lastAnswered && now - lastAnswerTime < 6500) {
            finishProcessing()
            return
        }

        lastAnswered = normalized
        lastAnswerTime = now

        when (modeSettings.getMode()) {
            AnswerModeSettings.Mode.INTERNET -> answerOnline(question)
            else -> {
                val match = repository.findBest(question)
                answerLocal(question, match)
            }
        }
    }

    private fun answerLocal(question: String, match: ResponseRepository.MatchResult) {
        memory.saveLast(question, match.answer, match.itemId, match.score)
        sendUpdate("Respuesta TXT", question, match.answer, -1)
        speakThenRestart(match.answer)
    }

    private fun answerOnline(question: String) {
        sendUpdate("Buscando NET...", question, "", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré respuesta en NET. Agrégala al TXT."
            }

            memory.saveLast(question, answer, "wikipedia", 0)
            handler.post {
                sendUpdate("Respuesta NET", question, answer, -1)
                speakThenRestart(answer)
            }
        }.start()
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val q = ResponseRepository.normalize(question)
        val a = lastSpokenNormalized
        if (q.isBlank() || a.isBlank()) return false
        if (a.contains(q) && q.length >= 8) return true

        val qWords = q.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val aWords = a.split(" ").toSet()
        val common = qWords.count { it in aWords }
        return common >= 4 && common >= qWords.size * 0.65
    }

    private fun speakThenRestart(answer: String) {
        isSpeaking = true
        lastSpokenNormalized = ResponseRepository.normalize(answer)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) finishProcessing()
    }

    private fun finishProcessing() {
        processing = false
        isSpeaking = false
        startRecordingSafely()
        sendUpdate("Sherpa listo", "", "", -1)
    }

    private fun pcmToFloatArray(pcm: ByteArray): FloatArray {
        val samples = FloatArray(pcm.size / 2)
        var i = 0
        var j = 0
        while (i + 1 < pcm.size) {
            val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort()
            samples[j] = s / 32768.0f
            i += 2
            j++
        }
        return samples
    }

    private fun setupAudioEffects(sessionId: Int) {
        if (sessionId <= 0) return
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                acousticEchoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {
        }
        try {
            if (AutomaticGainControl.isAvailable()) {
                automaticGainControl = AutomaticGainControl.create(sessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {
        }
        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanAndBoostAudio(buffer: ByteArray, read: Int) {
        val gain = if (appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER) 5.0f else 2.2f
        val cleaner = appSettings.getNoiseCleaner()
        val softGate = if (cleaner == AppSettings.NoiseCleaner.STRONG) 34 else 24
        val gateFactor = if (cleaner == AppSettings.NoiseCleaner.STRONG) 0.78f else 0.88f
        val highPassAlpha = if (cleaner == AppSettings.NoiseCleaner.STRONG) 0.982f else 0.988f

        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()

            val highPassed = sample - highPassPrevInput + highPassAlpha * highPassPrevOutput
            highPassPrevInput = sample.toFloat()
            highPassPrevOutput = highPassed

            var cleaned = highPassed
            if (abs(cleaned) < softGate) cleaned *= gateFactor

            var boosted = cleaned * gain
            val absBoosted = abs(boosted)
            if (absBoosted > 26000f) {
                boosted = if (boosted > 0) 26000f + (absBoosted - 26000f) * 0.14f
                else -26000f - (absBoosted - 26000f) * 0.14f
            }

            val out = boosted.toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()

            buffer[i] = (out.toInt() and 0xFF).toByte()
            buffer[i + 1] = ((out.toInt() shr 8) and 0xFF).toByte()
            i += 2
        }
    }

    private fun voiceThreshold(): Int {
        return if (appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER) 8 else 13
    }

    private fun calculateLevel(buffer: ByteArray, read: Int): Int {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()
            sum += (sample * sample).toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0
        val rms = sqrt(sum / count)
        return ((rms / 32768.0) * 100.0 * 9.0).toInt().coerceIn(0, 100)
    }

    private fun sendLevel(level: Int) {
        val now = System.currentTimeMillis()
        if (now - lastLevelUpdate < 220) return
        lastLevelUpdate = now
        sendUpdate("", "", "", level)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun startRecordingSafely() {
        try {
            if (running && audioRecord?.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                audioRecord?.startRecording()
            }
        } catch (_: Exception) {
        }
    }

    private fun stopRecordingSafely() {
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu Sherpa", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Sherpa activo")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::SherpaWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({ finishProcessing() }, 700)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    finishProcessing()
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        audioRecord?.release()
        bridge?.release()
        acousticEchoCanceler?.release()
        automaticGainControl?.release()
        noiseSuppressor?.release()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.SHERPA_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_sherpa_channel"
        private const val NOTIFICATION_ID = 4001
        private const val UTTERANCE_ID = "geo_susu_sherpa_answer"
    }
}
