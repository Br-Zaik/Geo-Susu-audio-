package com.bph.geosusuaudio

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class SherpaModelManager(private val context: Context) {
    private val modelDir: File = File(context.filesDir, "sherpa/moonshine_es")

    fun isReady(): Boolean {
        return File(modelDir, "encoder_model.ort").length() > 1024 * 1024 &&
            File(modelDir, "decoder_model_merged.ort").length() > 1024 * 1024 &&
            File(modelDir, "tokens.txt").length() > 100
    }

    fun getModelDir(): File = modelDir

    fun download(
        onProgress: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        Thread {
            try {
                modelDir.mkdirs()
                FILES.forEachIndexed { index, item ->
                    val target = File(modelDir, item.name)
                    onProgress("Sherpa ${index + 1}/${FILES.size}: descargando ${item.name}...")
                    downloadFile(item.url, target, onProgress)
                }

                if (isReady()) {
                    onDone(true, "Sherpa listo. Ahora escucha mejor que Vosk para frases.")
                } else {
                    onDone(false, "Sherpa no quedó completo. Repite descarga con buen internet.")
                }
            } catch (_: Exception) {
                onDone(false, "No se pudo descargar Sherpa. Revisa internet y espacio.")
            }
        }.start()
    }

    private fun downloadFile(urlText: String, target: File, onProgress: (String) -> Unit) {
        if (target.exists() && target.length() > 1024) return

        val tmp = File(target.parentFile, target.name + ".tmp")
        if (tmp.exists()) tmp.delete()

        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 60000
        connection.setRequestProperty("User-Agent", "GeoSusuAudio/1.0 Android")
        connection.instanceFollowRedirects = true

        val total = connection.contentLengthLong
        var readTotal = 0L
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

        connection.inputStream.use { input ->
            tmp.outputStream().use { output ->
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                    readTotal += read

                    if (total > 0) {
                        val pct = ((readTotal * 100) / total).coerceIn(0, 100)
                        if (pct % 10L == 0L) {
                            onProgress("Sherpa ${target.name}: $pct%")
                        }
                    }
                }
            }
        }

        if (target.exists()) target.delete()
        tmp.renameTo(target)
    }

    companion object {
        private data class ModelFile(val name: String, val url: String)

        private const val BASE_URL =
            "https://huggingface.co/csukuangfj2/sherpa-onnx-moonshine-base-es-quantized-2026-02-27/resolve/main"

        private val FILES = listOf(
            ModelFile("encoder_model.ort", "$BASE_URL/encoder_model.ort?download=true"),
            ModelFile("decoder_model_merged.ort", "$BASE_URL/decoder_model_merged.ort?download=true"),
            ModelFile("tokens.txt", "$BASE_URL/tokens.txt?download=true")
        )
    }
}
