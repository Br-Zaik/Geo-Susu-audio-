package com.bph.geosusuaudio

import android.content.res.AssetManager
import java.io.File

class SherpaRecognizerBridge(private val modelDir: File) {

    private var recognizer: Any? = null

    fun init(): Boolean {
        return try {
            val featureConfigClass = Class.forName("com.k2fsa.sherpa.onnx.FeatureConfig")
            val moonshineClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineMoonshineModelConfig")
            val modelConfigClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineModelConfig")
            val recognizerConfigClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineRecognizerConfig")
            val recognizerClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineRecognizer")

            val feat = featureConfigClass.getDeclaredConstructor().newInstance()
            callSetter(feat, "setSampleRate", Int::class.javaPrimitiveType, SAMPLE_RATE)
            callSetter(feat, "setFeatureDim", Int::class.javaPrimitiveType, 80)

            val moonshine = moonshineClass.getDeclaredConstructor().newInstance()
            callSetter(moonshine, "setEncoder", String::class.java, File(modelDir, "encoder_model.ort").absolutePath)
            callSetter(
                moonshine,
                "setMergedDecoder",
                String::class.java,
                File(modelDir, "decoder_model_merged.ort").absolutePath
            )

            val modelConfig = modelConfigClass.getDeclaredConstructor().newInstance()
            callSetter(modelConfig, "setMoonshine", moonshineClass, moonshine)
            callSetter(modelConfig, "setTokens", String::class.java, File(modelDir, "tokens.txt").absolutePath)
            callSetter(modelConfig, "setNumThreads", Int::class.javaPrimitiveType, 2)

            val config = recognizerConfigClass.getDeclaredConstructor().newInstance()
            callSetter(config, "setFeatConfig", featureConfigClass, feat)
            callSetter(config, "setModelConfig", modelConfigClass, modelConfig)

            recognizer = recognizerClass
                .getConstructor(AssetManager::class.java, recognizerConfigClass)
                .newInstance(null, config)

            true
        } catch (_: Exception) {
            false
        }
    }

    fun recognize(samples: FloatArray): String {
        val rec = recognizer ?: return ""

        return try {
            val stream = rec.javaClass.getMethod("createStream").invoke(rec)
            stream.javaClass
                .getMethod("acceptWaveform", FloatArray::class.java, Int::class.javaPrimitiveType)
                .invoke(stream, samples, SAMPLE_RATE)

            rec.javaClass.getMethod("decode", stream.javaClass).invoke(rec, stream)
            val result = rec.javaClass.getMethod("getResult", stream.javaClass).invoke(rec, stream)
            val text = result?.javaClass?.getMethod("getText")?.invoke(result)?.toString().orEmpty()

            try {
                stream.javaClass.getMethod("release").invoke(stream)
            } catch (_: Exception) {
            }

            text.trim()
        } catch (_: Exception) {
            ""
        }
    }

    fun release() {
        try {
            recognizer?.javaClass?.getMethod("release")?.invoke(recognizer)
        } catch (_: Exception) {
        }
        recognizer = null
    }

    private fun callSetter(target: Any, method: String, type: Class<*>?, value: Any) {
        target.javaClass.getMethod(method, type).invoke(target, value)
    }

    companion object {
        const val SAMPLE_RATE = 16000
    }
}
