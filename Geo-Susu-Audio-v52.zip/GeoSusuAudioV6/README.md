# Geo Susu Audio v52

## Sherpa fuera, Whisper.cpp dentro
- Sherpa no cargó en el celular, por eso se reemplazó por Whisper.cpp.
- Whisper.cpp queda como motor principal.
- Vosk queda como respaldo.
- Se mantiene solo TXT y NET.
- Sin IA, sin Gemini y sin micrófono Google.

## Descarga offline
En AJUSTES puedes elegir motor:
- Whisper.cpp pesado
- Vosk respaldo

Si está seleccionado Whisper, DESCARGAR OFFLINE baja:
- ggml-base.bin (~140 MB)

## Uso
1. Ajustes > Motor escucha > Whisper.cpp pesado.
2. Descargar offline.
3. Escuchar.
4. Probar susurro cerca del Zync.

## Nota
Whisper puede tardar más en responder porque procesa frases completas, pero debería reconocer mejor que Vosk.
