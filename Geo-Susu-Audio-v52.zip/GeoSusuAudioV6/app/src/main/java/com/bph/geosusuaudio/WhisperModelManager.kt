package com.bph.geosusuaudio

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class WhisperModelManager(private val context: Context) {
    private val modelFile: File = File(context.filesDir, MODEL_NAME)

    fun isReady(): Boolean {
        return modelFile.exists() && modelFile.length() > 70L * 1024L * 1024L
    }

    fun getModelFile(): File = modelFile

    fun download(
        onProgress: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        Thread {
            try {
                onProgress("Whisper: descargando modelo base...")
                downloadFile(MODEL_URL, modelFile, onProgress)

                if (isReady()) {
                    onDone(true, "Whisper listo. Prueba susurros cerca del Zync.")
                } else {
                    onDone(false, "Whisper no quedó completo. Repite descarga con buen internet.")
                }
            } catch (_: Exception) {
                onDone(false, "No se pudo descargar Whisper. Revisa internet y espacio.")
            }
        }.start()
    }

    private fun downloadFile(urlText: String, target: File, onProgress: (String) -> Unit) {
        if (target.exists() && target.length() > 70L * 1024L * 1024L) return

        val tmp = File(target.parentFile, target.name + ".tmp")
        if (tmp.exists()) tmp.delete()

        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 90000
        connection.setRequestProperty("User-Agent", "GeoSusuAudio/1.0 Android")
        connection.instanceFollowRedirects = true

        val total = connection.contentLengthLong
        var readTotal = 0L
        var lastPct = -1L
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

        connection.inputStream.use { input ->
            tmp.outputStream().use { output ->
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                    readTotal += read

                    if (total > 0) {
                        val pct = ((readTotal * 100) / total).coerceIn(0, 100)
                        if (pct >= lastPct + 5) {
                            lastPct = pct
                            onProgress("Whisper modelo: $pct%")
                        }
                    } else if (readTotal % (10L * 1024L * 1024L) < buffer.size) {
                        onProgress("Whisper descargado: ${readTotal / 1024L / 1024L} MB")
                    }
                }
            }
        }

        if (target.exists()) target.delete()
        tmp.renameTo(target)
    }

    companion object {
        private const val MODEL_NAME = "ggml-base.bin"
        private const val MODEL_URL =
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin?download=true"
    }
}
