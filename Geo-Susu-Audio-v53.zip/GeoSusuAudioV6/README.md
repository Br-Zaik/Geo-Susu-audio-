# Geo Susu Audio v53

## Versión estable
- Se retiró Whisper.cpp porque la compilación falló en GitHub.
- Se mantiene la app estable con Vosk offline.
- Se mantiene TXT y NET con Wikipedia API.
- Sin IA, sin Gemini, sin Google micrófono.

## Mejora aplicada para susurros
- Más ganancia de micrófono.
- Menor umbral para detectar voz baja.
- Filtro menos agresivo para no cortar susurros.
- Vosk sigue siendo el motor estable.

## Uso recomendado
1. Ajustes > Sensibilidad micrófono > Susurro / voz baja.
2. Ajustes > Limpiador de ruido > Fuerte.
3. Descargar offline.
4. Usar TXT como principal.
