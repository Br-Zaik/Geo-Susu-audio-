# Geo Susu Audio v54

## Corrección
- Vosk offline sí necesita modelo. Sin modelo no puede escuchar.
- Ahora al tocar ESCUCHAR, si falta el modelo, la app lo descarga automáticamente.
- Ya no solo muestra “descargar offline”.
- Si el modelo quedó incompleto o dañado, se borra y pide descargar otra vez.
- Se mejoró validación del modelo para evitar cierres por carpeta incompleta.
- Se mantiene TXT y NET con Wikipedia API.
- Sin IA, sin Gemini, sin Google.

## Uso
1. Abre la app.
2. Toca ESCUCHAR.
3. Si falta modelo, espera la descarga.
4. Cuando diga Modelo Vosk listo, toca ESCUCHAR otra vez si no inicia solo.
