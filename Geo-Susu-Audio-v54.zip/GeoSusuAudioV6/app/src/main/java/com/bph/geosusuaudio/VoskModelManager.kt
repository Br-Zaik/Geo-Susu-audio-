package com.bph.geosusuaudio

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class VoskModelManager(private val context: Context) {

    private val modelName = "vosk-model-small-es-0.42"
    private val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"

    fun modelDir(): File = File(context.filesDir, modelName)

    fun isReady(): Boolean {
        val dir = modelDir()
        val finalMdl = File(dir, "am/final.mdl")
        val modelConf = File(dir, "conf/model.conf")
        val graph = File(dir, "graph/HCLG.fst")

        return dir.exists() &&
            finalMdl.exists() && finalMdl.length() > 1024L * 1024L &&
            modelConf.exists() && modelConf.length() > 100L &&
            graph.exists() && graph.length() > 1024L * 1024L
    }

    fun deleteModel() {
        try {
            modelDir().deleteRecursively()
        } catch (_: Exception) {
        }
    }

    fun downloadAndUnzip(onProgress: (String) -> Unit, onDone: (Boolean, String) -> Unit) {
        Thread {
            try {
                if (isReady()) {
                    onDone(true, "Modelo Vosk ya está listo.")
                    return@Thread
                }

                onProgress("Descargando modelo offline. Pesa aprox. 39 MB...")
                deleteModel()

                val zipFile = File(context.cacheDir, "$modelName.zip")
                if (zipFile.exists()) zipFile.delete()

                download(zipFile, onProgress)

                if (!zipFile.exists() || zipFile.length() < 10L * 1024L * 1024L) {
                    zipFile.delete()
                    onDone(false, "Descarga incompleta. Revisa internet y vuelve a intentar.")
                    return@Thread
                }

                onProgress("Descomprimiendo modelo...")
                unzip(zipFile, context.filesDir)
                zipFile.delete()

                if (isReady()) {
                    onDone(true, "Modelo Vosk listo. Toca ESCUCHAR.")
                } else {
                    deleteModel()
                    onDone(false, "Modelo incompleto. Repite descarga con buen internet.")
                }
            } catch (e: Exception) {
                onDone(false, "Error descargando modelo: ${e.message ?: "sin detalle"}")
            }
        }.start()
    }

    private fun download(target: File, onProgress: (String) -> Unit) {
        val connection = URL(modelUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 60000
        connection.setRequestProperty("User-Agent", "GeoSusuAudio/1.0 Android")
        connection.instanceFollowRedirects = true

        val total = connection.contentLengthLong.takeIf { it > 0 } ?: 1L
        var downloaded = 0L
        var lastPercent = -1

        connection.inputStream.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break

                    output.write(buffer, 0, read)
                    downloaded += read

                    val percent = ((downloaded * 100) / total).toInt().coerceIn(0, 100)
                    if (percent != lastPercent && percent % 5 == 0) {
                        lastPercent = percent
                        onProgress("Descargando modelo: $percent%")
                    }
                }
            }
        }
    }

    private fun unzip(zipFile: File, outputDir: File) {
        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val cleanName = entry.name.replace("\\", "/")
                if (!cleanName.contains("..")) {
                    val outFile = File(outputDir, cleanName)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { output ->
                            zip.copyTo(output)
                        }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }
}
