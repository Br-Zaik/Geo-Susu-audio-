# Geo Susu Audio v55

## Corrección del modelo incompleto
El error venía de una validación demasiado estricta:
- La app buscaba graph/HCLG.fst.
- El modelo español pequeño de Vosk puede venir con graph/HCLr.fst y graph/Gr.fst.
- La descarga podía estar bien, pero la app la marcaba como incompleta.

## Cambios
- Se acepta HCLG.fst o HCLr.fst + Gr.fst.
- Ya no borra el modelo si está descomprimido pero con estructura válida.
- Si aún falta algo, muestra detalle interno para saber qué archivo falta.
- Mantiene TXT y NET con Wikipedia API.
