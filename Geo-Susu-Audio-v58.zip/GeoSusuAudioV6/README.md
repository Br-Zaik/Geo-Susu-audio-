# Geo Susu Audio v58

## Respuesta más rápida para la siguiente pregunta
- Antes la app esperaba varios segundos después de responder.
- Se redujo el tiempo de bloqueo después de hablar.
- Ahora reinicia escucha casi al toque después de terminar la voz.
- Se mantiene la protección mínima contra eco.

## Cambios técnicos
- ignoreUntil bajó de varios segundos a 450 ms.
- Reinicio después de TTS bajó a 120 ms.
- Estado: "Listo. Pregunta de nuevo."

## Recomendación
Usa audífono/Zync para evitar que el micrófono escuche la propia voz de la app.
