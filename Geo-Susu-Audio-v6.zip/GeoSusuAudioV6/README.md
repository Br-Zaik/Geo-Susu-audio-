# Geo Susu Audio v6

Cambio fuerte: esta versión ya no depende de la ventana de Google para el modo principal.

## Qué trae
- Botón Descargar modelo offline Vosk.
- Botón Escuchar continuo Vosk.
- Escucha continua usando Vosk offline.
- Responde por voz.
- Memoria local.
- Guardar preguntas desde la app.
- Google Speech queda solo como respaldo.

## Primer uso
1. Conecta internet.
2. Abre la app.
3. Pulsa Descargar modelo offline Vosk.
4. Espera a que llegue a 100%.
5. Pulsa Escuchar continuo Vosk.
6. Susurra cerca del Zync.

## Importante
El modelo pesa aprox. 39 MB.
Después de descargarlo, funciona sin internet para reconocer voz.
Internet solo queda para búsqueda online si usas el respaldo de Google/texto.

## Limitación honesta
Vosk escucha continuo mejor que Google Speech para este caso, pero los susurros dependen del micrófono y del ruido.
