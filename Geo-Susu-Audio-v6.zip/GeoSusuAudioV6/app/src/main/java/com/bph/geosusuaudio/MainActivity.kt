package com.bph.geosusuaudio

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bph.geosusuaudio.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private val onlineProvider = OnlineAnswerProvider()
    private lateinit var modelManager: VoskModelManager
    private var tts: TextToSpeech? = null

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (modelManager.isReady()) startVoskService() else launchReliableVoice()
        } else {
            binding.tvStatus.text = "Permiso de micrófono denegado"
            binding.tvAnswer.text = "Activa el permiso de micrófono."
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> if (modelManager.isReady()) startVoskService() else startServiceMode() }

    private val reliableVoiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val heard = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                .orEmpty()
            if (heard.isBlank()) {
                binding.tvStatus.text = "No se entendió la voz"
                binding.tvHeard.text = "Sin texto reconocido"
            } else {
                processQuestion(heard, useOnlineFallback = true)
            }
        } else {
            binding.tvStatus.text = "Escucha cancelada o sin resultado"
        }
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val status = intent?.getStringExtra(WhisperListenService.EXTRA_STATUS).orEmpty()
            val heard = intent?.getStringExtra(WhisperListenService.EXTRA_HEARD).orEmpty()
            val answer = intent?.getStringExtra(WhisperListenService.EXTRA_ANSWER).orEmpty()

            if (status.isNotBlank()) binding.tvStatus.text = status
            if (heard.isNotBlank()) binding.tvHeard.text = heard
            if (answer.isNotBlank()) binding.tvAnswer.text = answer
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        tts = TextToSpeech(this, this)

        setupUi()
        refreshRepository()
        binding.tvStatus.text = if (modelManager.isReady()) "Modelo Vosk listo. Pulsa Escuchar continuo Vosk." else "Primero descarga el modelo offline Vosk."
        binding.tvAnswer.text = memory.getSummary()
    }

    private fun setupUi() {
        binding.btnDownloadModel.setOnClickListener {
            binding.tvStatus.text = "Preparando descarga..."
            modelManager.downloadAndUnzip(
                onProgress = { msg -> runOnUiThread { binding.tvStatus.text = msg } },
                onDone = { ok, msg ->
                    runOnUiThread {
                        binding.tvStatus.text = msg
                        binding.tvAnswer.text = if (ok) "Modelo listo. Pulsa Escuchar continuo Vosk." else "No se pudo preparar el modelo."
                    }
                }
            )
        }

        binding.btnStart.setOnClickListener {
            when {
                !hasAudioPermission() -> audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission() ->
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                !modelManager.isReady() -> {
                    binding.tvStatus.text = "Falta modelo offline"
                    binding.tvAnswer.text = "Pulsa Descargar modelo offline Vosk una sola vez."
                }
                else -> startVoskService()
            }
        }

        binding.btnContinuous.setOnClickListener {
            if (!hasAudioPermission()) {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                launchReliableVoice()
            }
        }

        binding.btnStop.setOnClickListener {
            stopService(Intent(this, VoskListenService::class.java))
            stopService(Intent(this, WhisperListenService::class.java))
            binding.tvStatus.text = "Escucha detenida"
            binding.tvAnswer.text = memory.getSummary()
        }

        binding.btnSaveMemory.setOnClickListener {
            val pregunta = binding.etQuestion.text.toString().trim()
            val aliases = binding.etAliases.text.toString().trim()
            val respuesta = binding.etAnswer.text.toString().trim()

            if (pregunta.isBlank() || respuesta.isBlank()) {
                binding.tvStatus.text = "Falta pregunta o respuesta"
                return@setOnClickListener
            }

            val totalCustom = ResponseRepository.saveCustomItem(this, pregunta, aliases, respuesta)
            refreshRepository()
            binding.tvStatus.text = "Guardado en memoria. Personalizadas: $totalCustom"
            binding.tvAnswer.text = "Respuesta guardada: $respuesta"
            binding.etQuestion.text?.clear()
            binding.etAliases.text?.clear()
            binding.etAnswer.text?.clear()
        }

        binding.btnTestText.setOnClickListener {
            val pregunta = binding.etQuestion.text.toString().trim()
            if (pregunta.isBlank()) {
                binding.tvStatus.text = "Escribe una palabra para probar"
                return@setOnClickListener
            }
            processQuestion(pregunta, useOnlineFallback = true)
        }
    }

    private fun startVoskService() {
        val intent = Intent(this, VoskListenService::class.java)
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Vosk continuo iniciado"
        binding.tvAnswer.text = "Ahora escucha sin ventana de Google."
    }

    private fun launchReliableVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla o susurra cerca del micrófono")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        try {
            binding.tvStatus.text = "Abriendo escucha confiable..."
            reliableVoiceLauncher.launch(intent)
        } catch (_: Exception) {
            binding.tvStatus.text = "No hay reconocimiento de voz. Activa Google Speech."
            binding.tvAnswer.text = "Instala o activa Speech Services by Google."
        }
    }

    private fun processQuestion(question: String, useOnlineFallback: Boolean) {
        binding.tvHeard.text = question
        val match = repository.findBest(question)

        if (match.score >= 34 || !useOnlineFallback) {
            showAndSpeak(match.answer, "Memoria local. Score ${match.score}%")
            memory.saveLast(question, match.answer, match.itemId, match.score)
            return
        }

        binding.tvStatus.text = "Buscando online..."
        binding.tvAnswer.text = "Buscando respuesta simple..."

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré respuesta online. Guarda esa pregunta en memoria."
            }

            runOnUiThread {
                showAndSpeak(answer, "Respuesta online")
                memory.saveLast(question, answer, "online", 0)
            }
        }.start()
    }

    private fun showAndSpeak(answer: String, status: String) {
        binding.tvStatus.text = status
        binding.tvAnswer.text = answer
        tts?.stop()
        tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "geo_susu_answer")
    }

    private fun refreshRepository() {
        repository = ResponseRepository(this)
        binding.tvDataInfo.text = "Base cargada: ${repository.totalItems} respuestas. ${memory.getSummary()}"
    }

    private fun startServiceMode() {
        val intent = Intent(this, WhisperListenService::class.java)
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Servicio continuo iniciado. Es experimental."
        binding.tvAnswer.text = "Si falla, usa Escuchar ahora."
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(WhisperListenService.ACTION_UPDATE)
            addAction(VoskListenService.ACTION_UPDATE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(updateReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(updateReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "PE")) ?: TextToSpeech.ERROR
            tts?.setSpeechRate(1.05f)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "La voz en español no está disponible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
    }
}
