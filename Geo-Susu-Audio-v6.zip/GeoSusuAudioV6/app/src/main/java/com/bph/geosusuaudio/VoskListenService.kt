package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

class VoskListenService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private lateinit var modelManager: VoskModelManager
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastAnswered = ""
    private var lastAnswerTime = 0L

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Vosk continuo activo"))
        startVosk()
        return START_STICKY
    }

    private fun startVosk() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "")
            stopSelf()
            return
        }

        if (!modelManager.isReady()) {
            sendUpdate("Falta descargar el modelo Vosk", "", "Pulsa Descargar modelo offline Vosk.")
            stopSelf()
            return
        }

        Thread {
            try {
                sendUpdate("Cargando modelo Vosk...", "", "")
                model = Model(modelManager.modelDir().absolutePath)
                recognizer = Recognizer(model, 16000.0f)
                speechService = SpeechService(recognizer, 16000.0f)
                speechService?.startListening(this)
                sendUpdate("Escucha continua activa. Susurra cerca del Zync.", "", "Esperando pregunta...")
            } catch (e: Exception) {
                sendUpdate("Error iniciando Vosk: ${e.message ?: "sin detalle"}", "", "")
                stopSelf()
            }
        }.start()
    }

    override fun onPartialResult(hypothesis: String?) {
        val text = extractText(hypothesis)
        if (text.isNotBlank()) sendUpdate("Escuchando...", text, "")
    }

    override fun onResult(hypothesis: String?) {
        val text = extractText(hypothesis)
        if (text.isNotBlank()) processText(text)
    }

    override fun onFinalResult(hypothesis: String?) {
        val text = extractText(hypothesis)
        if (text.isNotBlank()) processText(text)
    }

    override fun onError(exception: Exception?) {
        sendUpdate("Error de Vosk: ${exception?.message ?: "sin detalle"}", "", "")
    }

    override fun onTimeout() {
        sendUpdate("Vosk esperando voz...", "", "")
    }

    private fun processText(text: String) {
        val normalized = ResponseRepository.normalize(text)
        val now = System.currentTimeMillis()
        if (normalized == lastAnswered && now - lastAnswerTime < 3500) return

        val match = repository.findBest(text)
        lastAnswered = normalized
        lastAnswerTime = now
        memory.saveLast(text, match.answer, match.itemId, match.score)

        sendUpdate("Memoria local. Score ${match.score}%", text, match.answer)
        speak(match.answer)
    }

    private fun extractText(json: String?): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val obj = JSONObject(json)
            obj.optString("text").ifBlank { obj.optString("partial") }
        } catch (_: Exception) {
            ""
        }
    }

    private fun speak(text: String) {
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vosk_answer")
    }

    private fun sendUpdate(status: String, heard: String, answer: String) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
        }
        sendBroadcast(intent)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu Vosk", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Audio Vosk")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::VoskWakeLock").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(1.05f)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechService?.stop()
        speechService?.shutdown()
        recognizer?.close()
        model?.close()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.VOSK_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        private const val CHANNEL_ID = "geo_susu_vosk_channel"
        private const val NOTIFICATION_ID = 2001
    }
}
