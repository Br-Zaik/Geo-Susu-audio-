# Geo Susu Audio v60

## Corrección fuerte: no responder otra pregunta
Problema:
- Si Vosk escuchaba mal, el TXT podía buscar una palabra parecida y responder otra pregunta.

## Cambios
- En TXT ahora se usa coincidencia estricta.
- Ya no usa parecido/fuzzy para responder.
- Solo responde si encuentra palabra, pregunta o variante exacta en el TXT.
- Si no está seguro, no responde otra pregunta.
- Filtra aliases sueltos peligrosos como "abierto", "mineral", "proceso", etc.
- Las variantes reales siguen funcionando: si agregas "bor ni ta | tajo" o "mena | nena", sí puede reconocerlas.

## Recomendación
Cuando veas que escucha mal una palabra, entra a VARIANTES y agrega esa forma exacta.
Ejemplo:
tajo abierto | bor ni ta, taj abierto
mena | nena, mema, me na
