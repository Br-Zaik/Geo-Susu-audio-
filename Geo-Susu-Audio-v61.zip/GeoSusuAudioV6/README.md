# Geo Susu Audio v61

## Google preciso agregado
- Se agregó motor de escucha "Google preciso".
- Google escucha mejor que Vosk para susurros y frases.
- Vosk queda como respaldo offline.
- Se mantiene TXT y NET.
- Sin IA, sin Gemini.

## Importante
Google preciso no es Google Assistant completo. Usa el reconocimiento de voz de Google/Speech Services.
Puede abrir la ventana del micrófono y necesita que el servicio de Google funcione en el celular.
No es ideal para pantalla apagada como Vosk, pero entiende mejor.

## Uso
1. AJUSTES > Motor escucha > Google preciso.
2. Toca ESCUCHAR.
3. Habla cuando salga el micrófono.
4. La app responde por TXT o NET.
5. Luego reabre Google para la siguiente pregunta.
