# Geo Susu Audio v63

## Modo sin tocar el celular
Se agregó motor:
- Manos libres: Geo + Google

Cómo funciona:
1. Tocas ESCUCHAR una sola vez.
2. La app queda escuchando en segundo plano con Vosk solo para detectar el comando.
3. Dices: geo
4. La app abre Google preciso.
5. Haces tu pregunta.
6. La app responde por TXT o NET.
7. Regresa al modo manos libres esperando otra vez: geo.

## Importante
Android no permite meter Google Assistant completo dentro de una app.
Esta versión usa Vosk como detector de palabra clave y Google Speech para entender la pregunta.

## Motores
- Manos libres: Geo + Google
- Google preciso
- Vosk offline
