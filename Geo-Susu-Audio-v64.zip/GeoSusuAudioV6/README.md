# Geo Susu Audio v64

## Corrección modo manos libres
Problema:
- Al decir "geo", se abría Google desde el estado de fondo y parecía que la app se cerraba.
- Al terminar Google, podía regresar al inicio del celular en vez de volver a Geo Susu.

## Cambios
- Cuando Vosk detecta "geo", ahora primero trae Geo Susu Audio al frente.
- Luego abre Google preciso desde la app.
- Así, al cerrar Google debe volver a Geo Susu Audio.
- Se mantiene modo Manos libres: Geo + Google.
- Se mantiene Vosk como detector y Google para la pregunta.

## Uso
1. Abre Geo Susu Audio.
2. Ajustes > Motor escucha > Manos libres: Geo + Google.
3. Toca ESCUCHAR una vez.
4. Puedes ir al inicio si deseas.
5. Di "geo".
6. La app se abre y lanza Google preciso.
