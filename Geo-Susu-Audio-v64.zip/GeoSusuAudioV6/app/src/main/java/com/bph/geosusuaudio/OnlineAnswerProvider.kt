package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import kotlin.math.min

class OnlineAnswerProvider(private val context: Context? = null) {

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val subject = subjectWords(query).joinToString(" ").ifBlank { query }
        val titles = linkedSetOf<String>()

        titles.add(subject)
        titles.addAll(searchWikipediaTitles(subject))

        for (q in buildWikipediaQueries(query, subject)) {
            titles.addAll(searchWikipediaTitles(q))
        }

        val candidates = titles
            .mapNotNull { title ->
                val extract = fetchWikipediaExtract(title)
                if (extract.isBlank()) null else title to extract
            }
            .map { it.first to it.second to scoreAnswer(query, it.first, it.second) }
            .filter { it.second >= 25 }
            .sortedByDescending { it.second }

        val best = candidates.firstOrNull()?.first?.second ?: ""
        if (best.isNotBlank()) return cleanFinalAnswer(best)

        return "No encontré esa definición en Wikipedia. Agrégala al TXT para respuesta segura."
    }

    private fun buildWikipediaQueries(query: String, subject: String): List<String> {
        val focus = context?.let { AppSettings(it).getNetFocus() } ?: AppSettings.NetFocus.GENERAL
        val list = linkedSetOf<String>()

        if (focus == AppSettings.NetFocus.MINING) {
            list.add("$subject minería")
            list.add("$subject mineria")
            list.add("$subject explotación minera")
            list.add("$subject mineral")
            list.add("$subject geología")
        }

        if (isWeightQuestion(query)) {
            list.add("$subject densidad")
            list.add("$subject peso específico")
        }

        list.add(subject)
        list.add(query)

        return list.filter { it.isNotBlank() }
    }

    private fun searchWikipediaTitles(search: String): List<String> {
        return try {
            val url = "https://es.wikipedia.org/w/api.php?action=query&format=json&list=search" +
                "&utf8=1&srlimit=6&srsearch=" + URLEncoder.encode(search, "UTF-8")
            val raw = get(url)
            val json = JSONObject(raw)
            val arr = json.optJSONObject("query")?.optJSONArray("search") ?: return emptyList()

            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val title = arr.optJSONObject(i)?.optString("title").orEmpty()
                if (title.isNotBlank() && !isBadTitle(title)) out.add(title)
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun fetchWikipediaExtract(title: String): String {
        return try {
            val url = "https://es.wikipedia.org/w/api.php?action=query&format=json&prop=extracts" +
                "&exintro=1&explaintext=1&redirects=1&utf8=1&titles=" +
                URLEncoder.encode(title, "UTF-8")
            val raw = get(url)
            val json = JSONObject(raw)
            val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: return ""

            val keys = pages.keys()
            while (keys.hasNext()) {
                val page = pages.optJSONObject(keys.next()) ?: continue
                val missing = page.has("missing")
                val extract = page.optString("extract").trim()
                if (!missing && extract.isNotBlank() && !isBadAnswer(extract)) return extract
            }
            ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun scoreAnswer(query: String, title: String, extract: String): Int {
        if (isBadAnswer(extract) || isBadTitle(title)) return 0

        val qWords = subjectWords(query)
        val normalizedTitle = ResponseRepository.normalize(title)
        val normalizedExtract = ResponseRepository.normalize(extract)
        val focus = context?.let { AppSettings(it).getNetFocus() } ?: AppSettings.NetFocus.GENERAL

        var score = 0

        for (word in qWords) {
            if (normalizedTitle.contains(word)) score += 35
            if (normalizedExtract.contains(word)) score += 20
        }

        val definitionMarks = listOf(
            " es ", " son ", "se denomina", "se conoce", "consiste", "mineral",
            "roca", "material", "proceso", "actividad", "metal", "residuo",
            "sin valor", "extraer", "extraccion"
        )
        if (definitionMarks.any { normalizedExtract.contains(it) }) score += 20

        if (focus == AppSettings.NetFocus.MINING) {
            val miningMarks = listOf(
                "mineria", "minera", "minero", "mineral", "yacimiento",
                "explotacion", "geologia", "metal", "roca", "mena", "ganga",
                "desmonte", "estéril", "esteril"
            )
            if (miningMarks.any { normalizedExtract.contains(it) || normalizedTitle.contains(it) }) score += 20
        }

        if (passesSpecificFilter(query, normalizedExtract)) score += 20 else score -= 20

        if (extract.length in 50..650) score += 10
        if (extract.length > 1200) score -= 10

        return score.coerceIn(0, 100)
    }

    private fun passesSpecificFilter(query: String, answerNormalized: String): Boolean {
        val subject = subjectWords(query).firstOrNull().orEmpty()

        return when (subject) {
            "mena" -> answerNormalized.contains("mineral") &&
                (answerNormalized.contains("extraer") ||
                    answerNormalized.contains("metal") ||
                    answerNormalized.contains("valor economico") ||
                    answerNormalized.contains("rentable") ||
                    answerNormalized.contains("elemento util"))
            "ganga" -> answerNormalized.contains("material") &&
                (answerNormalized.contains("sin valor") ||
                    answerNormalized.contains("esteril") ||
                    answerNormalized.contains("mena") ||
                    answerNormalized.contains("mineral"))
            "desmonte" -> answerNormalized.contains("material") ||
                answerNormalized.contains("roca") ||
                answerNormalized.contains("residuo") ||
                answerNormalized.contains("extraccion") ||
                answerNormalized.contains("mina")
            "cateo" -> answerNormalized.contains("mineral") ||
                answerNormalized.contains("busqueda") ||
                answerNormalized.contains("exploracion")
            "prospeccion" -> answerNormalized.contains("mineral") ||
                answerNormalized.contains("yacimiento") ||
                answerNormalized.contains("exploracion")
            "iperc" -> answerNormalized.contains("peligro") || answerNormalized.contains("riesgo")
            "epp" -> answerNormalized.contains("proteccion") || answerNormalized.contains("equipo")
            else -> true
        }
    }

    private fun cleanFinalAnswer(extract: String): String {
        val clean = extract
            .replace("\\s+".toRegex(), " ")
            .trim()

        val sentences = clean.split(". ")
            .map { it.trim() }
            .filter { it.length >= 25 && !isBadAnswer(it) }

        val first = sentences.firstOrNull() ?: clean
        val second = sentences.drop(1).firstOrNull().orEmpty()

        val candidate = if (first.length < 90 && second.isNotBlank()) "$first. $second" else first
        val limit = min(candidate.length, 260)
        val short = candidate.take(limit).trim()

        return if (candidate.length > 260) "$short..." else short
    }

    private fun subjectWords(text: String): List<String> {
        val stop = setOf(
            "q", "que", "qué", "es", "son", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuales",
            "dime", "di", "define", "defineme", "significa", "significado",
            "definicion", "concepto", "palabra", "wikipedia", "internet", "net",
            "mineria", "minera", "minero", "explotacion", "corto", "breve"
        )
        return ResponseRepository.normalize(text)
            .split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
            .replace(" y mineria", " en mineria")
            .replace(" y minera", " en mineria")
            .replace(" y minero", " en mineria")

        val prefixes = listOf(
            "q es ", "que es ", "qué es ", "es ", "que significa ",
            "dime que es ", "define ", "definicion de ", "definicion del ",
            "concepto de ", "concepto del ", "buscar ", "busca ",
            "wikipedia ", "internet ", "net ", "la palabra ", "palabra "
        )

        for (prefix in prefixes) {
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }

        return q
    }

    private fun isWeightQuestion(text: String): Boolean {
        val q = ResponseRepository.normalize(text)
        return q.contains("cuanto pesa") ||
            q.contains("peso especifico") ||
            q.contains("densidad")
    }

    private fun isBadTitle(title: String): Boolean {
        val t = ResponseRepository.normalize(title)
        return t.contains("desambiguacion") ||
            t.contains("anexo") ||
            t.contains("lista de") ||
            t.contains("categoria")
    }

    private fun isBadAnswer(text: String): Boolean {
        val t = ResponseRepository.normalize(text)
        val bad = listOf(
            "puede referirse a",
            "puede hacer referencia",
            "pagina de desambiguacion",
            "wikimedia",
            "archivo:",
            "categoria:",
            "lista de",
            "anexo:"
        )
        return bad.any { t.contains(it) }
    }

    private fun get(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 12000
        connection.setRequestProperty("Accept-Language", "es-PE,es;q=0.9")
        connection.setRequestProperty(
            "User-Agent",
            "GeoSusuAudio/1.0 Android educational app"
        )

        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        }
    }
}
