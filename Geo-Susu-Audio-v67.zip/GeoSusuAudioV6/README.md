# Geo Susu Audio v67

## Nuevo motor: Google interno parecido
Se agregó un motor parecido a Google, pero sin la ventana grande.

Motor nuevo:
- Google interno parecido

Cómo funciona:
- Usa SpeechRecognizer interno del celular.
- No abre el cuadro grande de Google.
- Reinicia solo después de responder.
- Escucha mejor que Vosk si el servicio de Google funciona bien.
- Mantiene TXT y NET.

Motores disponibles:
- Google interno parecido
- Manos libres pantalla apagada
- Google ventana
- Vosk offline

Importante:
- Google interno necesita Speech Services by Google activo.
- Puede necesitar internet según el celular.
- Si Android lo corta con pantalla apagada, usa Manos libres pantalla apagada.
