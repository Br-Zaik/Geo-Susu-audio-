package com.bph.geosusuaudio

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import android.app.Activity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bph.geosusuaudio.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }
    private lateinit var modelManager: VoskModelManager
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private var tts: TextToSpeech? = null
    private var pendingStartMode = ""
    private var googleLoopRunning = false
    private val editorPrefs by lazy { getSharedPreferences("geo_susu_txt_editor", Context.MODE_PRIVATE) }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            when (pendingStartMode) {
                "google_internal" -> startGoogleInternalService()
                "google" -> launchGooglePrecise()
                "wake" -> if (modelManager.isReady()) startVoskWakeService() else {
                    binding.tvStatus.text = "Falta modelo offline"
                    binding.tvAnswer.text = "Toca ESCUCHAR para descargar automático."
                }
                "wake" -> if (modelManager.isReady()) startVoskWakeService() else {
                binding.tvStatus.text = "Falta modelo offline"
                binding.tvAnswer.text = "Toca ESCUCHAR para descargar automático."
            }
            "vosk" -> if (modelManager.isReady()) startVoskService() else {
                    binding.tvStatus.text = "Falta modelo offline"
                    binding.tvAnswer.text = "Toca ESCUCHAR para descargar automático."
                }
                else -> binding.tvStatus.text = "Permiso de micrófono listo"
            }
        } else {
            binding.tvStatus.text = "Permiso de micrófono denegado"
            binding.tvAnswer.text = "Activa el permiso de micrófono."
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        when (pendingStartMode) {
            "vosk" -> if (modelManager.isReady()) startVoskService() else {
                binding.tvStatus.text = "Falta modelo offline"
                binding.tvAnswer.text = "Toca ESCUCHAR para descargar automático."
            }

        }
    }

    private val googleVoiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (!googleLoopRunning) return@registerForActivityResult

        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                .orEmpty()

            val best = matches
                .map { it.trim() }
                .firstOrNull { it.isNotBlank() }
                .orEmpty()

            if (best.isNotBlank()) {
                processQuestion(best, useOnlineFallback = false)
            } else {
                binding.tvStatus.text = "Google no entendió. Reintentando..."
                reopenGooglePrecise(550)
            }
        } else {
            binding.tvStatus.text = "Google no entendió. Reintentando..."
            reopenGooglePrecise(700)
        }
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == VoskListenService.ACTION_WAKE_GOOGLE) {
                launchGooglePrecise()
                return
            }

            val status = intent?.getStringExtra(VoskListenService.EXTRA_STATUS)
                ?: intent?.getStringExtra(GoogleInternalListenService.EXTRA_STATUS)
                ?: ""
            val heard = intent?.getStringExtra(VoskListenService.EXTRA_HEARD)
                ?: intent?.getStringExtra(GoogleInternalListenService.EXTRA_HEARD)
                ?: ""
            val answer = intent?.getStringExtra(VoskListenService.EXTRA_ANSWER)
                ?: intent?.getStringExtra(GoogleInternalListenService.EXTRA_ANSWER)
                ?: ""

            if (status.isNotBlank()) binding.tvStatus.text = status
            if (heard.isNotBlank()) binding.tvHeard.text = "Te escuché: $heard"
            if (answer.isNotBlank()) binding.tvAnswer.text = "Respuesta: $answer"

            val level = intent?.getIntExtra(VoskListenService.EXTRA_LEVEL, -1) ?: -1
            if (level >= 0) {
                binding.pbVoiceLevel.progress = level
                binding.tvVoiceLevel.text = when {
                    level < 15 -> "Muy bajo: acerca el Zync o sube voz. Nivel $level%"
                    level > 85 -> "Muy fuerte: baja un poco. Nivel $level%"
                    else -> "Nivel correcto: $level%"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        resetModeToTxtOnce()
        seedTxtIfEmpty()
        tts = TextToSpeech(this, this)

        setupUi()
        refreshRepository()
        binding.tvStatus.text = "Listo. Escucha: ${appSettings.getListenEngineLabel()}"
        binding.tvAnswer.text = "Respuesta: listo."
        handleStartIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleStartIntent(intent)
    }

    private fun handleStartIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_START_GOOGLE, false) == true) {
            appSettings.setListenEngine(AppSettings.ListenEngine.HANDS_FREE)
            binding.tvStatus.text = "Comando geo detectado"
            binding.tvAnswer.text = "Respuesta: abriendo Google preciso."
            binding.root.postDelayed({
                launchGooglePrecise()
            }, 1200L)
        }
    }

    private fun resetModeToTxtOnce() {
        val prefs = getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("v19_txt_default_done", false)) {
            modeSettings.setMode(AnswerModeSettings.Mode.LOCAL)
            prefs.edit().putBoolean("v19_txt_default_done", true).apply()
        }
    }

    private fun seedTxtIfEmpty() {
        val currentQa = editorPrefs.getString(KEY_TXT_QA, "").orEmpty()
        val currentVariants = editorPrefs.getString(KEY_TXT_VARIANTS, "").orEmpty()
        val qaPack = questionsAnswersTemplate()
        val variantsPack = variantsTemplate()

        val prefs = getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)

        if (currentQa.isBlank()) {
            editorPrefs.edit()
                .putString(KEY_TXT_QA, qaPack)
                .putString(KEY_TXT_VARIANTS, variantsPack)
                .apply()
            ResponseRepository.replaceInternalTexts(this, qaPack, variantsPack)
            prefs.edit().putBoolean("v41_mining_pack_done", true).apply()
            return
        }

        // Si el usuario ya tenía TXT, no se borra: se agregan las nuevas preguntas una sola vez.
        if (!prefs.getBoolean("v41_mining_pack_done", false)) {
            val mergedQa = mergeTxtLines(currentQa, qaPack)
            val mergedVariants = mergeTxtLines(currentVariants, variantsPack)

            editorPrefs.edit()
                .putString(KEY_TXT_QA, mergedQa)
                .putString(KEY_TXT_VARIANTS, mergedVariants)
                .apply()

            ResponseRepository.replaceInternalTexts(this, mergedQa, mergedVariants)
            prefs.edit().putBoolean("v41_mining_pack_done", true).apply()
        }
    }

    private fun mergeTxtLines(current: String, extra: String): String {
        val existingKeys = current.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .map { it.substringBefore("|").trim().lowercase() }
            .toMutableSet()

        val output = StringBuilder(current.trim())

        extra.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .forEach { line ->
                val key = line.substringBefore("|").trim().lowercase()
                if (key.isNotBlank() && key !in existingKeys) {
                    if (output.isNotBlank()) output.append("\n")
                    output.append(line)
                    existingKeys.add(key)
                }
            }

        return output.toString().trim()
    }

    private fun applyModeToUi() {
        when (modeSettings.getMode()) {
            AnswerModeSettings.Mode.INTERNET -> binding.rbInternet.isChecked = true
            else -> binding.rbLocal.isChecked = true
        }
        binding.tvModeMini.text = modeSettings.getLabel()
    }

    private fun openQuestionsAnswersTxt() {
        showInternalTxtEditor(
            type = "qa",
            title = "TXT P/R dentro de la app",
            hint = "pregunta | respuesta"
        )
    }

    private fun openVariantsTxt() {
        showInternalTxtEditor(
            type = "variants",
            title = "TXT VAR dentro de la app",
            hint = "pregunta | variante1, variante2"
        )
    }

    private fun showInternalTxtEditor(type: String, title: String, hint: String) {
        val key = if (type == "variants") KEY_TXT_VARIANTS else KEY_TXT_QA
        val current = editorPrefs.getString(key, "").orEmpty()
        val startText = current.ifBlank {
            if (type == "variants") variantsTemplate() else questionsAnswersTemplate()
        }

        val input = EditText(this).apply {
            setText(startText)
            setSelection(startText.length)
            minLines = 10
            maxLines = 16
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setHorizontallyScrolling(false)
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("Edita aquí mismo. Luego toca Guardar y cargar.")
            .setView(input)
            .setPositiveButton("Guardar y cargar") { _, _ ->
                val raw = input.text.toString()
                editorPrefs.edit().putString(key, raw).apply()

                val qaRaw = if (type == "variants") {
                    editorPrefs.getString(KEY_TXT_QA, "").orEmpty()
                } else {
                    raw
                }

                val variantsRaw = if (type == "variants") {
                    raw
                } else {
                    editorPrefs.getString(KEY_TXT_VARIANTS, "").orEmpty()
                }

                val result = ResponseRepository.replaceInternalTexts(this, qaRaw, variantsRaw)
                refreshRepository()

                binding.tvStatus.text = if (type == "variants") {
                    "TXT VAR guardado. Variantes: ${result.second}"
                } else {
                    "TXT P/R guardado. Preguntas: ${result.first}"
                }
                binding.tvAnswer.text = "Respuesta: guardado dentro de la app."
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun questionsAnswersTemplate(): String {
        return """
# Formato: pregunta | respuesta
# Escribe una pregunta por línea.

epp | Equipo de Protección Personal usado para proteger al trabajador.
iperc | Identificación de Peligros, Evaluación de Riesgos y Controles.
ana | Autoridad Nacional del Agua, entidad que administra los recursos hídricos.
mineral | Sustancia natural, sólida e inorgánica, con composición química definida.
roca | Agregado natural formado por uno o varios minerales.
mena | Mineral o roca del cual se puede extraer un metal o elemento útil de forma rentable.
ganga | Material sin valor económico que acompaña a la mena.
yacimiento | Acumulación natural de minerales con posible valor económico.
veta | Cuerpo mineralizado alargado que rellena una fractura de la roca.
filón | Masa mineral que ocupa una grieta o fractura.
manto | Depósito mineral con forma de capa casi horizontal.
cuerpo mineralizado | Zona de roca que contiene minerales de interés económico.
ley de mineral | Cantidad de metal útil presente en un mineral, expresada en porcentaje o gramos por tonelada.
ley de corte | Ley mínima necesaria para que un mineral sea considerado económicamente explotable.
reserva mineral | Parte del recurso mineral que puede explotarse económicamente con estudios suficientes.
recurso mineral | Concentración mineral con potencial económico, aún no necesariamente explotable.
cateo | Búsqueda inicial de indicios de minerales en superficie.
prospección | Búsqueda técnica de zonas con posible mineralización.
exploración minera | Estudios y trabajos para comprobar tamaño, ley y continuidad de un yacimiento.
explotación minera | Extracción del mineral desde un yacimiento para su aprovechamiento económico.
mina | Lugar donde se extraen minerales mediante labores superficiales o subterráneas.
minería superficial | Explotación minera realizada desde la superficie del terreno.
tajo abierto | Método de explotación superficial con bancos escalonados.
minería subterránea | Explotación realizada mediante túneles, galerías o rampas bajo tierra.
galería | Labor minera horizontal subterránea usada para acceso, transporte o explotación.
rampa | Labor inclinada que comunica niveles en una mina subterránea.
pique | Excavación vertical o inclinada usada para acceso, ventilación o extracción.
chimenea | Labor vertical o inclinada que comunica niveles y ayuda a ventilación o paso de mineral.
frente de trabajo | Zona donde se realiza perforación, voladura, carguío o avance.
banco | Escalón de trabajo en una mina a cielo abierto.
berma | Plataforma de seguridad entre bancos para contener caída de material.
talud | Inclinación de una pared de excavación o banco.
desmonte | Material extraído sin valor económico.
estéril | Roca o material que no contiene mineral aprovechable.
dilución | Mezcla de mineral con material estéril durante la explotación.
recuperación minera | Porcentaje de mineral útil que se logra extraer del yacimiento.
mineral oxidado | Mineral alterado por oxígeno, agua o intemperismo cerca de la superficie.
mineral sulfurado | Mineral que contiene azufre combinado con metales.
mineral primario | Mineral formado originalmente en profundidad.
mineral secundario | Mineral formado por alteración de minerales primarios.
alteración hidrotermal | Cambio químico de la roca producido por fluidos calientes.
calcopirita | Mineral sulfurado de cobre y hierro, de color amarillo latón.
pirita | Sulfuro de hierro conocido como oro de los tontos.
bornita | Mineral sulfurado de cobre con colores iridiscentes.
galena | Sulfuro de plomo, principal mena de plomo.
esfalerita | Sulfuro de zinc, principal mena de zinc.
hematita | Óxido de hierro de color rojo a gris, mena importante de hierro.
magnetita | Óxido de hierro magnético, mena importante de hierro.
cuarzo | Mineral compuesto por dióxido de silicio, común en vetas y rocas.
calcita | Mineral de carbonato de calcio que reacciona con ácido.
geología | Ciencia que estudia la Tierra, sus rocas, minerales y procesos.
topografía | Ciencia que mide y representa la superficie del terreno.
cota | Altura de un punto respecto a un plano de referencia.
nivelación | Método topográfico para determinar diferencias de altura.
bm | Punto de referencia con cota conocida usado en nivelación.
azimut | Ángulo horizontal medido desde el norte en sentido horario.
rumbo | Dirección de una línea expresada por cuadrantes.
contra azimut | Dirección opuesta al azimut, se obtiene sumando o restando 180 grados.
distancia horizontal | Distancia medida en proyección plana entre dos puntos.
estación total | Instrumento topográfico que mide ángulos y distancias.
gps | Sistema de posicionamiento global usado para ubicar puntos.
curva de nivel | Línea que une puntos de igual cota en un plano.
perfil longitudinal | Representación del terreno a lo largo de un eje.
escala | Relación entre la medida del plano y la medida real.
muestreo | Toma representativa de material para análisis.
muestra | Porción de mineral o roca usada para estudio o análisis.
sondaje | Perforación realizada para conocer el subsuelo.
testigo | Cilindro de roca recuperado en una perforación diamantina.
perforación | Acción de hacer taladros en roca para exploración o voladura.
voladura | Fragmentación de roca mediante explosivos.
explosivo | Sustancia que libera energía rápidamente para romper roca.
taladro | Agujero perforado en la roca para colocar explosivo o tomar muestras.
burden | Distancia entre el taladro y la cara libre en una voladura.
espaciamiento | Distancia entre taladros de una misma fila.
chancado | Reducción inicial del tamaño de roca mediante chancadoras.
molienda | Reducción fina del mineral usando molinos.
concentración mineral | Proceso para separar minerales valiosos de la ganga.
flotación | Proceso de concentración que separa minerales usando burbujas y reactivos.
relave | Residuo fino que queda después de recuperar el mineral valioso.
lixiviación | Proceso que disuelve metales usando soluciones químicas.
cianuración | Lixiviación del oro o plata usando cianuro bajo control técnico.
recuperación metalúrgica | Porcentaje de metal recuperado en planta respecto al contenido inicial.
ventilación minera | Circulación de aire para remover gases, polvo y calor en mina.
sostenimiento | Elementos usados para estabilizar labores subterráneas.
perno de roca | Elemento de sostenimiento que refuerza el macizo rocoso.
shotcrete | Concreto lanzado usado para sostener superficies de roca.
peligro | Fuente o situación con potencial de causar daño.
riesgo | Probabilidad y consecuencia de que ocurra un daño.
incidente | Evento no deseado que pudo causar daño.
accidente | Evento no deseado que causa lesión, daño o pérdida.
pets | Procedimiento Escrito de Trabajo Seguro.
ats | Análisis de Trabajo Seguro antes de iniciar una tarea.
iperc continuo | Evaluación permanente de peligros y riesgos durante el trabajo.
sctr | Seguro Complementario de Trabajo de Riesgo para actividades peligrosas.
permiso de trabajo | Autorización formal para realizar una tarea riesgosa.
serfor | Servicio Nacional Forestal y de Fauna Silvestre del Perú.
petitorio minero | Solicitud presentada para obtener una concesión minera.
concesión minera | Derecho otorgado para explorar y explotar recursos minerales en un área.
derecho minero | Facultad legal relacionada con la concesión o actividad minera.
canon minero | Participación económica que reciben gobiernos por la explotación de recursos minerales.
ingemmet | Instituto Geológico, Minero y Metalúrgico del Perú.
oefa | Organismo que fiscaliza el cumplimiento ambiental.
osinergmin | Organismo que supervisa seguridad, energía y minería en el Perú.
drem | Dirección Regional de Energía y Minas.
senace | Entidad que evalúa estudios ambientales de proyectos importantes.
eia | Estudio de Impacto Ambiental para proyectos con impactos significativos.
dia | Declaración de Impacto Ambiental para proyectos de menor impacto.
cierre de minas | Conjunto de acciones para rehabilitar áreas afectadas por la minería.
formalización minera | Proceso para que una actividad minera informal cumpla requisitos legales.
""".trimIndent()
    }


    private fun variantsTemplate(): String {
        return """
# Formato: pregunta | variante1, variante2, variante3
# La pregunta debe escribirse igual que en TXT P/R.

epp | equipo de proteccion personal, e p p, epi
iperc | i perc, hiper, iper, identificacion de peligros
ana | autoridad nacional del agua
mineral | minerales, meniral, mineralogia
roca | rocas, tipos de roca, piedra
mena | mema, nena, mina, minea, mineral rentable
ganga | gaga, aga, canga, material sin valor
yacimiento | deposito mineral, yacimento, yacimiento mineral
veta | beta, veta mineral, filon
filón | filon, veta
manto | capa mineral, manto mineralizado
cuerpo mineralizado | cuerpo mineral, zona mineralizada
ley de mineral | ley mineral, contenido metalico, tenor
ley de corte | cut off, ley minima
reserva mineral | reservas, reserva minera
recurso mineral | recursos, recurso minero
cateo | kateo, catio, cate, busqueda inicial
prospección | prospeccion, prospeccion minera, busqueda tecnica
exploración minera | exploracion, exploracion minera
explotación minera | explotacion, explotacion minera, extraccion minera
mina | minas, unidad minera
minería superficial | mineria superficial, cielo abierto
tajo abierto | open pit, rajo abierto, tajo
minería subterránea | mineria subterranea, mina subterranea
galería | galeria, tunel minero
rampa | rampa minera
pique | pozo, pique minero
chimenea | chimenea minera
frente de trabajo | frente, labor minera
banco | banco minero, escalon
berma | berma de seguridad
talud | pared, inclinacion del banco
desmonte | material de desmonte, desmontes
estéril | esteril, material esteril
dilución | dilucion, mezcla con esteril
mineral oxidado | oxidado, mineral oxidao, meniral oxidado
mineral sulfurado | sulfurado, sulfuros
calcopirita | calcopirita cobre, chalcopyrite
pirita | oro de los tontos, sulfuro de hierro
bornita | mineral de cobre, bornita cobre
galena | sulfuro de plomo
esfalerita | blenda, sulfuro de zinc
hematita | oxido de hierro, hematites
magnetita | mineral magnetico
cuarzo | quartz, silice
calcita | carbonato de calcio
geología | geologia, estudio de la tierra
topografía | topografia, levantamiento topografico
cota | altura, elevacion
nivelación | nivelacion, calcular cotas
bm | benchmark, banco de marca, punto de referencia
azimut | azimuth, asimut
rumbo | rumbo topografico
contra azimut | contraazimut, azimut inverso
distancia horizontal | distancia plana
estación total | estacion total
gps | gepe ese, posicionamiento global
curva de nivel | curvas de nivel
perfil longitudinal | perfil del terreno
escala | escala del plano
muestreo | muestra, toma de muestra
sondaje | perforacion diamantina, sondeo
testigo | core, testigo de perforacion
perforación | perforacion, taladro
voladura | disparo, tronadura
explosivo | explosivos
taladro | barreno, agujero
burden | bordo, burden de voladura
espaciamiento | espaciamiento entre taladros
chancado | trituracion, chancadora
molienda | molino, moler mineral
concentración mineral | concentracion, beneficio de minerales
flotación | flotacion, floatacion
relave | tailing, residuos de planta
lixiviación | lixiviacion, lixiviar
cianuración | cianuracion, cianuro
ventilación minera | ventilacion, aire en mina
sostenimiento | soporte, sostenimiento de roca
perno de roca | pernos, rock bolt
shotcrete | concreto lanzado, shocret
peligro | fuente de daño
riesgo | probabilidad de daño
incidente | casi accidente
accidente | accidente laboral
pets | procedimiento escrito de trabajo seguro
ats | analisis de trabajo seguro
iperc continuo | iperc de campo
sctr | seguro complementario
permiso de trabajo | permiso, autorizacion de trabajo
serfor | servicio forestal, fauna silvestre
petitorio minero | petitorio, solicitud minera
concesión minera | concesion minera, derecho de concesion
derecho minero | derechos mineros
canon minero | canon
ingemmet | instituto geologico minero metalurgico
oefa | fiscalizacion ambiental
osinergmin | supervision minera
drem | direccion regional de energia y minas
senace | certificacion ambiental
eia | estudio de impacto ambiental
dia | declaracion de impacto ambiental
cierre de minas | plan de cierre
formalización minera | formalizacion, mineria formal
""".trimIndent()
    }


    private fun showSettingsDialog() {
        val items = arrayOf(
            "Motor escucha: ${appSettings.getListenEngineLabel()}",
            "Sensibilidad micrófono: ${appSettings.getMicSensitivityLabel()}",
            "Limpiador de ruido: ${appSettings.getNoiseCleanerLabel()}",
            "Enfoque Internet: ${appSettings.getNetFocusLabel()}",
            "Velocidad de voz: ${appSettings.getVoiceSpeedLabel()}"
        )

        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showListenEngineDialog()
                    1 -> showMicSensitivityDialog()
                    2 -> showNoiseCleanerDialog()
                    3 -> showNetFocusDialog()
                    else -> showVoiceSpeedDialog()
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showListenEngineDialog() {
        val options = arrayOf("Google interno parecido", "Manos libres pantalla apagada", "Google ventana", "Vosk offline")
        val checked = when (appSettings.getListenEngine()) {
            AppSettings.ListenEngine.HANDS_FREE -> 1
            AppSettings.ListenEngine.GOOGLE -> 2
            AppSettings.ListenEngine.VOSK -> 3
            else -> 0
        }

        AlertDialog.Builder(this)
            .setTitle("Motor de escucha")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = when (which) {
                    1 -> AppSettings.ListenEngine.HANDS_FREE
                    2 -> AppSettings.ListenEngine.GOOGLE
                    3 -> AppSettings.ListenEngine.VOSK
                    else -> AppSettings.ListenEngine.GOOGLE_INTERNAL
                }
                appSettings.setListenEngine(value)
                binding.tvStatus.text = "Escucha: ${appSettings.getListenEngineLabel()}"
                binding.tvAnswer.text = when (value) {
                    AppSettings.ListenEngine.GOOGLE_INTERNAL ->
                        "Respuesta: Google interno escucha sin ventana grande y reinicia solo."
                    AppSettings.ListenEngine.HANDS_FREE ->
                        "Respuesta: di ${commandSettings.getCommandWord()}, luego pregunta sin tocar el celular."
                    AppSettings.ListenEngine.GOOGLE ->
                        "Respuesta: Google ventana escucha mejor, pero abre cuadro de Google."
                    else ->
                        "Respuesta: Vosk sirve offline y pantalla apagada, pero entiende peor."
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMicSensitivityDialog() {
        val options = arrayOf("Normal", "Susurro / voz baja")
        val checked = if (appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER) 1 else 0

        AlertDialog.Builder(this)
            .setTitle("Sensibilidad del micrófono")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = if (which == 1) AppSettings.MicSensitivity.WHISPER else AppSettings.MicSensitivity.NORMAL
                appSettings.setMicSensitivity(value)
                binding.tvStatus.text = "Micrófono: ${appSettings.getMicSensitivityLabel()}"
                binding.tvAnswer.text = "Respuesta: usa el Zync cerca de la boca."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showNoiseCleanerDialog() {
        val options = arrayOf("Normal", "Fuerte")
        val checked = if (appSettings.getNoiseCleaner() == AppSettings.NoiseCleaner.STRONG) 1 else 0

        AlertDialog.Builder(this)
            .setTitle("Limpiador de ruido")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = if (which == 1) AppSettings.NoiseCleaner.STRONG else AppSettings.NoiseCleaner.NORMAL
                appSettings.setNoiseCleaner(value)
                binding.tvStatus.text = "Ruido: ${appSettings.getNoiseCleanerLabel()}"
                binding.tvAnswer.text = "Respuesta: si estás susurrando, usa Fuerte."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showNetFocusDialog() {
        val options = arrayOf("General", "Minería / Explotación minera")
        val checked = if (appSettings.getNetFocus() == AppSettings.NetFocus.MINING) 1 else 0

        AlertDialog.Builder(this)
            .setTitle("Enfoque para Internet")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = if (which == 1) AppSettings.NetFocus.MINING else AppSettings.NetFocus.GENERAL
                appSettings.setNetFocus(value)
                binding.tvStatus.text = "Internet: ${appSettings.getNetFocusLabel()}"
                binding.tvAnswer.text = "Respuesta: ajuste guardado."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showVoiceSpeedDialog() {
        val options = arrayOf("Lento", "Normal", "Rápido")
        val checked = when (appSettings.getVoiceSpeed()) {
            AppSettings.VoiceSpeed.SLOW -> 0
            AppSettings.VoiceSpeed.NORMAL -> 1
            AppSettings.VoiceSpeed.FAST -> 2
        }

        AlertDialog.Builder(this)
            .setTitle("Velocidad de la voz")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = when (which) {
                    0 -> AppSettings.VoiceSpeed.SLOW
                    2 -> AppSettings.VoiceSpeed.FAST
                    else -> AppSettings.VoiceSpeed.NORMAL
                }
                appSettings.setVoiceSpeed(value)
                tts?.setSpeechRate(appSettings.getVoiceRate())
                binding.tvStatus.text = "Voz: ${appSettings.getVoiceSpeedLabel()}"
                binding.tvAnswer.text = "Respuesta: velocidad guardada."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startListeningSmart() {
        requestIgnoreBatteryOptimizationOnce()
        val engine = appSettings.getListenEngine()
        pendingStartMode = when (engine) {
            AppSettings.ListenEngine.GOOGLE_INTERNAL -> "google_internal"
            AppSettings.ListenEngine.GOOGLE -> "google"
            AppSettings.ListenEngine.HANDS_FREE -> "wake"
            else -> "vosk"
        }

        when {
            !hasAudioPermission() -> audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission() ->
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            engine == AppSettings.ListenEngine.GOOGLE_INTERNAL -> startGoogleInternalService()
            engine == AppSettings.ListenEngine.GOOGLE -> launchGooglePrecise()
            engine == AppSettings.ListenEngine.HANDS_FREE && modelManager.isReady() -> startVoskWakeService()
            engine == AppSettings.ListenEngine.VOSK && modelManager.isReady() -> startVoskService()
            else -> downloadOffline(startAfter = true)
        }
    }

    private fun downloadOffline(startAfter: Boolean) {
        binding.tvStatus.text = "Preparando modelo offline..."
        binding.tvAnswer.text = "Respuesta: se descargará una sola vez. Necesita internet estable."

        modelManager.downloadAndUnzip(
            onProgress = { msg -> runOnUiThread { binding.tvStatus.text = msg } },
            onDone = { ok, msg ->
                runOnUiThread {
                    binding.tvStatus.text = msg
                    binding.tvAnswer.text = if (ok) {
                        if (startAfter) "Modelo listo. Iniciando escucha..." else "Offline listo. Toca ESCUCHAR."
                    } else {
                        "No se pudo preparar offline. Revisa internet, espacio y vuelve a tocar DESCARGAR."
                    }

                    if (ok && startAfter) {
                        if (pendingStartMode == "wake") startVoskWakeService() else startVoskService()
                    }
                }
            }
        )
    }

    private fun requestIgnoreBatteryOptimizationOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return

        val prefs = getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_request_shown", false)) return

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return

        prefs.edit().putBoolean("battery_request_shown", true).apply()

        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
            binding.tvStatus.text = "Permite batería sin restricciones para pantalla apagada."
        } catch (_: Exception) {
            binding.tvStatus.text = "Quita restricción de batería manualmente."
        }
    }

    private fun setupUi() {
        binding.etCommandWord.setText(commandSettings.getCommandWord())
        applyModeToUi()

        binding.rgAnswerMode.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == binding.rbInternet.id) {
                modeSettings.setMode(AnswerModeSettings.Mode.INTERNET)
            } else {
                modeSettings.setMode(AnswerModeSettings.Mode.LOCAL)
            }
            applyModeToUi()
            binding.tvStatus.text = "Modo: ${modeSettings.getLabel()}"
        }

        binding.btnOpenTxt.setOnClickListener { openQuestionsAnswersTxt() }
        binding.btnImportText.setOnClickListener { openVariantsTxt() }
        binding.btnSettings.setOnClickListener { showSettingsDialog() }

        binding.btnDownloadModel.setOnClickListener {
            downloadOffline(startAfter = false)
        }

        binding.btnSaveCommand.setOnClickListener {
            val saved = commandSettings.saveCommandWord(binding.etCommandWord.text.toString())
            binding.etCommandWord.setText(saved)
            binding.tvStatus.text = "Comando guardado: $saved"
            binding.tvAnswer.text = "Comando guardado para pausar o reanudar."
        }

        binding.btnStart.setOnClickListener {
            startListeningSmart()
        }

        binding.btnStop.setOnClickListener {
            googleLoopRunning = false
            stopService(Intent(this, GoogleInternalListenService::class.java))
            stopService(Intent(this, VoskListenService::class.java))
            binding.tvStatus.text = "Escucha detenida"
            binding.tvHeard.text = "Te escuché: ---"
            binding.tvAnswer.text = "Respuesta: listo."
        }

    }

    private fun launchGooglePrecise() {
        googleLoopRunning = true
        stopService(Intent(this, GoogleInternalListenService::class.java))
        stopService(Intent(this, VoskListenService::class.java))

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla o susurra cerca del micrófono")
        }

        try {
            binding.tvStatus.text = "Escucha precisa de Google..."
            binding.tvAnswer.text = "Respuesta: habla cuando aparezca el micrófono."
            googleVoiceLauncher.launch(intent)
        } catch (_: Exception) {
            googleLoopRunning = false
            binding.tvStatus.text = "Google Speech no disponible"
            binding.tvAnswer.text = "Respuesta: activa Speech Services by Google o cambia a Vosk."
        }
    }

    private fun reopenGooglePrecise(delayMs: Long = 650L) {
        if (!googleLoopRunning || appSettings.getListenEngine() != AppSettings.ListenEngine.GOOGLE) return
        binding.root.postDelayed({
            if (googleLoopRunning && appSettings.getListenEngine() == AppSettings.ListenEngine.GOOGLE) {
                launchGooglePrecise()
            }
        }, delayMs)
    }

    private fun startGoogleInternalService() {
        googleLoopRunning = false
        stopService(Intent(this, VoskListenService::class.java))
        val intent = Intent(this, GoogleInternalListenService::class.java)
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Google interno activo"
        binding.tvAnswer.text = "Respuesta: habla o susurra. No abre ventana grande."
    }

    private fun startVoskWakeService() {
        googleLoopRunning = false
        stopService(Intent(this, GoogleInternalListenService::class.java))
        stopService(Intent(this, VoskListenService::class.java))
        val intent = Intent(this, VoskListenService::class.java).apply {
            putExtra(VoskListenService.EXTRA_WAKE_ONLY, true)
        }
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Manos libres activo"
        binding.tvAnswer.text = "Respuesta: di ${commandSettings.getCommandWord()}, luego pregunta."
    }

    private fun startVoskService() {
        googleLoopRunning = false
        stopService(Intent(this, GoogleInternalListenService::class.java))
        val intent = Intent(this, VoskListenService::class.java)
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Escuchando offline..."
        binding.tvAnswer.text = "Respuesta: escuchando según el modo elegido."
    }

    private fun processQuestion(question: String, useOnlineFallback: Boolean, forceInternet: Boolean = false) {
        val cleanQuestion = question.trim()
        binding.tvHeard.text = "Te escuché: $cleanQuestion"

        if (cleanQuestion.length < 2) {
            showAndSpeak("Pregunta muy corta. Repite la palabra completa.", "No se procesó")
            return
        }

        if (commandSettings.isToggleCommand(cleanQuestion)) {
            binding.tvStatus.text = "Comando detectado"
            binding.tvAnswer.text = "Respuesta: comando de pausa, no se busca en internet."
            return
        }

        val mode = if (forceInternet) AnswerModeSettings.Mode.INTERNET else modeSettings.getMode()
        val match = repository.findBest(cleanQuestion)

        when (mode) {
            AnswerModeSettings.Mode.INTERNET -> {
                searchOnline(cleanQuestion)
            }

            else -> {
                showAndSpeak(match.answer, "Respuesta local")
                memory.saveLast(cleanQuestion, match.answer, match.itemId, match.score)
            }
        }
    }

    private fun searchOnline(question: String) {
        binding.tvStatus.text = "Buscando online..."
        binding.tvAnswer.text = "Buscando respuesta simple..."

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré respuesta online. Guarda esa pregunta en memoria o TXT."
            }

            runOnUiThread {
                showAndSpeak(answer, "Respuesta online")
                memory.saveLast(question, answer, "online", 0)
            }
        }.start()
    }

    private fun showAndSpeak(answer: String, status: String) {
        binding.tvStatus.text = status
        binding.tvAnswer.text = "Respuesta: $answer"
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "geo_susu_answer")

        if (googleLoopRunning && appSettings.getListenEngine() == AppSettings.ListenEngine.GOOGLE) {
            val waitMs = (answer.length * 55L).coerceIn(1200L, 6500L)
            reopenGooglePrecise(waitMs)
        }
    }

    private fun refreshRepository() {
        repository = ResponseRepository(this)
        binding.tvModeMini.text = modeSettings.getLabel()
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(VoskListenService.ACTION_UPDATE)
            addAction(VoskListenService.ACTION_WAKE_GOOGLE)
            addAction(GoogleInternalListenService.ACTION_UPDATE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(updateReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(updateReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "PE")) ?: TextToSpeech.ERROR
            tts?.setSpeechRate(appSettings.getVoiceRate())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "La voz en español no está disponible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        googleLoopRunning = false
        stopService(Intent(this, GoogleInternalListenService::class.java))
        tts?.stop()
        tts?.shutdown()
    }
    companion object {
        const val EXTRA_START_GOOGLE = "start_google_precise"
        private const val KEY_TXT_QA = "txt_qa_raw"
        private const val KEY_TXT_VARIANTS = "txt_variants_raw"
    }

}
