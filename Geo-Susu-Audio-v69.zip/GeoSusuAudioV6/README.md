# Geo Susu Audio v69

## Mensaje corto cuando no encuentra respuesta
- Si TXT no encuentra coincidencia, ahora dice solo: "No encontrado."
- Si NET no encuentra respuesta, también dice: "No encontrado."
- Se quitaron frases largas como "agrega variante" o "no estoy seguro".

## Mantiene
- Google interno parecido.
- TXT / NET.
- Vosk y modo manos libres.
