# Geo Susu Audio v72

## Reparación de variantes
Esta versión corrige el caso donde el pack de variantes v70 podía no aplicarse bien si ya tenías datos guardados antes.

Cambios:
- Fuerza una reparación una sola vez con bandera v72_repair_variants_done.
- Vuelve a combinar preguntas/respuestas base con tus datos.
- Vuelve a combinar variantes base con tus variantes manuales.
- No borra tus textos; los combina.
- Agrega correcciones directas para errores reales:
  - tipo de socas -> tipos de roca
  - tipos de socas -> tipos de roca
  - socas -> rocas
  - que es canca -> ganga
  - canca -> ganga

Uso:
- Instala v72.
- Abre la app una vez.
- Usa Google interno parecido + TXT.
- Prueba: "tipos de roca" aunque escuche "tipo de socas".
