package com.bph.geosusuaudio

import android.content.Context

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_settings", Context.MODE_PRIVATE)

    enum class NetFocus {
        GENERAL,
        MINING
    }

    enum class VoiceSpeed {
        SLOW,
        NORMAL,
        FAST
    }

    enum class MicSensitivity {
        NORMAL,
        WHISPER
    }

    enum class NoiseCleaner {
        NORMAL,
        STRONG
    }

    enum class ListenEngine {
        GOOGLE_INTERNAL,
        HANDS_FREE,
        GOOGLE,
        VOSK
    }

    fun getNetFocus(): NetFocus {
        return when (prefs.getString(KEY_NET_FOCUS, NetFocus.GENERAL.name)) {
            NetFocus.MINING.name -> NetFocus.MINING
            else -> NetFocus.GENERAL
        }
    }

    fun setNetFocus(value: NetFocus) {
        prefs.edit().putString(KEY_NET_FOCUS, value.name).apply()
    }

    fun getVoiceSpeed(): VoiceSpeed {
        return when (prefs.getString(KEY_VOICE_SPEED, VoiceSpeed.NORMAL.name)) {
            VoiceSpeed.SLOW.name -> VoiceSpeed.SLOW
            VoiceSpeed.FAST.name -> VoiceSpeed.FAST
            else -> VoiceSpeed.NORMAL
        }
    }

    fun setVoiceSpeed(value: VoiceSpeed) {
        prefs.edit().putString(KEY_VOICE_SPEED, value.name).apply()
    }

    fun getVoiceRate(): Float {
        return when (getVoiceSpeed()) {
            VoiceSpeed.SLOW -> 0.85f
            VoiceSpeed.NORMAL -> 1.05f
            VoiceSpeed.FAST -> 1.25f
        }
    }

    fun getMicSensitivity(): MicSensitivity {
        return when (prefs.getString(KEY_MIC_SENSITIVITY, MicSensitivity.WHISPER.name)) {
            MicSensitivity.NORMAL.name -> MicSensitivity.NORMAL
            else -> MicSensitivity.WHISPER
        }
    }

    fun setMicSensitivity(value: MicSensitivity) {
        prefs.edit().putString(KEY_MIC_SENSITIVITY, value.name).apply()
    }

    fun getMicGain(): Float {
        return when (getMicSensitivity()) {
            MicSensitivity.NORMAL -> 1.80f
            MicSensitivity.WHISPER -> 4.20f
        }
    }

    fun getNetFocusLabel(): String {
        return when (getNetFocus()) {
            NetFocus.GENERAL -> "General"
            NetFocus.MINING -> "Minería"
        }
    }

    fun getVoiceSpeedLabel(): String {
        return when (getVoiceSpeed()) {
            VoiceSpeed.SLOW -> "Lento"
            VoiceSpeed.NORMAL -> "Normal"
            VoiceSpeed.FAST -> "Rápido"
        }
    }

    fun getMicSensitivityLabel(): String {
        return when (getMicSensitivity()) {
            MicSensitivity.NORMAL -> "Normal"
            MicSensitivity.WHISPER -> "Susurro"
        }
    }

    fun getNoiseCleaner(): NoiseCleaner {
        return when (prefs.getString(KEY_NOISE_CLEANER, NoiseCleaner.STRONG.name)) {
            NoiseCleaner.NORMAL.name -> NoiseCleaner.NORMAL
            else -> NoiseCleaner.STRONG
        }
    }

    fun setNoiseCleaner(value: NoiseCleaner) {
        prefs.edit().putString(KEY_NOISE_CLEANER, value.name).apply()
    }

    fun getNoiseCleanerLabel(): String {
        return when (getNoiseCleaner()) {
            NoiseCleaner.NORMAL -> "Normal"
            NoiseCleaner.STRONG -> "Fuerte"
        }
    }



    fun getListenEngine(): ListenEngine {
        return when (prefs.getString(KEY_LISTEN_ENGINE, ListenEngine.GOOGLE_INTERNAL.name)) {
            ListenEngine.HANDS_FREE.name -> ListenEngine.HANDS_FREE
            ListenEngine.GOOGLE.name -> ListenEngine.GOOGLE
            ListenEngine.VOSK.name -> ListenEngine.VOSK
            else -> ListenEngine.GOOGLE_INTERNAL
        }
    }

    fun setListenEngine(value: ListenEngine) {
        prefs.edit().putString(KEY_LISTEN_ENGINE, value.name).apply()
    }

    fun getListenEngineLabel(): String {
        return when (getListenEngine()) {
            ListenEngine.GOOGLE_INTERNAL -> "Google interno"
            ListenEngine.HANDS_FREE -> "Manos libres"
            ListenEngine.GOOGLE -> "Google ventana"
            ListenEngine.VOSK -> "Vosk offline"
        }
    }

    companion object {
        private const val KEY_NET_FOCUS = "net_focus"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_MIC_SENSITIVITY = "mic_sensitivity"
        private const val KEY_NOISE_CLEANER = "noise_cleaner"
        private const val KEY_LISTEN_ENGINE = "listen_engine"
    }
}
