package com.bph.geosusuaudio

import android.content.Context

class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)

    fun saveLast(heard: String, answer: String, itemId: String, score: Int) {
        prefs.edit()
            .putString("last_heard", heard)
            .putString("last_answer", answer)
            .putString("last_item_id", itemId)
            .putInt("last_score", score)
            .putLong("last_time", System.currentTimeMillis())
            .putInt("total_answers", getTotalAnswers() + 1)
            .apply()
    }

    fun getTotalAnswers(): Int = prefs.getInt("total_answers", 0)

    fun getSummary(): String {
        val total = getTotalAnswers()
        val last = prefs.getString("last_heard", "Sin preguntas todavía") ?: "Sin preguntas todavía"
        val score = prefs.getInt("last_score", 0)
        return "Memoria: $total respuestas. Último: $last. Precisión: $score%."
    }
}
