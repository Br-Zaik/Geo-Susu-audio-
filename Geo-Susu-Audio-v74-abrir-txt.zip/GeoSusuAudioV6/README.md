# Geo Susu Audio v74

## Nueva opción para abrir archivos TXT

Agregado:
- Botón ABRIR P/R para cargar el archivo TXT de preguntas y respuestas.
- Botón ABRIR VAR para cargar el archivo TXT de variantes.
- La carga se hace en segundo plano para evitar que Android muestre "no responde".

Uso:
1. Guarda los archivos TXT en el celular.
2. Toca ABRIR P/R y selecciona TXT_PR_500_recursos_geologicos.txt.
3. Toca ABRIR VAR y selecciona TXT_VARIANTES_500_recursos_geologicos.txt.
4. Espera el mensaje de cargado.
5. Usa Google interno parecido + TXT.

Formato:
pregunta | respuesta
pregunta | variante1, variante2
