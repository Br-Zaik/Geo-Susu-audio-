# Geo Susu Audio v75

## Corrección para que no se congele al abrir

Problema:
- Si ya pegaste o abriste los TXT de 500 preguntas, la app podía quedarse en "no responde" al iniciar.

Solución:
- Al iniciar, limpia temporalmente el índice pesado anterior.
- Abre la pantalla rápido.
- Reconstruye el TXT grande en segundo plano.
- Muestra "Preparando TXT grande..." y luego "TXT listo".
- Mantiene los botones ABRIR P/R y ABRIR VAR.
- No borra tus archivos TXT guardados.

Uso:
1. Instala v75 encima.
2. Abre la app.
3. Si Android muestra "no responde", toca ESPERAR.
4. Espera hasta ver "TXT listo".
5. Usa Google interno parecido + TXT.
