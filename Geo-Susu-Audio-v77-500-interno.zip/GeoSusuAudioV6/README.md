# Geo Susu Audio v77

## Solución real: 500 preguntas dentro del APK

Cambio principal:
- Las 500 preguntas y sus variantes van dentro del APK como assets.
- Ya no necesitas pegar ni abrir TXT para usar el pack de 500.
- Al iniciar limpia el índice pesado viejo de v74/v75/v76.
- La app carga el pack interno directamente desde assets, sin convertirlo a JSON pesado en SharedPreferences.
- Conserva ABRIR P/R y ABRIR VAR solo como opción adicional.

Uso:
1. Instala v77 encima.
2. Abre la app.
3. Selecciona Google interno parecido + TXT.
4. Toca ESCUCHAR.
5. Pregunta: "qué es mineral", "tipos de roca", "qué es Antapaccay", etc.

Nota:
No cargues el TXT de 500 manualmente. Ya está dentro de la APK.
