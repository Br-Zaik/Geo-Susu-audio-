# Geo Susu Audio v78 limpio

Base usada: Geo-Susu-Audio-v77-500-interno.zip

## Cambios
- Se borraron las preguntas internas.
- Se borraron las variantes internas.
- Se vació respuestas.json.
- Se vaciaron los TXT internos de 500 preguntas y variantes.
- Al abrir esta versión por primera vez se limpia la memoria anterior guardada en el celular.
- Se mantiene la interfaz original de esta base.
- Se deja listo para que agregues todo manualmente desde la app.

## Formato para agregar
Pregunta y respuesta:
pregunta | respuesta

Variantes:
pregunta | variante1, variante2, variante3
