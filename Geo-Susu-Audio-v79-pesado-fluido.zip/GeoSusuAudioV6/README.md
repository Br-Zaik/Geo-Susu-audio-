# Geo Susu Audio v79

## Versión pesada y más fluida

Cambios principales:
- 500 preguntas internas dentro del APK.
- 500 líneas de variantes internas.
- Mínimo 10 variantes por cada pregunta.
- Promedio aproximado: 13 variantes por pregunta.
- Índice exacto para responder rápido.
- Índice por palabras para no revisar todas las preguntas cada vez.
- Más frases de gramática para Vosk offline si descargas modelo.
- Limpia datos pesados antiguos de versiones anteriores.
- No necesitas pegar ni abrir TXT.

Correcciones agregadas:
- santa pacay / anta pacay / antapacay -> antapaccay
- tipo de socas -> tipos de roca
- canca -> ganga
- nena/mema -> mena
- logeo -> logueo
- escala de mosh -> escala de mohs
- porfiro / por fido -> pórfido
- escarn -> skarn
- calco pirita -> calcopirita
- bonita mineral -> bornita

Uso recomendado:
1. Instala v79 encima.
2. No abras ni pegues TXT.
3. Ajustes: Google interno parecido.
4. Modo: TXT.
5. Toca escuchar.

Para pantalla apagada/offline:
- Descarga OFFLINE y usa Vosk, pero el reconocimiento puede ser menos preciso que Google.
