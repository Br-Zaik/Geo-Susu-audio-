# Geo Susu Audio v80 - edición limpia estable

Solución real aplicada:
- Nuevo applicationId: com.bph.geosusuaudio.v80
- Se instala como app nueva para no arrastrar datos dañados de versiones anteriores.
- 500 preguntas internas dentro del APK.
- 500 líneas de variantes internas, mínimo 10 por pregunta.
- No usa TXT pegado ni TXT abierto para el pack principal.
- No carga JSON pesado viejo de SharedPreferences.
- Desactiva backup para evitar restaurar datos dañados.
- Índice exacto + índice por palabras para respuesta más fluida.
- Botones ABRIR P/R y ABRIR VAR quedan ocultos para no volver a meter TXT pesado.

Uso correcto:
1. Desinstala o ignora la app vieja.
2. Instala esta v80.
3. Abre "Geo Susu Audio v80".
4. Ajustes: Google interno parecido.
5. Modo: TXT.
6. Toca ESCUCHAR.

Offline:
- El botón DESCARGAR OFFLINE sigue para Vosk.
- La base de respuestas ya está offline dentro del APK.
- Google interno reconoce mejor que Vosk, pero necesita Speech Services/Google.
