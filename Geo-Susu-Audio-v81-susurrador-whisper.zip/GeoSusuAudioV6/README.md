# Geo Susu Audio v81 - Susurrador Whisper

Base: v77 limpia manual.

## Cambios principales
- Motor principal: Susurrador Whisper local.
- Ya no usa Google interno como escuchador.
- Ya no usa Vosk como motor principal.
- El botón ESCUCHAR graba bloques cortos de audio tipo WhatsApp.
- Transcribe con Whisper local y reinicia solo para la siguiente pregunta.
- Mantiene TXT / NET.
- TXT y variantes siguen vacíos para que agregues manualmente.
- El TXT soporta texto largo porque se guarda como bloque completo en SharedPreferences.
- NET usa búsqueda organizada con enfoque minería por defecto.

## Uso
1. Instala la app.
2. Toca DESCARGAR OFFLINE una vez.
3. Espera que descargue el modelo Whisper base.
4. Toca ESCUCHAR.
5. Habla o susurra cerca del Zync.
6. Agrega preguntas en EDITAR TXT y variantes en VARIANTES.

## Formato TXT
pregunta | respuesta

## Formato variantes
pregunta | variante1, variante2, variante3
