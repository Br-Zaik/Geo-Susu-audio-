# Geo Susu Audio v82 - fix Whisper compile

## Corrección
Se corrigió el error de compilación:

Suspend function 'transcribe' should be called only from a coroutine or another suspend function.

Ahora transcribe se llama dentro de runBlocking y se agregó la dependencia de coroutines.

## Mantiene
- Susurrador Whisper como motor principal.
- Sin Google interno como escuchador.
- Sin Vosk como motor principal.
- TXT vacío para carga manual.
- Variantes vacías para carga manual.
- NET organizado.
