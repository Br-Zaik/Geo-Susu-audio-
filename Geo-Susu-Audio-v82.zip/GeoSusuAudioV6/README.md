# Geo Susu Audio v82

## Corrección de ruta
Esta versión continúa la numeración correcta: v82.

## Incluye
- Base interna ampliada a 250 preguntas con variantes.
- Interfaz compacta principal sin desplazarse para lo básico.
- Medidor de voz para saber si hablas bajo, correcto o fuerte.
- Botón TXT para abrir archivo.
- Botón Pegar para importar texto masivo.
- Modos: Mixto, TXT y Net.
- Comando configurable para pausar/reanudar.
- Vosk continuo.
- Reinicio del reconocedor después de cada respuesta.
- Corrección para no mostrar solo memoria 0 cuando ya existe base interna.

## Formato TXT
pregunta | variantes | respuesta

Ejemplo:
ganga | gaga, aga, canga | La ganga es el material sin valor económico que acompaña a la mena.
