# Geo Susu Audio v84 - escucha tipo Google

## Objetivo
Crear una versión que escuche como Google, porque Whisper/Vosk no funcionaron bien en el celular.

## Importante
Esta versión usa el reconocimiento tipo Google de Android porque es lo más preciso para voz baja.
Android puede mostrar la ventana de Google. Eso es normal en este modo.

## Mantiene
- Base limpia para agregar preguntas manualmente.
- EDITAR TXT.
- VARIANTES.
- TXT / NET.
- Reintento automático después de responder.
- Interfaz de la base v77.

## Uso
1. Instala la APK.
2. Toca ESCUCHAR.
3. Habla cerca del Zync.
4. La app responde y vuelve a abrir escucha.
