# Geo Susu Audio v86 - auto retry accesibilidad

## Cambios
- Mantiene escucha tipo Google.
- Mantiene botón flotante sobre otras apps.
- Agrega servicio de Accesibilidad: Geo Susu Auto Retry.
- Cuando aparece "No entendí" o "Reintentar", intenta tocar Reintentar automáticamente.
- Si no encuentra el botón, hace BACK y vuelve a abrir la escucha.
- Reintento más rápido.

## Importante
Android no permite que una app normal toque la ventana de Google.
Para que funcione de verdad debes activar:
Ajustes > Accesibilidad > Geo Susu Audio / Geo Susu Auto Retry.

## Uso
1. Instala v86.
2. Da permiso de micrófono.
3. Activa mostrar sobre otras apps.
4. Activa Accesibilidad de Geo Susu.
5. Toca ESCUCHAR.
