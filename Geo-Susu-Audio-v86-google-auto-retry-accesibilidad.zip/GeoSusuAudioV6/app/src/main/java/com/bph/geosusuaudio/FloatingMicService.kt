package com.bph.geosusuaudio

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button

class FloatingMicService : Service() {

    private var windowManager: WindowManager? = null
    private var button: Button? = null

    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        button = Button(this).apply {
            text = "🎙"
            textSize = 22f
            alpha = 0.88f
            setOnClickListener {
                val intent = Intent(this@FloatingMicService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra(MainActivity.EXTRA_START_GOOGLE, true)
                }
                startActivity(intent)
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            150,
            150,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 24
            y = 0
        }

        windowManager?.addView(button, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        button?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        button = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
