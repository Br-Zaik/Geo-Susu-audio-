package com.bph.geosusuaudio

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GoogleRetryAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 1600L) return

        val visibleText = collectText(root).lowercase()
        val looksLikeGoogleNoUnderstand =
            visibleText.contains("no entend") ||
            visibleText.contains("dilo de nuevo") ||
            visibleText.contains("no te entend") ||
            visibleText.contains("try again") ||
            visibleText.contains("retry")

        if (!looksLikeGoogleNoUnderstand) return

        val retryNode = findClickableByText(
            root,
            listOf("reintentar", "intentar de nuevo", "dilo de nuevo", "retry", "try again")
        )

        if (retryNode != null) {
            lastActionAt = now
            retryNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return
        }

        lastActionAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(MainActivity.EXTRA_START_GOOGLE, true)
            }
            startActivity(intent)
        }, 450L)
    }

    override fun onInterrupt() = Unit

    private fun collectText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val out = StringBuilder()
        node.text?.let { out.append(it).append(' ') }
        node.contentDescription?.let { out.append(it).append(' ') }

        for (i in 0 until node.childCount) {
            out.append(collectText(node.getChild(i)))
        }

        return out.toString()
    }

    private fun findClickableByText(
        node: AccessibilityNodeInfo?,
        targets: List<String>
    ): AccessibilityNodeInfo? {
        if (node == null) return null

        val value = buildString {
            node.text?.let { append(it).append(' ') }
            node.contentDescription?.let { append(it).append(' ') }
        }.lowercase()

        if (targets.any { value.contains(it) }) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) return current
                current = current.parent
            }
        }

        for (i in 0 until node.childCount) {
            val found = findClickableByText(node.getChild(i), targets)
            if (found != null) return found
        }

        return null
    }
}
