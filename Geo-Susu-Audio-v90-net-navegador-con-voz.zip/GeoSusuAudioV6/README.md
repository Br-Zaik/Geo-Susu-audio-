# Geo Susu Audio v90 - NET navegador con voz

## Revisión
No puedo ejecutar la APK real en tu celular desde aquí, pero revisé el proyecto:
- No quedan clases ni referencias a Google.
- No quedan clases ni referencias a Vosk.
- No hay permiso de mostrar sobre otras apps.
- TXT sigue guardándose en archivo interno para soportar mucho texto.
- El proyecto no trae gradle wrapper, por eso no pude compilar aquí dentro.

## Cambios
- Se restaura NET.
- NET ahora funciona más parecido a navegador:
  1. busca en internet;
  2. abre resultados;
  3. lee texto de páginas;
  4. arma una respuesta corta;
  5. la dice en voz.
- No es solo Wikipedia.
- Mantiene TXT.
- Mantiene susurrador local con Whisper base-q5_1.
- Sin Google.
- Sin Vosk.
- Sin sobre otras apps.

## Uso
1. Instala v90.
2. Toca DESCARGAR OFFLINE para bajar el modelo de voz.
3. En TXT pega tus preguntas.
4. En NET puedes preguntar algo de internet.
5. La respuesta sale en pantalla y en sonido.
