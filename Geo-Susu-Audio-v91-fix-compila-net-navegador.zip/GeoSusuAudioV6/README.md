# Geo Susu Audio v91 - fix compile pendingStartMode

## Corrección
Se corrigió el error de compilación:

MainActivity.kt:574:9 Unresolved reference: pendingStartMode

## Cambios
- Se eliminó la referencia vieja a pendingStartMode.
- Se mantiene NET navegador con voz.
- Se mantiene TXT.
- Se mantiene Whisper base-q5_1.
- No hay referencias a Google ni Vosk en el código Kotlin.
- No hay permiso de mostrar sobre otras apps.

## Nota
No trae gradle wrapper dentro del ZIP, por eso aquí no se pudo ejecutar el build completo; se hizo revisión estática del error mostrado y de referencias viejas.
