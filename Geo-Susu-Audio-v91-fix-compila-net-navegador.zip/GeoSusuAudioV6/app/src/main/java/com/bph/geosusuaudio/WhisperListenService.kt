package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.runBlocking
import mx.valdora.whisper.WhisperContext
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class WhisperListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }
    private lateinit var modelManager: WhisperModelManager

    private var audioRecord: AudioRecord? = null
    private var listenThread: Thread? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var whisper: WhisperContext? = null
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var busy = false
    @Volatile private var isSpeaking = false

    private var lastLevelUpdate = 0L
    private var lastQuestion = ""
    private var lastQuestionAt = 0L

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        memory = MemoryStore(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        modelManager = WhisperModelManager(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Susurrador preparando..."))
        if (!running) startWhisperLoop()
        return START_STICKY
    }

    private fun startWhisperLoop() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "Activa permiso de micrófono.", 0)
            stopSelf()
            return
        }

        if (!modelManager.isReady()) {
            sendUpdate("Falta modelo Whisper", "", "Toca DESCARGAR OFFLINE una vez.", 0)
            stopSelf()
            return
        }

        Thread {
            try {
                sendUpdate("Cargando Whisper...", "", "Espera unos segundos.", 0)
                whisper = WhisperContext(modelManager.modelFile().absolutePath)
                startAudioRecordLoop()
            } catch (e: Throwable) {
                sendUpdate("Whisper no pudo iniciar", "", "Modelo muy pesado o incompatible. Reinstala y descarga base q5.", 0)
                stopSelf()
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun startAudioRecordLoop() {
        val sampleRate = 16000
        val min = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(min, 2048)
        val buffer = ShortArray(bufferSize / 2)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            sendUpdate("No se pudo abrir micrófono", "", "Revisa permisos o Zync.", 0)
            stopSelf()
            return
        }

        running = true
        audioRecord?.startRecording()
        sendUpdate("Susurrador base q5 activo", "", "Habla cerca del micrófono. Graba bloques cortos.", 0)

        listenThread = Thread {
            val preRoll = ArrayDeque<Short>()
            val segment = ArrayList<Short>(sampleRate * 8)
            var recording = false
            var silenceMs = 0
            var speechMs = 0
            var maxLevel = 0

            val startThreshold = 5
            val stopThreshold = 3
            val minSpeechMs = 650
            val stopSilenceMs = 700
            val maxSpeechMs = 4500
            val bufferMs = ((buffer.size.toFloat() / sampleRate.toFloat()) * 1000f).toInt().coerceAtLeast(40)
            val preRollMax = (sampleRate * 0.45f).toInt()

            while (running) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read <= 0) continue

                val level = calculateLevel(buffer, read)
                sendLevel(level)

                if (busy || isSpeaking) {
                    continue
                }

                for (i in 0 until read) {
                    preRoll.addLast(buffer[i])
                    if (preRoll.size > preRollMax) preRoll.removeFirst()
                }

                if (!recording) {
                    if (level >= startThreshold) {
                        recording = true
                        silenceMs = 0
                        speechMs = 0
                        maxLevel = level
                        segment.clear()
                        segment.addAll(preRoll)
                        sendUpdate("Grabando susurro...", "", "Sigue hablando. Nivel $level%", level)
                    }
                    continue
                }

                for (i in 0 until read) segment.add(buffer[i])
                speechMs += bufferMs
                if (level > maxLevel) maxLevel = level

                silenceMs = if (level <= stopThreshold) silenceMs + bufferMs else 0

                val enoughSpeech = speechMs >= minSpeechMs
                val shouldStop = (enoughSpeech && silenceMs >= stopSilenceMs) || speechMs >= maxSpeechMs

                if (shouldStop) {
                    val captured = segment.toShortArray()
                    recording = false
                    segment.clear()

                    if (captured.size < sampleRate / 3 || maxLevel < startThreshold) {
                        sendUpdate("Susurro muy bajo", "", "Acerca el Zync y repite.", maxLevel)
                        continue
                    }

                    busy = true
                    processCapturedAudio(captured, sampleRate, maxLevel)
                    busy = false
                }
            }
        }.apply {
            name = "GeoSusuWhisperLoop"
            start()
        }
    }

    private fun processCapturedAudio(samples: ShortArray, sampleRate: Int, level: Int) {
        val wavFile = File(cacheDir, "geo_susu_question_${System.currentTimeMillis()}.wav")
        try {
            writeWav(wavFile, samples, sampleRate)
            sendUpdate("Procesando susurro...", "", "Whisper base q5 procesando audio corto.", level)

            val heard = runBlocking { whisper?.transcribe(wavFile) ?: "" }.trim()
            val cleanHeard = heard.replace("\\s+".toRegex(), " ").trim()

            if (cleanHeard.length < 2) {
                sendUpdate("No entendí el susurro", "", "Repite más cerca del micrófono.", level)
                return
            }

            val now = System.currentTimeMillis()
            if (ResponseRepository.normalize(cleanHeard) == lastQuestion && now - lastQuestionAt < 5000) {
                sendUpdate("Repetido ignorado", cleanHeard, "Listo para otra pregunta.", level)
                return
            }

            lastQuestion = ResponseRepository.normalize(cleanHeard)
            lastQuestionAt = now
            answerQuestion(cleanHeard, level)
        } catch (e: Throwable) {
            sendUpdate("Error procesando susurro", "", "No se pudo transcribir. Repite o reinicia escucha.", level)
        } finally {
            runCatching { wavFile.delete() }
        }
    }

    private fun answerQuestion(question: String, level: Int) {
        sendUpdate("Texto detectado", question, "Buscando respuesta...", level)

        if (modeSettings.getMode() == AnswerModeSettings.Mode.INTERNET) {
            Thread {
                val answer = try {
                    onlineProvider.fetchShortAnswer(question)
                } catch (_: Exception) {
                    "No pude buscar en internet. Revisa conexión."
                }
                memory.saveLast(question, answer, "net_browser", 0)
                handler.post {
                    speak(answer, "NET navegador", question, level)
                }
            }.start()
            return
        }

        val match = repository.findBest(question)
        if (match.itemId != "none") {
            memory.saveLast(question, match.answer, match.itemId, match.score)
            speak(match.answer, "TXT encontrado. Precisión ${match.score}%", question, level)
        } else {
            speak("No encontrado en TXT. Agrega esa pregunta o una variante.", "No encontrado en TXT", question, level)
        }
    }

    private fun speak(answer: String, status: String, heard: String, level: Int) {
        isSpeaking = true
        sendUpdate(status, heard, answer, level)
        handler.post {
            tts?.stop()
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
        }
    }

    private fun calculateLevel(buffer: ShortArray, read: Int): Int {
        var sum = 0.0
        var peak = 0
        val gain = appSettings.getMicGain().coerceAtLeast(4.2f)

        for (i in 0 until read) {
            val sample = buffer[i].toInt()
            val absValue = abs(sample)
            if (absValue > peak) peak = absValue
            sum += (sample * sample).toDouble()
        }

        val rms = sqrt(sum / read.coerceAtLeast(1))
        val rmsLevel = ((rms / 32768.0) * 100.0 * gain).toInt()
        val peakLevel = ((peak / 32768.0) * 100.0 * gain * 0.55f).toInt()
        return maxOf(rmsLevel, peakLevel).coerceIn(0, 100)
    }

    private fun sendLevel(level: Int) {
        val now = System.currentTimeMillis()
        if (now - lastLevelUpdate < 160L) return
        lastLevelUpdate = now
        sendUpdate("", "", "", level)
    }

    private fun writeWav(file: File, samples: ShortArray, sampleRate: Int) {
        val byteRate = sampleRate * 2
        val dataSize = samples.size * 2
        val totalSize = 36 + dataSize

        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(0)
            raf.writeBytes("RIFF")
            raf.writeIntLE(totalSize)
            raf.writeBytes("WAVE")
            raf.writeBytes("fmt ")
            raf.writeIntLE(16)
            raf.writeShortLE(1)
            raf.writeShortLE(1)
            raf.writeIntLE(sampleRate)
            raf.writeIntLE(byteRate)
            raf.writeShortLE(2)
            raf.writeShortLE(16)
            raf.writeBytes("data")
            raf.writeIntLE(dataSize)

            for (sample in samples) {
                raf.writeShortLE(sample.toInt())
            }
        }
    }

    private fun RandomAccessFile.writeIntLE(value: Int) {
        write(value and 0xFF)
        write((value shr 8) and 0xFF)
        write((value shr 16) and 0xFF)
        write((value shr 24) and 0xFF)
    }

    private fun RandomAccessFile.writeShortLE(value: Int) {
        write(value and 0xFF)
        write((value shr 8) and 0xFF)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)
        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu Whisper", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Susurrador")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::WhisperWakeLock").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            sendUpdate("Susurrador listo", "", "Listo para otra pregunta.", -1)
                        }, 650L)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    sendUpdate("Susurrador listo", "", "Listo para otra pregunta.", -1)
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        runCatching { whisper?.close() }
        tts?.stop()
        tts?.shutdown()
        runCatching { wakeLock?.release() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.WHISPER_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_whisper_channel"
        private const val NOTIFICATION_ID = 3001
        private const val UTTERANCE_ID = "geo_susu_whisper_answer"
    }
}
