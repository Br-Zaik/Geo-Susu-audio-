package com.bph.geosusuaudio

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class WhisperModelManager(private val context: Context) {

    private val modelUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base-q5_1.bin"
    private val modelName = "ggml-base-q5_1.bin"

    fun modelFile(): File {
        val dir = File(context.filesDir, "whisper")
        if (!dir.exists()) dir.mkdirs()
        File(dir, "ggml-base.bin").takeIf { it.exists() }?.delete()
        File(dir, "ggml-base.bin.tmp").takeIf { it.exists() }?.delete()
        File(dir, "ggml-tiny.bin").takeIf { it.exists() }?.delete()
        File(dir, "ggml-tiny.bin.tmp").takeIf { it.exists() }?.delete()
        return File(dir, modelName)
    }

    fun isReady(): Boolean {
        val file = modelFile()
        return file.exists() && file.length() > 50_000_000L
    }

    fun downloadModel(
        onProgress: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        Thread {
            try {
                val outFile = modelFile()
                val tempFile = File(outFile.parentFile, "$modelName.tmp")
                onProgress("Descargando modelo Whisper base q5...")

                val connection = URL(modelUrl).openConnection() as HttpURLConnection
                connection.instanceFollowRedirects = true
                connection.connectTimeout = 20000
                connection.readTimeout = 30000
                connection.setRequestProperty("User-Agent", "GeoSusuAudio/8.1 Android")
                connection.connect()

                val total = connection.contentLengthLong
                var downloaded = 0L

                connection.inputStream.use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(1024 * 128)
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            downloaded += read

                            if (total > 0) {
                                val pct = ((downloaded * 100) / total).toInt().coerceIn(0, 100)
                                onProgress("Descargando Whisper base q5... $pct%")
                            } else {
                                val mb = downloaded / (1024 * 1024)
                                onProgress("Descargando Whisper base q5... ${mb}MB")
                            }
                        }
                    }
                }

                if (tempFile.length() < 50_000_000L) {
                    tempFile.delete()
                    onDone(false, "Descarga incompleta. Reintenta con internet estable.")
                    return@Thread
                }

                if (outFile.exists()) outFile.delete()
                tempFile.renameTo(outFile)
                onDone(true, "Whisper listo. Toca ESCUCHAR.")
            } catch (e: Exception) {
                onDone(false, "Error descargando Whisper: ${e.message ?: "sin detalle"}")
            }
        }.start()
    }
}
