# Geo Susu Audio v93 - fix real de instalación

## Por qué se hizo
Si Android dice "No se instaló la app" aunque no esté instalada y haya espacio, no es por el peso del ZIP.
Puede ser por conflicto de paquete/firma o por cómo Android resuelve la app.

## Cambios de v93
- Nuevo paquete interno: com.bph.geosusu.v93
- Nombre visible forzado: Geo Susu Audio v93
- Activity y Service con nombre completo para evitar conflictos con applicationId.
- extractNativeLibs activado para librerías nativas.
- useLegacyPackaging activado para JNI.
- VersionCode 93 / VersionName 9.3.

## Mantiene
- TXT + NET navegador con voz.
- Whisper base-q5_1.
- Sin Google.
- Sin Vosk.
- Sin sobre otras apps.

## Importante
Si al instalar no dice "Geo Susu Audio v93", estás instalando un APK viejo o el workflow no usó este ZIP.
