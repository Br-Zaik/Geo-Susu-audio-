# Geo Susu Gemini v109

APK Android para repaso por voz con respuestas desde JSON y consulta a Google Gemini mediante API Key configurada dentro de la app.

## Cambios v109

- El antiguo modo NET ahora usa Gemini API.
- Se agregó botón API GEMINI para pegar, guardar y probar la API Key.
- El modo AUTO primero busca en JSON y, si no encuentra respuesta, consulta Gemini.
- La API Key no está dentro del código: se guarda localmente en el teléfono.

## Uso básico

1. Abre la app.
2. Toca API GEMINI.
3. Pega tu API Key de Google AI Studio.
4. Toca PROBAR API.
5. Si funciona, usa modo GEMINI o AUTO.

## Compilación

Sube este ZIP al repositorio con GitHub Actions. El workflow descomprime el proyecto y ejecuta `gradle assembleDebug`.
