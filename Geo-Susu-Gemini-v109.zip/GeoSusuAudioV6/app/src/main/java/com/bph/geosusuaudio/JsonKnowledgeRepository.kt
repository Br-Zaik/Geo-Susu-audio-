package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class JsonKnowledgeRepository(private val context: Context) {

    data class KnowledgeItem(
        val id: String,
        val tema: String,
        val titulo: String,
        val contenido: String,
        val keywords: List<String>
    )

    private val items: List<KnowledgeItem> by lazy { loadItems() }

    val totalItems: Int get() = items.size

    fun findBest(rawQuestion: String): ResponseRepository.MatchResult {
        val question = ResponseRepository.normalize(rawQuestion)
        if (question.length < 2 || items.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val qWords = keyWords(question)
        val importantPhrase = protectedPhrase(question)

        if (qWords.isEmpty() && importantPhrase.isBlank()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        var best: KnowledgeItem? = null
        var bestScore = -9999
        var secondScore = -9999

        for (item in items) {
            val score = scoreItem(question, qWords, importantPhrase, item)

            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                best = item
            } else if (score > secondScore) {
                secondScore = score
            }
        }

        val item = best ?: return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)

        val minimum = if (importantPhrase.isNotBlank()) 110 else 70
        if (bestScore < minimum) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        // Si la diferencia es muy baja y no hay frase protegida, mejor no inventar.
        if (importantPhrase.isBlank() && bestScore - secondScore < 8 && bestScore < 140) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        return ResponseRepository.MatchResult(
            buildAnswer(item, qWords, importantPhrase),
            "json_${item.id}",
            bestScore.coerceIn(0, 100)
        )
    }

    private fun scoreItem(
        question: String,
        qWords: List<String>,
        importantPhrase: String,
        item: KnowledgeItem
    ): Int {
        val normalizedTitle = ResponseRepository.normalize(item.titulo)
        val normalizedTema = ResponseRepository.normalize(item.tema)
        val normalizedId = ResponseRepository.normalize(item.id.replace("_", " "))
        val normalizedKeywords = item.keywords.map { ResponseRepository.normalize(it) }.filter { it.length >= 2 }
        val normalizedBody = ResponseRepository.normalize(item.contenido.take(6000))
        val meta = "$normalizedId $normalizedTema $normalizedTitle ${normalizedKeywords.joinToString(" ")}"

        var score = 0

        val penalty = protectedPenalty(question, importantPhrase, meta, normalizedBody)
        if (penalty <= -1000) return penalty
        score += penalty

        if (importantPhrase.isNotBlank()) {
            if (meta.contains(importantPhrase)) score += 520
            if (normalizedTitle.contains(importantPhrase)) score += 650
            if (normalizedId.contains(importantPhrase.replace(" ", "_")) || normalizedId.contains(importantPhrase)) score += 420
            if (normalizedBody.contains(importantPhrase)) score += 160
        }

        for (phrase in normalizedKeywords) {
            if (phrase.length < 3) continue

            when {
                question == phrase -> score += 900
                containsPhrase(question, phrase) -> score += if (phrase.length >= 8) 520 else 180
                phrase.contains(question) && question.length >= 5 -> score += 260
            }
        }

        for (w in qWords) {
            if (normalizedTitle.contains(w)) score += 42
            if (normalizedId.contains(w)) score += 35
            if (normalizedTema.contains(w)) score += 14
            if (normalizedKeywords.any { it.contains(w) }) score += 34
            if (normalizedBody.contains(w)) score += 8
        }

        val compactQuestion = question.replace(" ", "")
        val compactTitle = normalizedTitle.replace(" ", "")
        if (compactQuestion.length >= 5 && compactTitle.contains(compactQuestion)) score += 280
        if (compactTitle.length >= 5 && compactQuestion.contains(compactTitle)) score += 250

        score += intentScore(question, meta)

        return score
    }

    private fun protectedPhrase(question: String): String {
        val q = " $question "
        val phrases = listOf(
            "minerales no metalicos",
            "no metalicos",
            "minerales semimetalicos",
            "semimetalicos",
            "minerales metalicos",
            "metalicos",
            "minerales nativos",
            "nativos",
            "sulfosales",
            "sulfatos",
            "sulfuros",
            "escala de mohs",
            "escala de mosh",
            "materiales comunes",
            "minerales importantes por metal",
            "minerales importantes",
            "tipos de roca",
            "tipos de rocas",
            "rocas igneas",
            "rocas sedimentarias",
            "rocas metamorficas",
            "calcopirita",
            "calco pirita",
            "pirita",
            "galena",
            "antapaccay",
            "antapacay",
            "porfido",
            "skarn",
            "logueo geologico",
            "logeo geologico",
            "recursos geologicos",
            "yacimiento minero",
            "mina antapaccay",
            "mena",
            "ley mineral",
            "ley"
        )

        for (p in phrases) {
            if (q.contains(" $p ")) {
                if (p == "metalicos" && (q.contains(" no metalicos ") || q.contains(" semimetalicos "))) continue
                if (p == "pirita" && q.contains(" calcopirita ")) continue
                if (p == "ley" && !q.contains(" ley ")) continue
                return normalizeProtected(p)
            }
        }

        return ""
    }

    private fun normalizeProtected(phrase: String): String {
        return when (phrase) {
            "escala de mosh" -> "escala de mohs"
            "calco pirita" -> "calcopirita"
            "antapacay" -> "antapaccay"
            "logeo geologico" -> "logueo geologico"
            "tipos de rocas" -> "tipos de roca"
            else -> phrase
        }
    }

    private fun protectedPenalty(question: String, importantPhrase: String, meta: String, body: String): Int {
        if (importantPhrase.isBlank()) return 0

        val all = "$meta $body"

        fun has(text: String) = all.contains(text)

        if (importantPhrase == "no metalicos") {
            if (!has("no metalicos")) return -1400
        }

        if (importantPhrase == "minerales no metalicos") {
            if (!has("no metalicos") && !has("minerales no metalicos")) return -1400
        }

        if (importantPhrase == "semimetalicos" || importantPhrase == "minerales semimetalicos") {
            if (!has("semimetalicos")) return -1200
        }

        if (importantPhrase == "metalicos" || importantPhrase == "minerales metalicos") {
            if (question.contains("no metalicos") || question.contains("semimetalicos")) return -1400
            if (!has("metalicos") || has("no metalicos") || has("semimetalicos")) return -800
        }

        if (importantPhrase == "sulfuros" && (has("sulfatos") || has("sulfosales")) && !has("sulfuros")) return -900
        if (importantPhrase == "sulfatos" && (has("sulfuros") || has("sulfosales")) && !has("sulfatos")) return -900
        if (importantPhrase == "sulfosales" && (has("sulfuros") || has("sulfatos")) && !has("sulfosales")) return -900

        if (importantPhrase == "pirita" && has("calcopirita") && !has(" pirita ")) return -650
        if (importantPhrase == "calcopirita" && has("pirita") && !has("calcopirita")) return -650

        return 0
    }

    private fun intentScore(question: String, meta: String): Int {
        var score = 0

        if ((question.contains("ejemplo") || question.contains("menciona")) &&
            (meta.contains("ejemplo") || meta.contains("ejemplos"))) score += 180

        if ((question.contains("caracteristica") || question.contains("propiedad")) &&
            (meta.contains("caracteristica") || meta.contains("propiedad"))) score += 120

        if ((question.contains("importancia") || question.contains("importante")) &&
            meta.contains("importancia")) score += 120

        if ((question.contains("para que sirve") || question.contains("funcion") || question.contains("uso")) &&
            (meta.contains("sirve") || meta.contains("funcion") || meta.contains("uso"))) score += 120

        if ((question.contains("diferencia") || question.contains("diferenciar")) &&
            meta.contains("diferencia")) score += 120

        if ((question.contains("clasifica") || question.contains("clasificacion") || question.contains("clases")) &&
            meta.contains("clasificacion")) score += 120

        if ((question.contains("formula") || question.contains("simbolo") || question.contains("quimica")) &&
            (meta.contains("formula") || meta.contains("simbolo") || meta.contains("quimica"))) score += 120

        return score
    }

    private fun containsPhrase(text: String, phrase: String): Boolean {
        if (phrase.length < 3) return false
        val paddedText = " $text "
        val paddedPhrase = " $phrase "
        return paddedText.contains(paddedPhrase) || text.contains(phrase)
    }

    private fun buildAnswer(item: KnowledgeItem, qWords: List<String>, importantPhrase: String): String {
        val chunks = item.contenido
            .replace("\r", "\n")
            .split("\n\n", "\n", ". ")
            .map { it.trim() }
            .filter { it.length >= 30 }
            .map { chunk ->
                val normalized = ResponseRepository.normalize(chunk)
                var score = 0
                if (importantPhrase.isNotBlank() && normalized.contains(importantPhrase)) score += 8
                for (w in qWords) {
                    if (normalized.contains(w)) score += 2
                }
                if (looksLikeMainAnswer(normalized)) score += 3
                score to chunk
            }
            .filter { it.first > 0 }
            .sortedByDescending { it.first }
            .map { it.second }

        val picked = if (chunks.isNotEmpty()) {
            chunks.take(2).joinToString(". ")
        } else {
            item.contenido.trim()
        }

        val clean = picked.replace("\\s+".toRegex(), " ").trim()
        val limited = clean.take(540).trim()
        return if (clean.length > 540) "$limited..." else limited
    }

    private fun looksLikeMainAnswer(text: String): Boolean {
        val markers = listOf(" es ", " son ", "se forma", "se clasific", "ejemplo", "sirve", "importante", "contiene")
        return markers.any { text.contains(it) }
    }

    private fun loadItems(): List<KnowledgeItem> {
        val store = JsonKnowledgeStore(context)
        val raw = store.readJson()
        val variantsMap = loadVariantsMap(store.readVariantsJson())
        if (raw.isBlank()) return emptyList()

        return try {
            val trimmed = raw.trim()
            val array = when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> {
                    val obj = JSONObject(trimmed)
                    obj.optJSONArray("temas")
                        ?: obj.optJSONArray("items")
                        ?: obj.optJSONArray("data")
                        ?: JSONArray()
                }
            }

            val result = mutableListOf<KnowledgeItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val tema = obj.optString("tema", obj.optString("categoria", "General")).trim()
                val titulo = obj.optString(
                    "titulo",
                    obj.optString("pregunta", obj.optString("nombre", tema))
                ).trim()
                val contenido = obj.optString(
                    "contenido",
                    obj.optString("respuesta", obj.optString("texto", obj.optString("descripcion", "")))
                ).trim()

                if (contenido.isBlank()) continue

                val id = obj.optString("id", "item_$i").ifBlank { "item_$i" }
                val keywords = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "palabrasClave") +
                    readStringArray(obj, "negativos") +
                    variantsMap[id].orEmpty() +
                    variantsMap[ResponseRepository.normalize(titulo)].orEmpty() +
                    variantsMap[ResponseRepository.normalize(tema)].orEmpty()

                result.add(
                    KnowledgeItem(
                        id = id,
                        tema = tema.ifBlank { "General" },
                        titulo = titulo.ifBlank { tema.ifBlank { "Tema $i" } },
                        contenido = contenido,
                        keywords = keywords.distinct()
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun loadVariantsMap(raw: String): Map<String, List<String>> {
        if (raw.isBlank()) return emptyMap()

        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("variantes")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }

            val result = linkedMapOf<String, MutableList<String>>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val key = obj.optString(
                    "id",
                    obj.optString("tema", obj.optString("titulo", obj.optString("pregunta", "")))
                ).trim()
                if (key.isBlank()) continue

                val values = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "palabrasClave")

                if (values.isNotEmpty()) {
                    val normalizedKey = ResponseRepository.normalize(key)
                    result.getOrPut(key) { mutableListOf() }.addAll(values)
                    result.getOrPut(normalizedKey) { mutableListOf() }.addAll(values)
                }
            }

            result.mapValues { it.value.distinct() }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun readStringArray(obj: JSONObject, key: String): List<String> {
        val arr = obj.optJSONArray(key) ?: return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val value = obj.optJSONArray(key)?.optString(i)?.trim().orEmpty()
            if (value.isNotBlank()) list.add(value)
        }
        return list
    }

    private fun keyWords(text: String): List<String> {
        val stop = setOf(
            "que", "qué", "q", "es", "son", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuales",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa",
            "internet", "net", "json", "tema", "sobre", "explica", "breve", "rapido",
            "rápido", "respuesta", "pregunta"
        )
        return text.split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
            .take(18)
    }

    companion object {
        const val JSON_EMPTY = "No encontrado"
        const val JSON_NOT_FOUND = "No encontrado"
    }
}

class JsonKnowledgeStore(private val context: Context) {

    fun getUrl(): String {
        return prefs().getString(KEY_URL, "").orEmpty().trim()
    }

    fun saveUrl(url: String) {
        prefs().edit().putString(KEY_URL, url.trim()).apply()
    }

    fun getVariantsUrl(): String {
        return prefs().getString(KEY_VARIANTS_URL, "").orEmpty().trim()
    }

    fun saveVariantsUrl(url: String) {
        prefs().edit().putString(KEY_VARIANTS_URL, url.trim()).apply()
    }

    fun readJson(): String {
        val file = File(context.filesDir, JSON_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun hasJson(): Boolean {
        return readJson().isNotBlank()
    }

    fun readVariantsJson(): String {
        val file = File(context.filesDir, VARIANTS_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun downloadVariantsJson(): Pair<Boolean, String> {
        val url = getVariantsUrl()
        if (url.isBlank()) return true to "Sin JSON de variantes."
        return downloadToFile(url, VARIANTS_FILE, "Variantes JSON")
    }

    fun downloadJson(): Pair<Boolean, String> {
        val url = getUrl()
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }
        return downloadToFile(url, JSON_FILE, "Temas JSON")
    }

    private fun downloadToFile(url: String, fileName: String, label: String): Pair<Boolean, String> {
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }

        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.setRequestProperty("User-Agent", "GeoSusuAudio Android")
            connection.setRequestProperty("Accept", "application/json,text/plain,*/*")

            val raw = try {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally {
                connection.disconnect()
            }

            if (raw.isBlank()) return false to "$label descargado está vacío."

            val count = countItems(raw)
            if (count <= 0) return false to "$label no parece válido."

            File(context.filesDir, fileName).writeText(raw)
            true to "$label actualizado. Elementos: $count"
        } catch (_: Exception) {
            false to "No se pudo descargar $label. Revisa link o internet."
        }
    }

    private fun countItems(raw: String): Int {
        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("temas")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }
            array.length()
        } catch (_: Exception) {
            0
        }
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS = "geo_susu_json"
        private const val KEY_URL = "json_url"
        private const val KEY_VARIANTS_URL = "json_variants_url"
        private const val JSON_FILE = "temas_github.json"
        private const val VARIANTS_FILE = "variantes_github.json"
    }
}
