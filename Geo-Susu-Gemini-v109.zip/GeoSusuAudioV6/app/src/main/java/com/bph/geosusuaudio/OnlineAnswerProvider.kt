package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    private data class GeminiCallResult(
        val ok: Boolean,
        val text: String,
        val error: String,
        val model: String
    )

    private val modelCandidates = listOf(
        "gemini-3.5-flash",
        "gemini-2.5-flash",
        "gemini-1.5-flash"
    )

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val apiKey = context?.let { GeminiSettings(it).getApiKey() }.orEmpty()
        if (apiKey.isBlank()) {
            return "Sin API Key Gemini. Toca API GEMINI, pega tu clave y prueba si funciona."
        }

        val result = askGemini(apiKey, query)
        if (result.ok && result.text.isNotBlank()) return result.text

        return result.error.ifBlank {
            "Gemini no devolvió respuesta. Revisa tu API Key, internet o límite de uso."
        }
    }

    fun testApiKey(apiKey: String): Pair<Boolean, String> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) return false to "Pega primero tu API Key de Gemini."

        val result = askGemini(cleanKey, "Responde solo con estas dos palabras: API OK", testing = true)
        return if (result.ok && result.text.isNotBlank()) {
            true to "API Gemini funcionando. Modelo usado: ${result.model}."
        } else {
            false to result.error.ifBlank { "No se pudo probar la API. Revisa la clave o internet." }
        }
    }

    private fun askGemini(apiKey: String, question: String, testing: Boolean = false): GeminiCallResult {
        var lastError = ""

        for (model in modelCandidates) {
            val result = callGeminiModel(apiKey, model, question, testing)
            if (result.ok) return result

            lastError = result.error
            val lower = result.error.lowercase()
            val shouldTryNextModel = lower.contains("model") ||
                lower.contains("not found") ||
                lower.contains("not supported") ||
                lower.contains("deprecated") ||
                lower.contains("unavailable")

            if (!shouldTryNextModel) break
        }

        return GeminiCallResult(false, "", lastError, "")
    }

    private fun callGeminiModel(
        apiKey: String,
        model: String,
        question: String,
        testing: Boolean
    ): GeminiCallResult {
        var connection: HttpURLConnection? = null

        return try {
            val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            )

            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
            }

            val body = buildRequestBody(question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                val msg = parseGeminiError(raw).ifBlank { "Error HTTP $code al llamar Gemini." }
                return GeminiCallResult(false, "", msg, model)
            }

            val answer = parseGeminiText(raw)
            if (answer.isBlank()) {
                GeminiCallResult(false, "", "Gemini respondió vacío. Intenta otra pregunta.", model)
            } else {
                GeminiCallResult(true, answer, "", model)
            }
        } catch (e: Exception) {
            GeminiCallResult(false, "", "No se pudo conectar con Gemini: ${e.message ?: "error de conexión"}.", model)
        } finally {
            connection?.disconnect()
        }
    }

    private fun buildRequestBody(question: String, testing: Boolean): JSONObject {
        val prompt = if (testing) {
            question
        } else {
            """
            Eres Geo Susu, un asistente de estudio para minería, geología, topografía y temas técnicos.
            Responde en español claro, directo y útil.
            Da una respuesta corta, de máximo 5 líneas, porque será leída por voz.
            Si la pregunta es técnica, explica con precisión y sin inventar datos.

            Pregunta: $question
            """.trimIndent()
        }

        return JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", if (testing) 0.0 else 0.25)
                    put("maxOutputTokens", if (testing) 32 else 260)
                }
            )
        }
    }

    private fun parseGeminiText(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        val partsText = StringBuilder()

        for (i in 0 until candidates.length()) {
            val content = candidates.optJSONObject(i)
                ?.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue

            for (j in 0 until parts.length()) {
                val text = parts.optJSONObject(j)?.optString("text").orEmpty()
                if (text.isNotBlank()) {
                    if (partsText.isNotBlank()) partsText.append("\n")
                    partsText.append(text.trim())
                }
            }
        }

        return cleanAnswer(partsText.toString())
    }

    private fun parseGeminiError(raw: String): String {
        return try {
            val error = JSONObject(raw).optJSONObject("error")
            val message = error?.optString("message").orEmpty()
            when {
                message.contains("API key", ignoreCase = true) ->
                    "API Key inválida o sin permiso para Gemini. Revisa la clave en Google AI Studio."
                message.contains("quota", ignoreCase = true) || message.contains("limit", ignoreCase = true) ->
                    "La API Key llegó a su límite de uso o cuota. Prueba otra clave o espera el reinicio del límite."
                message.isNotBlank() -> message.take(260)
                else -> "Error de Gemini. Revisa API Key e internet."
            }
        } catch (_: Exception) {
            "Error de Gemini. Revisa API Key e internet."
        }
    }

    private fun cleanQuery(raw: String): String {
        return raw.replace("\\s+".toRegex(), " ").trim()
    }

    private fun cleanAnswer(raw: String): String {
        val cleaned = raw
            .replace("**", "")
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (cleaned.length <= 720) return cleaned
        return cleaned.take(720).trim() + "..."
    }
}
