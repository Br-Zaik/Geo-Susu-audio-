# Geo Susu Google NET v103

## Acordado
- Un solo JSON.
- El JSON contiene temas, preguntas, variantes, aliases, keywords y contenido.
- Modo AUTO: primero JSON; si no encuentra, usa Google NET.
- NET ahora usa Google normal como primera fuente.
- NET extrae primeros textos/snippets/resultados y arma una respuesta para leer en audio.
- Si Google bloquea o no devuelve texto útil, usa respaldo con otras fuentes y Wikipedia.
- Google interno ya no responde con parciales.
- Cuadro de respuesta grande.
- Interfaz limpia.

## Modos
- JSON: solo tu base de GitHub.
- NET: Google NET con audio.
- AUTO: JSON primero, Google NET después.

## Importante
La respuesta de NET es extracción de texto de Google normal y fuentes web. No es Google AI ni API.
