package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    data class SearchResult(
        val title: String,
        val url: String,
        val snippet: String
    )

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val google = googleAnswer(query)
        if (google.isNotBlank()) return google

        val fallback = fallbackAnswer(query)
        if (fallback.isNotBlank()) return fallback

        val wiki = fetchWikipediaFallback(query)
        if (wiki.isNotBlank()) return wiki

        return "No encontré respuesta clara en Google NET. Agrega ese tema al JSON."
    }

    private fun googleAnswer(query: String): String {
        val html = fetchGoogleHtml(query)
        if (html.isBlank()) return ""

        val textBlocks = extractGoogleTextBlocks(html)
        val answer = buildAnswerFromBlocks(query, textBlocks)
        if (answer.isNotBlank()) return answer

        val resultUrls = extractGoogleResultUrls(html)
        val pageBlocks = mutableListOf<String>()
        for (url in resultUrls.take(3)) {
            val page = fetchReadableText(url)
            if (page.isNotBlank()) pageBlocks.add(page)
        }

        return buildAnswerFromBlocks(query, pageBlocks)
    }

    private fun fallbackAnswer(query: String): String {
        val results = searchDuckDuckGoLite(query)
        val blocks = mutableListOf<String>()

        for (result in results.take(4)) {
            if (result.snippet.isNotBlank()) blocks.add(result.snippet)
            val page = fetchReadableText(result.url)
            if (page.isNotBlank()) blocks.add(page)
        }

        return buildAnswerFromBlocks(query, blocks)
    }

    private fun fetchGoogleHtml(query: String): String {
        return try {
            val finalQuery = when (context?.let { AppSettings(it).getNetFocus() }) {
                AppSettings.NetFocus.MINING -> "$query minería geología topografía"
                else -> query
            }

            val url = "https://www.google.com/search?hl=es-PE&gl=PE&num=8&q=" +
                URLEncoder.encode(finalQuery, "UTF-8")

            get(
                urlText = url,
                userAgent = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
            )
        } catch (_: Exception) {
            ""
        }
    }

    private fun extractGoogleTextBlocks(html: String): List<String> {
        val cleaned = html
            .replace("(?is)<script.*?</script>".toRegex(), " ")
            .replace("(?is)<style.*?</style>".toRegex(), " ")
            .replace("(?is)<svg.*?</svg>".toRegex(), " ")

        val blocks = mutableListOf<String>()

        val snippetPatterns = listOf(
            Regex("(?is)<div[^>]+class=\"[^\"]*VwiC3b[^\"]*\"[^>]*>(.*?)</div>"),
            Regex("(?is)<span[^>]+class=\"[^\"]*hgKElc[^\"]*\"[^>]*>(.*?)</span>"),
            Regex("(?is)<div[^>]+class=\"[^\"]*BNeawe[^\"]*\"[^>]*>(.*?)</div>"),
            Regex("(?is)<div[^>]+data-sncf=\"[^\"]*\"[^>]*>(.*?)</div>")
        )

        for (pattern in snippetPatterns) {
            pattern.findAll(cleaned).forEach { match ->
                val text = cleanHtml(match.groupValues[1])
                if (isUsefulBlock(text)) blocks.add(text)
            }
        }

        if (blocks.isEmpty()) {
            val plain = cleanHtml(cleaned)
            plain.split(". ", "\n")
                .map { it.trim() }
                .filter { isUsefulBlock(it) }
                .take(10)
                .forEach { blocks.add(it) }
        }

        return blocks.distinct().take(12)
    }

    private fun extractGoogleResultUrls(html: String): List<String> {
        val urls = mutableListOf<String>()

        Regex("href=\"/url\\?q=([^\"&]+)").findAll(html).forEach { match ->
            val decoded = runCatching {
                URLDecoder.decode(match.groupValues[1], "UTF-8")
            }.getOrDefault("")

            if (decoded.startsWith("http") && !isBadUrl(decoded)) {
                urls.add(decoded)
            }
        }

        return urls.distinct().take(6)
    }

    private fun searchDuckDuckGoLite(query: String): List<SearchResult> {
        return try {
            val finalQuery = when (context?.let { AppSettings(it).getNetFocus() }) {
                AppSettings.NetFocus.MINING -> "$query minería geología topografía"
                else -> query
            }

            val url = "https://lite.duckduckgo.com/lite/?q=" + URLEncoder.encode(finalQuery, "UTF-8")
            val html = get(url)
            val results = mutableListOf<SearchResult>()

            val regex = Regex(
                "<a[^>]+href=\"([^\"]+)\"[^>]*>(.*?)</a>\\s*</td>\\s*</tr>\\s*<tr>\\s*<td[^>]*>(.*?)</td>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )

            regex.findAll(html).forEach { m ->
                val urlOut = decodeDuckUrl(unescape(m.groupValues[1]))
                val title = cleanHtml(m.groupValues[2])
                val snippet = cleanHtml(m.groupValues[3])

                if (urlOut.startsWith("http") && title.isNotBlank() && !isBadUrl(urlOut)) {
                    results.add(SearchResult(title, urlOut, snippet))
                }
            }

            results.distinctBy { it.url }.take(8)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun fetchReadableText(url: String): String {
        return try {
            val html = get(url)
            val body = html
                .replace("(?is)<script.*?</script>".toRegex(), " ")
                .replace("(?is)<style.*?</style>".toRegex(), " ")
                .replace("(?is)<nav.*?</nav>".toRegex(), " ")
                .replace("(?is)<footer.*?</footer>".toRegex(), " ")

            val paragraphs = Regex("(?is)<p[^>]*>(.*?)</p>")
                .findAll(body)
                .map { cleanHtml(it.groupValues[1]) }
                .filter { isUsefulBlock(it) }
                .take(8)
                .joinToString(". ")

            if (paragraphs.isNotBlank()) paragraphs else cleanHtml(body).take(1600)
        } catch (_: Exception) {
            ""
        }
    }

    private fun buildAnswerFromBlocks(query: String, blocks: List<String>): String {
        val words = subjectWords(query)
        if (blocks.isEmpty()) return ""

        val scored = blocks
            .map { block ->
                val normalized = ResponseRepository.normalize(block)
                var score = 0
                for (w in words) {
                    if (normalized.contains(w)) score += 3
                }

                if (looksLikeDefinition(normalized)) score += 4
                if (block.length in 55..520) score += 2
                if (isBadAnswer(block)) score -= 10

                score to block.trim()
            }
            .filter { it.first > 0 && it.second.isNotBlank() }
            .sortedByDescending { it.first }

        val best = scored.map { it.second }.distinct().take(3)
        if (best.isEmpty()) return ""

        val answer = best.joinToString(". ")
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (answer.length < 35) return ""
        val limited = answer.take(560).trim()

        return if (answer.length > 560) "$limited..." else limited
    }

    private fun looksLikeDefinition(text: String): Boolean {
        val markers = listOf(
            " es ", " son ", "se define", "se denomina", "se conoce",
            "consiste", "significa", "sirve", "utiliza", "proceso",
            "actividad", "mineral", "roca", "riesgo", "peligro"
        )
        return markers.any { text.contains(it) }
    }

    private fun fetchWikipediaFallback(query: String): String {
        return try {
            val searchUrl = "https://es.wikipedia.org/w/api.php?action=query&format=json&list=search&srlimit=1&srsearch=" +
                URLEncoder.encode(query, "UTF-8")
            val searchRaw = get(searchUrl)
            val title = JSONObject(searchRaw)
                .optJSONObject("query")
                ?.optJSONArray("search")
                ?.optJSONObject(0)
                ?.optString("title")
                .orEmpty()

            if (title.isBlank()) return ""

            val extractUrl = "https://es.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=" +
                URLEncoder.encode(title, "UTF-8")
            val raw = get(extractUrl)
            val pages = JSONObject(raw).optJSONObject("query")?.optJSONObject("pages") ?: return ""
            val keys = pages.keys()

            while (keys.hasNext()) {
                val extract = pages.optJSONObject(keys.next())?.optString("extract").orEmpty()
                if (extract.isNotBlank() && !isBadAnswer(extract)) {
                    return extract.replace("\\s+".toRegex(), " ").take(430).trim()
                }
            }

            ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
        val prefixes = listOf(
            "busca ", "buscar ", "internet ", "net ", "google ",
            "que es ", "q es ", "qué es ", "define ", "dime que es ",
            "concepto de ", "definicion de ", "definición de "
        )

        for (prefix in prefixes) {
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }

        return q.ifBlank { text.trim() }
    }

    private fun subjectWords(text: String): List<String> {
        val stop = setOf(
            "que", "qué", "para", "por", "con", "los", "las", "una", "uno",
            "del", "como", "cual", "cuales", "dime", "define", "busca",
            "buscar", "internet", "google", "net", "concepto", "definicion",
            "definición", "significa", "significado"
        )

        return ResponseRepository.normalize(text)
            .split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
            .take(10)
    }

    private fun decodeDuckUrl(raw: String): String {
        var url = raw
        if (url.startsWith("//")) url = "https:$url"
        if (url.startsWith("/l/?")) {
            val uddg = url.substringAfter("uddg=", "").substringBefore("&")
            if (uddg.isNotBlank()) return URLDecoder.decode(uddg, "UTF-8")
        }
        if (url.startsWith("/")) return "https://lite.duckduckgo.com$url"
        return url
    }

    private fun cleanHtml(raw: String): String {
        return unescape(raw)
            .replace("(?is)<br\\s*/?>".toRegex(), ". ")
            .replace("(?is)<li[^>]*>".toRegex(), ". ")
            .replace("(?is)<[^>]+>".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    private fun unescape(raw: String): String {
        return raw
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            .replace("&#160;", " ")
    }

    private fun isUsefulBlock(text: String): Boolean {
        val clean = text.trim()
        if (clean.length !in 35..700) return false
        if (isBadAnswer(clean)) return false

        val normalized = ResponseRepository.normalize(clean)
        val bad = listOf(
            "todo imagenes videos noticias maps shopping",
            "iniciar sesion", "configuracion", "herramientas",
            "mas resultados", "se requiere javascript", "aceptar todo"
        )
        return bad.none { normalized.contains(it) }
    }

    private fun isBadUrl(url: String): Boolean {
        val u = url.lowercase()
        return u.endsWith(".pdf") ||
            u.contains("youtube.com") ||
            u.contains("youtu.be") ||
            u.contains("facebook.com") ||
            u.contains("tiktok.com") ||
            u.contains("instagram.com") ||
            u.contains("twitter.com") ||
            u.contains("x.com/") ||
            u.contains("accounts.google") ||
            u.contains("support.google")
    }

    private fun isBadAnswer(text: String): Boolean {
        val t = ResponseRepository.normalize(text)
        val bad = listOf(
            "cookie", "javascript", "inicio de sesion", "iniciar sesion",
            "privacy policy", "politica de privacidad",
            "todos los derechos reservados", "puede referirse a",
            "pagina de desambiguacion", "suscribete", "captcha",
            "detected unusual traffic", "trafico inusual"
        )
        return bad.any { t.contains(it) }
    }

    private fun get(urlText: String, userAgent: String = "Mozilla/5.0 GeoSusuAudio Android"): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 15000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", userAgent)
        connection.setRequestProperty("Accept-Language", "es-PE,es;q=0.9,en;q=0.5")
        connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
    }
}
