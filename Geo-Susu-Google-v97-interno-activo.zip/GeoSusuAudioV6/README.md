# Geo Susu Google v97 - Google interno activo

## Qué es
Versión con Google interno activo por defecto.

## Cambios
- El botón ESCUCHAR inicia Google interno.
- No abre ventana grande.
- El estado muestra "Google interno activo".
- El botón secundario ahora dice GOOGLE INTERNO.
- Mantiene TXT.
- Mantiene VARIANTES.
- Mantiene TXT / NET.
- Paquete nuevo: com.bph.geosusugoogle.v97.
- Nombre visible: Geo Susu Google v97.

## Uso
1. Instala la app.
2. Da permiso de micrófono.
3. Toca ESCUCHAR.
4. Debe aparecer "Google interno activo".
