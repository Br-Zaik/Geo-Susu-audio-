package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.min

class JsonKnowledgeRepository(private val context: Context) {

    data class KnowledgeItem(
        val id: String,
        val tema: String,
        val titulo: String,
        val contenido: String,
        val keywords: List<String>
    )

    private val items: List<KnowledgeItem> by lazy { loadItems() }

    val totalItems: Int get() = items.size

    fun findBest(rawQuestion: String): ResponseRepository.MatchResult {
        val question = ResponseRepository.normalize(rawQuestion)
        if (question.length < 2 || items.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_EMPTY, "none", 0)
        }

        val qWords = keyWords(question)
        if (qWords.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        var best: KnowledgeItem? = null
        var bestScore = 0

        for (item in items) {
            val title = ResponseRepository.normalize("${item.tema} ${item.titulo} ${item.keywords.joinToString(" ")}")
            val body = ResponseRepository.normalize(item.contenido.take(4500))

            var score = 0
            for (w in qWords) {
                if (title.contains(w)) score += 32
                if (body.contains(w)) score += 12
            }

            val phrase = qWords.joinToString(" ")
            if (phrase.length >= 5) {
                if (title.contains(phrase)) score += 35
                if (body.contains(phrase)) score += 18
            }

            if (score > bestScore) {
                bestScore = score
                best = item
            }
        }

        val item = best ?: return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore)
        if (bestScore < 28) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore)
        }

        return ResponseRepository.MatchResult(
            buildAnswer(item, qWords),
            "json_${item.id}",
            bestScore.coerceAtMost(100)
        )
    }

    private fun buildAnswer(item: KnowledgeItem, qWords: List<String>): String {
        val chunks = item.contenido
            .replace("\r", "\n")
            .split("\n\n", "\n", ". ")
            .map { it.trim() }
            .filter { it.length >= 35 }
            .map { chunk ->
                val normalized = ResponseRepository.normalize(chunk)
                var score = 0
                for (w in qWords) {
                    if (normalized.contains(w)) score += 1
                }
                score to chunk
            }
            .filter { it.first > 0 }
            .sortedByDescending { it.first }
            .map { it.second }

        val picked = if (chunks.isNotEmpty()) {
            chunks.take(2).joinToString(". ")
        } else {
            item.contenido.trim()
        }

        val clean = picked.replace("\\s+".toRegex(), " ").trim()
        val limited = clean.take(520).trim()
        return if (clean.length > 520) "$limited..." else limited
    }

    private fun loadItems(): List<KnowledgeItem> {
        val raw = JsonKnowledgeStore(context).readJson()
        if (raw.isBlank()) return emptyList()

        return try {
            val trimmed = raw.trim()
            val array = when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> {
                    val obj = JSONObject(trimmed)
                    obj.optJSONArray("temas")
                        ?: obj.optJSONArray("items")
                        ?: obj.optJSONArray("data")
                        ?: JSONArray()
                }
            }

            val result = mutableListOf<KnowledgeItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val tema = obj.optString("tema", obj.optString("categoria", "General")).trim()
                val titulo = obj.optString(
                    "titulo",
                    obj.optString("pregunta", obj.optString("nombre", tema))
                ).trim()
                val contenido = obj.optString(
                    "contenido",
                    obj.optString("respuesta", obj.optString("texto", obj.optString("descripcion", "")))
                ).trim()

                if (contenido.isBlank()) continue

                val keywords = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "palabrasClave")

                result.add(
                    KnowledgeItem(
                        id = obj.optString("id", "item_$i").ifBlank { "item_$i" },
                        tema = tema.ifBlank { "General" },
                        titulo = titulo.ifBlank { tema.ifBlank { "Tema $i" } },
                        contenido = contenido,
                        keywords = keywords.distinct()
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun readStringArray(obj: JSONObject, key: String): List<String> {
        val arr = obj.optJSONArray(key) ?: return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val value = arr.optString(i).trim()
            if (value.isNotBlank()) list.add(value)
        }
        return list
    }

    private fun keyWords(text: String): List<String> {
        val stop = setOf(
            "que", "qué", "q", "es", "son", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuales",
            "dime", "di", "define", "definicion", "concepto", "significa",
            "internet", "net", "json", "tema", "sobre", "explica", "breve"
        )
        return text.split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
            .take(12)
    }

    companion object {
        const val JSON_EMPTY = "No hay JSON cargado. Pega el link Raw de GitHub y toca ACTUALIZAR JSON."
        const val JSON_NOT_FOUND = "No encontré esa respuesta en el JSON."
    }
}

class JsonKnowledgeStore(private val context: Context) {

    fun getUrl(): String {
        return prefs().getString(KEY_URL, "").orEmpty().trim()
    }

    fun saveUrl(url: String) {
        prefs().edit().putString(KEY_URL, url.trim()).apply()
    }

    fun readJson(): String {
        val file = File(context.filesDir, JSON_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun hasJson(): Boolean {
        return readJson().isNotBlank()
    }

    fun downloadJson(): Pair<Boolean, String> {
        val url = getUrl()
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }

        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.setRequestProperty("User-Agent", "GeoSusuAudio Android")
            connection.setRequestProperty("Accept", "application/json,text/plain,*/*")

            val raw = try {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally {
                connection.disconnect()
            }

            if (raw.isBlank()) return false to "El JSON descargado está vacío."

            val count = countItems(raw)
            if (count <= 0) return false to "El archivo no parece JSON válido de temas."

            File(context.filesDir, JSON_FILE).writeText(raw)
            true to "JSON actualizado. Temas: $count"
        } catch (_: Exception) {
            false to "No se pudo descargar JSON. Revisa link o internet."
        }
    }

    private fun countItems(raw: String): Int {
        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("temas")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }
            array.length()
        } catch (_: Exception) {
            0
        }
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS = "geo_susu_json"
        private const val KEY_URL = "json_url"
        private const val JSON_FILE = "temas_github.json"
    }
}
