# Geo Susu JSON v104

## Cambios
- Se restauró el cuadro de pregunta.
- Ahora muestra: Pregunta: ...
- El cuadro de respuesta sigue grande.
- Si eliges JSON, solo busca en JSON.
- Si eliges AUTO, busca primero en JSON y solo si no encuentra usa NET.
- NET sigue usando Google NET como respaldo con audio.
- Un solo JSON para temas, preguntas, variantes, aliases, keywords y contenido.

## Regla de modos
JSON = nunca usa NET.
AUTO = JSON primero; NET solo si JSON no encuentra.
NET = busca directo en Google NET.

## Google interno
Sigue esperando más antes de responder para evitar cortar preguntas.
