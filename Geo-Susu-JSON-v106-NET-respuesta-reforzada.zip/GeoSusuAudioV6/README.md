# Geo Susu JSON v106

## Corrección NET
NET ahora tiene respuesta reforzada:

1. Intenta Google normal.
2. Ignora redirecciones y textos basura de Google.
3. Si Google no sirve, usa respaldo con buscador ligero.
4. Lee snippets/títulos útiles si no puede abrir páginas.
5. Usa Wikipedia como último respaldo.
6. Si aun así no hay información confiable, responde claro que no pudo obtener una respuesta confiable.

## Regla
- JSON: solo JSON, nunca NET.
- AUTO: JSON primero, NET solo si JSON no encuentra.
- NET: siempre intenta devolver una respuesta útil en audio, sin leer redirecciones.
