# Geo Susu JSON v107

## Corrección de NET
NET ahora filtra por la palabra principal de la pregunta.

Ejemplo:
Pregunta: "qué es cateo en minería"
La respuesta debe contener cateo. Ya no debe responder sobre otro proyecto minero como Agua Rica.

## Orden de NET
1. Busca en Google normal.
2. Solo acepta bloques relacionados con la palabra principal.
3. Si Google no sirve, usa respaldo con buscador ligero.
4. Si sigue sin encontrar, usa Wikipedia.
5. Para términos mineros comunes, usa una definición segura interna como último respaldo.

## Modos
JSON = solo JSON.
AUTO = JSON primero; si no encuentra, NET.
NET = búsqueda web con audio y filtro de relevancia.
