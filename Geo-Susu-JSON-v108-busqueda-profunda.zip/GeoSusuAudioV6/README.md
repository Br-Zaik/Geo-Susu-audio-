# Geo Susu JSON v108

## Ajustes
- Búsqueda JSON más profunda y precisa.
- Prioriza frase exacta y variantes antes de palabras sueltas.
- Corrige confusiones como:
  - no metálicos vs metálicos
  - semimetálicos vs metálicos
  - sulfuros vs sulfatos vs sulfosales
  - pirita vs calcopirita
- Si no encuentra respuesta, dice solo: No encontrado.
- NET también devuelve "No encontrado" si no obtiene respuesta confiable.
- NET mantiene respaldo interno para temas mineros comunes: cateo, ley, mena, minerales metálicos, no metálicos, semimetálicos, sulfuros, sulfatos, sulfosales, Antapaccay, pórfido, skarn, logueo geológico y recursos geológicos.

## Reglas
JSON = solo JSON.
AUTO = JSON primero; si no encuentra, NET.
NET = búsqueda web con audio y filtros de relevancia.
