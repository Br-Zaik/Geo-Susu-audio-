# Geo Susu JSON v98

## Objetivo
Versión con Google interno activo y 3 modos claros:

- JSON: responde solo desde tu archivo JSON descargado de GitHub.
- NET: busca en internet.
- AUTO: primero busca en JSON; si no encuentra, recién usa NET.

## Qué mejora
- Ya no necesitas pegar texto largo en la app.
- El JSON se descarga desde GitHub Raw.
- La app lo guarda como archivo interno.
- No muestra todo el texto en pantalla, por eso no debe trabarse como el editor.
- Botón ACTUALIZAR JSON descarga la información nueva.
- NET queda como respaldo, no como fuente principal.

## Formato recomendado del JSON
[
  {
    "id": "iperc",
    "tema": "Seguridad minera",
    "titulo": "IPERC",
    "keywords": ["iperc", "peligros", "riesgos", "controles"],
    "contenido": "El IPERC es la identificación de peligros, evaluación de riesgos y controles..."
  }
]

También acepta:
- items
- temas
- data

Campos compatibles:
- tema
- titulo / pregunta / nombre
- contenido / respuesta / texto / descripcion
- keywords / aliases / preguntas / palabrasClave

## Uso
1. Sube temas.json a GitHub.
2. Copia el link Raw.
3. En la app entra a AJUSTES > Link JSON GitHub.
4. Pega el link.
5. Toca ACTUALIZAR JSON.
6. Usa modo AUTO.
