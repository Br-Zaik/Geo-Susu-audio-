package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    data class SearchResult(
        val title: String,
        val url: String,
        val snippet: String
    )

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val results = searchDuckDuckGoLite(query)
        val answer = results
            .take(5)
            .asSequence()
            .mapNotNull { result ->
                val text = fetchReadableText(result.url)
                buildAnswer(query, result.snippet, text).ifBlank { null }
            }
            .firstOrNull()

        if (!answer.isNullOrBlank()) return answer

        val wiki = fetchWikipediaFallback(query)
        if (wiki.isNotBlank()) return wiki

        return "NET no encontró respuesta clara. Agrega ese tema al JSON de GitHub."
    }

    private fun searchDuckDuckGoLite(query: String): List<SearchResult> {
        return try {
            val miningQuery = when (context?.let { AppSettings(it).getNetFocus() }) {
                AppSettings.NetFocus.MINING -> "$query minería geología topografía"
                else -> query
            }
            val url = "https://lite.duckduckgo.com/lite/?q=" + URLEncoder.encode(miningQuery, "UTF-8")
            val html = get(url)
            val results = mutableListOf<SearchResult>()

            val regex = Regex(
                "<a[^>]+href=\"([^\"]+)\"[^>]*>(.*?)</a>\\s*</td>\\s*</tr>\\s*<tr>\\s*<td[^>]*>(.*?)</td>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )

            regex.findAll(html).forEach { m ->
                val urlOut = decodeDuckUrl(unescape(m.groupValues[1]))
                val title = cleanHtml(m.groupValues[2])
                val snippet = cleanHtml(m.groupValues[3])
                if (urlOut.startsWith("http") && title.isNotBlank() && !isBadUrl(urlOut)) {
                    results.add(SearchResult(title, urlOut, snippet))
                }
            }

            results.distinctBy { it.url }.take(8)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun fetchReadableText(url: String): String {
        return try {
            val html = get(url)
            val body = html
                .replace("(?is)<script.*?</script>".toRegex(), " ")
                .replace("(?is)<style.*?</style>".toRegex(), " ")
                .replace("(?is)<nav.*?</nav>".toRegex(), " ")
                .replace("(?is)<footer.*?</footer>".toRegex(), " ")

            val paragraphs = Regex("(?is)<p[^>]*>(.*?)</p>")
                .findAll(body)
                .map { cleanHtml(it.groupValues[1]) }
                .filter { it.length >= 45 }
                .take(10)
                .joinToString(". ")

            if (paragraphs.isNotBlank()) paragraphs else cleanHtml(body).take(1800)
        } catch (_: Exception) {
            ""
        }
    }

    private fun buildAnswer(query: String, snippet: String, pageText: String): String {
        val combined = listOf(snippet, pageText)
            .joinToString(". ")
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (combined.length < 50 || isBadAnswer(combined)) return ""

        val words = subjectWords(query)
        val sentences = combined
            .split(". ", ".\n", "? ", "! ")
            .map { it.trim() }
            .filter { sentence ->
                sentence.length in 35..380 &&
                    !isBadAnswer(sentence) &&
                    (words.isEmpty() || words.any { w -> ResponseRepository.normalize(sentence).contains(w) })
            }

        val picked = if (sentences.isNotEmpty()) {
            sentences.take(2).joinToString(". ")
        } else {
            combined.take(360)
        }.trim()

        if (picked.length < 35) return ""

        val short = picked.take(430).trim()
        return if (picked.length > 430) "$short..." else short
    }

    private fun fetchWikipediaFallback(query: String): String {
        return try {
            val searchUrl = "https://es.wikipedia.org/w/api.php?action=query&format=json&list=search&srlimit=1&srsearch=" +
                URLEncoder.encode(query, "UTF-8")
            val searchRaw = get(searchUrl)
            val title = JSONObject(searchRaw)
                .optJSONObject("query")
                ?.optJSONArray("search")
                ?.optJSONObject(0)
                ?.optString("title")
                .orEmpty()

            if (title.isBlank()) return ""

            val extractUrl = "https://es.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=" +
                URLEncoder.encode(title, "UTF-8")
            val raw = get(extractUrl)
            val pages = JSONObject(raw).optJSONObject("query")?.optJSONObject("pages") ?: return ""
            val keys = pages.keys()
            while (keys.hasNext()) {
                val extract = pages.optJSONObject(keys.next())?.optString("extract").orEmpty()
                if (extract.isNotBlank() && !isBadAnswer(extract)) {
                    return extract.replace("\\s+".toRegex(), " ").take(430).trim()
                }
            }
            ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun cleanQuery(text: String): String {
        var q = ResponseRepository.normalize(text)
        val prefixes = listOf(
            "busca ", "buscar ", "internet ", "net ", "navega ", "navegar ",
            "que es ", "q es ", "define ", "dime que es ",
            "concepto de ", "definicion de "
        )
        prefixes.forEach { prefix ->
            if (q.startsWith(prefix)) q = q.removePrefix(prefix).trim()
        }
        return q.ifBlank { text.trim() }
    }

    private fun subjectWords(text: String): List<String> {
        val stop = setOf(
            "que", "para", "por", "con", "los", "las", "una", "uno", "del",
            "como", "cual", "dime", "define", "busca", "buscar", "internet",
            "net", "concepto", "definicion", "significa"
        )
        return ResponseRepository.normalize(text)
            .split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stop }
            .distinct()
    }

    private fun decodeDuckUrl(raw: String): String {
        var url = raw
        if (url.startsWith("//")) url = "https:$url"
        if (url.startsWith("/l/?")) {
            val uddg = url.substringAfter("uddg=", "").substringBefore("&")
            if (uddg.isNotBlank()) return URLDecoder.decode(uddg, "UTF-8")
        }
        if (url.startsWith("/")) return "https://lite.duckduckgo.com$url"
        return url
    }

    private fun cleanHtml(raw: String): String {
        return unescape(raw)
            .replace("(?is)<br\\s*/?>".toRegex(), ". ")
            .replace("(?is)<[^>]+>".toRegex(), " ")
            .replace("&nbsp;", " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    private fun unescape(raw: String): String {
        return raw
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
    }

    private fun isBadUrl(url: String): Boolean {
        val u = url.lowercase()
        return u.endsWith(".pdf") ||
            u.contains("youtube.com") ||
            u.contains("youtu.be") ||
            u.contains("facebook.com") ||
            u.contains("tiktok.com") ||
            u.contains("instagram.com") ||
            u.contains("twitter.com") ||
            u.contains("x.com/")
    }

    private fun isBadAnswer(text: String): Boolean {
        val t = ResponseRepository.normalize(text)
        val bad = listOf(
            "cookie", "javascript", "inicio de sesion", "privacy policy",
            "todos los derechos reservados", "puede referirse a",
            "pagina de desambiguacion", "suscribete"
        )
        return bad.any { t.contains(it) }
    }

    private fun get(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 14000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 GeoSusuAudio Android")
        connection.setRequestProperty("Accept-Language", "es-PE,es;q=0.9,en;q=0.5")

        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
    }
}
