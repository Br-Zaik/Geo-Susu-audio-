# Geo Susu Lector v81

Nueva APK diferente, basada en la app anterior pero cambiada a lector por partes.

Qué hace:
- Abre PDF o TXT.
- Extrae texto del PDF si el PDF tiene texto real.
- Divide el contenido en partes pequeñas.
- Lee por audio con TTS.
- Permite pausar, siguiente, anterior e inicio.
- Permite preguntar por voz y busca dentro del documento.
- Trae BASE 500 de Recursos Geológicos integrada como documento interno.
- No carga variantes gigantes ni JSON pesado.
- No depende de pegar TXT manualmente.

Uso:
1. Instala como app nueva: Geo Susu Lector v81.
2. Espera que cargue BASE 500.
3. Toca LEER para escuchar.
4. Toca PREGUNTAR VOZ para buscar una respuesta por voz.
5. También puedes abrir un PDF/TXT propio con ABRIR PDF/TXT.

Importante:
- PDF escaneado como imagen no tendrá texto legible.
- Para PDF escaneado se necesitaría OCR, eso no está incluido.
- La lectura de PDF/TXT funciona offline; la pregunta por voz usa Google si está disponible.
