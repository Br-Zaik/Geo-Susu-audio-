package com.bph.geosusuaudio

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bph.geosusuaudio.databinding.ActivityMainBinding
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.text.Normalizer
import java.util.Locale
import kotlin.math.max

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private var tts: TextToSpeech? = null
    private var chunks: List<String> = emptyList()
    private var currentIndex = 0
    private var isReading = false
    private var ttsReady = false
    private var documentName = "Base 500"

    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) loadDocumentFromUri(uri)
    }

    private val voiceQuestionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val heard = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                .orEmpty()
                .trim()

            if (heard.isNotBlank()) {
                searchAndSpeak(heard)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUi()
        tts = TextToSpeech(this, this)

        binding.tvStatus.text = "Lector listo. Cargando base 500..."
        binding.tvAnswer.text = "Contenido: espera unos segundos."
        loadInternalBaseInBackground()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("es", "PE")
            tts?.setSpeechRate(1.02f)
            tts?.setPitch(1.0f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (isReading) {
                        runOnUiThread {
                            if (currentIndex < chunks.lastIndex) {
                                currentIndex++
                                speakCurrent()
                            } else {
                                isReading = false
                                binding.tvStatus.text = "Lectura terminada."
                            }
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    runOnUiThread {
                        isReading = false
                        binding.tvStatus.text = "Error de voz TTS."
                    }
                }
            })
        }
    }

    private fun setupUi() {
        binding.tvModeMini.text = "LECTOR"
        binding.rbLocal.text = "LECTOR"
        binding.rbInternet.text = "BUSCAR"
        binding.rbLocal.isChecked = true
        binding.etCommandWord.hint = "Escribe qué buscar"
        binding.etCommandWord.inputType = InputType.TYPE_CLASS_TEXT

        binding.btnStart.text = "LEER"
        binding.btnStop.text = "PAUSA"
        binding.btnDownloadModel.text = "SIGUIENTE"
        binding.btnOpenTxt.text = "ABRIR PDF/TXT"
        binding.btnImportText.text = "ANTERIOR"
        binding.btnSettings.text = "BASE 500"
        binding.btnOpenQaFile.text = "PREGUNTAR VOZ"
        binding.btnOpenVarFile.text = "INICIO"
        binding.btnSaveCommand.text = "BUSCAR"

        binding.btnOpenTxt.setOnClickListener {
            openDocumentLauncher.launch("*/*")
        }

        binding.btnSettings.setOnClickListener {
            loadInternalBaseInBackground()
        }

        binding.btnStart.setOnClickListener {
            if (chunks.isEmpty()) {
                binding.tvStatus.text = "No hay documento cargado."
                return@setOnClickListener
            }
            isReading = true
            speakCurrent()
        }

        binding.btnStop.setOnClickListener {
            isReading = false
            tts?.stop()
            binding.tvStatus.text = "Lectura pausada."
        }

        binding.btnDownloadModel.setOnClickListener {
            nextChunk()
        }

        binding.btnImportText.setOnClickListener {
            previousChunk()
        }

        binding.btnOpenVarFile.setOnClickListener {
            currentIndex = 0
            showCurrentChunk()
            binding.tvStatus.text = "Inicio del documento."
        }

        binding.btnOpenQaFile.setOnClickListener {
            askByVoice()
        }

        binding.btnSaveCommand.setOnClickListener {
            val query = binding.etCommandWord.text.toString().trim()
            if (query.isBlank()) {
                Toast.makeText(this, "Escribe qué buscar.", Toast.LENGTH_SHORT).show()
            } else {
                searchAndSpeak(query)
            }
        }

        binding.btnImportText.setOnLongClickListener {
            showHelp()
            true
        }
    }

    private fun loadInternalBaseInBackground() {
        binding.tvStatus.text = "Cargando BASE 500..."
        binding.tvAnswer.text = "Contenido: preparando por partes."
        Thread {
            try {
                val raw = assets.open("base_500_recursos_geologicos.txt")
                    .bufferedReader()
                    .use { it.readText() }

                val text = raw.lines()
                    .map { it.trim() }
                    .filter { it.isNotBlank() && !it.startsWith("#") && it.contains("|") }
                    .joinToString("\n") { line ->
                        val parts = line.split("|", limit = 2)
                        val q = parts.getOrNull(0)?.trim().orEmpty()
                        val a = parts.getOrNull(1)?.trim().orEmpty()
                        "${cleanQuestionForDisplay(q)}. $a"
                    }

                val parts = splitIntoChunks(text)
                runOnUiThread {
                    documentName = "Base 500 Recursos Geológicos"
                    chunks = parts
                    currentIndex = 0
                    isReading = false
                    binding.pbVoiceLevel.progress = 0
                    binding.tvVoiceLevel.text = "Base cargada: ${chunks.size} partes."
                    binding.tvStatus.text = "BASE 500 lista. Puedes leer o preguntar."
                    showCurrentChunk()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.tvStatus.text = "No se pudo cargar BASE 500."
                    binding.tvAnswer.text = "Contenido: abre un PDF o TXT."
                    Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadDocumentFromUri(uri: Uri) {
        val name = getDisplayName(uri)
        binding.tvStatus.text = "Abriendo $name..."
        binding.tvAnswer.text = "Contenido: extrayendo texto por partes."
        Thread {
            try {
                val mime = contentResolver.getType(uri).orEmpty().lowercase()
                val lowerName = name.lowercase()
                val text = if (mime.contains("pdf") || lowerName.endsWith(".pdf")) {
                    extractPdfText(uri)
                } else {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                }

                val cleaned = cleanText(text)
                if (cleaned.isBlank()) error("No se encontró texto legible.")

                val parts = splitIntoChunks(cleaned)
                runOnUiThread {
                    documentName = name
                    chunks = parts
                    currentIndex = 0
                    isReading = false
                    binding.pbVoiceLevel.progress = 0
                    binding.tvVoiceLevel.text = "Documento: ${chunks.size} partes."
                    binding.tvStatus.text = "Documento cargado: $name"
                    showCurrentChunk()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.tvStatus.text = "No se pudo abrir el documento."
                    binding.tvAnswer.text = "Contenido: prueba con PDF de texto o TXT."
                    Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun extractPdfText(uri: Uri): String {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
        if (bytes.isEmpty()) return ""
        PDDocument.load(bytes).use { document ->
            return PDFTextStripper().getText(document)
        }
    }

    private fun splitIntoChunks(text: String, maxLen: Int = 650): List<String> {
        val normalized = cleanText(text)
        if (normalized.isBlank()) return emptyList()

        val paragraphs = normalized
            .split("\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val result = mutableListOf<String>()
        val buffer = StringBuilder()

        fun flush() {
            val value = buffer.toString().trim()
            if (value.isNotBlank()) result.add(value)
            buffer.clear()
        }

        for (paragraph in paragraphs) {
            if (paragraph.length > maxLen) {
                flush()
                paragraph.split(Regex("(?<=[.!?])\\s+")).forEach { sentence ->
                    if (buffer.length + sentence.length + 1 > maxLen) flush()
                    if (sentence.isNotBlank()) {
                        if (buffer.isNotBlank()) buffer.append(" ")
                        buffer.append(sentence.trim())
                    }
                }
            } else {
                if (buffer.length + paragraph.length + 1 > maxLen) flush()
                if (buffer.isNotBlank()) buffer.append("\n")
                buffer.append(paragraph)
            }
        }
        flush()

        return result.ifEmpty { listOf(normalized.take(maxLen)) }
    }

    private fun speakCurrent() {
        if (!ttsReady) {
            binding.tvStatus.text = "Voz TTS no lista."
            return
        }
        if (chunks.isEmpty()) return

        showCurrentChunk()
        val text = chunks[currentIndex]
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "chunk_$currentIndex")
        binding.tvStatus.text = "Leyendo ${currentIndex + 1}/${chunks.size}: $documentName"
    }

    private fun showCurrentChunk() {
        if (chunks.isEmpty()) {
            binding.tvAnswer.text = "Contenido: abre PDF/TXT o usa BASE 500."
            binding.tvHeard.text = "Pregunta/búsqueda: ---"
            binding.pbVoiceLevel.progress = 0
            return
        }

        val progress = (((currentIndex + 1).toFloat() / chunks.size.toFloat()) * 100).toInt().coerceIn(0, 100)
        binding.pbVoiceLevel.progress = progress
        binding.tvVoiceLevel.text = "Parte ${currentIndex + 1}/${chunks.size}. Mantén presionado ANTERIOR para ayuda."
        binding.tvHeard.text = "Documento: $documentName"
        binding.tvAnswer.text = "Contenido: ${chunks[currentIndex]}"
    }

    private fun nextChunk() {
        if (chunks.isEmpty()) return
        isReading = false
        tts?.stop()
        if (currentIndex < chunks.lastIndex) currentIndex++
        showCurrentChunk()
        binding.tvStatus.text = "Siguiente parte."
    }

    private fun previousChunk() {
        if (chunks.isEmpty()) return
        isReading = false
        tts?.stop()
        if (currentIndex > 0) currentIndex--
        showCurrentChunk()
        binding.tvStatus.text = "Parte anterior."
    }

    private fun askByVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Pregunta sobre el documento")
        }

        try {
            voiceQuestionLauncher.launch(intent)
        } catch (e: Exception) {
            binding.tvStatus.text = "Google voz no disponible."
            binding.tvAnswer.text = "Contenido: escribe la búsqueda abajo y toca BUSCAR."
        }
    }

    private fun searchAndSpeak(rawQuery: String) {
        if (chunks.isEmpty()) {
            binding.tvStatus.text = "No hay documento cargado."
            binding.tvAnswer.text = "Contenido: abre PDF/TXT o toca BASE 500."
            return
        }

        val query = normalize(applyCommonCorrections(rawQuery))
        val queryTokens = coreWords(query)
        if (queryTokens.isEmpty()) {
            binding.tvStatus.text = "Búsqueda vacía."
            return
        }

        var bestIndex = -1
        var bestScore = 0

        chunks.forEachIndexed { index, chunk ->
            val chunkNorm = normalize(chunk)
            val chunkTokens = coreWords(chunkNorm).toSet()
            val exact = queryTokens.count { it in chunkTokens }
            var score = exact * 20

            if (chunkNorm.contains(query)) score += 80
            if (queryTokens.size >= 2 && exact >= 2) score += 40
            if (chunkNorm.startsWith(query)) score += 30

            if (score > bestScore) {
                bestScore = score
                bestIndex = index
            }
        }

        binding.tvHeard.text = "Pregunta/búsqueda: $rawQuery"

        if (bestIndex >= 0 && bestScore >= 35) {
            currentIndex = bestIndex
            isReading = false
            showCurrentChunk()
            binding.tvStatus.text = "Encontrado en parte ${currentIndex + 1}/${chunks.size}."
            speakCurrent()
        } else {
            binding.tvStatus.text = "No encontré respuesta clara."
            binding.tvAnswer.text = "Contenido: prueba con palabra clave, por ejemplo mineral, mena, Antapaccay."
            tts?.speak("No encontré respuesta clara.", TextToSpeech.QUEUE_FLUSH, null, "not_found")
        }
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("Uso rápido")
            .setMessage(
                "ABRIR PDF/TXT: carga un documento.\n" +
                    "BASE 500: carga recursos geológicos.\n" +
                    "LEER: lee desde la parte actual.\n" +
                    "PAUSA: detiene la lectura.\n" +
                    "SIGUIENTE/ANTERIOR: cambia de parte.\n" +
                    "PREGUNTAR VOZ: busca en el documento.\n" +
                    "BUSCAR: busca lo escrito abajo."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun getDisplayName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && it.moveToFirst()) {
                return it.getString(nameIndex) ?: "documento"
            }
        }
        return uri.lastPathSegment ?: "documento"
    }

    private fun cleanText(text: String): String {
        return text
            .replace("\r", "\n")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun cleanQuestionForDisplay(question: String): String {
        return question.replace("_", " ").trim()
    }

    private fun normalize(text: String): String {
        return Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("[^a-z0-9ñ ]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    private fun coreWords(text: String): List<String> {
        val stop = setOf(
            "q", "que", "es", "son", "el", "la", "los", "las", "un", "una",
            "de", "del", "en", "por", "para", "dime", "di", "define",
            "defineme", "explica", "explicame", "concepto", "significa",
            "cual", "cuales", "como", "se", "llama", "sobre"
        )
        return normalize(text).split(" ")
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stop }
            .distinct()
    }

    private fun applyCommonCorrections(text: String): String {
        var out = normalize(text)
        val corrections = mapOf(
            "santa pacay" to "antapaccay",
            "santa pacai" to "antapaccay",
            "anta pacay" to "antapaccay",
            "antapacay" to "antapaccay",
            "antapacai" to "antapaccay",
            "tipo de socas" to "tipos de rocas",
            "tipos de socas" to "tipos de rocas",
            "socas" to "rocas",
            "soca" to "roca",
            "canca" to "ganga",
            "canga" to "ganga",
            "gaga" to "ganga",
            "nena" to "mena",
            "mema" to "mena",
            "escala de mosh" to "escala de mohs",
            "escala de mos" to "escala de mohs",
            "logeo" to "logueo",
            "porfiro" to "porfido",
            "por fido" to "porfido",
            "escarn" to "skarn",
            "calco pirita" to "calcopirita",
            "bonita mineral" to "bornita"
        )
        for ((bad, good) in corrections) {
            out = out.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }
        return out
    }

    override fun onDestroy() {
        isReading = false
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
