# Geo Susu JSON v112

Cambios:
- El modo online vuelve a mostrarse como NET.
- El boton API ya no dice Gemini.
- El boton JSON abre configuracion: link Raw y actualizar desde un solo lugar.
- AUTO mantiene la logica correcta: JSON primero, NET solo si no encuentra.
- No se tocaron escucha, sensibilidad, reduccion de ruido, variantes JSON ni Bluetooth.
