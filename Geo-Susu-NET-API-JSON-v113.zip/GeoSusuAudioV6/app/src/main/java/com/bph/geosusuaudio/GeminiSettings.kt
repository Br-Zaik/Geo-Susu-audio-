package com.bph.geosusuaudio

import android.content.Context

class GeminiSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_gemini", Context.MODE_PRIVATE)

    fun getApiKey(): String {
        return prefs.getString(KEY_API_KEY, "").orEmpty().trim()
    }

    fun saveApiKey(value: String) {
        prefs.edit().putString(KEY_API_KEY, value.trim()).apply()
    }

    fun hasApiKey(): Boolean {
        return getApiKey().isNotBlank()
    }

    companion object {
        private const val KEY_API_KEY = "gemini_api_key"
    }
}
