package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    private data class GeminiCallResult(
        val ok: Boolean,
        val text: String,
        val error: String,
        val model: String
    )

    // Mismo modelo que usa la APK "Mi Asistente IA" que respondia completo.
    private val modelCandidates = listOf("gemini-2.5-flash")

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val apiKey = context?.let { GeminiSettings(it).getApiKey() }.orEmpty()
        if (apiKey.isBlank()) {
            return "Sin API configurada. Toca API, pega tu clave y prueba si funciona."
        }

        val result = askGemini(apiKey, query)
        if (result.ok && result.text.isNotBlank()) return result.text

        return result.error.ifBlank {
            "NET no devolvio respuesta. Revisa tu API Key, internet o limite de uso."
        }
    }

    fun testApiKey(apiKey: String): Pair<Boolean, String> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) return false to "Pega primero tu API Key."

        val result = askGemini(cleanKey, "Responde solo: API funcionando", testing = true)
        return if (result.ok && result.text.isNotBlank()) {
            true to "API funcionando correctamente."
        } else {
            false to result.error.ifBlank { "No se pudo probar la API. Revisa la clave o internet." }
        }
    }

    private fun askGemini(apiKey: String, question: String, testing: Boolean = false): GeminiCallResult {
        var lastError = ""

        for (model in modelCandidates) {
            val first = callGeminiModel(apiKey, model, question, testing)
            if (!first.ok) {
                lastError = first.error
                continue
            }

            if (testing || !looksIncomplete(first.text)) return first

            // Segundo intento solo si la primera respuesta vino claramente inconclusa.
            val retryQuestion = "$question\n\nResponde otra vez con la respuesta completa. No dejes frases inconclusas."
            val retry = callGeminiModel(apiKey, model, retryQuestion, false)
            if (retry.ok && retry.text.isNotBlank() && !looksIncomplete(retry.text)) return retry

            return first
        }

        return GeminiCallResult(false, "", lastError, "")
    }

    private fun callGeminiModel(
        apiKey: String,
        model: String,
        question: String,
        testing: Boolean
    ): GeminiCallResult {
        var connection: HttpURLConnection? = null

        return try {
            val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            )

            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
            }

            val body = buildRequestBody(question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                val msg = parseGeminiError(raw).ifBlank { "Error HTTP $code al llamar API." }
                return GeminiCallResult(false, "", msg, model)
            }

            val answer = parseGeminiText(raw)
            if (answer.isBlank()) {
                GeminiCallResult(false, "", "La API respondio vacio. Intenta otra pregunta.", model)
            } else {
                GeminiCallResult(true, answer, "", model)
            }
        } catch (e: Exception) {
            GeminiCallResult(false, "", "No se pudo conectar con la API: ${e.message ?: "error de conexion"}.", model)
        } finally {
            connection?.disconnect()
        }
    }

    private fun buildRequestBody(question: String, testing: Boolean): JSONObject {
        val prompt = if (testing) {
            question
        } else {
            "Eres un asistente inteligente. Responde siempre en español de forma clara, corta y practica. Maximo 3 oraciones.\n\nPregunta: $question"
        }

        return JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("maxOutputTokens", if (testing) 64 else 300)
                    put("temperature", if (testing) 0.0 else 0.7)
                }
            )
        }
    }

    private fun parseGeminiText(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""

        // Igual que la APK buena: tomar el primer candidato y el primer bloque de texto.
        val firstText = candidates.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
            ?.optJSONObject(0)
            ?.optString("text")
            .orEmpty()

        if (firstText.isNotBlank()) return cleanAnswer(firstText)

        // Respaldo por si Gemini devuelve varios parts.
        val partsText = StringBuilder()
        for (i in 0 until candidates.length()) {
            val content = candidates.optJSONObject(i)
                ?.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue

            for (j in 0 until parts.length()) {
                val text = parts.optJSONObject(j)?.optString("text").orEmpty()
                if (text.isNotBlank()) {
                    if (partsText.isNotBlank()) partsText.append("\n")
                    partsText.append(text.trim())
                }
            }
        }

        return cleanAnswer(partsText.toString())
    }

    private fun parseGeminiError(raw: String): String {
        return try {
            val error = JSONObject(raw).optJSONObject("error")
            val message = error?.optString("message").orEmpty()
            when {
                message.contains("API key", ignoreCase = true) ->
                    "API Key invalida o sin permiso. Revisa la clave."
                message.contains("quota", ignoreCase = true) || message.contains("limit", ignoreCase = true) ->
                    "La API Key llego a su limite de uso o cuota. Prueba otra clave o espera el reinicio del limite."
                message.isNotBlank() -> message.take(260)
                else -> "Error de API. Revisa API Key e internet."
            }
        } catch (_: Exception) {
            "Error de API. Revisa API Key e internet."
        }
    }

    private fun cleanQuery(raw: String): String {
        return raw.replace("\\s+".toRegex(), " ").trim()
    }

    private fun cleanAnswer(raw: String): String {
        val cleaned = raw
            .replace("**", "")
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (cleaned.length <= 2000) return cleaned
        return cleaned.take(2000).trim()
    }

    private fun looksIncomplete(text: String): Boolean {
        val cleaned = cleanAnswer(text)
        if (cleaned.isBlank()) return true

        val lastChar = cleaned.last()
        if (lastChar == ':' || lastChar == ',' || lastChar == ';' || lastChar == '-') return true

        val lastWord = cleaned
            .lowercase()
            .replace("[^a-záéíóúñü]+$".toRegex(), "")
            .substringAfterLast(' ')

        val weakEndings = setOf(
            "de", "del", "la", "el", "los", "las", "un", "una", "uno",
            "y", "o", "que", "para", "por", "en", "con", "a", "se", "es"
        )

        return lastWord in weakEndings
    }
}
