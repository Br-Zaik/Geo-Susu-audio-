# Geo Susu JSON v115

Cambios principales:
- NET usa una sola llamada por API Key, sin reintentos para ahorrar tokens.
- Configuracion API permite guardar varias API Keys con el boton + AGREGAR API.
- Si una API llega a limite/cuota o es invalida, NET prueba automaticamente la siguiente API guardada.
- JSON mantiene un solo link con preguntas, respuestas y variantes juntas.
- No se tocaron JSON, variantes, escucha, sensibilidad, reduccion de ruido ni Bluetooth.
