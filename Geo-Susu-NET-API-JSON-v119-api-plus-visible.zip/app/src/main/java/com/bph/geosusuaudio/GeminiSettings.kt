package com.bph.geosusuaudio

import android.content.Context

class GeminiSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_gemini", Context.MODE_PRIVATE)

    fun getApiKey(): String {
        return getApiKeys().firstOrNull().orEmpty()
    }

    fun getApiKeys(): List<String> {
        val stored = prefs.getString(KEY_API_KEYS, null)
        if (!stored.isNullOrBlank()) {
            return stored
                .split("\n")
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
        }

        val oldKey = prefs.getString(KEY_API_KEY, "").orEmpty().trim()
        return if (oldKey.isBlank()) emptyList() else listOf(oldKey)
    }

    fun saveApiKey(value: String) {
        saveApiKeys(listOf(value))
    }

    fun saveApiKeys(values: List<String>) {
        val clean = values
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()

        prefs.edit()
            .putString(KEY_API_KEYS, clean.joinToString("\n"))
            .putString(KEY_API_KEY, clean.firstOrNull().orEmpty())
            .putInt(KEY_LAST_GOOD_INDEX, 0)
            .apply()
    }

    fun hasApiKey(): Boolean {
        return getApiKeys().isNotEmpty()
    }

    fun getLastGoodIndex(): Int {
        val size = getApiKeys().size
        if (size <= 0) return 0
        val saved = prefs.getInt(KEY_LAST_GOOD_INDEX, 0)
        return saved.coerceIn(0, size - 1)
    }

    fun saveLastGoodIndex(index: Int) {
        prefs.edit().putInt(KEY_LAST_GOOD_INDEX, index.coerceAtLeast(0)).apply()
    }

    fun getCooldownUntil(index: Int): Long {
        return prefs.getLong("${KEY_COOLDOWN_PREFIX}$index", 0L)
    }

    fun setCooldownUntil(index: Int, untilMs: Long) {
        prefs.edit().putLong("${KEY_COOLDOWN_PREFIX}$index", untilMs).apply()
    }

    fun clearCooldown(index: Int) {
        prefs.edit().remove("${KEY_COOLDOWN_PREFIX}$index").apply()
    }

    companion object {
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_API_KEYS = "gemini_api_keys"
        private const val KEY_LAST_GOOD_INDEX = "gemini_last_good_index"
        private const val KEY_COOLDOWN_PREFIX = "gemini_key_cooldown_"
    }
}
