package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    private data class GeminiCallResult(
        val ok: Boolean,
        val text: String,
        val error: String,
        val model: String,
        val canTryNextKey: Boolean = false
    )

    // Mismo modelo que usa la APK "Mi Asistente IA" que respondia completo.
    private val modelCandidates = listOf("gemini-2.5-flash")

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val settings = context?.let { GeminiSettings(it) }
        val apiKeys = settings?.getApiKeys().orEmpty()
        if (apiKeys.isEmpty()) {
            return "Sin API configurada. Toca API, pega tu clave y prueba si funciona."
        }

        var lastError = ""
        var quotaOrLimitHit = false
        val now = System.currentTimeMillis()
        val baseOrder = orderedKeys(apiKeys, settings?.getLastGoodIndex() ?: 0)
        val ordered = baseOrder
            .filter { (idx, _) -> (settings?.getCooldownUntil(idx) ?: 0L) <= now }
            .ifEmpty { baseOrder }

        for ((originalIndex, apiKey) in ordered) {
            val result = askGemini(apiKey, query)
            if (result.ok && result.text.isNotBlank()) {
                settings?.saveLastGoodIndex(originalIndex)
                settings?.clearCooldown(originalIndex)
                return result.text
            }

            lastError = result.error
            if (isQuotaOrLimitMessage(result.error)) {
                quotaOrLimitHit = true
                settings?.setCooldownUntil(originalIndex, System.currentTimeMillis() + KEY_COOLDOWN_MS)
            }
            if (!result.canTryNextKey) break
        }

        return if (quotaOrLimitHit) {
            "Todas las API disponibles llegaron a su limite o cuota. Espera unos minutos o agrega una API de otro proyecto."
        } else {
            lastError.ifBlank {
                "NET no devolvio respuesta. Revisa tu API Key, internet o limite de uso."
            }
        }
    }

    fun testApiKey(apiKey: String): Pair<Boolean, String> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) return false to "Pega primero tu API Key."

        val result = askGemini(cleanKey, "Responde solo: API funcionando", testing = true)
        return if (result.ok && result.text.isNotBlank()) {
            true to "API funcionando correctamente."
        } else {
            false to result.error.ifBlank { "No se pudo probar la API. Revisa la clave o internet." }
        }
    }

    fun testApiKeys(apiKeys: List<String>): Pair<Boolean, String> {
        val cleanKeys = apiKeys.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (cleanKeys.isEmpty()) return false to "Pega por lo menos una API Key."

        var lastError = ""
        for ((index, key) in cleanKeys.withIndex()) {
            val result = askGemini(key, "Responde solo: API funcionando", testing = true)
            if (result.ok && result.text.isNotBlank()) {
                context?.let {
                    GeminiSettings(it).apply {
                        saveLastGoodIndex(index)
                        clearCooldown(index)
                    }
                }
                return true to "API ${index + 1} funcionando correctamente."
            }
            lastError = "API ${index + 1}: ${result.error}"
            if (!result.canTryNextKey) break
        }

        return false to lastError.ifBlank { "No se pudo probar ninguna API. Revisa claves o internet." }
    }

    private fun askGemini(apiKey: String, question: String, testing: Boolean = false): GeminiCallResult {
        var lastError = ""
        var canTryNext = false

        for (model in modelCandidates) {
            val result = callGeminiModel(apiKey, model, question, testing)
            if (result.ok) return result
            lastError = result.error
            canTryNext = result.canTryNextKey
        }

        return GeminiCallResult(false, "", lastError, "", canTryNext)
    }

    private fun callGeminiModel(
        apiKey: String,
        model: String,
        question: String,
        testing: Boolean
    ): GeminiCallResult {
        var connection: HttpURLConnection? = null

        return try {
            val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            )

            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
            }

            val body = buildRequestBody(question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                val parsed = parseGeminiError(raw, code)
                return GeminiCallResult(false, "", parsed.first, model, parsed.second)
            }

            val answer = parseGeminiText(raw)
            if (answer.isBlank()) {
                GeminiCallResult(false, "", "La API respondio vacio. Intenta otra pregunta.", model, true)
            } else {
                GeminiCallResult(true, answer, "", model)
            }
        } catch (e: Exception) {
            GeminiCallResult(false, "", "No se pudo conectar con la API: ${e.message ?: "error de conexion"}.", model)
        } finally {
            connection?.disconnect()
        }
    }

    private fun buildRequestBody(question: String, testing: Boolean): JSONObject {
        val prompt = if (testing) {
            question
        } else {
            """
            Eres un asistente de repaso. Responde en español con el texto mínimo útil.
            Reglas estrictas:
            1. Si preguntan fórmula química o símbolo químico, responde solo la fórmula o símbolo. Ejemplo: oro -> Au.
            2. Si preguntan tipos, clases, división, clasificación, lista, minerales o dicen "todos", responde solo los nombres principales separados por coma. No expliques.
            3. Si preguntan "qué es", responde una sola oración corta.
            4. No saludes, no digas "soy", no agregues introducciones, no uses Markdown y no termines con frases incompletas.
            5. Si una lista es larga, da los principales y cierra la frase con punto.

            Pregunta: $question
            """.trimIndent()
        }

        return JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("maxOutputTokens", if (testing) 64 else 160)
                    put("temperature", if (testing) 0.0 else 0.2)
                }
            )
        }
    }

    private fun parseGeminiText(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        val partsText = StringBuilder()
        var finishReason = ""

        for (i in 0 until candidates.length()) {
            val candidate = candidates.optJSONObject(i) ?: continue
            finishReason = candidate.optString("finishReason").orEmpty()
            val content = candidate.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue

            for (j in 0 until parts.length()) {
                val text = parts.optJSONObject(j)?.optString("text").orEmpty().trim()
                if (text.isNotBlank()) {
                    if (partsText.isNotBlank()) {
                        val current = partsText.toString().trimEnd()
                        val firstChar = text.firstOrNull()
                        val joinsDirectly = current.endsWith(":") ||
                            current.endsWith("-") ||
                            firstChar == ',' ||
                            firstChar == '.' ||
                            firstChar == ';' ||
                            firstChar == ':'
                        partsText.append(if (joinsDirectly) "" else " ")
                    }
                    partsText.append(text)
                }
            }

            if (partsText.isNotBlank()) break
        }

        val clean = cleanAnswer(partsText.toString())
        return if (finishReason == "MAX_TOKENS" && clean.isNotBlank() && clean.last() !in listOf('.', '!', '?')) {
            "$clean..."
        } else {
            clean
        }
    }

    private fun parseGeminiError(raw: String, httpCode: Int): Pair<String, Boolean> {
        return try {
            val error = JSONObject(raw).optJSONObject("error")
            val message = error?.optString("message").orEmpty()
            val status = error?.optString("status").orEmpty()
            val lower = "$message $status".lowercase()

            when {
                lower.contains("api key") || lower.contains("permission_denied") || lower.contains("unauthenticated") ->
                    "API Key invalida o sin permiso. Revisa la clave." to true
                lower.contains("quota") || lower.contains("limit") || lower.contains("resource_exhausted") || httpCode == 429 ->
                    "La API Key llego a su limite de uso o cuota." to true
                message.isNotBlank() -> message.take(260) to false
                else -> "Error de API. Revisa API Key e internet." to false
            }
        } catch (_: Exception) {
            if (httpCode == 429) {
                "La API Key llego a su limite de uso o cuota." to true
            } else {
                "Error de API. Revisa API Key e internet." to false
            }
        }
    }

    private fun isQuotaOrLimitMessage(message: String): Boolean {
        val lower = message.lowercase()
        return lower.contains("limite") || lower.contains("límite") || lower.contains("cuota") || lower.contains("quota")
    }

    private fun orderedKeys(keys: List<String>, startIndex: Int): List<Pair<Int, String>> {
        if (keys.isEmpty()) return emptyList()
        val safeStart = startIndex.coerceIn(0, keys.size - 1)
        return keys.indices.map { offset ->
            val index = (safeStart + offset) % keys.size
            index to keys[index]
        }
    }

    private fun cleanQuery(raw: String): String {
        return raw.replace("\\s+".toRegex(), " ").trim()
    }

    private fun cleanAnswer(raw: String): String {
        val cleaned = raw
            .replace("**", "")
            .replace("\\s+".toRegex(), " ")
            .trim()

        if (cleaned.length <= 2000) return cleaned
        return cleaned.take(2000).trim()
    }

    companion object {
        private const val KEY_COOLDOWN_MS = 10 * 60 * 1000L
    }
}
