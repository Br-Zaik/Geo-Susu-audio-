# Geo Susu JSON v122

Cambios v122:
- NET/API separa las claves por estado: ACTIVA, LIMITE, EN ESPERA y ERROR.
- Si una API llega a LIMITE, queda apartada 24 horas y no se vuelve a usar durante ese tiempo.
- Si una API esta mal escrita, sin permiso o invalida, queda en ERROR y no se mezcla con las activas.
- Si hay error temporal del servidor, queda EN ESPERA por 10 minutos.
- Las API nuevas quedan disponibles y se prueban antes que las bloqueadas.
- La app no se cierra si falla NET: JSON sigue funcionando.
- No se tocaron JSON, variantes, escucha, sensibilidad, reduccion de ruido ni Bluetooth.
