package com.bph.geosusuaudio

import android.content.Context
import kotlin.math.max

class GeminiSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_gemini", Context.MODE_PRIVATE)

    fun getApiKey(): String {
        return getApiKeys().firstOrNull().orEmpty()
    }

    fun getApiKeys(): List<String> {
        val stored = prefs.getString(KEY_API_KEYS, null)
        if (!stored.isNullOrBlank()) {
            return stored
                .split("\n")
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
        }

        val oldKey = prefs.getString(KEY_API_KEY, "").orEmpty().trim()
        return if (oldKey.isBlank()) emptyList() else listOf(oldKey)
    }

    fun saveApiKey(value: String) {
        saveApiKeys(listOf(value))
    }

    fun saveApiKeys(values: List<String>) {
        val oldKeys = getApiKeys().toSet()
        val clean = values
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()

        prefs.edit()
            .putString(KEY_API_KEYS, clean.joinToString("\n"))
            .putString(KEY_API_KEY, clean.firstOrNull().orEmpty())
            .putInt(KEY_LAST_GOOD_INDEX, 0)
            .apply()

        // Las claves nuevas quedan disponibles. No se mezclan con las que ya estaban en limite/error.
        clean.filter { it !in oldKeys }.forEach { markReady(it) }
    }

    fun hasApiKey(): Boolean {
        return getApiKeys().isNotEmpty()
    }

    fun getLastGoodIndex(): Int {
        val size = getApiKeys().size
        if (size <= 0) return 0
        val saved = prefs.getInt(KEY_LAST_GOOD_INDEX, 0)
        return saved.coerceIn(0, size - 1)
    }

    fun saveLastGoodIndex(index: Int) {
        prefs.edit().putInt(KEY_LAST_GOOD_INDEX, index.coerceAtLeast(0)).apply()
    }

    fun markReady(apiKey: String) {
        val id = keyId(apiKey)
        prefs.edit()
            .putString("${KEY_STATUS_PREFIX}$id", STATUS_READY)
            .remove("${KEY_UNTIL_PREFIX}$id")
            .remove("${KEY_MESSAGE_PREFIX}$id")
            .apply()
    }

    fun markLimit(apiKey: String, message: String = "Llego al limite diario de uso.") {
        markBlocked(apiKey, STATUS_LIMIT, System.currentTimeMillis() + DAILY_LIMIT_COOLDOWN_MS, message)
    }

    fun markWait(apiKey: String, message: String = "En espera temporal.", cooldownMs: Long = WAIT_COOLDOWN_MS) {
        markBlocked(apiKey, STATUS_WAIT, System.currentTimeMillis() + cooldownMs, message)
    }

    fun markMinuteLimit(apiKey: String, message: String = "Limite por minuto. Espera unos minutos.") {
        markWait(apiKey, message, MINUTE_LIMIT_COOLDOWN_MS)
    }

    fun markUnknownLimit(apiKey: String, message: String = "Limite temporal. Espera o usa otra API.") {
        markWait(apiKey, message, UNKNOWN_LIMIT_COOLDOWN_MS)
    }

    fun markError(apiKey: String, message: String = "API invalida o sin permiso.") {
        markBlocked(apiKey, STATUS_ERROR, 0L, message)
    }

    private fun markBlocked(apiKey: String, status: String, untilMs: Long, message: String) {
        val id = keyId(apiKey)
        prefs.edit()
            .putString("${KEY_STATUS_PREFIX}$id", status)
            .putLong("${KEY_UNTIL_PREFIX}$id", untilMs)
            .putString("${KEY_MESSAGE_PREFIX}$id", message.take(180))
            .apply()
    }

    fun shouldSkip(apiKey: String): Boolean {
        val status = getStatus(apiKey)
        if (status == STATUS_ERROR) return true

        if (status == STATUS_LIMIT || status == STATUS_WAIT) {
            val until = getUntil(apiKey)
            if (until > System.currentTimeMillis()) return true
            // Si ya paso el tiempo de espera, vuelve a estar disponible.
            markReady(apiKey)
            return false
        }

        return false
    }

    fun getStatus(apiKey: String): String {
        val id = keyId(apiKey)
        return prefs.getString("${KEY_STATUS_PREFIX}$id", STATUS_READY) ?: STATUS_READY
    }

    fun getUntil(apiKey: String): Long {
        val id = keyId(apiKey)
        return prefs.getLong("${KEY_UNTIL_PREFIX}$id", 0L)
    }

    fun getMessage(apiKey: String): String {
        val id = keyId(apiKey)
        return prefs.getString("${KEY_MESSAGE_PREFIX}$id", "").orEmpty()
    }

    fun getStatusLabel(apiKey: String, index: Int): String {
        val status = getStatus(apiKey)
        val name = "API ${index + 1}"
        return when (status) {
            STATUS_LIMIT -> "$name: LIMITE DIARIO (${remainingText(getUntil(apiKey))})"
            STATUS_WAIT -> "$name: EN ESPERA (${remainingText(getUntil(apiKey))})"
            STATUS_ERROR -> "$name: ERROR - ${getMessage(apiKey).ifBlank { "no se puede usar" }}"
            else -> "$name: ACTIVA"
        }
    }

    fun getStatusReport(keys: List<String> = getApiKeys()): String {
        if (keys.isEmpty()) return "Sin API guardada."
        return keys.mapIndexed { index, key -> getStatusLabel(key, index) }.joinToString("\n")
    }

    private fun remainingText(untilMs: Long): String {
        val diff = untilMs - System.currentTimeMillis()
        if (diff <= 0L) return "lista"
        val minutes = max(1L, diff / 60000L)
        val hours = minutes / 60L
        val mins = minutes % 60L
        return if (hours > 0L) "${hours}h ${mins}m" else "${minutes}m"
    }

    private fun keyId(apiKey: String): String {
        // Identificador estable para no depender del orden si el usuario reordena o agrega claves.
        return apiKey.trim().hashCode().toString()
    }

    companion object {
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_API_KEYS = "gemini_api_keys"
        private const val KEY_LAST_GOOD_INDEX = "gemini_last_good_index"
        private const val KEY_STATUS_PREFIX = "api_status_"
        private const val KEY_UNTIL_PREFIX = "api_until_"
        private const val KEY_MESSAGE_PREFIX = "api_message_"

        private const val STATUS_READY = "ready"
        private const val STATUS_LIMIT = "limit"
        private const val STATUS_WAIT = "wait"
        private const val STATUS_ERROR = "error"

        // Cuota diaria: se separa fuerte para no repetir hasta el reinicio.
        private const val DAILY_LIMIT_COOLDOWN_MS = 24L * 60L * 60L * 1000L
        // Limite por minuto: solo necesita descansar poco tiempo.
        private const val MINUTE_LIMIT_COOLDOWN_MS = 10L * 60L * 1000L
        // Cuota no identificada: descanso intermedio, no 24 horas.
        private const val UNKNOWN_LIMIT_COOLDOWN_MS = 60L * 60L * 1000L
        // Errores temporales del servidor se dejan en espera corta.
        private const val WAIT_COOLDOWN_MS = 10L * 60L * 1000L
    }
}
