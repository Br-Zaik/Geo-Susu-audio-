package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    private data class GeminiCallResult(
        val ok: Boolean,
        val text: String,
        val error: String,
        val model: String,
        val canTryNextKey: Boolean = false,
        val failureType: FailureType = FailureType.NONE
    )

    private enum class FailureType {
        NONE, LIMIT_DAILY, LIMIT_MINUTE, LIMIT_UNKNOWN, INVALID, TEMPORARY, NETWORK, OTHER
    }

    // Mismo modelo base que usa la APK "Mi Asistente IA" que respondia completo.
    private val modelCandidates = listOf("gemini-2.5-flash")

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val settings = context?.let { GeminiSettings(it) }
        val apiKeys = settings?.getApiKeys().orEmpty()
        if (apiKeys.isEmpty()) {
            return "Sin API configurada. Toca API, pega tu clave y prueba si funciona."
        }

        val baseOrder = orderedKeys(apiKeys, settings?.getLastGoodIndex() ?: 0)
        val available = baseOrder.filter { (_, key) -> settings?.shouldSkip(key) != true }
        if (available.isEmpty()) {
            return "No hay API disponible ahora. Hay claves en limite diario, espera temporal o error. Usa JSON o agrega otra API."
        }

        var lastError = ""
        var dailyLimitHit = false
        var minuteLimitHit = false
        var unknownLimitHit = false
        var invalidHit = false
        var waitHit = false

        for ((originalIndex, apiKey) in available) {
            val result = askGemini(apiKey, query)
            if (result.ok && result.text.isNotBlank()) {
                settings?.saveLastGoodIndex(originalIndex)
                settings?.markReady(apiKey)
                return result.text
            }

            lastError = result.error
            when (result.failureType) {
                FailureType.LIMIT_DAILY -> {
                    dailyLimitHit = true
                    settings?.markLimit(apiKey, result.error.ifBlank { "Llego al limite diario de uso." })
                }
                FailureType.LIMIT_MINUTE -> {
                    minuteLimitHit = true
                    settings?.markMinuteLimit(apiKey, result.error.ifBlank { "Limite por minuto. Espera unos minutos." })
                }
                FailureType.LIMIT_UNKNOWN -> {
                    unknownLimitHit = true
                    settings?.markUnknownLimit(apiKey, result.error.ifBlank { "Limite temporal. Espera o usa otra API." })
                }
                FailureType.INVALID -> {
                    invalidHit = true
                    settings?.markError(apiKey, result.error.ifBlank { "API invalida o sin permiso." })
                }
                FailureType.TEMPORARY -> {
                    waitHit = true
                    settings?.markWait(apiKey, result.error.ifBlank { "Error temporal del servidor." })
                }
                FailureType.NETWORK -> {
                    return result.error.ifBlank { "Conexion inestable. Revisa internet y vuelve a intentar." }
                }
                else -> Unit
            }

            if (!result.canTryNextKey) break
        }

        return when {
            dailyLimitHit && !minuteLimitHit && !unknownLimitHit && !invalidHit && !waitHit -> "Las API disponibles llegaron a limite diario. Quedan separadas 24 horas. Agrega otra API o usa JSON."
            minuteLimitHit && !dailyLimitHit && !unknownLimitHit && !invalidHit && !waitHit -> "Limite por minuto. Esa API queda en espera 10 minutos; prueba otra API o espera."
            unknownLimitHit && !dailyLimitHit && !minuteLimitHit && !invalidHit && !waitHit -> "Limite temporal de API. Queda en espera 1 hora para no insistir."
            invalidHit && !dailyLimitHit && !minuteLimitHit && !unknownLimitHit && !waitHit -> "Una o mas API no se pueden usar. Revisa las claves en API y agrega otra valida."
            waitHit && !dailyLimitHit && !minuteLimitHit && !unknownLimitHit && !invalidHit -> "API en espera temporal. Vuelve a intentar en unos minutos o agrega otra API."
            lastError.isNotBlank() -> lastError
            else -> "NET no devolvio respuesta. Revisa API, internet o limite de uso."
        }
    }

    fun testApiKey(apiKey: String): Pair<Boolean, String> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) return false to "Pega primero tu API Key."

        val result = askGemini(cleanKey, "Responde solo: API funcionando", testing = true)
        return if (result.ok && result.text.isNotBlank()) {
            true to "API funcionando correctamente."
        } else {
            false to result.error.ifBlank { "No se pudo probar la API. Revisa la clave o internet." }
        }
    }

    fun testApiKeys(apiKeys: List<String>): Pair<Boolean, String> {
        val cleanKeys = apiKeys.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (cleanKeys.isEmpty()) return false to "Pega por lo menos una API Key."

        val settings = context?.let { GeminiSettings(it) }
        var lastError = ""

        for ((index, key) in cleanKeys.withIndex()) {
            val result = askGemini(key, "Responde solo: API funcionando", testing = true)
            if (result.ok && result.text.isNotBlank()) {
                settings?.apply {
                    saveLastGoodIndex(index)
                    markReady(key)
                }
                return true to "API ${index + 1} funcionando correctamente.\n\n${settings?.getStatusReport(cleanKeys).orEmpty()}"
            }

            when (result.failureType) {
                FailureType.LIMIT_DAILY -> settings?.markLimit(key, result.error)
                FailureType.LIMIT_MINUTE -> settings?.markMinuteLimit(key, result.error)
                FailureType.LIMIT_UNKNOWN -> settings?.markUnknownLimit(key, result.error)
                FailureType.INVALID -> settings?.markError(key, result.error)
                FailureType.TEMPORARY -> settings?.markWait(key, result.error)
                else -> Unit
            }

            lastError = "API ${index + 1}: ${result.error}"
            if (!result.canTryNextKey) break
        }

        val report = settings?.getStatusReport(cleanKeys).orEmpty()
        return false to listOf(lastError.ifBlank { "No se pudo probar ninguna API. Revisa claves o internet." }, report)
            .filter { it.isNotBlank() }
            .joinToString("\n\n")
    }

    private fun askGemini(apiKey: String, question: String, testing: Boolean = false): GeminiCallResult {
        var lastError = ""
        var canTryNext = false
        var failureType = FailureType.OTHER

        for (model in modelCandidates) {
            val result = callGeminiModel(apiKey, model, question, testing)
            if (result.ok) return result
            lastError = result.error
            canTryNext = result.canTryNextKey
            failureType = result.failureType
        }

        return GeminiCallResult(false, "", lastError, "", canTryNext, failureType)
    }

    private fun callGeminiModel(
        apiKey: String,
        model: String,
        question: String,
        testing: Boolean
    ): GeminiCallResult {
        var connection: HttpURLConnection? = null

        return try {
            val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            )

            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GeoSusuJSON/122")
            }

            val body = buildRequestBody(question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                val parsed = parseGeminiError(raw, code)
                return parsed.copy(model = model)
            }

            val answer = parseGeminiText(raw)
            if (answer.isBlank()) {
                GeminiCallResult(false, "", "La API respondio vacio. API en espera temporal.", model, true, FailureType.TEMPORARY)
            } else {
                GeminiCallResult(true, answer, "", model)
            }
        } catch (e: Exception) {
            val msg = (e.message ?: "error de conexion").lowercase()
            val cleanMessage = when {
                msg.contains("reset") -> "Conexion inestable. Revisa internet y vuelve a intentar."
                msg.contains("timeout") || msg.contains("timed out") -> "La conexion demoro demasiado. Revisa internet y vuelve a intentar."
                msg.contains("unable to resolve") || msg.contains("failed to connect") -> "Sin conexion estable a internet. Revisa datos o Wi-Fi."
                else -> "No se pudo conectar con la API. Revisa internet y vuelve a intentar."
            }
            GeminiCallResult(false, "", cleanMessage, model, false, FailureType.NETWORK)
        } finally {
            connection?.disconnect()
        }
    }

    private fun buildRequestBody(question: String, testing: Boolean): JSONObject {
        val prompt = if (testing) {
            question
        } else {
            """
            Responde en español con el texto mínimo útil.

            Reglas obligatorias:
            1. Entrega SOLO la respuesta final.
            2. No incluyas análisis, razonamiento interno, pasos, reglas ni explicación del proceso.
            3. Si preguntan fórmula química o símbolo químico, responde solo la fórmula o símbolo. Ejemplo: oro -> Au.
            4. Si preguntan tipos, clases, división, clasificación, lista, minerales o dicen "todos", responde solo los nombres principales separados por coma. No expliques.
            5. Si preguntan "qué es", responde una sola oración corta.
            6. No saludes, no digas "soy", no uses Markdown y no termines con frases incompletas.
            7. Responde máximo en una línea o una oración corta, salvo listas de nombres.

            Pregunta: $question
            """.trimIndent()
        }

        return JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("maxOutputTokens", if (testing) 64 else 160)
                    put("temperature", if (testing) 0.0 else 0.2)
                }
            )
        }
    }

    private fun parseGeminiText(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        val partsText = StringBuilder()
        var finishReason = ""

        for (i in 0 until candidates.length()) {
            val candidate = candidates.optJSONObject(i) ?: continue
            finishReason = candidate.optString("finishReason").orEmpty()
            val content = candidate.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue

            for (j in 0 until parts.length()) {
                val text = parts.optJSONObject(j)?.optString("text").orEmpty().trim()
                if (text.isNotBlank()) {
                    if (partsText.isNotBlank()) {
                        val current = partsText.toString().trimEnd()
                        val firstChar = text.firstOrNull()
                        val joinsDirectly = current.endsWith(":") ||
                            current.endsWith("-") ||
                            firstChar == ',' ||
                            firstChar == '.' ||
                            firstChar == ';' ||
                            firstChar == ':'
                        partsText.append(if (joinsDirectly) "" else " ")
                    }
                    partsText.append(text)
                }
            }

            if (partsText.isNotBlank()) break
        }

        val clean = cleanAnswer(partsText.toString())
        return if (finishReason == "MAX_TOKENS" && clean.isNotBlank() && clean.last() !in listOf('.', '!', '?')) {
            "$clean..."
        } else {
            clean
        }
    }

    private fun parseGeminiError(raw: String, httpCode: Int): GeminiCallResult {
        return try {
            val error = JSONObject(raw).optJSONObject("error")
            val message = error?.optString("message").orEmpty()
            val status = error?.optString("status").orEmpty()
            val lower = "$message $status $raw".lowercase()

            when {
                lower.contains("api key") || lower.contains("permission_denied") || lower.contains("unauthenticated") ->
                    GeminiCallResult(false, "", "API Key invalida o sin permiso. Revisa la clave.", "", true, FailureType.INVALID)
                lower.contains("per day") || lower.contains("perday") || lower.contains("requestsperday") || lower.contains("rpd") || lower.contains("daily") ->
                    GeminiCallResult(false, "", "La API llego a su limite diario. Queda separada 24 horas.", "", true, FailureType.LIMIT_DAILY)
                lower.contains("per minute") || lower.contains("perminute") || lower.contains("requestsperminute") || lower.contains("tokensperminute") || lower.contains("rpm") || lower.contains("tpm") ->
                    GeminiCallResult(false, "", "Limite por minuto. API en espera 10 minutos.", "", true, FailureType.LIMIT_MINUTE)
                lower.contains("quota") || lower.contains("limit") || lower.contains("resource_exhausted") || httpCode == 429 ->
                    GeminiCallResult(false, "", "Limite temporal de API. Queda en espera 1 hora.", "", true, FailureType.LIMIT_UNKNOWN)
                httpCode in 500..599 ->
                    GeminiCallResult(false, "", "Servidor de API ocupado. API en espera temporal.", "", true, FailureType.TEMPORARY)
                message.isNotBlank() ->
                    GeminiCallResult(false, "", message.take(260), "", false, FailureType.OTHER)
                else -> GeminiCallResult(false, "", "Error de API. Revisa API Key e internet.", "", false, FailureType.OTHER)
            }
        } catch (_: Exception) {
            if (httpCode == 429) {
                GeminiCallResult(false, "", "Limite temporal de API. Queda en espera 1 hora.", "", true, FailureType.LIMIT_UNKNOWN)
            } else if (httpCode in 500..599) {
                GeminiCallResult(false, "", "Servidor de API ocupado. API en espera temporal.", "", true, FailureType.TEMPORARY)
            } else {
                GeminiCallResult(false, "", "Error de API. Revisa API Key e internet.", "", false, FailureType.OTHER)
            }
        }
    }

    private fun orderedKeys(keys: List<String>, startIndex: Int): List<Pair<Int, String>> {
        if (keys.isEmpty()) return emptyList()
        val safeStart = startIndex.coerceIn(0, keys.size - 1)
        return keys.indices.map { offset ->
            val index = (safeStart + offset) % keys.size
            index to keys[index]
        }
    }

    private fun cleanQuery(raw: String): String {
        return raw.replace("\\s+".toRegex(), " ").trim()
    }

    private fun cleanAnswer(raw: String): String {
        var candidate = raw
            .replace("**", "")
            .replace("```", "")
            .trim()

        candidate = removeReasoningLeak(candidate)
            .replace("\\s+".toRegex(), " ")
            .trim()

        candidate = candidate
            .replace(Regex("^(Respuesta final|Respuesta|Final)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("^(Rpta|Resp)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .trim()

        if (candidate.contains("THOUGHT:", ignoreCase = true) ||
            candidate.contains("REASONING:", ignoreCase = true) ||
            candidate.contains("ANALYSIS:", ignoreCase = true)
        ) {
            candidate = removeReasoningLeak(candidate).trim()
        }

        if (candidate.length <= 2000) return candidate
        return candidate.take(2000).trim()
    }

    private fun removeReasoningLeak(raw: String): String {
        val markers = listOf(
            "THOUGHT:",
            "Thought:",
            "REASONING:",
            "Reasoning:",
            "ANALYSIS:",
            "Analysis:",
            "PENSAMIENTO:",
            "RAZONAMIENTO:"
        )
        if (markers.none { raw.contains(it) }) return raw

        val sentences = raw
            .replace("\n", " ")
            .split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val cleanSentence = sentences.asReversed().firstOrNull { sentence ->
            isLikelyFinalAnswer(sentence)
        }
        if (!cleanSentence.isNullOrBlank()) return cleanSentence

        val lines = raw.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val cleanLine = lines.asReversed().firstOrNull { line ->
            isLikelyFinalAnswer(line)
        }
        if (!cleanLine.isNullOrBlank()) return cleanLine

        return "NET devolvio texto interno. Repite la pregunta."
    }

    private fun isLikelyFinalAnswer(text: String): Boolean {
        val lower = text.lowercase()
        if (text.length < 2) return false
        if (lower.contains("thought:") || lower.contains("reasoning:") || lower.contains("analysis:")) return false
        if (lower.contains("the user") || lower.contains("rule #") || lower.contains("i need") || lower.contains("falls under")) return false
        if (lower.contains("pregunta:") || lower.contains("regla") || lower.contains("responde solo")) return false
        return true
    }
}
