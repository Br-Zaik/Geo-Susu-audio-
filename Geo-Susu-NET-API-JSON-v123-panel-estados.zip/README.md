# Geo Susu JSON v123

Cambios v123:
- La ventana API ahora muestra un panel claro con conteo: disponibles, en espera, limite y error.
- Cada API aparece con estado individual: ACTIVA, DISPONIBLE, EN ESPERA, LIMITE DIARIO o ERROR.
- Las APIs se muestran con terminacion ocultada, por ejemplo API 1 (...ABCD), para reconocerlas sin mostrar la clave completa.
- Se mantiene espera inteligente: limite diario = 24h, limite por minuto = 10m, limite desconocido = 1h y error temporal = 10m.
- Si una API esta mal escrita o sin permiso, queda en ERROR hasta corregirla.
- NET/API hace una sola llamada por API Key disponible y pasa a otra solo si corresponde.
- La app no se cierra si falla NET: JSON sigue funcionando.
- No se tocaron JSON, variantes, busqueda fuzzy, escucha, sensibilidad, reduccion de ruido ni Bluetooth.
