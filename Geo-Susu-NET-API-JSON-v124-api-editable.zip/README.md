# Geo Susu JSON v124

Cambios v124:
- La ventana API ahora permite ver, editar, agregar y borrar APIs manualmente.
- Cada API aparece como casilla editable con su propio boton BORRAR ESTA API.
- El panel muestra resumen: disponibles, en espera, limite y error.
- Cada API muestra su estado individual: ACTIVA, DISPONIBLE, EN ESPERA, LIMITE DIARIO o ERROR.
- Al borrar una API, se quita de la lista y se confirma con GUARDAR.
- Si se borran todas las APIs, NET queda sin API pero JSON sigue funcionando.
- Se mantiene espera inteligente: limite diario = 24h, limite por minuto = 10m, limite desconocido = 1h y error temporal = 10m.
- NET/API hace una sola llamada por API Key disponible y pasa a otra solo si corresponde.
- No se tocaron JSON, variantes, busqueda fuzzy, escucha, sensibilidad, reduccion de ruido ni Bluetooth.
