# Geo Susu JSON v125

Cambios v125:
- Al guardar APIs nuevas quedan como SIN PROBAR, no como ACTIVA.
- PROBAR API valida cada clave por separado.
- APIs muy cortas, con espacios o caracteres raros quedan en ERROR sin gastar solicitud.
- Si hay internet inestable, no marca la API como mala.
- Mantiene panel editable para ver, editar, agregar o borrar APIs.
- Mantiene JSON / NET / AUTO.
- No se tocó JSON, variantes, escucha, sensibilidad, reducción de ruido ni Bluetooth.
