# Geo Susu JSON v127

Cambios v127:
- JSON ahora funciona por cursos/temas de forma manual.
- Puedes agregar varios JSON con nombre y link Raw.
- Boton + AGREGAR OTRO JSON.
- Boton USAR ESTE JSON para elegir el tema activo.
- Boton ACTUALIZAR para descargar solo el JSON elegido.
- La app busca solo en el JSON activo, no en todos.
- Muestra el tema activo en pantalla: modo + nombre del JSON.
- Recomendado: maximo 400 preguntas por JSON y maximo 10 variantes por pregunta.
- Conserva JSON / NET / AUTO.
- AUTO usa primero el JSON activo; si no encuentra, recien NET.
- No se tocó escucha, sensibilidad, reducción de ruido ni Bluetooth.
