# Geo Susu JSON v128

Correccion v128:
- Se vuelve a una sola configuracion JSON Raw como antes.
- Se quita la idea de multiples JSON en la app para evitar bloqueos.
- Se mantiene el panel de APIs de v125: agregar, editar, borrar y PROBAR API.
- Se optimiza JSON para que la busqueda/carga se haga fuera del hilo principal y no congele la pantalla.
- Mantiene JSON / NET / AUTO.
- No se tocó escucha, sensibilidad, reducción de ruido ni Bluetooth.
