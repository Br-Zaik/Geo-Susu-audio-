package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var memory: MemoryStore
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var isListening = false

    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var lastPartial = ""
    private var partialRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        jsonRepository = JsonKnowledgeRepository(this)
        warmJsonInBackground()
        memory = MemoryStore(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Google interno activo"))
        running = true
        startInternalRecognition(delayMs = 350L)
        return START_STICKY
    }

    private fun startInternalRecognition(delayMs: Long = 300L) {
        if (!running || isSpeaking || isListening) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "Activa permiso de micrófono.", 0)
            stopSelf()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendUpdate("Google interno no disponible", "", "Actualiza Speech Services by Google o usa Google ventana.", 0)
            stopSelf()
            return
        }

        handler.postDelayed({
            if (!running || isSpeaking || isListening) return@postDelayed

            try {
                if (recognizer == null) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer?.setRecognitionListener(listener)
                }

                isListening = true
                lastPartial = ""
                cancelPartialRunnable()
                sendUpdate("Google interno escuchando...", "", "", 0)
                recognizer?.startListening(buildIntent())
            } catch (_: Exception) {
                isListening = false
                sendUpdate("Reiniciando Google interno...", "", "", -1)
                restartRecognizer(900L)
            }
        }, delayMs)
    }

    private fun buildIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            sendUpdate("Google interno listo", "", "", 0)
        }

        override fun onBeginningOfSpeech() {
            sendUpdate("Te estoy escuchando...", "", "", 25)
        }

        override fun onRmsChanged(rmsdB: Float) {
            val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
            sendUpdate("", "", "", level)
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() {
            sendUpdate("Procesando voz...", "", "", -1)
        }

        override fun onError(error: Int) {
            isListening = false
            cancelPartialRunnable()

            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    sendUpdate("No detectó voz", "", "", -1)
                    restartRecognizer(600L)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    restartRecognizer(900L)
                }
                else -> {
                    sendUpdate("Google interno error $error", "", "Reintentando escucha.", -1)
                    restartRecognizer(1200L)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            cancelPartialRunnable()

            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()

            val best = matches
                .map { it.trim() }
                .firstOrNull { it.isNotBlank() }
                .orEmpty()

            if (best.isBlank()) {
                restartRecognizer(500L)
                return
            }

            processQuestion(best)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .trim()

            if (partial.isNotBlank()) {
                lastPartial = partial
                sendUpdate("Escuchando...", partial, "", -1)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun schedulePartialAnswer(partial: String) {
        cancelPartialRunnable()

        val task = Runnable {
            if (!running || isSpeaking || !isListening) return@Runnable
            if (partial != lastPartial) return@Runnable

            try {
                recognizer?.cancel()
            } catch (_: Exception) {
            }

            isListening = false
            processQuestion(partial)
        }

        partialRunnable = task
        handler.postDelayed(task, 1100L)
    }

    private fun cancelPartialRunnable() {
        partialRunnable?.let { handler.removeCallbacks(it) }
        partialRunnable = null
    }

    private fun processQuestion(raw: String) {
        val question = ResponseRepository.normalize(raw)
        if (question.length < 2) {
            restartRecognizer(350L)
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            restartRecognizer(350L)
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastHeard && now - lastHeardTime < 4500) {
            restartRecognizer(350L)
            return
        }

        lastHeard = question
        lastHeardTime = now

        when (modeSettings.getMode()) {
            AnswerModeSettings.Mode.INTERNET -> answerOnline(question)

            AnswerModeSettings.Mode.JSON -> answerJsonInBackground(question, fallbackToOnline = false)

            AnswerModeSettings.Mode.AUTO -> answerJsonInBackground(question, fallbackToOnline = true)
        }
    }

    private fun answerJsonInBackground(question: String, fallbackToOnline: Boolean) {
        sendUpdate("Buscando en JSON...", question, "Procesando sin bloquear la app.", -1)

        Thread {
            val jsonMatch = try {
                jsonRepository.findBest(question)
            } catch (_: Exception) {
                ResponseRepository.MatchResult("No encontrado", "none", 0)
            }

            if (!running) return@Thread

            if (jsonMatch.itemId != "none") {
                memory.saveLast(question, jsonMatch.answer, jsonMatch.itemId, jsonMatch.score)
                handler.post { speakAnswer(question, jsonMatch.answer) }
            } else if (fallbackToOnline) {
                answerOnline(question)
            } else {
                handler.post { speakAnswer(question, "No encontrado") }
            }
        }.start()
    }

    private fun warmJsonInBackground() {
        Thread {
            try {
                jsonRepository.totalItems
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun answerOnline(question: String) {
        sendUpdate("Buscando NET...", question, "Buscando NET.", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontrado"
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                speakAnswer(question, answer)
            }
        }.start()
    }

    private fun speakAnswer(question: String, answer: String) {
        isSpeaking = true
        isListening = false
        cancelPartialRunnable()
        lastSpokenNormalized = ResponseRepository.normalize(answer)

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        sendUpdate("Respuesta lista", question, answer, -1)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())

        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false
            restartRecognizer(500L)
        }
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val spoken = lastSpokenNormalized
        if (question.isBlank() || spoken.isBlank()) return false
        if (spoken.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = qWords.count { it in spokenWords }
        return common >= 3 && common >= qWords.size * 0.6
    }

    private fun restartRecognizer(delayMs: Long) {
        if (!running || isSpeaking) return

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        isListening = false
        startInternalRecognition(delayMs)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Google interno")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GoogleInternalWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            sendUpdate("Google interno escuchando...", "", "", -1)
                            restartRecognizer(550L)
                        }, 350L)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    restartRecognizer(550L)
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        cancelPartialRunnable()

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        try {
            recognizer?.destroy()
        } catch (_: Exception) {
        }

        recognizer = null
        tts?.stop()
        tts?.shutdown()

        try {
            wakeLock?.release()
        } catch (_: Exception) {
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID = "geo_susu_google_internal_answer"
    }
}
