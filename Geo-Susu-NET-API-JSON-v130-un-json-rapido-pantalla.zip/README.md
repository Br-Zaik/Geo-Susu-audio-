# Geo Susu JSON v130

Correccion v130:
- Vuelve a un solo link JSON Raw.
- Modo JSON busca solo dentro del JSON cargado.
- Busqueda JSON mas rapida: indice exacto + indice por palabras.
- Cache del JSON para no reprocesar en cada pregunta.
- La respuesta encontrada se muestra en pantalla y tambien se lee por audio.
- Si la app vuelve de segundo plano, restaura la ultima respuesta visible.
- APIs se mantienen como v125: agregar, editar, borrar y probar API.

No se toca escucha, sensibilidad, reduccion de ruido ni Bluetooth.
