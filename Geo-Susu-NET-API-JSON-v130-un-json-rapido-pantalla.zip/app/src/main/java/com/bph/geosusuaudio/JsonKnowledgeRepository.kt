package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class JsonKnowledgeRepository(private val context: Context) {

    data class KnowledgeItem(
        val id: String,
        val tema: String,
        val titulo: String,
        val contenido: String,
        val keywords: List<String>,
        val normalizedId: String,
        val normalizedTema: String,
        val normalizedTitulo: String,
        val normalizedContenido: String,
        val normalizedKeywords: List<String>,
        val meta: String
    )

    private data class RepositoryData(
        val items: List<KnowledgeItem>,
        val exactIndex: Map<String, KnowledgeItem>,
        val invertedIndex: Map<String, List<KnowledgeItem>>
    )

    private val data: RepositoryData by lazy { loadDataCached() }

    val totalItems: Int get() = data.items.size

    fun findBest(rawQuestion: String): ResponseRepository.MatchResult {
        return try {
            findBestInternal(rawQuestion)
        } catch (_: Exception) {
            ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }
    }

    private fun findBestInternal(rawQuestion: String): ResponseRepository.MatchResult {
        val question = ResponseRepository.normalize(rawQuestion)
        val items = data.items
        val exactIndex = data.exactIndex
        if (question.length < 2 || items.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        // 1) Busqueda directa: si la pregunta coincide con una pregunta/variante del JSON,
        // responde al toque sin recorrer todo el archivo.
        exactIndex[question]?.let { item ->
            return ResponseRepository.MatchResult(buildAnswer(item), "json_${item.id}", 100)
        }

        val qWords = keyWords(question)
        if (qWords.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        // No responder por palabras demasiado vagas.
        if (qWords.size == 1 && qWords.first() in vagueSingleWords) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val coreQuestion = qWords.joinToString(" ")
        if (coreQuestion.length >= 3) {
            exactIndex[coreQuestion]?.let { item ->
                return ResponseRepository.MatchResult(buildAnswer(item), "json_${item.id}", 98)
            }
        }

        val importantPhrase = protectedPhrase(question)
        val candidates = candidateItems(qWords, importantPhrase, data.invertedIndex, items)
        if (candidates.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        var best: KnowledgeItem? = null
        var bestScore = -9999
        var secondScore = -9999

        for (item in candidates) {
            val score = scoreItem(question, coreQuestion, qWords, importantPhrase, item)
            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                best = item
            } else if (score > secondScore) {
                secondScore = score
            }
        }

        val item = best ?: return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)

        val minimum = when {
            importantPhrase.isNotBlank() -> 70
            qWords.size == 1 -> 55
            else -> 65
        }

        if (bestScore < minimum) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        // Si dos respuestas empatan casi igual, no inventa.
        if (bestScore < 120 && bestScore - secondScore < 6) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        return ResponseRepository.MatchResult(
            buildAnswer(item),
            "json_${item.id}",
            bestScore.coerceIn(0, 100)
        )
    }

    private fun scoreItem(
        question: String,
        coreQuestion: String,
        qWords: List<String>,
        importantPhrase: String,
        item: KnowledgeItem
    ): Int {
        var score = 0

        if (importantPhrase.isNotBlank()) {
            if (containsTerm(item.meta, importantPhrase)) score += 500
            if (containsTerm(item.normalizedTitulo, importantPhrase)) score += 650
            if (containsTerm(item.normalizedContenido, importantPhrase)) score += 70
        }

        // Coincidencias con preguntas/variantes/aliases/keywords ya normalizadas.
        for (phrase in item.normalizedKeywords) {
            if (phrase.length < 3) continue
            when {
                question == phrase -> score += 1000
                coreQuestion.isNotBlank() && coreQuestion == phrase -> score += 930
                phrase.length >= 5 && containsTerm(question, phrase) -> score += 520
                question.length >= 5 && containsTerm(phrase, question) -> score += 420
                coreQuestion.length >= 5 && containsTerm(phrase, coreQuestion) -> score += 360
            }
        }

        // Titulo e id pesan mas que el contenido. El contenido solo ayuda, no decide solo.
        if (coreQuestion.length >= 5) {
            if (containsTerm(item.normalizedTitulo, coreQuestion)) score += 430
            if (containsTerm(item.normalizedId, coreQuestion)) score += 320
            if (containsTerm(item.meta, coreQuestion)) score += 250
        }

        for (w in qWords) {
            if (containsTerm(item.normalizedTitulo, w)) score += 60
            if (containsTerm(item.normalizedId, w)) score += 44
            if (containsTerm(item.normalizedTema, w)) score += 12
            if (item.normalizedKeywords.any { containsTerm(it, w) }) score += 46
            if (containsTerm(item.normalizedContenido, w)) score += 7
        }

        score += intentScore(question, item.meta)
        return score
    }

    private fun buildExactIndex(source: List<KnowledgeItem>): Map<String, KnowledgeItem> {
        val map = LinkedHashMap<String, KnowledgeItem>()
        for (item in source) {
            val candidates = mutableListOf<String>()
            candidates.add(item.normalizedTitulo)
            candidates.add(item.normalizedId.replace("_", " "))
            candidates.addAll(item.normalizedKeywords)

            for (candidate in candidates) {
                val c = candidate.trim()
                if (c.length >= 3) map.putIfAbsent(c, item)

                val compactCore = keyWords(c).joinToString(" ")
                if (compactCore.length >= 3) map.putIfAbsent(compactCore, item)
            }
        }
        return map
    }

    private fun buildInvertedIndex(source: List<KnowledgeItem>): Map<String, List<KnowledgeItem>> {
        val map = LinkedHashMap<String, LinkedHashSet<KnowledgeItem>>()
        for (item in source) {
            val text = "${item.normalizedId} ${item.normalizedTema} ${item.normalizedTitulo} ${item.normalizedKeywords.joinToString(" ")}"
            for (word in keyWords(text)) {
                map.getOrPut(word) { linkedSetOf() }.add(item)
            }
        }
        return map.mapValues { it.value.toList() }
    }

    private fun candidateItems(
        qWords: List<String>,
        importantPhrase: String,
        index: Map<String, List<KnowledgeItem>>,
        allItems: List<KnowledgeItem>
    ): List<KnowledgeItem> {
        val candidates = LinkedHashSet<KnowledgeItem>()
        val lookupWords = (qWords + keyWords(importantPhrase)).distinct()
        for (word in lookupWords) {
            index[word]?.let { candidates.addAll(it) }
        }

        if (candidates.isNotEmpty()) return candidates.toList()

        // Solo cae al recorrido completo si la pregunta tiene varias palabras reales.
        // Si es una palabra que no está en el índice, responde rápido: No encontrado.
        return if (qWords.size >= 2 || importantPhrase.isNotBlank()) allItems else emptyList()
    }

    private fun buildAnswer(item: KnowledgeItem): String {
        val clean = item.contenido
            .replace("\r", " ")
            .replace("\n", " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
        val limited = clean.take(540).trim()
        return if (clean.length > 540) "$limited..." else limited
    }

    private fun protectedPhrase(question: String): String {
        val q = " $question "
        val phrases = listOf(
            "minerales no metalicos",
            "no metalicos",
            "minerales semimetalicos",
            "semimetalicos",
            "minerales metalicos",
            "metalicos",
            "minerales nativos",
            "nativos",
            "sulfosales",
            "sulfatos",
            "sulfuros",
            "escala de mohs",
            "escala de mosh",
            "materiales comunes",
            "minerales importantes por metal",
            "minerales importantes",
            "tipos de roca",
            "tipos de rocas",
            "rocas igneas",
            "rocas sedimentarias",
            "rocas metamorficas",
            "calcopirita",
            "calco pirita",
            "pirita",
            "galena",
            "antapaccay",
            "antapacay",
            "porfido",
            "skarn",
            "logueo geologico",
            "logeo geologico",
            "recursos geologicos",
            "yacimiento minero",
            "mina antapaccay",
            "mena",
            "ley mineral",
            "ley"
        )

        for (p in phrases) {
            if (q.contains(" $p ")) {
                if (p == "metalicos" && (q.contains(" no metalicos ") || q.contains(" semimetalicos "))) continue
                if (p == "pirita" && q.contains(" calcopirita ")) continue
                if (p == "ley" && !q.contains(" ley ")) continue
                return normalizeProtected(p)
            }
        }

        return ""
    }

    private fun normalizeProtected(phrase: String): String {
        return when (phrase) {
            "escala de mosh" -> "escala de mohs"
            "calco pirita" -> "calcopirita"
            "antapacay" -> "antapaccay"
            "logeo geologico" -> "logueo geologico"
            "tipos de rocas" -> "tipos de roca"
            else -> phrase
        }
    }

    private fun intentScore(question: String, meta: String): Int {
        var score = 0

        if ((question.contains("ejemplo") || question.contains("menciona")) &&
            (meta.contains("ejemplo") || meta.contains("ejemplos"))) score += 180

        if ((question.contains("caracteristica") || question.contains("propiedad")) &&
            (meta.contains("caracteristica") || meta.contains("propiedad"))) score += 120

        if ((question.contains("importancia") || question.contains("importante")) &&
            meta.contains("importancia")) score += 120

        if ((question.contains("para que sirve") || question.contains("funcion") || question.contains("uso")) &&
            (meta.contains("sirve") || meta.contains("funcion") || meta.contains("uso"))) score += 120

        if ((question.contains("diferencia") || question.contains("diferenciar")) &&
            meta.contains("diferencia")) score += 120

        if ((question.contains("clasifica") || question.contains("clasificacion") || question.contains("clases")) &&
            meta.contains("clasificacion")) score += 120

        if ((question.contains("formula") || question.contains("simbolo") || question.contains("quimica")) &&
            (meta.contains("formula") || meta.contains("simbolo") || meta.contains("quimica"))) score += 120

        return score
    }

    private fun containsTerm(text: String, term: String): Boolean {
        if (term.length < 3) return false
        val paddedText = " $text "
        val paddedTerm = " $term "
        return paddedText.contains(paddedTerm) || text.contains(term)
    }

    private fun loadDataCached(): RepositoryData {
        val store = JsonKnowledgeStore(context)
        val cacheKey = store.cacheKey()
        synchronized(cacheLock) {
            cachedData?.let { cached ->
                if (cachedKey == cacheKey) return cached
            }
        }

        val items = loadItems()
        val built = RepositoryData(
            items = items,
            exactIndex = buildExactIndex(items),
            invertedIndex = buildInvertedIndex(items)
        )

        synchronized(cacheLock) {
            cachedKey = cacheKey
            cachedData = built
        }

        return built
    }

    private fun loadItems(): List<KnowledgeItem> {
        val store = JsonKnowledgeStore(context)
        val raw = store.readJson()
        val variantsMap = loadVariantsMap(store.readVariantsJson())
        if (raw.isBlank()) return emptyList()

        return try {
            val trimmed = raw.trim()
            val array = when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> {
                    val obj = JSONObject(trimmed)
                    obj.optJSONArray("temas")
                        ?: obj.optJSONArray("items")
                        ?: obj.optJSONArray("data")
                        ?: JSONArray()
                }
            }

            val result = mutableListOf<KnowledgeItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val tema = obj.optString("tema", obj.optString("categoria", "General")).trim()
                val titulo = obj.optString(
                    "titulo",
                    obj.optString("pregunta", obj.optString("nombre", tema))
                ).trim()
                val contenido = obj.optString(
                    "contenido",
                    obj.optString("respuesta", obj.optString("texto", obj.optString("descripcion", "")))
                ).trim()

                if (contenido.isBlank()) continue

                val id = obj.optString("id", "item_$i").ifBlank { "item_$i" }
                val keywords = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "palabrasClave") +
                    readStringArray(obj, "negativos") +
                    variantsMap[id].orEmpty() +
                    variantsMap[ResponseRepository.normalize(titulo)].orEmpty() +
                    variantsMap[ResponseRepository.normalize(tema)].orEmpty()

                val cleanKeywords = keywords
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()

                val normalizedId = ResponseRepository.normalize(id.replace("_", " "))
                val normalizedTema = ResponseRepository.normalize(tema)
                val normalizedTitulo = ResponseRepository.normalize(titulo)
                val normalizedContenido = ResponseRepository.normalize(contenido.take(1200))
                val normalizedKeywords = cleanKeywords
                    .map { ResponseRepository.normalize(it) }
                    .filter { it.length >= 3 }
                    .distinct()
                val meta = "$normalizedId $normalizedTema $normalizedTitulo ${normalizedKeywords.joinToString(" ")}"

                result.add(
                    KnowledgeItem(
                        id = id,
                        tema = tema.ifBlank { "General" },
                        titulo = titulo.ifBlank { tema.ifBlank { "Tema $i" } },
                        contenido = contenido,
                        keywords = cleanKeywords,
                        normalizedId = normalizedId,
                        normalizedTema = normalizedTema,
                        normalizedTitulo = normalizedTitulo,
                        normalizedContenido = normalizedContenido,
                        normalizedKeywords = normalizedKeywords,
                        meta = meta
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun loadVariantsMap(raw: String): Map<String, List<String>> {
        if (raw.isBlank()) return emptyMap()

        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("variantes")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }

            val result = linkedMapOf<String, MutableList<String>>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val key = obj.optString(
                    "id",
                    obj.optString("tema", obj.optString("titulo", obj.optString("pregunta", "")))
                ).trim()
                if (key.isBlank()) continue

                val values = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "palabrasClave")

                if (values.isNotEmpty()) {
                    val normalizedKey = ResponseRepository.normalize(key)
                    result.getOrPut(key) { mutableListOf() }.addAll(values)
                    result.getOrPut(normalizedKey) { mutableListOf() }.addAll(values)
                }
            }

            result.mapValues { it.value.distinct() }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun readStringArray(obj: JSONObject, key: String): List<String> {
        val arr = obj.optJSONArray(key) ?: return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val value = arr.optString(i).trim()
            if (value.isNotBlank()) list.add(value)
        }
        return list
    }

    private fun keyWords(text: String): List<String> {
        return text.split(" ")
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stopWords }
            .distinct()
            .take(12)
    }

    companion object {
        const val JSON_EMPTY = "No encontrado"
        const val JSON_NOT_FOUND = "No encontrado"

        private val cacheLock = Any()
        @Volatile private var cachedKey: String = ""
        @Volatile private var cachedData: RepositoryData? = null

        private val stopWords = setOf(
            "que", "qué", "q", "ke", "k", "es", "son", "ser", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuál", "cuales", "cuáles",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa",
            "internet", "net", "json", "tema", "sobre", "explica", "breve", "rapido", "rápido",
            "respuesta", "pregunta", "habla", "susurra"
        )

        private val vagueSingleWords = setOf(
            "tipo", "tipos", "clase", "clases", "tema", "pregunta", "respuesta", "ejemplo", "ejemplos"
        )
    }
}

class JsonKnowledgeStore(private val context: Context) {

    fun getUrl(): String {
        return prefs().getString(KEY_URL, "").orEmpty().trim()
    }

    fun saveUrl(url: String) {
        prefs().edit().putString(KEY_URL, url.trim()).apply()
    }

    fun getVariantsUrl(): String {
        return prefs().getString(KEY_VARIANTS_URL, "").orEmpty().trim()
    }

    fun saveVariantsUrl(url: String) {
        prefs().edit().putString(KEY_VARIANTS_URL, url.trim()).apply()
    }

    fun clearVariantsConfig() {
        prefs().edit().putString(KEY_VARIANTS_URL, "").apply()
        File(context.filesDir, VARIANTS_FILE).delete()
    }

    fun cacheKey(): String {
        val jsonFile = File(context.filesDir, JSON_FILE)
        val variantsFile = File(context.filesDir, VARIANTS_FILE)
        return listOf(
            jsonFile.length(),
            jsonFile.lastModified(),
            variantsFile.length(),
            variantsFile.lastModified()
        ).joinToString(":")
    }

    fun readJson(): String {
        val file = File(context.filesDir, JSON_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun hasJson(): Boolean {
        return readJson().isNotBlank()
    }

    fun readVariantsJson(): String {
        val file = File(context.filesDir, VARIANTS_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun downloadVariantsJson(): Pair<Boolean, String> {
        val url = getVariantsUrl()
        if (url.isBlank()) return true to "Sin JSON de variantes."
        return downloadToFile(url, VARIANTS_FILE, "Variantes JSON")
    }

    fun downloadJson(): Pair<Boolean, String> {
        val url = getUrl()
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }
        return downloadToFile(url, JSON_FILE, "Temas JSON")
    }

    private fun downloadToFile(url: String, fileName: String, label: String): Pair<Boolean, String> {
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }

        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.setRequestProperty("User-Agent", "GeoSusuAudio Android")
            connection.setRequestProperty("Accept", "application/json,text/plain,*/*")

            val raw = try {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally {
                connection.disconnect()
            }

            if (raw.isBlank()) return false to "$label descargado está vacío."

            val count = countItems(raw)
            if (count <= 0) return false to "$label no parece válido."

            File(context.filesDir, fileName).writeText(raw)
            true to "$label actualizado. Elementos: $count"
        } catch (_: Exception) {
            false to "No se pudo descargar $label. Revisa link o internet."
        }
    }

    private fun countItems(raw: String): Int {
        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("temas")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }
            array.length()
        } catch (_: Exception) {
            0
        }
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS = "geo_susu_json"
        private const val KEY_URL = "json_url"
        private const val KEY_VARIANTS_URL = "json_variants_url"
        private const val JSON_FILE = "temas_github.json"
        private const val VARIANTS_FILE = "variantes_github.json"
    }
}
