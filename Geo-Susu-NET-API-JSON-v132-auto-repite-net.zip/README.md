# Geo Susu JSON v132

Correccion v132:
- Un solo link JSON Raw, como la version fluida anterior.
- Modo JSON busca solo dentro del JSON cargado.
- Modo AUTO: primero JSON; si no encuentra, pasa a NET.
- La busqueda JSON ahora prioriza preguntas y variantes exactas antes de palabras sueltas.
- Se corrigio el caso "tipo de rocas" para que vaya a "tipos de roca" y no a una respuesta cercana como rocas igneas.
- Si el audio reconoce solo una palabra vaga como "tipo", no inventa respuesta.
- Cache del JSON para no reprocesar en cada pregunta.
- La respuesta encontrada se muestra en pantalla y tambien se lee por audio.
- APIs se mantienen como v125: agregar, editar, borrar y probar API.

No se toca escucha, sensibilidad, reduccion de ruido ni Bluetooth.


Cambio v132:
- Modo AUTO: si la primera vez responde desde JSON y repites la misma pregunta, la segunda vez pasa directo a NET.
- Modo JSON sigue usando solo JSON.
- Modo NET sigue usando solo API.
