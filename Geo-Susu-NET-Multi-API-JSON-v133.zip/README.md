# Geo Susu JSON v133 - NET Multi API

Cambio v133:
- NET ahora soporta 5 proveedores: Gemini, Groq, OpenRouter, Mistral y Cohere.
- Cada API guarda proveedor, clave, modelo y estado.
- Si una API llega a limite, error o espera temporal, NET cambia a otra API disponible.
- No se agregaron reintentos innecesarios por la misma API.
- Las claves antiguas de v132 se migran como Gemini automáticamente.

Se mantiene intacto:
- JSON primero.
- Busqueda fuzzy/variantes.
- Voz/susurro.
- Sensibilidad y escucha.
- Bluetooth.
- Modo AUTO: primero JSON; si no encuentra, NET.

Modelos recomendados por defecto:
- Gemini: gemini-2.5-flash
- Groq: llama-3.1-8b-instant
- OpenRouter: openrouter/free
- Mistral: mistral-small-latest
- Cohere: command-r7b-12-2024
