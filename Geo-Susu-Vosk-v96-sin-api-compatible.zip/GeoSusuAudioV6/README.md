# Geo Susu Vosk v96 - sin API, compatible

## Qué es
Versión sin API key y sin servicios externos de transcripción.
Usa Vosk offline porque es el motor compatible que sí puede funcionar sin Google y sin API.

## Incluye
- Vosk offline como escuchador.
- Descarga del modelo con DESCARGAR OFFLINE.
- TXT en blanco.
- Variantes en blanco.
- TXT guardado como archivo interno para soportar más texto.
- NET tipo navegador: busca, abre resultados, lee texto y responde con voz.
- Sin Google.
- Sin Whisper.
- Sin API key.
- Sin mostrar sobre otras apps.
- Sin accesibilidad automática.

## Importante
Sin API y sin Google, el mejor motor compatible disponible aquí es Vosk.
Para susurros no será perfecto, pero es lo que puede instalar y funcionar en tu celular.
