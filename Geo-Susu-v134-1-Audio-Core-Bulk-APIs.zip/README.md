Geo Susu v134.1 - Audio Core USB-C + Pegado Rapido de APIs

Cambios principales:
- Mantiene v134 Audio Core: modo Susurro USB-C, normalizador tecnico y NET seguro.
- Agrega pegado rapido de APIs por proveedor.

Uso del pegado rapido:
1. Abrir API.
2. En Pegado rapido por proveedor elegir Gemini, Groq, OpenRouter, Mistral o Cohere.
3. Revisar o dejar el modelo recomendado.
4. Pegar varias claves, una por linea.
5. Tocar IMPORTAR LISTA.
6. Tocar PROBAR API o GUARDAR.

Formatos aceptados:
clave_1
clave_2
clave_3

Tambien acepta:
1. clave_1
2) clave_2
API 1: clave_3

La app elimina duplicados por proveedor + clave + modelo.
