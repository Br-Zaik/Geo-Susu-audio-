package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class OnlineAnswerProvider(private val context: Context? = null) {

    private data class NetCallResult(
        val ok: Boolean,
        val text: String,
        val error: String,
        val provider: NetProvider,
        val model: String,
        val canTryNextApi: Boolean = false,
        val failureType: FailureType = FailureType.NONE
    )

    private enum class FailureType {
        NONE, LIMIT_DAILY, LIMIT_MINUTE, LIMIT_UNKNOWN, INVALID, TEMPORARY, NETWORK, OTHER
    }

    fun fetchShortAnswer(rawQuery: String): String {
        val query = cleanQuery(rawQuery)
        if (query.length < 2) return "Pregunta muy corta. Repite la palabra completa."

        val settings = context?.let { GeminiSettings(it) }
        val configs = settings?.getApiConfigs().orEmpty()
        if (configs.isEmpty()) {
            return "Sin API configurada. Toca API, agrega Gemini, Groq, OpenRouter, Mistral o Cohere y prueba si funciona."
        }

        val baseOrder = orderedConfigs(configs, settings?.getLastGoodIndex() ?: 0)
        val available = baseOrder.filter { (_, config) -> settings?.shouldSkip(config) != true }
        if (available.isEmpty()) {
            return "No hay API disponible ahora. Hay claves en limite, espera temporal o error. Usa JSON o agrega otra API."
        }

        var lastError = ""
        var dailyLimitHit = false
        var minuteLimitHit = false
        var unknownLimitHit = false
        var invalidHit = false
        var waitHit = false

        for ((originalIndex, config) in available) {
            val cleanConfig = config.clean(originalIndex)
            val formatError = getApiConfigError(cleanConfig)
            if (formatError != null) {
                invalidHit = true
                lastError = "${cleanConfig.name}: $formatError"
                settings?.markError(cleanConfig, formatError)
                continue
            }

            val result = askProvider(cleanConfig, query)
            if (result.ok && result.text.isNotBlank()) {
                settings?.saveLastGoodIndex(originalIndex)
                settings?.markReady(cleanConfig)
                return result.text
            }

            lastError = result.error
            when (result.failureType) {
                FailureType.LIMIT_DAILY -> {
                    dailyLimitHit = true
                    settings?.markLimit(cleanConfig, result.error.ifBlank { "Llego al limite diario o sin creditos." })
                }
                FailureType.LIMIT_MINUTE -> {
                    minuteLimitHit = true
                    settings?.markMinuteLimit(cleanConfig, result.error.ifBlank { "Limite por minuto. Espera unos minutos." })
                }
                FailureType.LIMIT_UNKNOWN -> {
                    unknownLimitHit = true
                    settings?.markUnknownLimit(cleanConfig, result.error.ifBlank { "Limite temporal. Espera o usa otra API." })
                }
                FailureType.INVALID -> {
                    invalidHit = true
                    settings?.markError(cleanConfig, result.error.ifBlank { "API invalida, modelo incorrecto o sin permiso." })
                }
                FailureType.TEMPORARY -> {
                    waitHit = true
                    settings?.markWait(cleanConfig, result.error.ifBlank { "Error temporal del servidor." })
                }
                FailureType.NETWORK -> {
                    return result.error.ifBlank { "Conexion inestable. Revisa internet y vuelve a intentar." }
                }
                FailureType.OTHER -> {
                    waitHit = true
                    settings?.markWait(cleanConfig, result.error.ifBlank { "Respuesta NET no util." })
                }
                else -> Unit
            }

            if (!result.canTryNextApi) break
        }

        return when {
            dailyLimitHit && !minuteLimitHit && !unknownLimitHit && !invalidHit && !waitHit -> "Las API disponibles llegaron a limite diario o sin creditos. Agrega otra API o usa JSON."
            minuteLimitHit && !dailyLimitHit && !unknownLimitHit && !invalidHit && !waitHit -> "Limite por minuto. Esa API queda en espera 10 minutos; prueba otra API o espera."
            unknownLimitHit && !dailyLimitHit && !minuteLimitHit && !invalidHit && !waitHit -> "Limite temporal de API. Queda en espera 1 hora para no insistir."
            invalidHit && !dailyLimitHit && !minuteLimitHit && !unknownLimitHit && !waitHit -> "Una o mas API no se pueden usar. Revisa proveedor, modelo, clave o agrega otra valida."
            waitHit && !dailyLimitHit && !minuteLimitHit && !unknownLimitHit && !invalidHit -> "API en espera temporal. Vuelve a intentar en unos minutos o agrega otra API."
            lastError.isNotBlank() -> lastError
            else -> "NET no devolvio respuesta. Revisa API, proveedor, modelo, internet o limite de uso."
        }
    }

    fun testApiKey(apiKey: String): Pair<Boolean, String> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) return false to "Pega primero tu API Key."
        val config = NetApiConfig("API 1", NetProvider.GEMINI, cleanKey, NetProvider.GEMINI.defaultModel)
        return testOneConfig(config)
    }

    fun testApiKeys(apiKeys: List<String>): Pair<Boolean, String> {
        val configs = apiKeys.mapIndexed { index, key ->
            NetApiConfig("API ${index + 1}", NetProvider.GEMINI, key, NetProvider.GEMINI.defaultModel)
        }
        return testApiConfigs(configs)
    }

    fun testApiConfigs(apiConfigs: List<NetApiConfig>): Pair<Boolean, String> {
        val cleanConfigs = apiConfigs
            .mapIndexed { index, config -> config.clean(index) }
            .filter { it.apiKey.isNotBlank() }
            .distinctBy { "${it.provider.id}|${it.apiKey}|${it.model}" }

        if (cleanConfigs.isEmpty()) return false to "Agrega por lo menos una API Key."

        val settings = context?.let { GeminiSettings(it) }
        var firstGoodIndex = -1
        var okCount = 0
        var networkCount = 0
        val lines = mutableListOf<String>()

        for ((index, config) in cleanConfigs.withIndex()) {
            val formatError = getApiConfigError(config)
            if (formatError != null) {
                settings?.markError(config, formatError)
                lines.add("${config.name} (${config.provider.label}): ERROR - $formatError")
                continue
            }

            val result = askProvider(config, "Responde solo: API funcionando", testing = true)
            if (result.ok && result.text.isNotBlank()) {
                okCount += 1
                if (firstGoodIndex < 0) firstGoodIndex = index
                settings?.markReady(config)
                lines.add("${config.name} (${config.provider.label}): OK - funcionando")
                continue
            }

            when (result.failureType) {
                FailureType.LIMIT_DAILY -> {
                    settings?.markLimit(config, result.error)
                    lines.add("${config.name} (${config.provider.label}): LIMITE / SIN CREDITOS")
                }
                FailureType.LIMIT_MINUTE -> {
                    settings?.markMinuteLimit(config, result.error)
                    lines.add("${config.name} (${config.provider.label}): EN ESPERA - limite por minuto")
                }
                FailureType.LIMIT_UNKNOWN -> {
                    settings?.markUnknownLimit(config, result.error)
                    lines.add("${config.name} (${config.provider.label}): EN ESPERA - limite temporal")
                }
                FailureType.INVALID -> {
                    settings?.markError(config, result.error.ifBlank { "API invalida, modelo incorrecto o sin permiso." })
                    lines.add("${config.name} (${config.provider.label}): ERROR - ${result.error.ifBlank { "API invalida o modelo incorrecto" }}")
                }
                FailureType.TEMPORARY -> {
                    settings?.markWait(config, result.error.ifBlank { "Error temporal del servidor." })
                    lines.add("${config.name} (${config.provider.label}): EN ESPERA - error temporal")
                }
                FailureType.NETWORK -> {
                    networkCount += 1
                    lines.add("${config.name} (${config.provider.label}): NO PROBADA - ${result.error.ifBlank { "conexion inestable" }}")
                }
                else -> {
                    settings?.markWait(config, result.error.ifBlank { "No se puede usar esta API ahora." })
                    lines.add("${config.name} (${config.provider.label}): EN ESPERA - ${result.error.ifBlank { "sin respuesta util" }}")
                }
            }
        }

        if (firstGoodIndex >= 0) {
            settings?.saveLastGoodIndex(firstGoodIndex)
        }

        val report = settings?.getStatusReportForConfigs(cleanConfigs).orEmpty()
        val header = when {
            okCount > 0 -> "Listo: $okCount API funcionando."
            networkCount == cleanConfigs.size -> "No se pudo probar por conexion inestable. Las APIs no se marcaron como malas."
            else -> "No hay API funcionando. Revisa las marcadas como ERROR/LIMITE o agrega otra."
        }

        val message = listOf(header, lines.joinToString("\n"), report)
            .filter { it.isNotBlank() }
            .joinToString("\n\n")
        return (okCount > 0) to message
    }

    private fun testOneConfig(config: NetApiConfig): Pair<Boolean, String> {
        val clean = config.clean(0)
        val formatError = getApiConfigError(clean)
        if (formatError != null) return false to formatError
        val result = askProvider(clean, "Responde solo: API funcionando", testing = true)
        return if (result.ok && result.text.isNotBlank()) {
            true to "API funcionando correctamente."
        } else {
            false to result.error.ifBlank { "No se pudo probar la API. Revisa clave, proveedor, modelo o internet." }
        }
    }

    private fun getApiConfigError(config: NetApiConfig): String? {
        val key = config.apiKey.trim()
        if (key.isBlank()) return "API vacia."
        if (key.length < 8) return "API demasiado corta o mal copiada."
        if (key.any { it.isWhitespace() }) return "API con espacios. Pegala completa sin espacios."
        if (!key.matches(Regex("^[A-Za-z0-9_\\-.]+$"))) return "API con caracteres no validos."
        if (config.model.isBlank()) return "Modelo vacio. Escribe el modelo o usa el recomendado."
        if (config.model.any { it.isWhitespace() }) return "Modelo con espacios. Copia el nombre exacto del modelo."
        return null
    }

    private fun askProvider(config: NetApiConfig, question: String, testing: Boolean = false): NetCallResult {
        return when (config.provider) {
            NetProvider.GEMINI -> callGemini(config, question, testing)
            NetProvider.GROQ -> callOpenAiCompatible(
                config = config,
                endpoint = "https://api.groq.com/openai/v1/chat/completions",
                question = question,
                testing = testing
            )
            NetProvider.OPENROUTER -> callOpenAiCompatible(
                config = config,
                endpoint = "https://openrouter.ai/api/v1/chat/completions",
                question = question,
                testing = testing,
                extraHeaders = mapOf(
                    "HTTP-Referer" to "https://geosusu.local",
                    "X-Title" to "Geo Susu JSON"
                )
            )
            NetProvider.MISTRAL -> callOpenAiCompatible(
                config = config,
                endpoint = "https://api.mistral.ai/v1/chat/completions",
                question = question,
                testing = testing
            )
            NetProvider.COHERE -> callCohere(config, question, testing)
        }
    }

    private fun callGemini(config: NetApiConfig, question: String, testing: Boolean): NetCallResult {
        var connection: HttpURLConnection? = null
        val model = config.model.ifBlank { config.provider.defaultModel }

        return try {
            val encodedKey = URLEncoder.encode(config.apiKey, "UTF-8")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            )

            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GeoSusuJSON/133")
            }

            val body = buildGeminiBody(question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                return parseProviderError(raw, code, config.provider, model)
            }

            val answer = parseGeminiText(raw)
            if (answer.isBlank()) {
                NetCallResult(false, "", "${config.provider.label} respondio vacio. API en espera temporal.", config.provider, model, true, FailureType.TEMPORARY)
            } else {
                NetCallResult(true, answer, "", config.provider, model)
            }
        } catch (e: Exception) {
            networkResult(e, config.provider, model)
        } finally {
            connection?.disconnect()
        }
    }

    private fun callOpenAiCompatible(
        config: NetApiConfig,
        endpoint: String,
        question: String,
        testing: Boolean,
        extraHeaders: Map<String, String> = emptyMap()
    ): NetCallResult {
        var connection: HttpURLConnection? = null
        val model = config.model.ifBlank { config.provider.defaultModel }

        return try {
            val url = URL(endpoint)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GeoSusuJSON/133")
                extraHeaders.forEach { (key, value) -> setRequestProperty(key, value) }
            }

            val body = buildChatBody(model, question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                return parseProviderError(raw, code, config.provider, model)
            }

            val answer = parseChatCompletionsText(raw)
            if (answer.isBlank()) {
                NetCallResult(false, "", "${config.provider.label} respondio vacio. API en espera temporal.", config.provider, model, true, FailureType.TEMPORARY)
            } else {
                NetCallResult(true, answer, "", config.provider, model)
            }
        } catch (e: Exception) {
            networkResult(e, config.provider, model)
        } finally {
            connection?.disconnect()
        }
    }

    private fun callCohere(config: NetApiConfig, question: String, testing: Boolean): NetCallResult {
        var connection: HttpURLConnection? = null
        val model = config.model.ifBlank { config.provider.defaultModel }

        return try {
            val url = URL("https://api.cohere.com/v2/chat")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GeoSusuJSON/133")
            }

            val body = buildCohereBody(model, question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                return parseProviderError(raw, code, config.provider, model)
            }

            val answer = parseCohereText(raw)
            if (answer.isBlank()) {
                NetCallResult(false, "", "${config.provider.label} respondio vacio. API en espera temporal.", config.provider, model, true, FailureType.TEMPORARY)
            } else {
                NetCallResult(true, answer, "", config.provider, model)
            }
        } catch (e: Exception) {
            networkResult(e, config.provider, model)
        } finally {
            connection?.disconnect()
        }
    }

    private fun buildGeminiBody(question: String, testing: Boolean): JSONObject {
        return JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", buildPrompt(question, testing)))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("maxOutputTokens", if (testing) 64 else 160)
                    put("temperature", if (testing) 0.0 else 0.2)
                }
            )
        }
    }

    private fun buildChatBody(model: String, question: String, testing: Boolean): JSONObject {
        return JSONObject().apply {
            put("model", model)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", buildSystemRules(testing)))
                    .put(JSONObject().put("role", "user").put("content", if (testing) question else cleanQuery(question)))
            )
            put("temperature", if (testing) 0.0 else 0.2)
            put("max_tokens", if (testing) 64 else 160)
            put("stream", false)
        }
    }

    private fun buildCohereBody(model: String, question: String, testing: Boolean): JSONObject {
        return JSONObject().apply {
            put("model", model)
            put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", buildPrompt(question, testing))
                )
            )
            put("temperature", if (testing) 0.0 else 0.2)
            put("max_tokens", if (testing) 64 else 160)
        }
    }

    private fun buildPrompt(question: String, testing: Boolean): String {
        if (testing) return question
        return "${buildSystemRules(false)}\n\nPregunta: ${cleanQuery(question)}"
    }

    private fun buildSystemRules(testing: Boolean): String {
        if (testing) return "Responde solo: API funcionando"
        return """
            Responde siempre en español con el texto mínimo útil. Contexto principal: minería, topografía, nivelación, cotas, BM, CP, VA, VI, VF, AI, levantamiento y replanteo.

            Reglas obligatorias:
            1. Entrega SOLO la respuesta final.
            2. No incluyas análisis, razonamiento interno, pasos, reglas ni explicación del proceso.
            3. Si preguntan fórmula química o símbolo químico, responde solo la fórmula o símbolo. Ejemplo: oro -> Au.
            4. Si preguntan tipos, clases, división, clasificación, lista, minerales o dicen "todos", responde solo los nombres principales separados por coma. No expliques.
            5. Si preguntan "qué es", responde una sola oración corta.
            6. No saludes, no digas "soy", no uses Markdown y no termines con frases incompletas.
            7. Responde máximo en una línea o una oración corta, salvo listas de nombres.
            8. Si la pregunta parece reconocimiento imperfecto, interprétala dentro del contexto técnico indicado y no respondas en inglés.
        """.trimIndent()
    }

    private fun parseGeminiText(raw: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        val partsText = StringBuilder()
        var finishReason = ""

        for (i in 0 until candidates.length()) {
            val candidate = candidates.optJSONObject(i) ?: continue
            finishReason = candidate.optString("finishReason").orEmpty()
            val content = candidate.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue

            for (j in 0 until parts.length()) {
                val text = parts.optJSONObject(j)?.optString("text").orEmpty().trim()
                appendCleanPart(partsText, text)
            }

            if (partsText.isNotBlank()) break
        }

        val clean = cleanAnswer(partsText.toString())
        return if (finishReason == "MAX_TOKENS" && clean.isNotBlank() && clean.last() !in listOf('.', '!', '?')) {
            "$clean..."
        } else {
            clean
        }
    }

    private fun parseChatCompletionsText(raw: String): String {
        val obj = JSONObject(raw)
        val choices = obj.optJSONArray("choices") ?: return ""
        val partsText = StringBuilder()
        var finishReason = ""

        for (i in 0 until choices.length()) {
            val choice = choices.optJSONObject(i) ?: continue
            finishReason = choice.optString("finish_reason", choice.optString("finishReason"))
            val message = choice.optJSONObject("message") ?: choice.optJSONObject("delta") ?: continue
            val contentValue = message.opt("content") ?: continue
            appendJsonContent(partsText, contentValue)
            if (partsText.isNotBlank()) break
        }

        val clean = cleanAnswer(partsText.toString())
        return if ((finishReason == "length" || finishReason == "MAX_TOKENS") && clean.isNotBlank() && clean.last() !in listOf('.', '!', '?')) {
            "$clean..."
        } else {
            clean
        }
    }

    private fun parseCohereText(raw: String): String {
        val obj = JSONObject(raw)
        val partsText = StringBuilder()
        val message = obj.optJSONObject("message")
        val contentValue = message?.opt("content") ?: obj.opt("text") ?: return ""
        appendJsonContent(partsText, contentValue)
        return cleanAnswer(partsText.toString())
    }

    private fun appendJsonContent(builder: StringBuilder, value: Any) {
        when (value) {
            is String -> appendCleanPart(builder, value.trim())
            is JSONArray -> {
                for (i in 0 until value.length()) {
                    val item = value.opt(i)
                    when (item) {
                        is String -> appendCleanPart(builder, item.trim())
                        is JSONObject -> appendCleanPart(
                            builder,
                            item.optString("text", item.optString("content")).trim()
                        )
                    }
                }
            }
            is JSONObject -> appendCleanPart(builder, value.optString("text", value.optString("content")).trim())
        }
    }

    private fun appendCleanPart(builder: StringBuilder, text: String) {
        if (text.isBlank()) return
        if (builder.isNotBlank()) {
            val current = builder.toString().trimEnd()
            val firstChar = text.firstOrNull()
            val joinsDirectly = current.endsWith(":") ||
                current.endsWith("-") ||
                firstChar == ',' ||
                firstChar == '.' ||
                firstChar == ';' ||
                firstChar == ':'
            builder.append(if (joinsDirectly) "" else " ")
        }
        builder.append(text)
    }

    private fun parseProviderError(raw: String, httpCode: Int, provider: NetProvider, model: String): NetCallResult {
        val message = extractErrorMessage(raw)
        val lower = "$message $raw".lowercase()

        return when {
            httpCode == 401 || httpCode == 403 ||
                lower.contains("api key") || lower.contains("invalid key") ||
                lower.contains("unauthorized") || lower.contains("unauthenticated") ||
                lower.contains("permission_denied") || lower.contains("permission denied") ||
                lower.contains("forbidden") ->
                NetCallResult(false, "", "${provider.label}: API Key invalida o sin permiso.", provider, model, true, FailureType.INVALID)

            lower.contains("model_not_found") || lower.contains("model not found") ||
                lower.contains("invalid model") || lower.contains("does not exist") ||
                lower.contains("not a valid model") ->
                NetCallResult(false, "", "${provider.label}: modelo incorrecto o no disponible: $model", provider, model, true, FailureType.INVALID)

            lower.contains("per day") || lower.contains("perday") ||
                lower.contains("requestsperday") || lower.contains("rpd") ||
                lower.contains("daily") || lower.contains("insufficient credits") ||
                lower.contains("credit balance") || lower.contains("no credits") ->
                NetCallResult(false, "", "${provider.label}: limite diario o sin creditos. Se cambia a otra API.", provider, model, true, FailureType.LIMIT_DAILY)

            lower.contains("per minute") || lower.contains("perminute") ||
                lower.contains("requestsperminute") || lower.contains("tokensperminute") ||
                lower.contains("rpm") || lower.contains("tpm") ->
                NetCallResult(false, "", "${provider.label}: limite por minuto. Se cambia a otra API.", provider, model, true, FailureType.LIMIT_MINUTE)

            httpCode == 429 || lower.contains("quota") || lower.contains("rate limit") ||
                lower.contains("ratelimit") || lower.contains("too many requests") ||
                lower.contains("resource_exhausted") || lower.contains("limit") ->
                NetCallResult(false, "", "${provider.label}: limite temporal. Se cambia a otra API.", provider, model, true, FailureType.LIMIT_UNKNOWN)

            httpCode in 500..599 ->
                NetCallResult(false, "", "${provider.label}: servidor ocupado. Se cambia a otra API.", provider, model, true, FailureType.TEMPORARY)

            message.isNotBlank() ->
                NetCallResult(false, "", "${provider.label}: ${message.take(220)}", provider, model, true, FailureType.OTHER)

            else -> NetCallResult(false, "", "${provider.label}: error de API. Revisa clave, modelo o internet.", provider, model, true, FailureType.OTHER)
        }
    }

    private fun extractErrorMessage(raw: String): String {
        return try {
            val obj = JSONObject(raw)
            val error = obj.opt("error")
            when (error) {
                is JSONObject -> error.optString("message", error.optString("error", error.toString()))
                is String -> error
                else -> obj.optString("message", obj.optString("detail", raw.take(260)))
            }.trim()
        } catch (_: Exception) {
            raw.take(260).trim()
        }
    }

    private fun networkResult(e: Exception, provider: NetProvider, model: String): NetCallResult {
        val msg = (e.message ?: "error de conexion").lowercase()
        val cleanMessage = when {
            msg.contains("reset") -> "Conexion inestable. Revisa internet y vuelve a intentar."
            msg.contains("timeout") || msg.contains("timed out") -> "La conexion demoro demasiado. Revisa internet y vuelve a intentar."
            msg.contains("unable to resolve") || msg.contains("failed to connect") -> "Sin conexion estable a internet. Revisa datos o Wi-Fi."
            else -> "No se pudo conectar con la API. Revisa internet y vuelve a intentar."
        }
        return NetCallResult(false, "", cleanMessage, provider, model, false, FailureType.NETWORK)
    }

    private fun orderedConfigs(configs: List<NetApiConfig>, startIndex: Int): List<Pair<Int, NetApiConfig>> {
        if (configs.isEmpty()) return emptyList()
        val safeStart = startIndex.coerceIn(0, configs.size - 1)
        return configs.indices.map { offset ->
            val index = (safeStart + offset) % configs.size
            index to configs[index]
        }
    }

    private fun cleanQuery(raw: String): String {
        return raw.replace("\\s+".toRegex(), " ").trim()
    }

    private fun cleanAnswer(raw: String): String {
        var candidate = raw
            .replace("**", "")
            .replace("```", "")
            .trim()

        candidate = removeReasoningLeak(candidate)
            .replace("\\s+".toRegex(), " ")
            .trim()

        candidate = candidate
            .replace(Regex("^(Respuesta final|Respuesta|Final)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("^(Rpta|Resp)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .trim()

        if (candidate.contains("THOUGHT:", ignoreCase = true) ||
            candidate.contains("REASONING:", ignoreCase = true) ||
            candidate.contains("ANALYSIS:", ignoreCase = true)
        ) {
            candidate = removeReasoningLeak(candidate).trim()
        }

        if (candidate.length <= 2000) return candidate
        return candidate.take(2000).trim()
    }

    private fun removeReasoningLeak(raw: String): String {
        val markers = listOf(
            "THOUGHT:",
            "Thought:",
            "REASONING:",
            "Reasoning:",
            "ANALYSIS:",
            "Analysis:",
            "PENSAMIENTO:",
            "RAZONAMIENTO:"
        )
        if (markers.none { raw.contains(it) }) return raw

        val sentences = raw
            .replace("\n", " ")
            .split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val cleanSentence = sentences.asReversed().firstOrNull { sentence ->
            isLikelyFinalAnswer(sentence)
        }
        if (!cleanSentence.isNullOrBlank()) return cleanSentence

        val lines = raw.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val cleanLine = lines.asReversed().firstOrNull { line ->
            isLikelyFinalAnswer(line)
        }
        if (!cleanLine.isNullOrBlank()) return cleanLine

        return "NET devolvio texto interno. Repite la pregunta."
    }

    private fun isLikelyFinalAnswer(text: String): Boolean {
        val lower = text.lowercase()
        if (text.length < 2) return false
        if (lower.contains("thought:") || lower.contains("reasoning:") || lower.contains("analysis:")) return false
        if (lower.contains("the user") || lower.contains("rule #") || lower.contains("i need") || lower.contains("falls under")) return false
        if (lower.contains("pregunta:") || lower.contains("regla") || lower.contains("responde solo")) return false
        return true
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 12000
        private const val READ_TIMEOUT_MS = 30000
    }
}
