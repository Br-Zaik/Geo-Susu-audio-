# Geo Susu v134.5 - Prueba de reconocimiento de susurro

Esta build NO agrega JSON ni APIs.

Objetivo:
- Probar si el micrófono USB-C + susurro + ruido bajo se transcribe bien.
- Mostrar en pantalla el texto bruto y el texto corregido.
- No buscar en JSON.
- No mandar a NET.

Uso:
1. Instala la APK.
2. Conecta micrófono USB-C.
3. Conecta audífonos Bluetooth solo para salida.
4. Motor recomendado: Susurro Google.
5. Toca ESCUCHAR.
6. Susurra una pregunta completa.
7. Revisa "Pregunta" y el bloque "Escuchado / Corregido".

Si escribe mal la pregunta, el problema todavía está en reconocimiento.
Si la escribe bien, recién se vuelve a activar JSON/NET en otra build.
