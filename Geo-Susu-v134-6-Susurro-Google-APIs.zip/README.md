# Geo Susu v134.6 - Susurro Google + JSON/NET APIs

Esta build vuelve a activar el flujo real después de probar reconocimiento.

Objetivo:
- Usar Susurro Google para reconocer mejor la pregunta completa.
- Escribir la pregunta corregida en pantalla.
- Buscar primero en JSON según el modo elegido.
- En AUTO, si JSON no encuentra, usar NET con las APIs guardadas.
- En NET, usar directamente las APIs guardadas.

Uso recomendado:
1. Motor de escucha: Susurro Google recomendado.
2. Modo: AUTO para uso normal.
3. Para probar APIs directamente: Modo NET.
4. Pregunta con micrófono USB-C cerca de la boca.

Notas:
- No responde con resultados parciales.
- Si la transcripción queda insegura, bloquea NET y pide repetir.
- El pegado rápido de APIs sigue disponible.
