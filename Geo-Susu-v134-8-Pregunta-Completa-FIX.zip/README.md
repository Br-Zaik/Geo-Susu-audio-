Geo Susu v134.8 - Pregunta completa sin recortar

Cambios:
- No agrega palabras ocultas a la pregunta corregida.
- Elige la frase completa reconocida, no una palabra clave suelta.
- Evita que respuestas genéricas como topografía ganen cuando la pregunta tiene otro término específico.
- Mantiene JSON, NET, AUTO y Susurro Google.
