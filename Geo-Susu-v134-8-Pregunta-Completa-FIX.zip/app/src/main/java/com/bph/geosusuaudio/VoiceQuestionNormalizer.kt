package com.bph.geosusuaudio

object VoiceQuestionNormalizer {

    private val technicalContextWords = setOf(
        "topografia", "topografico", "nivelacion", "nivel", "cota", "cotas", "altura",
        "terreno", "levantamiento", "replanteo", "banco", "instrumento", "mira", "vista"
    )

    private val weakNoiseWords = setOf(
        "ruido", "musica", "ingles", "english", "hola", "eh", "ah", "mmm", "este", "esto",
        "cosa", "cosas", "algo", "alguien", "gente"
    )

    private val stopWords = setOf(
        "que", "q", "ke", "es", "son", "un", "una", "el", "la", "los", "las", "de", "del",
        "en", "por", "para", "dime", "di", "define", "definicion", "concepto", "significa",
        "explica", "sobre", "pregunta", "oye"
    )

    fun normalize(raw: String): String {
        var q = ResponseRepository.normalize(raw)
        if (q.isBlank()) return ""

        q = q.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()

        val hasContext = hasTechnicalContext(q)

        val phraseCorrections = linkedMapOf(
            "be eme" to "bm",
            "ve eme" to "bm",
            "bi em" to "bm",
            "bee em" to "bm",
            "be me" to "bm",
            "b m" to "bm",
            "banco nivel" to "banco de nivel",
            "banco del nivel" to "banco de nivel",
            "cuota" to "cota",
            "cuotas" to "cotas",
            "ce pe" to "cp",
            "c p" to "cp",
            "ve a" to "va",
            "v a" to "va",
            "ve i" to "vi",
            "v i" to "vi",
            "ve efe" to "vf",
            "v f" to "vf",
            "a i" to "ai",
            "altura instrumental" to "altura de instrumento",
            "altura del instrumento" to "altura de instrumento",
            "vista final" to "vista adelante",
            "lectura final" to "vista adelante",
            "vista atras" to "vista atras",
            "mieria" to "mineria",
            "miniria" to "mineria",
            "menerea" to "mineria",
            "meneria" to "mineria",
            "topo grafia" to "topografia",
            "topogafia" to "topografia",
            "topografia superfacial" to "topografia superficial"
        )

        for ((bad, good) in phraseCorrections) {
            q = q.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }

        if (hasContext || q.contains("banco") || q.contains("nivel")) {
            val bmLike = listOf("bebe", "bebé", "pm", "p m", "bm.", "beme")
            for (bad in bmLike) {
                q = q.replace("\\b${Regex.escape(ResponseRepository.normalize(bad))}\\b".toRegex(), "bm")
            }
        }

        // Devuelve la pregunta completa corregida, sin agregar palabras ocultas.
        // La app debe responder a lo que el usuario preguntó, no a una palabra clave añadida.
        q = q.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()
        return q
    }

    fun isTooUnclearForJsonOrNet(question: String): Boolean {
        val q = normalize(question)
        if (q.isBlank()) return true
        val words = q.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }
        if (content.isEmpty()) return true

        if (content.size == 1) {
            val w = content.first()
            if (w in setOf("topografia", "mineria", "terreno", "ruido", "pregunta")) return true
            if (w.length <= 2 && w !in setOf("bm", "cp", "va", "vi", "vf", "ai")) return true
        }

        val noiseHits = words.count { it in weakNoiseWords }
        return noiseHits >= 2 && !hasTechnicalContext(q)
    }

    fun isUnsafeForNet(question: String): Boolean {
        val q = normalize(question)
        if (isTooUnclearForJsonOrNet(q)) return true

        // NET debe aceptar preguntas claras aunque tengan una sola palabra importante.
        // Ejemplo: "que es cateo" tiene un solo contenido (cateo), pero es una pregunta válida.
        // El bloqueo fuerte se deja solo para texto vacío, ruido o frases sin sentido.
        return false
    }

    private fun hasTechnicalContext(q: String): Boolean {
        val words = q.split(" ").filter { it.isNotBlank() }.toSet()
        return words.any { it in technicalContextWords } ||
            q.contains("banco de nivel") ||
            q.contains("vista atras") ||
            q.contains("vista adelante") ||
            q.contains("vista intermedia") ||
            q.contains("altura de instrumento")
    }

    private fun strengthenTechnicalIntent(input: String): String {
        return input.replace("\\s+".toRegex(), " ").trim()
    }
}