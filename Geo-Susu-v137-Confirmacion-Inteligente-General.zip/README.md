# Geo Susu v137 - Confirmacion inteligente general

Cambios principales:

- La confirmacion ya no queda limitada a BM.
- Si la pregunta es dudosa, corta, rara o parece mal reconocida, la app pregunta primero:
  - "Quisiste decir ...?"
- Luego escucha solo confirmacion por 3 segundos:
  - "si" -> recien procesa la pregunta.
  - "no" -> pide repetir.
  - silencio -> pide repetir.
- BM sigue protegido con correcciones como baby, bebe, barbie, beme, pm.
- Se agrego correccion aproximada para terminos tecnicos cortos. Ejemplo:
  - "que es gateo" puede confirmar "cateo" antes de enviar a JSON o NET.
- Se agregaron frases de sesgo de reconocimiento para mineria/geologia:
  - cateo, prospeccion, exploracion, explotacion, yacimiento, mineral, roca, mena, ganga, veta, manto, IPERC, EPP, ATS, PETS, etc.
- Se mantiene:
  - pregunta completa,
  - AUTO = JSON primero,
  - NET/API solo cuando corresponde,
  - limpieza de respuestas largas o internas de NET.

Pruebas recomendadas:

1. Modo NET sin JSON: decir "que es cateo" con poco ruido.
2. Decir "que es BM" con ruido. Si reconoce baby/bebe/barbie, debe preguntar por BM.
3. Decir mal "que es gateo". Debe intentar confirmar cateo.
4. Si dices "si", responde. Si dices "no" o callas 3 segundos, pide repetir.
