Geo Susu v138 - NET sin respuestas cortadas

Cambios principales:
- Corrige respuestas NET cortadas como "Exploración..." o "Un BM es un...".
- Sube el límite de salida NET/API de 80 a 220 tokens para evitar cortes por MAX_TOKENS.
- Si aun así la API devuelve una respuesta incompleta, la app ya no agrega puntos suspensivos ni lee basura incompleta; devuelve "No entendí bien. Repite la pregunta.".
- Mantiene respuestas cortas limpiando la primera oración y limitando a 32 palabras.
- Para Gemini 2.5 intenta desactivar pensamiento interno con thinkingBudget 0 para respuestas más rápidas y directas.
- No cambia JSON primero en AUTO ni la lógica de variantes/fuzzy.
- Mantiene confirmación inteligente de v137.

Pruebas recomendadas:
1. Modo NET, pregunta: "qué es cateo". Debe responder una oración completa, no "Exploración...".
2. Modo NET, pregunta: "qué es BM". Debe responder completo, no "Un BM es un...".
3. Pregunta dudosa con ruido. Si reconoce raro, debe confirmar o pedir repetir.
