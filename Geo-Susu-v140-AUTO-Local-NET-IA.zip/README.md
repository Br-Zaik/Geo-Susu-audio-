Geo Susu v140 - AUTO claro + respuestas locales dinámicas + NET/API libre

Cambios principales:
- AUTO mantiene el orden correcto: respuestas locales rápidas, luego JSON, luego NET/API.
- NET/API acepta cualquier pregunta clara; no bloquea por no ser minería.
- Fecha, hora, año actual, días de un año y años bisiestos se responden localmente con el reloj del celular.
- Feriados y días no laborables pasan a NET/API para evitar datos fijos desactualizados.
- El prompt NET/API incluye la fecha local del celular para preguntas como "hoy", "este mes" o "este año".
- La confirmación inteligente ya no frena preguntas claras solo por ser cortas.
- Se mantiene la limpieza de respuestas largas, internas, en inglés o cortadas.
