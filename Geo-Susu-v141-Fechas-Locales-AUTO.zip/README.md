Geo Susu v141 - Fechas relativas locales + AUTO limpio

Cambios principales:
- AUTO mantiene el orden correcto: respuestas locales rápidas, luego JSON, luego NET/API.
- Se agregó respuesta local dinámica para: "qué día es mañana", "qué fecha es mañana", "qué día será pasado mañana", "qué día fue ayer" y "anteayer".
- Las fechas relativas usan el reloj real del celular; no quedan escritas fijas en el código.
- Preguntas de feriados y días no laborables siguen pasando a NET/API para evitar datos desactualizados.
- Se mantienen respuestas locales para hora, fecha actual, año actual, días de un año y años bisiestos.
- Se mantiene la confirmación inteligente sí/no con 3 segundos y la limpieza de respuestas NET/API.
