Geo Susu v142 - API proveedor auto

Cambios principales:
- Mantiene v141: fechas locales en AUTO, confirmacion si/no y flujo local -> JSON -> NET/API.
- Corrige configuracion de APIs: si una clave tiene formato de Gemini, Groq u OpenRouter, la app corrige el proveedor automaticamente antes de guardar/probar.
- Evita que una clave Gemini quede probada como Groq por error de seleccion o por lista pegada.
- Al importar lista, usa el proveedor seleccionado como respaldo, pero respeta el proveedor detectado por el formato de la clave.
- Si el modelo escrito era un modelo por defecto de otro proveedor, se cambia al modelo por defecto del proveedor detectado.

Regla de uso:
- Igual conviene pegar por proveedor, pero ahora si te equivocas con Gemini/Groq/OpenRouter la app intenta corregirlo.
