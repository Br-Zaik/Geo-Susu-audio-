package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private data class PendingConfirmation(
        val heardQuestion: String,
        val confirmedQuestion: String,
        val spokenLabel: String
    )

    private lateinit var repository: ResponseRepository
    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var memory: MemoryStore
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var isListening = false
    @Volatile private var waitingConfirmation = false

    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var lastPartial = ""
    private var partialRunnable: Runnable? = null
    private var pendingConfirmation: PendingConfirmation? = null
    private var confirmationTimeoutRunnable: Runnable? = null
    private var suppressNextRecognizerError = false
    private var lastAutoQuestionKey = ""
    private var lastAutoAnswerSource = ""
    private var lastAutoAnswerTime = 0L

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        jsonRepository = JsonKnowledgeRepository(this)
        warmJsonInBackground()
        memory = MemoryStore(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Susurro Google activo"))
        running = true
        startInternalRecognition(delayMs = 350L)
        return START_STICKY
    }

    private fun startInternalRecognition(delayMs: Long = 300L) {
        if (!running || isSpeaking || isListening || waitingConfirmation) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "Activa permiso de micrófono.", 0)
            stopSelf()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendUpdate("Google interno no disponible", "", "Actualiza Speech Services by Google o usa Google ventana.", 0)
            stopSelf()
            return
        }

        handler.postDelayed({
            if (!running || isSpeaking || isListening || waitingConfirmation) return@postDelayed

            try {
                if (recognizer == null) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer?.setRecognitionListener(listener)
                }

                isListening = true
                lastPartial = ""
                cancelPartialRunnable()
                prepareAudioRouteForUsbMic()
                sendUpdate("Susurro Google: escuchando...", "", "", 0)
                recognizer?.startListening(buildIntent())
            } catch (_: Exception) {
                isListening = false
                sendUpdate("Reiniciando Google interno...", "", "", -1)
                restartRecognizer(900L)
            }
        }, delayMs)
    }

    private fun buildIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            if (Build.VERSION.SDK_INT >= 33) {
                putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, arrayListOf(
                    "qué es topografía", "qué es topografía superficial",
                    "qué es levantamiento topográfico", "qué es levantamiento simple",
                    "qué es nivelación", "qué es cota", "qué es banco de nivel",
                    "qué es BM en topografía", "BM", "be eme", "ve eme", "pm", "bebé",
                    "qué es cateo", "cateo", "qué es prospección", "prospección minera",
                    "qué es exploración minera", "qué es explotación minera", "qué es yacimiento",
                    "qué es mineral", "qué es roca", "qué es mena", "qué es ganga",
                    "qué es veta", "qué es manto", "qué es ley de mineral", "qué es ley de corte",
                    "qué es concesión minera", "qué es petitorio minero", "qué es canon minero",
                    "qué es IPERC", "qué es EPP", "qué es ATS", "qué es PETS",
                    "qué es cambio de punto", "CP", "ce pe",
                    "vista atrás", "vista adelante", "vista intermedia",
                    "altura de instrumento", "AI", "a i",
                    "replanteo topográfico", "límites del plano al terreno",
                    "distancia horizontal", "distancia inclinada", "distancia vertical",
                    "curvas de nivel", "pendiente", "rumbo", "azimut",
                    "estación total", "mira topográfica", "coordenadas", "plano topográfico"
                ))
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (waitingConfirmation) {
                sendUpdate("Di si o no", pendingConfirmation?.confirmedQuestion.orEmpty(), "", 0)
            } else {
                sendUpdate("Susurro Google listo", "", "", 0)
            }
        }

        override fun onBeginningOfSpeech() {
            if (waitingConfirmation) {
                sendUpdate("Escuchando confirmacion...", pendingConfirmation?.confirmedQuestion.orEmpty(), "", 25)
            } else {
                sendUpdate("Te estoy escuchando...", "", "", 25)
            }
        }

        override fun onRmsChanged(rmsdB: Float) {
            val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
            sendUpdate("", "", "", level)
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() {
            if (waitingConfirmation) {
                sendUpdate("Procesando si/no...", pendingConfirmation?.confirmedQuestion.orEmpty(), "", -1)
            } else {
                sendUpdate("Procesando voz...", "", "", -1)
            }
        }

        override fun onError(error: Int) {
            isListening = false
            cancelPartialRunnable()

            if (suppressNextRecognizerError) {
                suppressNextRecognizerError = false
                return
            }

            if (waitingConfirmation) {
                finishConfirmationWithRepeat()
                return
            }

            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    sendUpdate("No detecto voz", "", "", -1)
                    restartRecognizer(600L)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    restartRecognizer(900L)
                }
                else -> {
                    sendUpdate("Google interno error $error", "", "Reintentando escucha.", -1)
                    restartRecognizer(1200L)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            cancelPartialRunnable()

            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()

            if (waitingConfirmation) {
                handleConfirmationResults(matches)
                return
            }

            val best = chooseBestSpeechCandidate(matches)

            if (best.isBlank()) {
                restartRecognizer(500L)
                return
            }

            processQuestion(best)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .trim()

            if (partial.isNotBlank()) {
                lastPartial = partial
                if (waitingConfirmation) {
                    sendUpdate("Confirmacion: si o no", partial, "", -1)
                } else {
                    sendUpdate("Escuchando sin responder todavia...", partial, "Texto parcial. Esperando resultado final.", -1)
                }
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun schedulePartialAnswer(partial: String) {
        cancelPartialRunnable()

        val task = Runnable {
            if (!running || isSpeaking || !isListening) return@Runnable
            if (partial != lastPartial) return@Runnable

            try {
                recognizer?.cancel()
            } catch (_: Exception) {
            }

            isListening = false
            processQuestion(partial)
        }

        partialRunnable = task
        handler.postDelayed(task, 1100L)
    }

    private fun cancelPartialRunnable() {
        partialRunnable?.let { handler.removeCallbacks(it) }
        partialRunnable = null
    }

    private fun requestQuestionConfirmation(heardQuestion: String, suggestion: VoiceQuestionNormalizer.ConfirmationSuggestion) {
        pendingConfirmation = PendingConfirmation(
            heardQuestion = heardQuestion,
            confirmedQuestion = suggestion.confirmedQuestion,
            spokenLabel = suggestion.spokenLabel
        )
        waitingConfirmation = false
        isSpeaking = true
        isListening = false
        cancelPartialRunnable()
        cancelConfirmationTimeout()

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        val prompt = "Quisiste decir ${suggestion.spokenLabel}?"
        lastSpokenNormalized = ResponseRepository.normalize(prompt)
        sendUpdate("Confirmando pregunta", heardQuestion, prompt, -1)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())

        val result = tts?.speak(prompt, TextToSpeech.QUEUE_FLUSH, null, CONFIRMATION_UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false
            finishConfirmationWithRepeat()
        }
    }

    private fun startConfirmationRecognition(delayMs: Long = 150L) {
        if (!running || isSpeaking || isListening) return
        val pending = pendingConfirmation ?: run {
            waitingConfirmation = false
            restartRecognizer(350L)
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de microfono", "", "Activa permiso de microfono.", 0)
            stopSelf()
            return
        }

        handler.postDelayed({
            if (!running || isSpeaking || isListening || pendingConfirmation == null) return@postDelayed

            try {
                if (recognizer == null) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer?.setRecognitionListener(listener)
                }

                waitingConfirmation = true
                isListening = true
                lastPartial = ""
                cancelPartialRunnable()
                prepareAudioRouteForUsbMic()
                sendUpdate("Di si o no", pending.confirmedQuestion, "", -1)
                recognizer?.startListening(buildConfirmationIntent())
                scheduleConfirmationTimeout()
            } catch (_: Exception) {
                isListening = false
                waitingConfirmation = false
                finishConfirmationWithRepeat()
            }
        }, delayMs)
    }

    private fun buildConfirmationIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 700L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 850L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 650L)
            if (Build.VERSION.SDK_INT >= 33) {
                putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, arrayListOf(
                    "si", "sí", "no", "correcto", "exacto"
                ))
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private fun scheduleConfirmationTimeout() {
        cancelConfirmationTimeout()
        val task = Runnable {
            if (!running || !waitingConfirmation) return@Runnable
            suppressNextRecognizerError = true
            try {
                recognizer?.cancel()
            } catch (_: Exception) {
            }
            handler.postDelayed({ suppressNextRecognizerError = false }, 1000L)
            isListening = false
            finishConfirmationWithRepeat()
        }
        confirmationTimeoutRunnable = task
        handler.postDelayed(task, CONFIRMATION_TIMEOUT_MS)
    }

    private fun cancelConfirmationTimeout() {
        confirmationTimeoutRunnable?.let { handler.removeCallbacks(it) }
        confirmationTimeoutRunnable = null
    }

    private fun handleConfirmationResults(matches: List<String>) {
        cancelConfirmationTimeout()
        val pending = pendingConfirmation
        waitingConfirmation = false
        isListening = false

        if (pending == null) {
            restartRecognizer(350L)
            return
        }

        val decision = parseConfirmationDecision(matches)
        pendingConfirmation = null

        when (decision) {
            true -> processQuestion(pending.confirmedQuestion, skipConfirmation = true)
            false -> speakAnswer(pending.heardQuestion, "Repite la pregunta.")
            null -> speakAnswer(pending.heardQuestion, "Repite la pregunta.")
        }
    }

    private fun finishConfirmationWithRepeat() {
        cancelConfirmationTimeout()
        val heard = pendingConfirmation?.heardQuestion.orEmpty()
        pendingConfirmation = null
        waitingConfirmation = false
        isListening = false
        speakAnswer(heard, "Repite la pregunta.")
    }

    private fun parseConfirmationDecision(matches: List<String>): Boolean? {
        val cleaned = matches
            .map { ResponseRepository.normalize(it) }
            .map { it.replace("\\s+".toRegex(), " ").trim() }
            .filter { it.isNotBlank() }

        for (text in cleaned) {
            if (text in setOf("si", "sí", "correcto", "exacto", "afirmativo", "ya")) return true
            if (text in setOf("no", "negativo", "nada", "repite")) return false
        }

        for (text in cleaned) {
            val words = text.split(" ").filter { it.isNotBlank() }.toSet()
            if ("no" in words || "negativo" in words) return false
            if ("si" in words || "sí" in words || "correcto" in words || "exacto" in words) return true
        }

        return null
    }

    private fun prepareAudioRouteForUsbMic() {
        try {
            val audioManager = getSystemService(AudioManager::class.java) ?: return
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.stopBluetoothSco()
            audioManager.isBluetoothScoOn = false
            audioManager.isSpeakerphoneOn = false
        } catch (_: Exception) {
        }
    }

    private fun chooseBestSpeechCandidate(matches: List<String>): String {
        val cleaned = matches
            .map { VoiceQuestionNormalizer.normalize(it.trim()) }
            .filter { it.isNotBlank() }
            .distinct()

        if (cleaned.isEmpty()) return ""

        // Elegir la frase completa más probable, no una palabra suelta.
        // Antes se priorizaba cualquier frase con "topografía" y eso podía recortar
        // preguntas como "qué es BM en topografía" a una respuesta genérica.
        return cleaned
            .filter { !VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(it) }
            .maxByOrNull { fullQuestionScore(it) }
            ?: cleaned.maxByOrNull { it.length }
            ?: ""
    }

    private fun fullQuestionScore(question: String): Int {
        val normalized = ResponseRepository.normalize(question)
        val stop = setOf(
            "q", "que", "es", "son", "sera", "seria", "el", "la", "los", "las",
            "un", "una", "unos", "unas", "de", "del", "en", "por", "para",
            "dime", "di", "define", "defineme", "explica", "explicame",
            "concepto", "significa", "significado", "sobre", "cual", "cuales"
        )
        val genericContext = setOf("topografia", "topografica", "topografico", "mineria", "geologia", "terreno")
        val specificCodes = setOf("bm", "cp", "va", "vi", "vf", "ai")
        val words = normalized.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stop }

        var score = 0
        score += content.size * 20
        score += normalized.length.coerceAtMost(120) / 3

        if (words.firstOrNull() in setOf("que", "dime", "define", "explica", "explicame")) score += 8
        if (content.any { it in specificCodes }) score += 35
        if (content.size == 1 && content.first() in genericContext) score -= 20
        if (content.size >= 2 && content.any { it !in genericContext }) score += 20

        return score
    }

    private fun processRecognitionTest(raw: String) {
        val question = VoiceQuestionNormalizer.normalize(raw)
        val answer = "Escuchado: ${raw.trim()}\nCorregido: $question\n\nNo se buscó en JSON ni NET."
        lastHeard = question
        lastHeardTime = System.currentTimeMillis()
        sendUpdate("Reconocimiento listo", question, answer, -1)
        restartRecognizer(900L)
    }

    private fun processQuestion(raw: String, skipConfirmation: Boolean = false) {
        val question = VoiceQuestionNormalizer.normalize(raw)

        if (!skipConfirmation) {
            val suggestion = VoiceQuestionNormalizer.confirmationSuggestion(raw, question)
            if (suggestion != null) {
                requestQuestionConfirmation(question, suggestion)
                return
            }
        }

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(question)) {
            sendUpdate("No entendí bien", question, "Repite cerca del micrófono.", -1)
            restartRecognizer(650L)
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            restartRecognizer(350L)
            return
        }

        val now = System.currentTimeMillis()
        val mode = modeSettings.getMode()
        val repeatedForNet = mode == AnswerModeSettings.Mode.AUTO && shouldForceNetForRepeatedAuto(question)
        if (question == lastHeard && now - lastHeardTime < 4500 && !repeatedForNet) {
            restartRecognizer(350L)
            return
        }

        lastHeard = question
        lastHeardTime = now

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            speakAnswer(question, localAnswer)
            return
        }

        when (mode) {
            AnswerModeSettings.Mode.INTERNET -> {
                if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                    speakAnswer(question, "No entendí bien. Repite cerca del micrófono.")
                } else {
                    answerOnline(question)
                }
            }

            AnswerModeSettings.Mode.JSON -> answerJsonInBackground(question, fallbackToOnline = false)

            AnswerModeSettings.Mode.AUTO -> {
                if (repeatedForNet) {
                    rememberAutoAnswer(question, "net")
                    answerOnline(question, "Repetida: buscando en NET...")
                } else {
                    answerJsonInBackground(question, fallbackToOnline = true)
                }
            }
        }
    }

    private fun answerJsonInBackground(question: String, fallbackToOnline: Boolean) {
        sendUpdate("Buscando en JSON...", question, "Procesando sin bloquear la app.", -1)

        Thread {
            val jsonMatch = try {
                jsonRepository.findBest(question)
            } catch (_: Exception) {
                ResponseRepository.MatchResult("No encontrado", "none", 0)
            }

            if (!running) return@Thread

            if (jsonMatch.itemId != "none") {
                if (fallbackToOnline) rememberAutoAnswer(question, "json")
                memory.saveLast(question, jsonMatch.answer, jsonMatch.itemId, jsonMatch.score)
                handler.post { speakAnswer(question, jsonMatch.answer) }
            } else if (fallbackToOnline) {
                if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                    handler.post { speakAnswer(question, "No entendí bien. Repite cerca del micrófono.") }
                } else {
                    rememberAutoAnswer(question, "net")
                    answerOnline(question)
                }
            } else {
                handler.post { speakAnswer(question, "No encontrado") }
            }
        }.start()
    }

    private fun warmJsonInBackground() {
        Thread {
            try {
                jsonRepository.totalItems
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun answerOnline(question: String, statusText: String = "Buscando NET...") {
        sendUpdate(statusText, question, "Buscando NET.", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontrado"
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                speakAnswer(question, answer)
            }
        }.start()
    }

    private fun speakAnswer(question: String, answer: String) {
        isSpeaking = true
        isListening = false
        cancelPartialRunnable()
        lastSpokenNormalized = ResponseRepository.normalize(answer)

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        sendUpdate("Respuesta lista", question, answer, -1)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())

        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false
            restartRecognizer(500L)
        }
    }

    private fun rememberAutoAnswer(question: String, source: String) {
        lastAutoQuestionKey = repeatKey(question)
        lastAutoAnswerSource = source
        lastAutoAnswerTime = System.currentTimeMillis()
    }

    private fun shouldForceNetForRepeatedAuto(question: String): Boolean {
        if (lastAutoAnswerSource != "json") return false
        if (System.currentTimeMillis() - lastAutoAnswerTime > 2 * 60 * 1000L) return false
        return isSameRepeatQuestion(repeatKey(question), lastAutoQuestionKey)
    }

    private fun isSameRepeatQuestion(currentKey: String, previousKey: String): Boolean {
        if (currentKey.isBlank() || previousKey.isBlank()) return false
        if (currentKey == previousKey) return true
        val a = currentKey.split(" ").filter { it.isNotBlank() }.toSet()
        val b = previousKey.split(" ").filter { it.isNotBlank() }.toSet()
        if (a.isEmpty() || b.isEmpty()) return false
        val common = a.count { it in b }
        val minSize = minOf(a.size, b.size)
        val maxSize = maxOf(a.size, b.size)
        return common >= minSize && maxSize <= minSize + 2
    }

    private fun repeatKey(text: String): String {
        return ResponseRepository.normalize(text)
            .replace("\btipo de rocas\b".toRegex(), "tipos de roca")
            .replace("\btipo de roca\b".toRegex(), "tipos de roca")
            .replace("\btipos de rocas\b".toRegex(), "tipos de roca")
            .split(" ")
            .map { repeatCanonical(it.trim()) }
            .filter { it.length >= 3 && it !in repeatStopWords }
            .distinct()
            .joinToString(" ")
    }

    private fun repeatCanonical(word: String): String {
        return when (word) {
            "rocas" -> "roca"
            "minerales" -> "mineral"
            "tipos", "tipo" -> "tipos"
            "clases", "clase" -> "clases"
            else -> if (word.length > 6 && word.endsWith("s") && !word.endsWith("is")) word.dropLast(1) else word
        }
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val spoken = lastSpokenNormalized
        if (question.isBlank() || spoken.isBlank()) return false
        if (spoken.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = qWords.count { it in spokenWords }
        return common >= 3 && common >= qWords.size * 0.6
    }

    private fun restartRecognizer(delayMs: Long) {
        if (!running || isSpeaking) return

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        isListening = false
        startInternalRecognition(delayMs)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Prueba de Voz")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GoogleInternalWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    when (utteranceId) {
                        CONFIRMATION_UTTERANCE_ID -> {
                            handler.postDelayed({
                                isSpeaking = false
                                startConfirmationRecognition(100L)
                            }, 150L)
                        }
                        UTTERANCE_ID -> {
                            handler.postDelayed({
                                isSpeaking = false
                                sendUpdate("Susurro Google escuchando...", "", "", -1)
                                restartRecognizer(550L)
                            }, 350L)
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    if (utteranceId == CONFIRMATION_UTTERANCE_ID) {
                        finishConfirmationWithRepeat()
                    } else {
                        restartRecognizer(550L)
                    }
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        cancelPartialRunnable()
        cancelConfirmationTimeout()

        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }

        try {
            recognizer?.destroy()
        } catch (_: Exception) {
        }

        recognizer = null
        tts?.stop()
        tts?.shutdown()

        try {
            wakeLock?.release()
        } catch (_: Exception) {
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID = "geo_susu_google_internal_answer"
        private const val CONFIRMATION_UTTERANCE_ID = "geo_susu_google_internal_confirm"
        private const val CONFIRMATION_TIMEOUT_MS = 3000L
        private val repeatStopWords = setOf(
            "que", "qué", "q", "ke", "k", "es", "son", "ser", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuál", "cuales", "cuáles",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa", "explica", "sobre"
        )
    }
}
