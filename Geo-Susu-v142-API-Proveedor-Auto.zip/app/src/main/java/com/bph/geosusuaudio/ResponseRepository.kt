package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import kotlin.math.max

class ResponseRepository(private val context: Context) {

    data class QaItem(
        val id: String,
        val tema: String,
        val pregunta: String,
        val respuesta: String,
        val aliases: List<String>
    )

    data class MatchResult(
        val answer: String,
        val itemId: String,
        val score: Int
    )

    private data class CandidateEntry(
        val item: QaItem,
        val candidates: List<String>
    )

    private data class InternalMatch(
        val item: QaItem?,
        val score: Int,
        val secondScore: Int,
        val heard: String
    )

    private val items: List<QaItem> = loadItems(context)
    private val candidateCache: List<CandidateEntry> = items.map { item ->
        CandidateEntry(item, buildCandidates(item))
    }

    val totalItems: Int get() = items.size

    fun findBest(input: String): MatchResult {
        return findBestFrom(listOf(input))
    }

    fun findBestFrom(inputs: List<String>): MatchResult {
        val best = findBestInternal(inputs)
        val safeGap = best.score - best.secondScore

        return if (best.item != null && best.score >= 90 && (safeGap >= 10 || best.score >= 98)) {
            MatchResult(best.item.respuesta, best.item.id, best.score)
        } else {
            MatchResult(DEFAULT_RESPONSE, "none", best.score)
        }
    }

    fun findBestStrictFrom(inputs: List<String>): MatchResult {
        var bestItem: QaItem? = null
        var bestScore = 0
        var secondScore = 0

        val cleanInputs = inputs
            .map { prepareForMatch(it) }
            .filter { it.isNotBlank() }
            .distinct()

        for (input in cleanInputs) {
            val inputCore = coreWords(input)
            if (inputCore.isEmpty()) continue

            for (entry in candidateCache) {
                val score = entry.candidates.maxOfOrNull { candidate ->
                    scoreCandidateStrict(input, inputCore, candidate)
                } ?: 0

                if (score > bestScore) {
                    if (entry.item.id != bestItem?.id) secondScore = bestScore
                    bestScore = score
                    bestItem = entry.item
                } else if (entry.item.id != bestItem?.id && score > secondScore) {
                    secondScore = score
                }
            }
        }

        return if (bestItem != null && bestScore == 100 && secondScore < 100) {
            MatchResult(bestItem.respuesta, bestItem.id, bestScore)
        } else {
            MatchResult(DEFAULT_RESPONSE, "none", bestScore)
        }
    }

    fun findBestResponse(input: String): String = findBest(input).answer

    private fun findBestInternal(inputs: List<String>): InternalMatch {
        var bestItem: QaItem? = null
        var bestScore = 0
        var secondScore = 0
        var bestHeard = ""

        val cleanInputs = inputs
            .map { prepareForMatch(it) }
            .filter { it.isNotBlank() }
            .distinct()

        for (input in cleanInputs) {
            val inputCore = coreWords(input)
            if (inputCore.isEmpty()) continue

            for (entry in candidateCache) {
                val score = entry.candidates.maxOfOrNull { candidate ->
                    scoreCandidate(input, inputCore, candidate)
                } ?: 0

                if (score > bestScore) {
                    if (entry.item.id != bestItem?.id) secondScore = bestScore
                    bestScore = score
                    bestItem = entry.item
                    bestHeard = input
                } else if (entry.item.id != bestItem?.id && score > secondScore) {
                    secondScore = score
                }
            }
        }

        return InternalMatch(bestItem, bestScore, secondScore, bestHeard)
    }

    fun buildVoskGrammar(commandWord: String): String {
        val phrases = linkedSetOf<String>()
        val cleanCommand = normalize(commandWord).ifBlank { "geo" }

        phrases.add(cleanCommand)
        if (cleanCommand == "geo") {
            phrases.add("jeo")
            phrases.add("gio")
            phrases.add("eo")
        }

        for (item in items) {
            phrases.add(normalize(item.id))
            phrases.add(normalize(item.pregunta))
            item.aliases.forEach { alias -> phrases.add(normalize(alias)) }

            val main = coreWords(normalize(item.pregunta)).joinToString(" ")
            if (main.isNotBlank()) phrases.add(main)
        }

        phrases.add("[unk]")

        val array = JSONArray()
        phrases.filter { it.isNotBlank() }.take(900).forEach { array.put(it) }
        return array.toString()
    }

    private fun loadItems(context: Context): List<QaItem> {
        val result = mutableListOf<QaItem>()
        result.addAll(readArray(context.assets.open("respuestas.json").bufferedReader().use { it.readText() }))
        result.addAll(readTxtAssets(context))
        result.addAll(readArray(getCustomJson(context)))
        return result
    }

    private fun readTxtAssets(context: Context): List<QaItem> {
        val qaRaw = runCatching {
            context.assets.open("txt_pr_500_recursos_geologicos.txt").bufferedReader().use { it.readText() }
        }.getOrDefault("")

        if (qaRaw.isBlank()) return emptyList()

        val variantsRaw = runCatching {
            context.assets.open("txt_variantes_500_recursos_geologicos.txt").bufferedReader().use { it.readText() }
        }.getOrDefault("")

        val answers = linkedMapOf<String, Pair<String, String>>()
        qaRaw.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.contains("|") }
            .forEach { line ->
                val parts = line.split("|", limit = 2).map { it.trim() }
                if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                    answers[normalize(parts[0])] = Pair(parts[0], parts[1])
                }
            }

        val aliases = mutableMapOf<String, MutableList<String>>()
        variantsRaw.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.contains("|") }
            .forEach { line ->
                val parts = line.split("|", limit = 2).map { it.trim() }
                if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                    val key = normalize(parts[0])
                    val list = aliases.getOrPut(key) { mutableListOf() }
                    parts[1]
                        .split(",", ";")
                        .map { it.trim() }
                        .filter { it.isNotBlank() }
                        .distinct()
                        .take(18)
                        .forEach { list.add(it) }
                }
            }

        return answers.map { (key, value) ->
            QaItem(
                id = "pack500_$key",
                tema = "Recursos Geologicos 500",
                pregunta = value.first,
                respuesta = value.second,
                aliases = aliases[key].orEmpty().distinct()
            )
        }
    }

    private fun readArray(json: String): List<QaItem> {
        val array = JSONArray(json)
        val result = mutableListOf<QaItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val aliasesArray = obj.optJSONArray("aliases") ?: JSONArray()
            val aliases = mutableListOf<String>()
            for (j in 0 until aliasesArray.length()) {
                aliases.add(aliasesArray.getString(j))
            }
            result.add(
                QaItem(
                    id = obj.optString("id", obj.optString("pregunta", "item_$i")),
                    tema = obj.optString("tema", ""),
                    pregunta = obj.getString("pregunta"),
                    respuesta = obj.getString("respuesta"),
                    aliases = aliases
                )
            )
        }
        return result
    }

    private fun buildCandidates(item: QaItem): List<String> {
        val raw = mutableListOf<String>()
        raw.add(item.id)
        raw.add(item.pregunta)

        val mainCore = coreWords(normalize(item.pregunta)).joinToString(" ")
        if (mainCore.isNotBlank()) raw.add(mainCore)

        item.aliases
            .asSequence()
            .filter { isSafeAlias(it, item) }
            .distinct()
            .take(40)
            .forEach { raw.add(it) }

        val generated = raw.mapNotNull { makeAcronym(it) }
        raw.addAll(generated)

        return raw
            .map { prepareForMatch(it) }
            .filter { it.length >= 2 }
            .distinct()
    }

    private fun isSafeAlias(value: String, item: QaItem): Boolean {
        val alias = normalize(value)
        if (alias.isBlank()) return false

        val words = coreWords(alias)
        if (words.isEmpty()) return false

        val itemCore = coreWords(normalize(item.pregunta))
        val firstKeyword = itemCore.firstOrNull().orEmpty()

        if (words.size == 1) {
            val word = words.first()
            val generic = setOf(
                "mineria", "minera", "minero", "explotacion", "geologia",
                "roca", "mineral", "proceso", "actividad", "definicion",
                "concepto", "seguridad", "equipo", "trabajo", "abierto",
                "superficial", "subterranea", "subterraneo", "metal", "valor"
            )
            if (word in generic) return false

            // Evita que palabras sueltas secundarias de una pregunta activen otra respuesta.
            // Ejemplo: en "tajo abierto", "abierto" no debe activar tajo.
            if (word in itemCore && word != firstKeyword) return false

            return word.length >= 3
        }

        return words.size in 2..8
    }

    private fun prepareForMatch(text: String): String {
        return normalize(applyCommonCorrections(text))
    }

    private fun scoreCandidateStrict(input: String, inputCore: List<String>, candidate: String): Int {
        val candidateCore = coreWords(candidate)
        if (candidateCore.isEmpty()) return 0

        if (input == candidate) return 100
        if (inputCore == candidateCore) return 100

        // TXT estricto: solo exacto o contenido exacto de palabras.
        if (candidateCore.all { it in inputCore }) return 100
        if (candidateCore.size == 1 && inputCore.contains(candidateCore.first())) return 100

        return 0
    }

    private fun scoreCandidate(input: String, inputCore: List<String>, candidate: String): Int {
        val candidateCore = coreWords(candidate)
        if (candidateCore.isEmpty()) return 0

        if (input == candidate) return 100
        if (inputCore == candidateCore) return 100

        val genericContextOnly = setOf(
            "topografia", "topografica", "topografico", "mineria", "geologia", "terreno", "tema"
        )

        // Una palabra genérica no debe ganarle a una pregunta completa.
        // Ejemplo: "que es bm en topografia" no debe responder "topografía".
        if (candidateCore.size == 1 && inputCore.size > 1 && candidateCore.first() in genericContextOnly) {
            return 35
        }

        // Coincidencia profesional por pregunta completa o término específico:
        // "que es epp" -> epp
        // "defineme cateo" -> cateo
        if (candidateCore.all { it in inputCore }) return 100
        if (inputCore.size >= 2 && inputCore.all { it in candidateCore }) return 92

        // Si el usuario dice solo la palabra, no confundir con parecidas.
        if (inputCore.size == 1) {
            val word = inputCore.first()
            if (candidateCore.contains(word)) return 100
            val best = candidateCore.maxOfOrNull { similarityPercent(word, it) } ?: 0
            return if (best >= 92) best else 0
        }

        // Si el candidato es una sigla o palabra corta y está dentro de la pregunta, es válido.
        if (candidateCore.size == 1) {
            val word = candidateCore.first()
            if (inputCore.contains(word)) return 100
            val best = inputCore.maxOfOrNull { similarityPercent(word, it) } ?: 0
            return if (best >= 92) best else 0
        }

        val exactMatches = candidateCore.count { it in inputCore }
        val coverage = (exactMatches * 100) / candidateCore.size

        val fuzzyMatches = candidateCore.count { candidateWord ->
            inputCore.any { inputWord -> similarityPercent(inputWord, candidateWord) >= 92 }
        }
        val fuzzyCoverage = (fuzzyMatches * 100) / candidateCore.size

        return max(coverage, fuzzyCoverage)
    }

    private fun coreWords(text: String): List<String> {
        val stop = setOf(
            "q", "que", "es", "son", "sera", "seria", "el", "la", "los", "las",
            "un", "una", "unos", "unas", "de", "del", "en", "por", "para",
            "dime", "di", "define", "defineme", "explica", "explicame",
            "concepto", "significa", "significado", "palabra", "sobre",
            "cual", "cuales", "como", "se", "llama", "simbolo", "quimico",
            "quimica"
        )
        return text.split(" ")
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stop }
            .distinct()
    }

    private fun similarityPercent(a: String, b: String): Int {
        if (a.isBlank() || b.isBlank()) return 0
        val distance = levenshtein(a, b)
        val maxLen = max(a.length, b.length)
        return ((1.0 - distance.toDouble() / maxLen.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    private fun levenshtein(a: String, b: String): Int {
        val costs = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var lastValue = i - 1
            costs[0] = i
            for (j in 1..b.length) {
                val newValue = minOf(
                    costs[j] + 1,
                    costs[j - 1] + 1,
                    lastValue + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                lastValue = costs[j]
                costs[j] = newValue
            }
        }
        return costs[b.length]
    }

    private fun applyCommonCorrections(text: String): String {
        var output = compactSpelledAcronyms(normalize(text))
        val corrections = mapOf(
            "gaga" to "ganga",
            "aga" to "ganga",
            "canga" to "ganga",
            "mema" to "mena",
            "nena" to "mena",
            "me na" to "mena",
            "minea" to "mena",
            "kateo" to "cateo",
            "cateu" to "cateo",
            "cate" to "cateo",
            "catio" to "cateo",
            "hiper" to "iperc",
            "iper" to "iperc",
            "i perc" to "iperc",
            "e p p" to "epp",
            "a n a" to "ana",
            "cuota de geologo" to "picota de geologo",
            "picota de solomo" to "picota de geologo",
            "tipo de socas" to "tipos de roca",
            "tipos de socas" to "tipos de roca",
            "tipo de soca" to "tipos de roca",
            "tipos de soca" to "tipos de roca",
            "socas" to "rocas",
            "soca" to "roca",
            "que es canca" to "ganga",
            "canca" to "ganga",
            "tipos de loca" to "tipos de roca",
            "loca" to "roca"
        )
        for ((bad, good) in corrections) {
            output = output.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }
        return output
    }

    private fun compactSpelledAcronyms(text: String): String {
        val tokens = text.split(" ").filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        var i = 0

        while (i < tokens.size) {
            if (tokens[i].length == 1 && tokens[i].all { it.isLetterOrDigit() }) {
                val letters = StringBuilder()
                var j = i
                while (j < tokens.size && tokens[j].length == 1 && tokens[j].all { it.isLetterOrDigit() }) {
                    letters.append(tokens[j])
                    j++
                }

                if (letters.length >= 2) {
                    out.add(letters.toString())
                    i = j
                    continue
                }
            }

            out.add(tokens[i])
            i++
        }

        return out.joinToString(" ")
    }

    private fun makeAcronym(text: String): String? {
        val words = coreWords(normalize(text)).filter { it.length >= 2 }
        if (words.size < 2 || words.size > 6) return null

        val acronym = words.joinToString("") { it.first().toString() }
        return if (acronym.length in 2..8) acronym else null
    }

    companion object {
        private const val DEFAULT_RESPONSE = "No encontrado."
        private const val PREFS = "geo_susu_memory"
        private const val CUSTOM_ITEMS = "custom_items"

        fun saveCustomItem(context: Context, pregunta: String, aliasesRaw: String, respuesta: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            val index = findIndex(array, pregunta)

            val aliases = JSONArray()
            pregunta.split(" ").filter { it.isNotBlank() }.forEach { aliases.put(it) }
            aliasesRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { aliases.put(it) }

            val item = if (index >= 0) array.getJSONObject(index) else JSONObject()
                .put("id", "custom_${System.currentTimeMillis()}")
                .put("tema", "Personalizado")
                .put("pregunta", pregunta)

            item.put("respuesta", respuesta)
            item.put("aliases", aliases)

            if (index < 0) array.put(item)
            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return array.length()
        }

        fun importQuestionsAnswers(context: Context, raw: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            val indexMap = buildQuestionIndex(array)
            var imported = 0

            raw.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val parts = line.split("|", limit = 2).map { it.trim() }
                    if (parts.size >= 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                        val pregunta = parts[0]
                        val respuesta = parts[1].trim()
                        val key = normalize(pregunta)
                        val index = indexMap[key] ?: -1

                        val item = if (index >= 0) array.getJSONObject(index) else JSONObject()
                            .put("id", key.ifBlank { "qa_${System.currentTimeMillis()}_$imported" })
                            .put("tema", "TXT")
                            .put("pregunta", pregunta)
                            .put("aliases", JSONArray())

                        item.put("respuesta", respuesta)

                        val aliases = mergeAliases(
                            item.optJSONArray("aliases") ?: JSONArray(),
                            listOf(pregunta)
                        )
                        item.put("aliases", aliases)

                        if (index < 0) {
                            array.put(item)
                            indexMap[key] = array.length() - 1
                        }
                        imported++
                    }
                }

            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).commit()
            return imported
        }

        fun importVariants(context: Context, raw: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            val indexMap = buildQuestionIndex(array)
            var imported = 0

            raw.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val parts = line.split("|", limit = 2).map { it.trim() }
                    if (parts.size >= 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                        val pregunta = parts[0]
                        val variants = parts[1]
                            .split(",", ";")
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .distinct()
                            .take(24)

                        val index = indexMap[normalize(pregunta)] ?: -1
                        if (index >= 0) {
                            val item = array.getJSONObject(index)
                            val aliases = mergeAliases(
                                item.optJSONArray("aliases") ?: JSONArray(),
                                listOf(pregunta) + variants
                            )
                            item.put("aliases", aliases)
                            imported++
                        }
                    }
                }

            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).commit()
            return imported
        }

        fun importBulkText(context: Context, raw: String): Int {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val array = JSONArray(prefs.getString(CUSTOM_ITEMS, "[]") ?: "[]")
            var imported = 0

            raw.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val parts = line.split("|").map { it.trim() }
                    if (parts.size >= 3 && parts[0].isNotBlank() && parts[2].isNotBlank()) {
                        val pregunta = parts[0]
                        val respuesta = parts.subList(2, parts.size).joinToString(" | ")
                        val index = findIndex(array, pregunta)

                        val item = if (index >= 0) array.getJSONObject(index) else JSONObject()
                            .put("id", "txt_${System.currentTimeMillis()}_$imported")
                            .put("tema", "TXT")
                            .put("pregunta", pregunta)

                        item.put("respuesta", respuesta)
                        item.put(
                            "aliases",
                            mergeAliases(
                                item.optJSONArray("aliases") ?: JSONArray(),
                                pregunta.split(" ") + parts[1].split(",")
                            )
                        )

                        if (index < 0) array.put(item)
                        imported++
                    }
                }

            prefs.edit().putString(CUSTOM_ITEMS, array.toString()).apply()
            return imported
        }

        fun replaceInternalTexts(context: Context, questionsRaw: String, variantsRaw: String): Pair<Int, Int> {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            prefs.edit().putString(CUSTOM_ITEMS, "[]").apply()

            val questions = importQuestionsAnswers(context, questionsRaw)
            val variants = if (variantsRaw.isBlank()) 0 else importVariants(context, variantsRaw)
            return Pair(questions, variants)
        }

        fun getCustomJson(context: Context): String {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(CUSTOM_ITEMS, "[]") ?: "[]"
        }

        fun normalize(text: String): String {
            return Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
                .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
                .replace("[^a-z0-9ñ ]".toRegex(), " ")
                .replace("\\s+".toRegex(), " ")
                .trim()
        }

        private fun findIndex(array: JSONArray, pregunta: String): Int {
            val target = normalize(pregunta)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                if (normalize(item.optString("pregunta")) == target) return i
            }
            return -1
        }

        private fun buildQuestionIndex(array: JSONArray): MutableMap<String, Int> {
            val map = mutableMapOf<String, Int>()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val key = normalize(item.optString("pregunta"))
                if (key.isNotBlank()) map[key] = i
            }
            return map
        }

        private fun mergeAliases(current: JSONArray, values: List<String>): JSONArray {
            val set = linkedSetOf<String>()

            for (i in 0 until current.length()) {
                val value = current.optString(i).trim()
                if (value.isNotBlank()) set.add(value)
            }

            values
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .forEach { set.add(it) }

            val out = JSONArray()
            set.forEach { out.put(it) }
            return out
        }
    }
}
