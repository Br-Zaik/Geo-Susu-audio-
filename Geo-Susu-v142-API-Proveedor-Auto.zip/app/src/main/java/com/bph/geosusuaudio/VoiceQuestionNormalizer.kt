package com.bph.geosusuaudio

import kotlin.math.min

object VoiceQuestionNormalizer {

    private val technicalContextWords = setOf(
        "topografia", "topografico", "topografica", "nivelacion", "nivel", "cota", "cotas", "altura",
        "terreno", "levantamiento", "replanteo", "banco", "instrumento", "mira", "vista",
        "mineria", "minera", "geologia", "mineral", "mina", "yacimiento", "exploracion", "prospeccion"
    )

    private val weakNoiseWords = setOf(
        "ruido", "musica", "ingles", "english", "hola", "eh", "ah", "mmm", "este", "esto",
        "cosa", "cosas", "algo", "alguien", "gente"
    )

    private val likelyBadSingleWords = setOf(
        "baby", "beibi", "barbie", "beybi", "beby", "babi", "bebey", "bebe", "beme",
        "ok", "okay", "google", "celular", "telefono"
    )

    private val stopWords = setOf(
        "que", "q", "ke", "es", "son", "un", "una", "el", "la", "los", "las", "de", "del",
        "en", "por", "para", "dime", "di", "define", "definicion", "concepto", "significa",
        "explica", "sobre", "pregunta", "oye"
    )

    private val clearShortCodes = setOf("bm", "cp", "va", "vi", "vf", "ai", "epp", "eia", "dia", "gps", "utm")

    private val knownTechnicalTerms = setOf(
        "mineria", "mineral", "mina", "roca", "mena", "ganga", "yacimiento", "veta", "manto",
        "cateo", "prospeccion", "exploracion", "explotacion", "geologia", "topografia", "nivelacion",
        "cota", "bm", "banco de nivel", "cp", "cambio de punto", "va", "vista atras", "vi",
        "vista intermedia", "vf", "vista adelante", "ai", "altura de instrumento", "azimut", "rumbo",
        "contra azimut", "distancia horizontal", "distancia inclinada", "distancia vertical",
        "estacion total", "mira", "teodolito", "gps", "utm", "curva de nivel", "perfil longitudinal",
        "muestreo", "muestra", "sondaje", "testigo", "perforacion", "voladura", "explosivo",
        "taladro", "burden", "espaciamiento", "chancado", "molienda", "flotacion", "relave",
        "lixiviacion", "cianuracion", "ventilacion", "sostenimiento", "shotcrete", "peligro",
        "riesgo", "incidente", "accidente", "pets", "ats", "iperc", "epp", "sctr",
        "petitorio", "concesion", "derecho minero", "canon", "ingemmet", "oefa", "osinergmin",
        "drem", "senace", "eia", "dia", "cierre de minas", "formalizacion", "calcopirita",
        "pirita", "bornita", "galena", "esfalerita", "hematita", "magnetita", "cuarzo", "calcita",
        "granulometria", "densidad", "porosidad", "permeabilidad", "talud", "berma", "banco",
        "desmonte", "esteril", "dilucion"
    )

    private val nearTermTargets = listOf(
        "cateo", "cota", "bm", "banco de nivel", "nivelacion", "azimut", "rumbo", "topografia",
        "geologia", "mineria", "mineral", "mena", "ganga", "veta", "manto", "yacimiento",
        "prospeccion", "exploracion", "explotacion", "muestreo", "sondaje", "perforacion",
        "voladura", "chancado", "molienda", "flotacion", "relave", "talud", "berma",
        "iperc", "epp", "ats", "pets", "sctr", "gps", "utm", "eia", "dia"
    )

    data class ConfirmationSuggestion(
        val confirmedQuestion: String,
        val spokenLabel: String
    )

    fun confirmationSuggestion(raw: String, normalizedQuestion: String = normalize(raw)): ConfirmationSuggestion? {
        val rawNorm = ResponseRepository.normalize(raw)
            .replace("\\s+".toRegex(), " ")
            .trim()
        val q = normalizedQuestion.replace("\\s+".toRegex(), " ").trim()
        if (rawNorm.isBlank() || q.isBlank()) return null

        val words = rawNorm.split(" ").filter { it.isNotBlank() }
        val qWords = q.split(" ").filter { it.isNotBlank() }
        val questionIntentWords = setOf(
            "que", "q", "ke", "dime", "di", "define", "definicion",
            "concepto", "significa", "explica", "sobre", "cuanto", "cuantos",
            "cuanta", "cuantas", "cual", "cuales", "cuando", "donde", "como"
        )
        val hasQuestionIntent = words.any { it in questionIntentWords } ||
            rawNorm.contains("que es") ||
            rawNorm.contains("q es") ||
            rawNorm.contains("ke es") ||
            rawNorm.contains("significa") ||
            rawNorm.contains("define") ||
            rawNorm.contains("explica")

        val bmBadRegex = Regex("\\b(baby|beibi|barbie|beybi|beby|babi|bebey|bebe|beme|peme|pm|p m)\\b")
        val bmExactNoise = setOf(
            "que es bien", "q es bien", "ke es bien",
            "que es biem", "q es biem", "ke es biem",
            "que es be m", "q es be m", "ke es be m"
        )

        val looksLikeBadBm = bmBadRegex.containsMatchIn(rawNorm) || rawNorm in bmExactNoise
        if (looksLikeBadBm && (hasQuestionIntent || words.size <= 5)) {
            return ConfirmationSuggestion(
                confirmedQuestion = "que es bm en topografia",
                spokenLabel = "BM"
            )
        }

        val content = qWords.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }
        val contentPhrase = content.joinToString(" ").trim()

        val nearTechnicalTerm = findNearTechnicalTerm(contentPhrase, content)
        if (nearTechnicalTerm != null && !containsKnownTerm(q, nearTechnicalTerm)) {
            return ConfirmationSuggestion(
                confirmedQuestion = buildConfirmedQuestion(q, nearTechnicalTerm, hasQuestionIntent),
                spokenLabel = speakableLabel(nearTechnicalTerm)
            )
        }

        if (shouldConfirmRecognizedQuestion(q, qWords, content, hasQuestionIntent)) {
            val confirmed = if (!hasQuestionIntent && contentPhrase.isNotBlank()) {
                "que es $contentPhrase"
            } else {
                q
            }
            val label = if (!hasQuestionIntent && contentPhrase.isNotBlank()) contentPhrase else q
            return ConfirmationSuggestion(
                confirmedQuestion = confirmed,
                spokenLabel = speakableLabel(label)
            )
        }

        return null
    }

    fun normalize(raw: String): String {
        var q = ResponseRepository.normalize(raw)
        if (q.isBlank()) return ""

        q = q.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()

        val hasContext = hasTechnicalContext(q)

        val phraseCorrections = linkedMapOf(
            "be eme" to "bm",
            "ve eme" to "bm",
            "e pe pe" to "epp",
            "e p p" to "epp",
            "i pe pe" to "epp",
            "equipo proteccion personal" to "epp",
            "bi em" to "bm",
            "bee em" to "bm",
            "be me" to "bm",
            "b m" to "bm",
            "banco nivel" to "banco de nivel",
            "banco del nivel" to "banco de nivel",
            "cuota" to "cota",
            "cuotas" to "cotas",
            "ce pe" to "cp",
            "c p" to "cp",
            "ve a" to "va",
            "v a" to "va",
            "ve i" to "vi",
            "v i" to "vi",
            "ve efe" to "vf",
            "v f" to "vf",
            "a i" to "ai",
            "altura instrumental" to "altura de instrumento",
            "altura del instrumento" to "altura de instrumento",
            "vista final" to "vista adelante",
            "lectura final" to "vista adelante",
            "vista atras" to "vista atras",
            "mieria" to "mineria",
            "miniria" to "mineria",
            "menerea" to "mineria",
            "meneria" to "mineria",
            "topo grafia" to "topografia",
            "topogafia" to "topografia",
            "topografia superfacial" to "topografia superficial"
        )

        for ((bad, good) in phraseCorrections) {
            q = q.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }

        if (hasContext || q.contains("banco") || q.contains("nivel")) {
            val bmLike = listOf("bebe", "bebé", "pm", "p m", "bm.", "beme")
            for (bad in bmLike) {
                q = q.replace("\\b${Regex.escape(ResponseRepository.normalize(bad))}\\b".toRegex(), "bm")
            }
        }

        // Devuelve la pregunta completa corregida, sin agregar palabras ocultas.
        // La app debe responder a lo que el usuario preguntó, no a una palabra clave añadida.
        q = q.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()
        return q
    }

    fun isTooUnclearForJsonOrNet(question: String): Boolean {
        val q = normalize(question)
        if (q.isBlank()) return true
        val words = q.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }
        if (content.isEmpty()) return true

        if (content.size == 1) {
            val w = content.first()
            if (w in setOf("topografia", "mineria", "terreno", "ruido", "pregunta")) return true
            if (w in likelyBadSingleWords) return true
            if (w.length <= 2 && w !in clearShortCodes) return true
        }

        val noiseHits = words.count { it in weakNoiseWords }
        return noiseHits >= 2 && !hasTechnicalContext(q)
    }

    fun isUnsafeForNet(question: String): Boolean {
        val q = normalize(question)
        if (isTooUnclearForJsonOrNet(q)) return true

        // NET debe aceptar preguntas claras aunque tengan una sola palabra importante.
        // Ejemplo: "que es cateo" tiene un solo contenido (cateo), pero es una pregunta válida.
        // El bloqueo fuerte se deja solo para texto vacío, ruido o frases sin sentido.
        return false
    }

    private fun shouldConfirmRecognizedQuestion(
        q: String,
        qWords: List<String>,
        content: List<String>,
        hasQuestionIntent: Boolean
    ): Boolean {
        if (content.isEmpty()) return false
        if (content.any { it in likelyBadSingleWords }) return true

        val hasKnown = knownTechnicalTerms.any { term -> containsKnownTerm(q, term) }
        val hasClearCode = content.any { it in clearShortCodes }
        if (hasKnown || hasClearCode) return false

        // No confirmar preguntas claras solo por ser cortas.
        // Ejemplo: "que es cateo", "que es amor" o "cuantos dias tiene 2026"
        // deben pasar a JSON/NET, no quedarse esperando si/no.
        if (hasQuestionIntent) {
            val veryWeak = content.size == 1 && content.first().length <= 2
            val noisy = qWords.count { it in weakNoiseWords } >= 2
            return veryWeak || noisy
        }

        // Sin intencion de pregunta, una o dos palabras sueltas si son dudosas.
        return qWords.size <= 2 && content.size <= 1
    }

    private fun findNearTechnicalTerm(contentPhrase: String, content: List<String>): String? {
        if (content.isEmpty()) return null
        val candidates = buildList {
            if (contentPhrase.isNotBlank()) add(contentPhrase)
            content.forEach { add(it) }
        }

        for (candidate in candidates.distinct()) {
            if (candidate in knownTechnicalTerms || candidate in clearShortCodes) continue
            val best = nearTermTargets
                .filter { target -> target.length >= 3 }
                .map { target -> target to editDistance(candidate, target) }
                .minByOrNull { it.second }
                ?: continue

            val target = best.first
            val distance = best.second
            val limit = when {
                target.length <= 4 -> 1
                target.length <= 7 -> 2
                else -> 3
            }

            if (distance <= limit && hasUsefulOverlap(candidate, target)) {
                return target
            }
        }

        return null
    }

    private fun hasUsefulOverlap(a: String, b: String): Boolean {
        if (a.isBlank() || b.isBlank()) return false
        if (a.first() == b.first()) return true
        if (a.length >= 4 && b.length >= 4 && a.takeLast(3) == b.takeLast(3)) return true
        if (a.length >= 5 && b.length >= 5 && a.drop(1).take(3) == b.drop(1).take(3)) return true
        return false
    }

    private fun buildConfirmedQuestion(q: String, term: String, hasQuestionIntent: Boolean): String {
        if (!hasQuestionIntent) return "que es $term"
        val words = q.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }
        if (content.isEmpty()) return "que es $term"

        var fixed = q
        content.sortedByDescending { it.length }.forEach { bad ->
            fixed = fixed.replace("\\b${Regex.escape(bad)}\\b".toRegex(), term)
        }
        return fixed.replace("\\s+".toRegex(), " ").trim()
    }

    private fun containsKnownTerm(q: String, term: String): Boolean {
        return q == term || q.contains(" $term ") || q.startsWith("$term ") || q.endsWith(" $term")
    }

    private fun speakableLabel(text: String): String {
        return text
            .replace("bm", "BM")
            .replace("cp", "CP")
            .replace("va", "VA")
            .replace("vi", "VI")
            .replace("vf", "VF")
            .replace("ai", "AI")
            .replace("epp", "EPP")
            .replace("eia", "EIA")
            .replace("dia", "DIA")
            .replace("gps", "GPS")
            .replace("utm", "UTM")
            .replace("iperc", "IPERC")
            .replace("ats", "ATS")
            .replace("pets", "PETS")
            .replace("sctr", "SCTR")
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isBlank()) return b.length
        if (b.isBlank()) return a.length

        val previous = IntArray(b.length + 1) { it }
        val current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = min(
                    min(current[j - 1] + 1, previous[j] + 1),
                    previous[j - 1] + cost
                )
            }
            for (j in previous.indices) previous[j] = current[j]
        }

        return previous[b.length]
    }

    private fun hasTechnicalContext(q: String): Boolean {
        val words = q.split(" ").filter { it.isNotBlank() }.toSet()
        return words.any { it in technicalContextWords } ||
            q.contains("banco de nivel") ||
            q.contains("vista atras") ||
            q.contains("vista adelante") ||
            q.contains("vista intermedia") ||
            q.contains("altura de instrumento")
    }

    private fun strengthenTechnicalIntent(input: String): String {
        return input.replace("\\s+".toRegex(), " ").trim()
    }
}
