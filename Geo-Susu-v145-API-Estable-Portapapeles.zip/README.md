Geo Susu v145 - API estable y portapapeles

Cambios principales:
- NET/API ya no debe usar "No entendí" para fallas de API. Esa frase queda solo para problemas de voz o confirmación.
- El prompt de NET obliga a responder la pregunta clara y prohíbe culpar al audio.
- Si una API devuelve respuesta inútil, incompleta, interna o "repite la pregunta", la app la marca en espera y prueba otra API.
- Si ninguna API sirve, muestra error de API: no dice que no entendió tu voz.
- Configuración API actualizada a v145.
- Botón PEGAR PORTAPAPELES para pegar rápido varias APIs copiadas.
- Botón LIMPIAR CUADRO para borrar el texto pegado sin borrar claves guardadas.
- Se conserva LIMPIAR ESPERA/ERROR, PROBAR API, detección de proveedor por formato, AUTO local -> JSON -> NET/API, y confirmación sí/no de 3 segundos.

Forma correcta de pegar APIs:
Una API por línea, sin números ni comas.
