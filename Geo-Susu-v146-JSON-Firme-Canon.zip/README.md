Geo Susu v146 - JSON firme + confirmacion corregida

Cambios principales:
- La confirmacion inteligente ya no bloquea preguntas claras del JSON como "que es el canon minero".
- "No entendi / Repite la pregunta" queda para voz dudosa, no para preguntas claras.
- Se agregaron anclas tecnicas: canon minero, regalias mineras y terminos de legislacion/mineria.
- El lector JSON acepta variantes como arreglo o como texto separado por comas, punto y coma o barra vertical.
- Se mantiene AUTO: local rapido -> JSON -> NET/API.
- Se mantiene API estable y botones de portapapeles de v145.

Prueba sugerida:
1. Modo JSON.
2. Pregunta: que es el canon minero.
3. Debe buscar en JSON directo, sin pedir confirmacion y sin decir Repite la pregunta.
