package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class JsonKnowledgeRepository(private val context: Context) {

    data class KnowledgeItem(
        val id: String,
        val tema: String,
        val titulo: String,
        val contenido: String,
        val keywords: List<String>,
        val normalizedId: String,
        val normalizedTema: String,
        val normalizedTitulo: String,
        val normalizedContenido: String,
        val normalizedKeywords: List<String>,
        val normalizedPhrases: List<String>,
        val meta: String
    )

    private data class RepositoryData(
        val items: List<KnowledgeItem>,
        val exactIndex: Map<String, KnowledgeItem>,
        val invertedIndex: Map<String, List<KnowledgeItem>>
    )

    private val data: RepositoryData by lazy { loadDataCached() }

    val totalItems: Int get() = data.items.size

    fun findBest(rawQuestion: String): ResponseRepository.MatchResult {
        return try {
            findBestInternal(rawQuestion)
        } catch (_: Exception) {
            ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }
    }

    private fun findBestInternal(rawQuestion: String): ResponseRepository.MatchResult {
        val question = normalizeForJson(rawQuestion)
        val items = data.items
        if (question.length < 2 || items.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val forms = queryForms(question)

        // 1) Primero busca EXACTO en preguntas, variantes, aliases, keywords y titulos.
        // Esto evita que una palabra suelta active la primera respuesta parecida.
        for (form in forms) {
            data.exactIndex[form]?.let { item ->
                return ResponseRepository.MatchResult(buildAnswer(item), "json_${item.id}", 100)
            }
        }

        val qWords = keyWords(question)
        if (qWords.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        // Si el audio solo reconoce una palabra vaga como "tipo", no inventa respuesta.
        if (qWords.size == 1 && qWords.first() in vagueSingleWords) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val coreQuestion = qWords.joinToString(" ")
        data.exactIndex[coreQuestion]?.let { item ->
            return ResponseRepository.MatchResult(buildAnswer(item), "json_${item.id}", 99)
        }

        val importantPhrase = protectedPhrase(question)
        val candidates = candidateItems(qWords, importantPhrase, data.invertedIndex, items)
        if (candidates.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        var best: KnowledgeItem? = null
        var bestScore = -9999
        var secondScore = -9999

        for (item in candidates) {
            val score = scoreItem(question, forms, coreQuestion, qWords, importantPhrase, item)
            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                best = item
            } else if (score > secondScore) {
                secondScore = score
            }
        }

        val item = best ?: return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        val minimum = when {
            importantPhrase.isNotBlank() -> 110
            qWords.size == 1 -> 120
            qWords.size == 2 -> 125
            else -> 130
        }

        // Si no hay una coincidencia real en preguntas/variantes/titulo, no responde cualquier cosa.
        if (bestScore < minimum) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        // Si dos respuestas son casi iguales, evita elegir al azar.
        if (bestScore < 250 && bestScore - secondScore < 12) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        return ResponseRepository.MatchResult(
            buildAnswer(item),
            "json_${item.id}",
            bestScore.coerceIn(0, 100)
        )
    }

    private fun scoreItem(
        question: String,
        forms: List<String>,
        coreQuestion: String,
        qWords: List<String>,
        importantPhrase: String,
        item: KnowledgeItem
    ): Int {
        var score = 0
        val qSet = qWords.toSet()

        // Frases exactas y variantes mandan. El contenido no decide solo.
        for (phrase in item.normalizedPhrases) {
            if (phrase.length < 3) continue
            if (phrase in forms) score += 2000

            val phraseCoreWords = keyWords(phrase)
            if (phraseCoreWords.isEmpty()) continue
            val phraseCore = phraseCoreWords.joinToString(" ")

            if (coreQuestion.isNotBlank() && coreQuestion == phraseCore) score += 1700
            if (phraseCoreWords.size >= 2 && phraseCoreWords.all { it in qSet } && qSet.all { it in phraseCoreWords }) {
                score += 1300
            }
            if (phraseCoreWords.size >= 2 && phraseCoreWords.all { it in qSet }) {
                score += 430
            }
        }

        if (importantPhrase.isNotBlank()) {
            if (containsTerm(item.normalizedTitulo, importantPhrase)) score += 650
            if (containsTerm(item.meta, importantPhrase)) score += 420
            if (containsTerm(item.normalizedContenido, importantPhrase)) score += 60
        }

        if (coreQuestion.length >= 3) {
            if (containsTerm(item.normalizedTitulo, coreQuestion)) score += 420
            if (containsTerm(item.normalizedId, coreQuestion)) score += 330
            if (containsTerm(item.meta, coreQuestion)) score += 220
        }

        val titleWords = keyWords(item.normalizedTitulo).toSet()
        val idWords = keyWords(item.normalizedId).toSet()
        val keywordWords = item.normalizedKeywords.flatMap { keyWords(it) }.toSet()
        val metaWords = keyWords(item.meta).toSet()
        val contentWords = keyWords(item.normalizedContenido).toSet()

        var titleHits = 0
        var keywordHits = 0
        for (w in qWords) {
            if (w in titleWords) {
                score += 95
                titleHits++
            }
            if (w in idWords) score += 65
            if (w in keywordWords) {
                score += 80
                keywordHits++
            }
            if (w in metaWords) score += 22
            if (w in contentWords) score += 5
        }

        // Bonificacion solo cuando la mayoria de palabras reales aparece en titulo/variantes.
        if (qWords.isNotEmpty() && (titleHits + keywordHits) >= qWords.size) {
            score += 120
        }

        score += intentScore(question, item.meta)
        return score
    }

    private fun buildExactIndex(source: List<KnowledgeItem>): Map<String, KnowledgeItem> {
        val map = LinkedHashMap<String, KnowledgeItem>()
        for (item in source) {
            for (candidate in item.normalizedPhrases) {
                val c = candidate.trim()
                if ((c.length >= 3 || c in technicalShortWords) && c !in vagueSingleWords) map.putIfAbsent(c, item)

                val coreWords = keyWords(c)
                val compactCore = coreWords.joinToString(" ")
                if (compactCore.length >= 3) {
                    if (coreWords.size >= 2 || compactCore !in vagueSingleWords) {
                        map.putIfAbsent(compactCore, item)
                    }
                }
            }
        }
        return map
    }

    private fun buildInvertedIndex(source: List<KnowledgeItem>): Map<String, List<KnowledgeItem>> {
        val map = LinkedHashMap<String, LinkedHashSet<KnowledgeItem>>()
        for (item in source) {
            val text = "${item.normalizedId} ${item.normalizedTema} ${item.normalizedTitulo} ${item.normalizedKeywords.joinToString(" ")}"
            for (word in keyWords(text)) {
                map.getOrPut(word) { linkedSetOf() }.add(item)
            }
        }
        return map.mapValues { it.value.toList() }
    }

    private fun candidateItems(
        qWords: List<String>,
        importantPhrase: String,
        index: Map<String, List<KnowledgeItem>>,
        allItems: List<KnowledgeItem>
    ): List<KnowledgeItem> {
        val candidates = LinkedHashSet<KnowledgeItem>()
        val lookupWords = (qWords + keyWords(importantPhrase)).distinct()
        for (word in lookupWords) {
            index[word]?.let { candidates.addAll(it) }
        }

        if (candidates.isNotEmpty()) return candidates.toList()

        // Recorre todo solo si hay suficientes palabras reales. Nunca por una palabra vaga.
        return if (qWords.size >= 2 || importantPhrase.isNotBlank()) allItems else emptyList()
    }

    private fun buildAnswer(item: KnowledgeItem): String {
        val clean = item.contenido
            .replace("\r", " ")
            .replace("\n", " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
        val limited = clean.take(540).trim()
        return if (clean.length > 540) "$limited..." else limited
    }

    private fun protectedPhrase(question: String): String {
        val q = " $question "
        val phrases = listOf(
            "bm",
            "banco de nivel",
            "cota",
            "cotas",
            "cp",
            "cambio de punto",
            "va",
            "vista atras",
            "vi",
            "vista intermedia",
            "vf",
            "vista adelante",
            "ai",
            "altura de instrumento",
            "nivelacion",
            "replanteo topografico",
            "levantamiento topografico",
            "topografia superficial",
            "minerales no metalicos",
            "no metalicos",
            "minerales semimetalicos",
            "semimetalicos",
            "minerales metalicos",
            "metalicos",
            "minerales nativos",
            "nativos",
            "sulfosales",
            "sulfatos",
            "sulfuros",
            "escala de mohs",
            "escala de mosh",
            "materiales comunes",
            "minerales importantes por metal",
            "minerales importantes",
            "tipos de roca",
            "tipo de roca",
            "tipos de rocas",
            "tipo de rocas",
            "rocas igneas",
            "roca ignea",
            "rocas sedimentarias",
            "roca sedimentaria",
            "rocas metamorficas",
            "roca metamorfica",
            "calcopirita",
            "calco pirita",
            "pirita",
            "galena",
            "antapaccay",
            "antapacay",
            "porfido",
            "skarn",
            "logueo geologico",
            "logeo geologico",
            "recursos geologicos",
            "yacimiento minero",
            "mina antapaccay",
            "canon minero",
            "regalia minera",
            "regalias mineras",
            "mena",
            "ley mineral",
            "ley"
        )

        for (p in phrases) {
            if (q.contains(" $p ")) {
                if (p == "metalicos" && (q.contains(" no metalicos ") || q.contains(" semimetalicos "))) continue
                if (p == "pirita" && q.contains(" calcopirita ")) continue
                if (p == "ley" && !q.contains(" ley ")) continue
                return normalizeProtected(p)
            }
        }

        return ""
    }

    private fun normalizeProtected(phrase: String): String {
        return when (phrase) {
            "escala de mosh" -> "escala de mohs"
            "calco pirita" -> "calcopirita"
            "antapacay" -> "antapaccay"
            "logeo geologico" -> "logueo geologico"
            "tipo de roca", "tipos de rocas", "tipo de rocas" -> "tipos de roca"
            "roca ignea" -> "rocas igneas"
            "roca sedimentaria" -> "rocas sedimentarias"
            "roca metamorfica" -> "rocas metamorficas"
            else -> phrase
        }
    }

    private fun intentScore(question: String, meta: String): Int {
        var score = 0

        if ((question.contains("ejemplo") || question.contains("menciona")) &&
            (meta.contains("ejemplo") || meta.contains("ejemplos"))) score += 180

        if ((question.contains("caracteristica") || question.contains("propiedad")) &&
            (meta.contains("caracteristica") || meta.contains("propiedad"))) score += 120

        if ((question.contains("importancia") || question.contains("importante")) &&
            meta.contains("importancia")) score += 120

        if ((question.contains("para que sirve") || question.contains("funcion") || question.contains("uso")) &&
            (meta.contains("sirve") || meta.contains("funcion") || meta.contains("uso"))) score += 120

        if ((question.contains("diferencia") || question.contains("diferenciar")) &&
            meta.contains("diferencia")) score += 120

        if ((question.contains("clasifica") || question.contains("clasificacion") || question.contains("clases")) &&
            meta.contains("clasificacion")) score += 120

        if ((question.contains("formula") || question.contains("simbolo") || question.contains("quimica")) &&
            (meta.contains("formula") || meta.contains("simbolo") || meta.contains("quimica"))) score += 120

        return score
    }

    private fun containsTerm(text: String, term: String): Boolean {
        if (term.length < 3) return false
        val paddedText = " $text "
        val paddedTerm = " $term "
        return paddedText.contains(paddedTerm) || text.contains(term)
    }

    private fun loadDataCached(): RepositoryData {
        val store = JsonKnowledgeStore(context)
        val cacheKey = store.cacheKey()
        synchronized(cacheLock) {
            cachedData?.let { cached ->
                if (cachedKey == cacheKey) return cached
            }
        }

        val items = loadItems()
        val built = RepositoryData(
            items = items,
            exactIndex = buildExactIndex(items),
            invertedIndex = buildInvertedIndex(items)
        )

        synchronized(cacheLock) {
            cachedKey = cacheKey
            cachedData = built
        }

        return built
    }

    private fun loadItems(): List<KnowledgeItem> {
        val store = JsonKnowledgeStore(context)
        val raw = store.readJson()
        val variantsMap = loadVariantsMap(store.readVariantsJson())
        if (raw.isBlank()) return emptyList()

        return try {
            val trimmed = raw.trim()
            val array = when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> {
                    val obj = JSONObject(trimmed)
                    obj.optJSONArray("temas")
                        ?: obj.optJSONArray("items")
                        ?: obj.optJSONArray("data")
                        ?: JSONArray()
                }
            }

            val result = mutableListOf<KnowledgeItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val tema = obj.optString("tema", obj.optString("categoria", "General")).trim()
                val titulo = obj.optString(
                    "titulo",
                    obj.optString("pregunta", obj.optString("nombre", tema))
                ).trim()
                val contenido = obj.optString(
                    "contenido",
                    obj.optString("respuesta", obj.optString("texto", obj.optString("descripcion", "")))
                ).trim()

                if (contenido.isBlank()) continue

                val id = obj.optString("id", "item_$i").ifBlank { "item_$i" }
                val keywords = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "palabrasClave") +
                    readStringArray(obj, "negativos") +
                    variantsMap[id].orEmpty() +
                    variantsMap[ResponseRepository.normalize(titulo)].orEmpty() +
                    variantsMap[ResponseRepository.normalize(tema)].orEmpty()

                val cleanKeywords = keywords
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()

                val normalizedId = normalizeForJson(id.replace("_", " "))
                val normalizedTema = normalizeForJson(tema)
                val normalizedTitulo = normalizeForJson(titulo)
                val normalizedContenido = normalizeForJson(contenido.take(1200))
                val normalizedKeywords = cleanKeywords
                    .map { normalizeForJson(it) }
                    .filter { it.length >= 3 }
                    .distinct()

                val phraseSeed = listOf(normalizedId, normalizedTema, normalizedTitulo) + normalizedKeywords
                val normalizedPhrases = phraseSeed
                    .flatMap { queryForms(it) }
                    .filter { it.length >= 3 }
                    .distinct()

                val meta = "$normalizedId $normalizedTema $normalizedTitulo ${normalizedKeywords.joinToString(" ")}"

                result.add(
                    KnowledgeItem(
                        id = id,
                        tema = tema.ifBlank { "General" },
                        titulo = titulo.ifBlank { tema.ifBlank { "Tema $i" } },
                        contenido = contenido,
                        keywords = cleanKeywords,
                        normalizedId = normalizedId,
                        normalizedTema = normalizedTema,
                        normalizedTitulo = normalizedTitulo,
                        normalizedContenido = normalizedContenido,
                        normalizedKeywords = normalizedKeywords,
                        normalizedPhrases = normalizedPhrases,
                        meta = meta
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun loadVariantsMap(raw: String): Map<String, List<String>> {
        if (raw.isBlank()) return emptyMap()

        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("variantes")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }

            val result = linkedMapOf<String, MutableList<String>>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val key = obj.optString(
                    "id",
                    obj.optString("tema", obj.optString("titulo", obj.optString("pregunta", "")))
                ).trim()
                if (key.isBlank()) continue

                val values = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "palabrasClave")

                if (values.isNotEmpty()) {
                    val normalizedKey = ResponseRepository.normalize(key)
                    result.getOrPut(key) { mutableListOf() }.addAll(values)
                    result.getOrPut(normalizedKey) { mutableListOf() }.addAll(values)
                }
            }

            result.mapValues { it.value.distinct() }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun readStringArray(obj: JSONObject, key: String): List<String> {
        val value = obj.opt(key) ?: return emptyList()
        val list = mutableListOf<String>()

        if (value is JSONArray) {
            for (i in 0 until value.length()) {
                val text = value.optString(i).trim()
                if (text.isNotBlank()) list.add(text)
            }
            return list
        }

        val text = value.toString().trim()
        if (text.isBlank() || text == "null") return emptyList()

        return text
            .split("|", ";", ",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    private fun queryForms(text: String): List<String> {
        val result = linkedSetOf<String>()
        val clean = normalizeForJson(text)
        if (clean.isNotBlank()) result.add(clean)

        val core = keyWords(clean).joinToString(" ")
        if (core.isNotBlank()) result.add(core)

        val protected = protectedPhrase(clean)
        if (protected.isNotBlank()) {
            result.add(protected)
            val pCore = keyWords(protected).joinToString(" ")
            if (pCore.isNotBlank()) result.add(pCore)
        }

        return result.toList()
    }

    private fun keyWords(text: String): List<String> {
        return text.split(" ")
            .map { canonicalWord(it.trim()) }
            .filter { (it.length >= 3 || it in technicalShortWords) && it !in stopWords }
            .distinct()
            .take(12)
    }

    private fun normalizeForJson(text: String): String {
        var output = ResponseRepository.normalize(text)
        val corrections = linkedMapOf(
            "tipo de rocas" to "tipos de roca",
            "tipo de roca" to "tipos de roca",
            "tipos de rocas" to "tipos de roca",
            "tipo rocas" to "tipos de roca",
            "tipo roca" to "tipos de roca",
            "tipos rocas" to "tipos de roca",
            "tipos roca" to "tipos de roca",
            "tipo de socas" to "tipos de roca",
            "tipos de socas" to "tipos de roca",
            "tipo de soca" to "tipos de roca",
            "tipos de soca" to "tipos de roca",
            "tipos de loca" to "tipos de roca",
            "tipo de loca" to "tipos de roca",
            "socas" to "rocas",
            "soca" to "roca",
            "locas" to "rocas",
            "loca" to "roca",
            "escala de mosh" to "escala de mohs",
            "calco pirita" to "calcopirita",
            "antapacay" to "antapaccay",
            "logeo geologico" to "logueo geologico",
            "kateo" to "cateo",
            "catio" to "cateo",
            "cateu" to "cateo",
            "mieria" to "mineria",
            "miniria" to "mineria",
            "menerea" to "mineria",
            "meneria" to "mineria",
            "be eme" to "bm",
            "ve eme" to "bm",
            "bi em" to "bm",
            "be me" to "bm",
            "bebe" to "bm",
            "bebé" to "bm",
            "pm" to "bm",
            "p m" to "bm",
            "cuota" to "cota",
            "cuotas" to "cotas",
            "ce pe" to "cp",
            "c p" to "cp",
            "ve a" to "va",
            "v a" to "va",
            "ve i" to "vi",
            "v i" to "vi",
            "ve efe" to "vf",
            "v f" to "vf",
            "a i" to "ai",
            "altura instrumental" to "altura de instrumento",
            "banco nivel" to "banco de nivel"
        )
        for ((bad, good) in corrections) {
            output = output.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }
        return output.replace("\\s+".toRegex(), " ").trim()
    }

    private fun canonicalWord(word: String): String {
        return when (word) {
            "rocas" -> "roca"
            "igneas" -> "ignea"
            "sedimentarias" -> "sedimentaria"
            "metamorficas" -> "metamorfica"
            "metalicos" -> "metalico"
            "metalicas" -> "metalica"
            "minerales" -> "mineral"
            "mineras", "mineros", "minera" -> "minero"
            "regalias" -> "regalia"
            "tipos", "tipo" -> "tipos"
            "clases", "clase" -> "clases"
            else -> {
                if (word.length > 6 && word.endsWith("s") && !word.endsWith("is")) word.dropLast(1) else word
            }
        }
    }

    companion object {
        const val JSON_EMPTY = "No encontrado"
        const val JSON_NOT_FOUND = "No encontrado"

        private val cacheLock = Any()
        @Volatile private var cachedKey: String = ""
        @Volatile private var cachedData: RepositoryData? = null

        private val technicalShortWords = setOf("bm", "cp", "va", "vi", "vf", "ai")

        private val stopWords = setOf(
            "que", "qué", "q", "ke", "k", "es", "son", "ser", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuál", "cuales", "cuáles",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa",
            "internet", "net", "json", "tema", "sobre", "explica", "breve", "rapido", "rápido",
            "respuesta", "pregunta", "habla", "susurra"
        )

        private val vagueSingleWords = setOf(
            "tipo", "tipos", "clase", "clases", "tema", "pregunta", "respuesta", "ejemplo", "ejemplos",
            "roca", "rocas", "actividad", "proceso", "cosa", "cosas"
        )
    }
}

class JsonKnowledgeStore(private val context: Context) {

    fun getUrl(): String {
        return prefs().getString(KEY_URL, "").orEmpty().trim()
    }

    fun saveUrl(url: String) {
        prefs().edit().putString(KEY_URL, url.trim()).apply()
    }

    fun getVariantsUrl(): String {
        return prefs().getString(KEY_VARIANTS_URL, "").orEmpty().trim()
    }

    fun saveVariantsUrl(url: String) {
        prefs().edit().putString(KEY_VARIANTS_URL, url.trim()).apply()
    }

    fun clearVariantsConfig() {
        prefs().edit().putString(KEY_VARIANTS_URL, "").apply()
        File(context.filesDir, VARIANTS_FILE).delete()
    }

    fun cacheKey(): String {
        val jsonFile = File(context.filesDir, JSON_FILE)
        val variantsFile = File(context.filesDir, VARIANTS_FILE)
        return listOf(
            jsonFile.length(),
            jsonFile.lastModified(),
            variantsFile.length(),
            variantsFile.lastModified()
        ).joinToString(":")
    }

    fun readJson(): String {
        val file = File(context.filesDir, JSON_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun hasJson(): Boolean {
        return readJson().isNotBlank()
    }

    fun readVariantsJson(): String {
        val file = File(context.filesDir, VARIANTS_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun downloadVariantsJson(): Pair<Boolean, String> {
        val url = getVariantsUrl()
        if (url.isBlank()) return true to "Sin JSON de variantes."
        return downloadToFile(url, VARIANTS_FILE, "Variantes JSON")
    }

    fun downloadJson(): Pair<Boolean, String> {
        val url = getUrl()
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }
        return downloadToFile(url, JSON_FILE, "Temas JSON")
    }

    private fun downloadToFile(url: String, fileName: String, label: String): Pair<Boolean, String> {
        if (!url.startsWith("https://")) {
            return false to "Pega un link https directo de GitHub Raw."
        }

        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.setRequestProperty("User-Agent", "GeoSusuAudio Android")
            connection.setRequestProperty("Accept", "application/json,text/plain,*/*")

            val raw = try {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally {
                connection.disconnect()
            }

            if (raw.isBlank()) return false to "$label descargado está vacío."

            val count = countItems(raw)
            if (count <= 0) return false to "$label no parece válido."

            File(context.filesDir, fileName).writeText(raw)
            true to "$label actualizado. Elementos: $count"
        } catch (_: Exception) {
            false to "No se pudo descargar $label. Revisa link o internet."
        }
    }

    private fun countItems(raw: String): Int {
        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val obj = JSONObject(trimmed)
                obj.optJSONArray("temas")
                    ?: obj.optJSONArray("items")
                    ?: obj.optJSONArray("data")
                    ?: JSONArray()
            }
            array.length()
        } catch (_: Exception) {
            0
        }
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS = "geo_susu_json"
        private const val KEY_URL = "json_url"
        private const val KEY_VARIANTS_URL = "json_variants_url"
        private const val JSON_FILE = "temas_github.json"
        private const val VARIANTS_FILE = "variantes_github.json"
    }
}
