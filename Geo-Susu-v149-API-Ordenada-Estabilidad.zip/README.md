Geo Susu v149 - API ordenada + estabilidad JSON/NET

Cambios principales:
- Mantiene estabilidad v148: AUTO = local rapido -> JSON seguro -> NET/API.
- JSON por intencion para evitar respuestas genericas equivocadas.
- Servicio no se detiene solo por salir de la pantalla.
- API ordenada: estado arriba, probar API arriba, limpiar espera/error arriba.
- Pegado rapido de APIs: pegar portapapeles, importar lista y limpiar cuadro sin bajar tanto.
- Lista de APIs queda oculta por defecto; se muestra solo para editar una por una.
- Mantiene deteccion automatica de proveedor por formato de clave.

Sube este ZIP a GitHub como proyecto Android.
