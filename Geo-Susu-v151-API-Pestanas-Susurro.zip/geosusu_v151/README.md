Geo Susu v151

API con pestañas fijas: UNA, MASA, LISTA y PROBAR. Botones Probar/Guardar siempre visibles. Mantiene estabilidad JSON/NET de v149.
