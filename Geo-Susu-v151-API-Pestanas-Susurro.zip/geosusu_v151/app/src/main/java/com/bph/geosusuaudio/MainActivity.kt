package com.bph.geosusuaudio

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bph.geosusuaudio.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: ResponseRepository
    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var memory: MemoryStore
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }
    private lateinit var modelManager: VoskModelManager
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private var tts: TextToSpeech? = null
    private var pendingStartMode = ""
    private var googleLoopRunning = false
    private var lastAutoQuestionKey = ""
    private var lastAutoAnswerSource = ""
    private var lastAutoAnswerTime = 0L
    private val editorPrefs by lazy { getSharedPreferences("geo_susu_txt_editor", Context.MODE_PRIVATE) }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            when (pendingStartMode) {
                "vosk" -> if (modelManager.isReady()) startVoskService() else downloadOffline(startAfter = true)
                "wake" -> if (modelManager.isReady()) startVoskWakeService() else downloadOffline(startAfter = true)
                "google" -> launchGooglePrecise()
                else -> startGoogleInternalService()
            }
        } else {
            binding.tvStatus.text = "Permiso de micrófono denegado"
            binding.tvAnswer.text = "Activa el permiso de micrófono."
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        when (pendingStartMode) {
            "vosk" -> if (modelManager.isReady()) startVoskService() else downloadOffline(startAfter = true)
            "wake" -> if (modelManager.isReady()) startVoskWakeService() else downloadOffline(startAfter = true)
            "google" -> launchGooglePrecise()
            else -> startGoogleInternalService()
        }
    }

    private val openQaFileLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) importTxtFromUri(uri, "qa")
    }

    private val openVarFileLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) importTxtFromUri(uri, "variants")
    }

    private val googleVoiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (!googleLoopRunning) return@registerForActivityResult

        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                .orEmpty()

            val best = matches
                .map { it.trim() }
                .firstOrNull { it.isNotBlank() }
                .orEmpty()

            if (best.isNotBlank()) {
                processQuestion(best, useOnlineFallback = true)
            } else {
                binding.tvStatus.text = "Google no entendió. Reintentando..."
                reopenGooglePrecise(550)
            }
        } else {
            binding.tvStatus.text = "Google no entendió. Reintentando..."
            reopenGooglePrecise(700)
        }
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == VoskListenService.ACTION_WAKE_GOOGLE) {
                launchGooglePrecise()
                return
            }

            val status = intent?.getStringExtra(VoskListenService.EXTRA_STATUS)
                ?: intent?.getStringExtra(GoogleInternalListenService.EXTRA_STATUS)
                ?: ""
            val heard = intent?.getStringExtra(VoskListenService.EXTRA_HEARD)
                ?: intent?.getStringExtra(GoogleInternalListenService.EXTRA_HEARD)
                ?: ""
            val answer = intent?.getStringExtra(VoskListenService.EXTRA_ANSWER)
                ?: intent?.getStringExtra(GoogleInternalListenService.EXTRA_ANSWER)
                ?: ""

            if (status.isNotBlank()) binding.tvStatus.text = status
            if (heard.isNotBlank()) binding.tvHeard.text = "Pregunta: $heard"
            if (answer.isNotBlank()) {
                binding.tvAnswer.text = answer
                if (heard.isNotBlank()) memory.saveLast(heard, answer, "service", 0)
            }

            val level = intent?.getIntExtra(VoskListenService.EXTRA_LEVEL, -1) ?: -1
            if (level >= 0) {
                binding.pbVoiceLevel.progress = level
                binding.tvVoiceLevel.text = when {
                    level < 15 -> "Muy bajo: acerca el Zync o sube voz. Nivel $level%"
                    level > 85 -> "Muy fuerte: baja un poco. Nivel $level%"
                    else -> "Nivel correcto: $level%"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        resetModeToTxtOnce()
        seedTxtIfEmpty()
        repository = ResponseRepository(this)
        jsonRepository = JsonKnowledgeRepository(this)
        tts = TextToSpeech(this, this)

        setupUi()
        warmJsonInBackground()
        binding.tvStatus.text = "Susurro Google + JSON/NET"
        binding.tvAnswer.text = "Ahora reconoce el susurro, corrige la pregunta y luego usa JSON o NET según el modo."
        handleStartIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleStartIntent(intent)
    }

    private fun handleStartIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_START_GOOGLE, false) == true) {
            appSettings.setListenEngine(AppSettings.ListenEngine.GOOGLE_INTERNAL)
            binding.tvStatus.text = "Google interno solicitado"
            binding.tvAnswer.text = "Iniciando escucha interna."
            binding.root.postDelayed({
                startGoogleInternalService()
            }, 600L)
        }
    }

    private fun resetModeToTxtOnce() {
        val prefs = getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        var changed = false

        if (!prefs.getBoolean("v19_txt_default_done", false)) {
            modeSettings.setMode(AnswerModeSettings.Mode.AUTO)
            editor.putBoolean("v19_txt_default_done", true)
            changed = true
        }

        if (!prefs.getBoolean("v110_auto_default_done", false)) {
            modeSettings.setMode(AnswerModeSettings.Mode.AUTO)
            editor.putBoolean("v110_auto_default_done", true)
            changed = true
        }

        if (changed) editor.apply()
    }

    private fun seedTxtIfEmpty() {
        val prefs = getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)

        if (!prefs.getBoolean("v78_manual_clean_done", false)) {
            prefs.edit()
                .putString("custom_items", "[]")
                .putString("last_heard", "Sin preguntas todavía")
                .putString("last_answer", "")
                .putString("last_item_id", "")
                .putInt("last_score", 0)
                .putInt("total_answers", 0)
                .putBoolean("v78_manual_clean_done", true)
                .apply()

            editorPrefs.edit()
                .putString(KEY_TXT_QA, "")
                .putString(KEY_TXT_VARIANTS, "")
                .apply()
        }
    }

    private fun mergeVariantLines(current: String, extra: String): String {
        val map = linkedMapOf<String, LinkedHashSet<String>>()

        fun addBlock(block: String) {
            block.lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .forEach { line ->
                    val key = line.substringBefore("|").trim()
                    val values = line.substringAfter("|", "").split(",", ";")
                        .map { it.trim() }
                        .filter { it.isNotBlank() }

                    if (key.isNotBlank() && values.isNotEmpty()) {
                        val set = map.getOrPut(key.lowercase()) { linkedSetOf() }
                        values.forEach { set.add(it) }
                    }
                }
        }

        addBlock(current)
        addBlock(extra)

        return map.entries.joinToString("\n") { (key, values) ->
            "$key | ${values.joinToString(", ")}"
        }.trim()
    }

    private fun mergeTxtLines(current: String, extra: String): String {
        val existingKeys = current.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .map { it.substringBefore("|").trim().lowercase() }
            .toMutableSet()

        val output = StringBuilder(current.trim())

        extra.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .forEach { line ->
                val key = line.substringBefore("|").trim().lowercase()
                if (key.isNotBlank() && key !in existingKeys) {
                    if (output.isNotBlank()) output.append("\n")
                    output.append(line)
                    existingKeys.add(key)
                }
            }

        return output.toString().trim()
    }

    private fun applyModeToUi() {
        when (modeSettings.getMode()) {
            AnswerModeSettings.Mode.JSON -> binding.rbJson.isChecked = true
            AnswerModeSettings.Mode.INTERNET -> binding.rbInternet.isChecked = true
            AnswerModeSettings.Mode.AUTO -> binding.rbAuto.isChecked = true
        }
        binding.tvModeMini.text = modeSettings.getLabel()
    }

    private fun rebuildSavedTxtInBackground() {
        // v76: no cargar TXT grande al iniciar para evitar cierres.
    }

    private fun importTxtFromUri(uri: Uri, type: String) {
        val key = if (type == "variants") KEY_TXT_VARIANTS else KEY_TXT_QA
        binding.tvStatus.text = if (type == "variants") {
            "Abriendo TXT VAR..."
        } else {
            "Abriendo TXT P/R..."
        }
        binding.tvAnswer.text = "Cargando archivo."

        Thread {
            try {
                val raw = contentResolver.openInputStream(uri)?.use { input ->
                    input.bufferedReader(Charsets.UTF_8).use { it.readText() }
                }.orEmpty()

                if (raw.isBlank()) error("Archivo TXT vacío")

                editorPrefs.edit().putString(key, raw).commit()

                val qaRaw = if (type == "variants") {
                    editorPrefs.getString(KEY_TXT_QA, "").orEmpty()
                } else {
                    raw
                }

                val variantsRaw = if (type == "variants") {
                    raw
                } else {
                    editorPrefs.getString(KEY_TXT_VARIANTS, "").orEmpty()
                }

                val result = ResponseRepository.replaceInternalTexts(this, qaRaw, variantsRaw)
                val newRepository = ResponseRepository(this)

                runOnUiThread {
                    repository = newRepository
                    binding.tvStatus.text = if (type == "variants") {
                        "TXT VAR archivo cargado. Variantes: ${result.second}"
                    } else {
                        "TXT P/R archivo cargado. Preguntas: ${result.first}"
                    }
                    binding.tvAnswer.text = "Archivo cargado. Ya puedes escuchar."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.tvStatus.text = "No se pudo abrir el TXT"
                    binding.tvAnswer.text = "Usa archivo .txt con formato pregunta | respuesta."
                    Toast.makeText(this, e.message ?: "Error al abrir TXT", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun openQuestionsAnswersTxt() {
        showInternalTxtEditor(
            type = "qa",
            title = "TXT P/R dentro de la app",
            hint = "pregunta | respuesta"
        )
    }

    private fun openVariantsTxt() {
        showInternalTxtEditor(
            type = "variants",
            title = "TXT VAR dentro de la app",
            hint = "pregunta | variante1, variante2"
        )
    }

    private fun showInternalTxtEditor(type: String, title: String, hint: String) {
        val key = if (type == "variants") KEY_TXT_VARIANTS else KEY_TXT_QA
        val current = editorPrefs.getString(key, "").orEmpty()
        val startText = current.ifBlank {
            if (type == "variants") variantsTemplate() else questionsAnswersTemplate()
        }

        val input = EditText(this).apply {
            setText(startText)
            setSelection(0)
            minLines = 8
            maxLines = 12
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setHorizontallyScrolling(false)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("Edita aquí mismo. Luego toca Guardar y cargar.")
            .setView(input)
            .setPositiveButton("Guardar y cargar", null)
            .setNegativeButton("Cerrar", null)
            .show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val raw = input.text.toString()
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            positiveButton.isEnabled = false
            negativeButton.isEnabled = false
            binding.tvStatus.text = "Guardando TXT..."
            binding.tvAnswer.text = "Espera unos segundos."

            Thread {
                try {
                    editorPrefs.edit().putString(key, raw).commit()

                    val qaRaw = if (type == "variants") {
                        editorPrefs.getString(KEY_TXT_QA, "").orEmpty()
                    } else {
                        raw
                    }

                    val variantsRaw = if (type == "variants") {
                        raw
                    } else {
                        editorPrefs.getString(KEY_TXT_VARIANTS, "").orEmpty()
                    }

                    val result = ResponseRepository.replaceInternalTexts(this, qaRaw, variantsRaw)
                    val newRepository = ResponseRepository(this)

                    runOnUiThread {
                        repository = newRepository
                        binding.tvStatus.text = if (type == "variants") {
                            "TXT VAR guardado. Variantes: ${result.second}"
                        } else {
                            "TXT P/R guardado. Preguntas: ${result.first}"
                        }
                        binding.tvAnswer.text = "Guardado dentro de la app."
                        dialog.dismiss()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        positiveButton.isEnabled = true
                        negativeButton.isEnabled = true
                        binding.tvStatus.text = "Error al guardar TXT"
                        binding.tvAnswer.text = "Revisa el formato pregunta | respuesta."
                        Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    private fun questionsAnswersTemplate(): String {
        return ""
    }


    private fun variantsTemplate(): String {
        return ""
    }


    private fun whisperVariantsTemplate(): String {
        return """
# Variantes extras para susurros y errores de Google/Vosk.
mineral | que es mineral, que mineral, ques mineral, que es minerar, que es meniral, minenal, minerar, minerol, mineralito
roca | que es roca, que es soca, que es loca, roca mineral, soca, loca, rocas
tipos de roca | tipo de socas, tipo de rocas, tipos de socas, tipos de rocas, tipo de loca, tipos de loca, rocas igneas, rocas sedimentarias, rocas metamorficas
mena | que es mena, que es nena, que es mema, que es mina, mena mineral, me na, nena, mema, mina, minea
ganga | que es ganga, que es gaga, que es canga, ganga mineral, material sin valor, gaga, canga, aga
tajo abierto | que es tajo abierto, que es bajo abierto, que es tajo, que es bajo, tajo, bajo abierto, tajo aviado, tajo abierto mina, open pit, rajo abierto
minería superficial | que es mineria superficial, mineria a cielo abierto, mineria cielo abierto, mina superficial, explotación superficial
minería subterránea | que es mineria subterranea, mina subterranea, mineria bajo tierra, explotacion subterranea, subterranea
yacimiento | que es yacimiento, yacimento, llacimiento, deposito mineral, depósito mineral, yacimiento mineral
veta | que es veta, que es beta, beta mineral, veta mineral, filon, filón
manto | que es manto, capa mineral, manto mineral, manto mineralizado
ley de mineral | que es ley de mineral, ley mineral, ley del mineral, contenido metalico, contenido metálico, tenor mineral
ley de corte | que es ley de corte, ley minima, ley mínima, cut off, cutoff
reserva mineral | que es reserva mineral, reservas minerales, reserva minera
recurso mineral | que es recurso mineral, recursos minerales, recurso minero
cateo | que es cateo, que es kateo, cate, catio, búsqueda inicial, busqueda inicial
prospección | que es prospeccion, que es prospección, prospeccion minera, busqueda tecnica, búsqueda técnica
exploración minera | que es exploracion minera, exploracion, explotación minera exploracion, exploración
explotación minera | que es explotacion minera, explotacion, extracción minera, extraer mineral, extraccion minera
mina | que es mina, que es una mina, unidad minera, minas
galería | que es galeria, galeria minera, tunel minero, túnel minero, labor horizontal
rampa | que es rampa, rampa minera, labor inclinada, acceso inclinado
pique | que es pique, pozo minero, pique minero, excavacion vertical
chimenea | que es chimenea, chimenea minera, labor vertical
banco | que es banco, banco minero, escalon, escalón, banco de mina
berma | que es berma, berma de seguridad, plataforma de seguridad
talud | que es talud, pared de mina, inclinacion de banco, inclinación de banco
desmonte | que es desmonte, material desmonte, material de desmonte, desmontes
estéril | que es esteril, que es estéril, material esteril, material estéril, roca esteril
dilución | que es dilucion, que es dilución, mezcla con esteril
calcopirita | que es calcopirita, calcopirita cobre, calco pirita, chalcopyrite
pirita | que es pirita, oro de los tontos, sulfuro de hierro
bornita | que es bornita, bornita cobre, bor ni ta, bonita mineral, mineral bornita
galena | que es galena, sulfuro de plomo, galena mineral
esfalerita | que es esfalerita, blenda, sulfuro de zinc, es falerita
hematita | que es hematita, hematites, oxido de hierro, óxido de hierro
magnetita | que es magnetita, mineral magnetico, mineral magnético
cuarzo | que es cuarzo, quartz, silice, sílice
calcita | que es calcita, carbonato de calcio
geología | que es geologia, que es jeologia, estudio de la tierra, geología
topografía | que es topografia, levantamiento topografico, topografía
cota | que es cota, altura de punto, elevacion, elevación
nivelación | que es nivelacion, calcular cotas, nivelación
azimut | que es azimut, que es asimut, azimuth, acimut
rumbo | que es rumbo, rumbo topografico, dirección por cuadrantes
contra azimut | que es contra azimut, contraazimut, azimut inverso
distancia horizontal | que es distancia horizontal, distancia plana, distancia en plano
estación total | que es estacion total, estación total, instrumento topografico
gps | que es gps, gepe ese, posicionamiento global
curva de nivel | que es curva de nivel, curvas de nivel, linea de igual cota
perfil longitudinal | que es perfil longitudinal, perfil del terreno
muestreo | que es muestreo, toma de muestra, muestras
muestra | que es muestra, muestra de mineral, muestra de roca
sondaje | que es sondaje, sondeo, perforacion diamantina
testigo | que es testigo, core, testigo de perforacion
perforación | que es perforacion, perforación, taladro, perforar roca
voladura | que es voladura, disparo, tronadura, romper roca
explosivo | que es explosivo, explosivos, sustancia explosiva
taladro | que es taladro, barreno, agujero de voladura
burden | que es burden, bordo, burden de voladura
espaciamiento | que es espaciamiento, distancia entre taladros
chancado | que es chancado, trituracion, trituración, chancadora
molienda | que es molienda, molino, moler mineral
concentración mineral | que es concentracion mineral, concentracion, beneficio de minerales
flotación | que es flotacion, flotación, floatacion
relave | que es relave, tailing, residuo de planta, residuos de planta
lixiviación | que es lixiviacion, lixiviación, lixiviar
cianuración | que es cianuracion, cianuración, cianuro
ventilación minera | que es ventilacion minera, ventilacion, aire en mina
sostenimiento | que es sostenimiento, soporte de roca, sostenimiento de roca
perno de roca | que es perno de roca, pernos, rock bolt
shotcrete | que es shotcrete, shocret, concreto lanzado
peligro | que es peligro, fuente de daño
riesgo | que es riesgo, probabilidad de daño
incidente | que es incidente, casi accidente
accidente | que es accidente, accidente laboral
pets | que es pets, pet, procedimiento escrito, procedimiento escrito de trabajo seguro
ats | que es ats, analisis de trabajo seguro, análisis de trabajo seguro
iperc | que es iperc, i perc, hiper, iper, peligro riesgo control
iperc continuo | que es iperc continuo, iperc de campo
epp | que es epp, equipo de proteccion personal, e p p, epi
sctr | que es sctr, seguro complementario, seguro de trabajo de riesgo
petitorio minero | que es petitorio minero, petitorio, solicitud minera
concesión minera | que es concesion minera, concesión minera, derecho de concesion
derecho minero | que es derecho minero, derechos mineros
canon minero | que es canon minero, canon
ingemmet | que es ingemmet, instituto geologico minero metalurgico
oefa | que es oefa, fiscalizacion ambiental
osinergmin | que es osinergmin, supervision minera
drem | que es drem, direccion regional de energia y minas
senace | que es senace, certificacion ambiental
eia | que es eia, estudio de impacto ambiental
dia | que es dia, declaracion de impacto ambiental
cierre de minas | que es cierre de minas, plan de cierre, cierre minero
formalización minera | que es formalizacion minera, formalización minera, mineria formal
serfor | que es serfor, servicio forestal, fauna silvestre
ana | que es ana, autoridad nacional del agua
""".trimIndent()
    }


    private fun showSettingsDialog() {
        showApiDialog()
    }

    private fun showApiDialog() {
        val settings = GeminiSettings(this)
        val providers = settings.getProviders()
        val providerLabels = providers.map { it.label }
        val knownDefaultModels = providers.map { it.defaultModel }
        val draftConfigs = settings.getApiConfigs().mapIndexed { index, config -> config.clean(index) }.toMutableList()

        lateinit var dialog: AlertDialog
        lateinit var statusSummary: TextView
        lateinit var tabOne: Button
        lateinit var tabBulk: Button
        lateinit var tabList: Button
        lateinit var tabTest: Button
        lateinit var panelBox: LinearLayout
        lateinit var testButtonTop: Button
        lateinit var saveButtonTop: Button
        lateinit var testButtonBottom: Button
        lateinit var saveButtonBottom: Button
        lateinit var closeButtonBottom: Button
        lateinit var clearButtonTop: Button
        var currentTab = "one"

        fun providerFromKeyOrSelected(key: String, selected: NetProvider): NetProvider {
            return NetProvider.detectFromApiKey(key) ?: selected
        }

        fun modelForProvider(rawModel: String, provider: NetProvider): String {
            val cleanModel = rawModel.trim()
            return if (cleanModel.isBlank() || cleanModel in knownDefaultModels) provider.defaultModel else cleanModel
        }

        fun cleanDraft(): List<NetApiConfig> {
            val clean = draftConfigs
                .mapIndexed { index, config ->
                    val provider = providerFromKeyOrSelected(config.apiKey, config.provider)
                    val model = modelForProvider(config.model, provider)
                    config.copy(name = "API ${index + 1}", provider = provider, model = model).clean(index)
                }
                .filter { it.apiKey.isNotBlank() }
                .distinctBy { "${it.provider.id}|${it.apiKey}|${it.model}" }
            draftConfigs.clear()
            draftConfigs.addAll(clean)
            return draftConfigs.toList()
        }

        fun currentConfigs(): List<NetApiConfig> = cleanDraft()

        fun maskKey(key: String): String {
            val clean = key.trim()
            if (clean.length <= 10) return clean
            return clean.take(5) + "..." + clean.takeLast(5)
        }

        fun setButtonText(button: Button, text: String) {
            button.text = text
            button.setAllCaps(false)
        }

        fun updateStatus() {
            val configs = currentConfigs()
            val report = settings.getStatusReportForConfigs(configs)
            val summary = report.substringBefore("\n")
            statusSummary.text = if (configs.isEmpty()) {
                "Sin APIs cargadas. Agrega una o pega varias."
            } else {
                "${configs.size} API(s) · $summary"
            }
        }

        fun parseBulkApiKeys(raw: String): List<String> {
            return raw
                .replace(",", "\n")
                .replace(";", "\n")
                .lines()
                .map { line ->
                    line.trim()
                        .replace(Regex("^\\d+[.)\\-:]?\\s*"), "")
                        .removePrefix("API")
                        .removePrefix("api")
                        .trim()
                        .replace(Regex("^\\d+[.)\\-:]?\\s*"), "")
                        .trim()
                }
                .filter { it.length >= 12 }
                .distinct()
        }

        fun importBulk(raw: String, selectedProvider: NetProvider, rawModel: String): Int {
            val existing = currentConfigs().map { "${it.provider.id}|${it.apiKey}|${it.model}" }.toMutableSet()
            var added = 0
            parseBulkApiKeys(raw).forEach { key ->
                val provider = providerFromKeyOrSelected(key, selectedProvider)
                val model = modelForProvider(rawModel, provider)
                val config = NetApiConfig("API ${draftConfigs.size + 1}", provider, key, model).clean(draftConfigs.size)
                val id = "${config.provider.id}|${config.apiKey}|${config.model}"
                if (id !in existing) {
                    draftConfigs.add(config)
                    existing.add(id)
                    added++
                }
            }
            updateStatus()
            return added
        }

        fun saveConfigs(closeAfter: Boolean = false) {
            val configs = currentConfigs()
            settings.saveApiConfigs(configs)
            updateStatus()
            binding.tvStatus.text = if (configs.isEmpty()) "Sin API configurada" else "API guardada"
            binding.tvAnswer.text = if (configs.isEmpty()) {
                "No hay APIs guardadas. JSON seguirá funcionando."
            } else {
                "Guardadas ${configs.size} API. Toca PROBAR para validarlas."
            }
            if (closeAfter) dialog.dismiss()
        }

        fun setTesting(enabled: Boolean) {
            testButtonTop.isEnabled = enabled
            testButtonBottom.isEnabled = enabled
            saveButtonTop.isEnabled = enabled
            saveButtonBottom.isEnabled = enabled
            closeButtonBottom.isEnabled = enabled
            clearButtonTop.isEnabled = enabled
        }

        fun runApiTest(configsToTest: List<NetApiConfig> = currentConfigs()) {
            val configs = configsToTest.ifEmpty { currentConfigs() }
            if (configs.isEmpty()) {
                binding.tvStatus.text = "API vacía"
                binding.tvAnswer.text = "Agrega por lo menos una API para probar."
                return
            }
            settings.saveApiConfigs(currentConfigs())
            setTesting(false)
            binding.tvStatus.text = "Probando APIs..."
            binding.tvAnswer.text = "Probando sin dejar la pantalla API. Si una clave falla, quedará marcada."
            Thread {
                val result = onlineProvider.testApiConfigs(configs)
                runOnUiThread {
                    setTesting(true)
                    updateStatus()
                    binding.tvStatus.text = if (result.first) "API OK" else "API falló"
                    binding.tvAnswer.text = result.second
                    if (currentTab == "list" || currentTab == "test") renderPanel(currentTab)
                }
            }.start()
        }

        fun switchTab(tab: String) {
            currentTab = tab
            renderPanel(tab)
        }

        fun makeTabButton(label: String, tab: String): Button {
            return Button(this).apply {
                setButtonText(this, label)
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
                setOnClickListener { switchTab(tab) }
            }
        }

        fun refreshTabStyle() {
            setButtonText(tabOne, if (currentTab == "one") "● UNA" else "UNA")
            setButtonText(tabBulk, if (currentTab == "bulk") "● MASA" else "MASA")
            setButtonText(tabList, if (currentTab == "list") "● LISTA" else "LISTA")
            setButtonText(tabTest, if (currentTab == "test") "● PROBAR" else "PROBAR")
        }

        fun renderOnePanel() {
            val providerSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providerLabels)
            }
            val modelInput = EditText(this).apply {
                setText(NetProvider.GEMINI.defaultModel)
                hint = "Modelo"
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            val keyInput = EditText(this).apply {
                hint = "Pega aquí una API"
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            val help = TextView(this).apply {
                text = "Proveedor y modelo recomendado. Si la clave es Gemini/Groq/OpenRouter, se corrige sola por formato."
                textSize = 12f
                setPadding(0, 4, 0, 8)
            }
            providerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val provider = providers.getOrElse(position) { NetProvider.GEMINI }
                    val currentModel = modelInput.text.toString().trim()
                    if (currentModel.isBlank() || currentModel in knownDefaultModels) {
                        modelInput.setText(provider.defaultModel)
                        modelInput.setSelection(modelInput.text.length)
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
            val pasteButton = Button(this).apply {
                setButtonText(this, "PEGAR PORTAPAPELES")
                setOnClickListener {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = clipboard.primaryClip
                    val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this@MainActivity)?.toString().orEmpty().trim() else ""
                    if (text.isBlank()) {
                        Toast.makeText(this@MainActivity, "Portapapeles vacío", Toast.LENGTH_SHORT).show()
                    } else {
                        keyInput.setText(parseBulkApiKeys(text).firstOrNull() ?: text)
                        keyInput.setSelection(keyInput.text.length)
                    }
                }
            }
            val addButton = Button(this).apply {
                setButtonText(this, "AGREGAR")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
                setOnClickListener {
                    val key = keyInput.text.toString().trim()
                    if (key.isBlank()) {
                        keyInput.error = "Pega una API"
                        return@setOnClickListener
                    }
                    val selected = providers.getOrElse(providerSpinner.selectedItemPosition) { NetProvider.GEMINI }
                    val provider = providerFromKeyOrSelected(key, selected)
                    val model = modelForProvider(modelInput.text.toString(), provider)
                    val config = NetApiConfig("API ${draftConfigs.size + 1}", provider, key, model).clean(draftConfigs.size)
                    val id = "${config.provider.id}|${config.apiKey}|${config.model}"
                    val exists = currentConfigs().any { "${it.provider.id}|${it.apiKey}|${it.model}" == id }
                    if (exists) {
                        binding.tvStatus.text = "API repetida"
                        binding.tvAnswer.text = "Esa API ya existe en la lista."
                    } else {
                        draftConfigs.add(config)
                        keyInput.setText("")
                        updateStatus()
                        binding.tvStatus.text = "API agregada"
                        binding.tvAnswer.text = "Se agregó 1 API. Puedes pegar otra sin bajar."
                    }
                }
            }
            val addTestButton = Button(this).apply {
                setButtonText(this, "AGREGAR Y PROBAR")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    addButton.performClick()
                    val latest = currentConfigs().lastOrNull()
                    if (latest != null) runApiTest(listOf(latest))
                }
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(addButton)
                addView(addTestButton)
            }
            panelBox.addView(TextView(this).apply { text = "Agregar una API"; textSize = 18f; setPadding(0,0,0,8) })
            panelBox.addView(providerSpinner)
            panelBox.addView(modelInput)
            panelBox.addView(help)
            panelBox.addView(pasteButton)
            panelBox.addView(keyInput)
            panelBox.addView(row)
        }

        fun renderBulkPanel() {
            val providerSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providerLabels)
            }
            val modelInput = EditText(this).apply {
                setText(NetProvider.GEMINI.defaultModel)
                hint = "Modelo"
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            val bulkInput = EditText(this).apply {
                hint = "Pega varias APIs, una por línea"
                minLines = 6
                maxLines = 8
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            }
            providerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val provider = providers.getOrElse(position) { NetProvider.GEMINI }
                    val currentModel = modelInput.text.toString().trim()
                    if (currentModel.isBlank() || currentModel in knownDefaultModels) {
                        modelInput.setText(provider.defaultModel)
                        modelInput.setSelection(modelInput.text.length)
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
            val pasteButton = Button(this).apply {
                setButtonText(this, "PEGAR PORTAPAPELES")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
                setOnClickListener {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = clipboard.primaryClip
                    val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this@MainActivity)?.toString().orEmpty().trim() else ""
                    if (text.isBlank()) {
                        Toast.makeText(this@MainActivity, "Portapapeles vacío", Toast.LENGTH_SHORT).show()
                    } else {
                        bulkInput.setText(text)
                        bulkInput.setSelection(bulkInput.text.length)
                        binding.tvStatus.text = "APIs pegadas"
                        binding.tvAnswer.text = "Detectadas ${parseBulkApiKeys(text).size} posible(s) API. Toca IMPORTAR."
                    }
                }
            }
            val importButton = Button(this).apply {
                setButtonText(this, "IMPORTAR")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
                setOnClickListener {
                    val provider = providers.getOrElse(providerSpinner.selectedItemPosition) { NetProvider.GEMINI }
                    val added = importBulk(bulkInput.text.toString(), provider, modelInput.text.toString())
                    if (added > 0) {
                        bulkInput.setText("")
                        binding.tvStatus.text = "APIs importadas"
                        binding.tvAnswer.text = "Se agregaron $added API. Ahora estás en LISTA para verlas."
                        switchTab("list")
                    } else {
                        binding.tvStatus.text = "Nada importado"
                        binding.tvAnswer.text = "No se encontró una clave nueva. Revisa que sea una API por línea."
                    }
                }
            }
            val clearButton = Button(this).apply {
                setButtonText(this, "LIMPIAR")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { bulkInput.setText("") }
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(pasteButton); addView(importButton); addView(clearButton) }
            panelBox.addView(TextView(this).apply { text = "Pegar en masa"; textSize = 18f; setPadding(0,0,0,8) })
            panelBox.addView(row)
            panelBox.addView(bulkInput)
            panelBox.addView(providerSpinner)
            panelBox.addView(modelInput)
            panelBox.addView(TextView(this).apply { text = "Formato correcto: una API por línea, sin números ni comas."; textSize = 12f; setPadding(0,6,0,0) })
        }

        fun renderListPanel() {
            val configs = currentConfigs()
            if (configs.isEmpty()) {
                panelBox.addView(TextView(this).apply { text = "No hay APIs agregadas todavía."; textSize = 15f; setPadding(0,16,0,16) })
                return
            }
            configs.forEachIndexed { index, config ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(20, 16, 20, 16)
                    setBackgroundResource(R.drawable.card_bg)
                }
                val status = settings.getStatusLabel(config, index).substringAfter(": ", "SIN ESTADO")
                card.addView(TextView(this).apply { text = "API ${index + 1} · ${config.provider.label}"; textSize = 16f })
                card.addView(TextView(this).apply { text = "Clave: ${maskKey(config.apiKey)}"; textSize = 13f })
                card.addView(TextView(this).apply { text = "Modelo: ${config.model}"; textSize = 13f })
                card.addView(TextView(this).apply { text = "Estado: $status"; textSize = 13f; setPadding(0,0,0,8) })
                val testOne = Button(this).apply {
                    setButtonText(this, "PROBAR")
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
                    setOnClickListener { runApiTest(listOf(config)) }
                }
                val edit = Button(this).apply {
                    setButtonText(this, "EDITAR")
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
                    setOnClickListener { showEditApiDialog(index) }
                }
                val delete = Button(this).apply {
                    setButtonText(this, "BORRAR")
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener {
                        draftConfigs.removeAt(index)
                        binding.tvStatus.text = "API borrada"
                        binding.tvAnswer.text = "Toca GUARDAR para confirmar el cambio."
                        renderPanel("list")
                    }
                }
                card.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(testOne); addView(edit); addView(delete) })
                panelBox.addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 })
            }
        }

        fun renderTestPanel() {
            val configs = currentConfigs()
            panelBox.addView(TextView(this).apply { text = "Probar y limpiar APIs"; textSize = 18f; setPadding(0,0,0,8) })
            panelBox.addView(TextView(this).apply { text = settings.getStatusReportForConfigs(configs); textSize = 13f; setPadding(0,0,0,12) })
            panelBox.addView(Button(this).apply { setButtonText(this, "PROBAR TODAS LAS DISPONIBLES"); setOnClickListener { runApiTest() } })
            panelBox.addView(Button(this).apply { setButtonText(this, "LIMPIAR ESPERA / ERROR / LÍMITE"); setOnClickListener {
                val cleared = settings.clearBlockedStatuses(currentConfigs())
                updateStatus()
                binding.tvStatus.text = "Estados limpiados"
                binding.tvAnswer.text = if (cleared > 0) "Se limpiaron $cleared API. Ahora puedes probar otra vez." else "No había estados bloqueados."
                renderPanel("test")
            } })
        }

        fun showEditApiDialog(index: Int) {
            val existing = draftConfigs.getOrNull(index) ?: return
            val providerSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providerLabels)
                setSelection(providers.indexOf(existing.provider).coerceAtLeast(0))
            }
            val modelInput = EditText(this).apply {
                setText(existing.model)
                hint = "Modelo"
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            val keyInput = EditText(this).apply {
                setText(existing.apiKey)
                hint = "Clave API"
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            providerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val provider = providers.getOrElse(position) { NetProvider.GEMINI }
                    val currentModel = modelInput.text.toString().trim()
                    if (currentModel.isBlank() || currentModel in knownDefaultModels) {
                        modelInput.setText(provider.defaultModel)
                        modelInput.setSelection(modelInput.text.length)
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 12, 24, 0)
                addView(providerSpinner)
                addView(modelInput)
                addView(keyInput)
            }
            val editDialog = AlertDialog.Builder(this)
                .setTitle("Editar API ${index + 1}")
                .setView(box)
                .setPositiveButton("GUARDAR", null)
                .setNegativeButton("CANCELAR", null)
                .setNeutralButton("BORRAR", null)
                .show()
            editDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = keyInput.text.toString().trim()
                if (key.isBlank()) { keyInput.error = "Pega una API"; return@setOnClickListener }
                val selected = providers.getOrElse(providerSpinner.selectedItemPosition) { NetProvider.GEMINI }
                val provider = providerFromKeyOrSelected(key, selected)
                val model = modelForProvider(modelInput.text.toString(), provider)
                draftConfigs[index] = NetApiConfig("API ${index + 1}", provider, key, model).clean(index)
                binding.tvStatus.text = "API editada"
                binding.tvAnswer.text = "Toca GUARDAR para confirmar el cambio."
                editDialog.dismiss()
                renderPanel("list")
            }
            editDialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                draftConfigs.removeAt(index)
                binding.tvStatus.text = "API borrada"
                binding.tvAnswer.text = "Toca GUARDAR para confirmar el cambio."
                editDialog.dismiss()
                renderPanel("list")
            }
        }

        fun renderPanel(tab: String) {
            currentTab = tab
            panelBox.removeAllViews()
            refreshTabStyle()
            updateStatus()
            when (tab) {
                "bulk" -> renderBulkPanel()
                "list" -> renderListPanel()
                "test" -> renderTestPanel()
                else -> renderOnePanel()
            }
        }

        val title = TextView(this).apply {
            text = "Configuración API v151"
            textSize = 23f
            setPadding(4, 4, 4, 2)
        }
        statusSummary = TextView(this).apply {
            textSize = 13f
            setPadding(4, 2, 4, 6)
        }

        tabOne = makeTabButton("UNA", "one")
        tabBulk = makeTabButton("MASA", "bulk")
        tabList = makeTabButton("LISTA", "list")
        tabTest = makeTabButton("PROBAR", "test")
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 8)
            addView(tabOne)
            addView(tabBulk)
            addView(tabList)
            addView(tabTest)
        }

        testButtonTop = Button(this).apply { setButtonText(this, "PROBAR"); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }; setOnClickListener { runApiTest() } }
        saveButtonTop = Button(this).apply { setButtonText(this, "GUARDAR"); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }; setOnClickListener { saveConfigs(false) } }
        clearButtonTop = Button(this).apply { setButtonText(this, "LIMPIAR ERROR"); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setOnClickListener {
            val cleared = settings.clearBlockedStatuses(currentConfigs())
            updateStatus()
            binding.tvStatus.text = "Estados limpiados"
            binding.tvAnswer.text = if (cleared > 0) "Se limpiaron $cleared API bloqueadas." else "No había API bloqueada."
            if (currentTab == "list" || currentTab == "test") renderPanel(currentTab)
        } }
        val topActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(testButtonTop); addView(saveButtonTop); addView(clearButtonTop) }

        panelBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }
        val panelScroll = ScrollView(this).apply {
            addView(panelBox)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        closeButtonBottom = Button(this).apply { setButtonText(this, "CERRAR"); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }; setOnClickListener { dialog.dismiss() } }
        saveButtonBottom = Button(this).apply { setButtonText(this, "GUARDAR"); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }; setOnClickListener { saveConfigs(false) } }
        testButtonBottom = Button(this).apply { setButtonText(this, "PROBAR"); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setOnClickListener { runApiTest() } }
        val bottomActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0); addView(closeButtonBottom); addView(saveButtonBottom); addView(testButtonBottom) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 8)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
            addView(title)
            addView(statusSummary)
            addView(topActions)
            addView(tabRow)
            addView(panelScroll)
            addView(bottomActions)
        }

        dialog = AlertDialog.Builder(this).setView(root).create()
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.98).toInt(), (resources.displayMetrics.heightPixels * 0.92).toInt())
        renderPanel("one")
    }

    private fun showJsonConfigDialog() {
        val store = JsonKnowledgeStore(this)
        val mainInput = EditText(this).apply {
            setText(store.getUrl())
            hint = "Pega un solo link JSON Raw"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSelection(text.length)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 0, 8, 0)
            addView(mainInput)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Configuración JSON")
            .setMessage("Pega un solo link JSON Raw. En ese archivo deben estar preguntas, respuestas y variantes.")
            .setView(box)
            .setPositiveButton("GUARDAR", null)
            .setNeutralButton("ACTUALIZAR", null)
            .setNegativeButton("CERRAR", null)
            .show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            store.saveUrl(mainInput.text.toString())
            store.clearVariantsConfig()
            binding.tvStatus.text = "JSON guardado"
            binding.tvAnswer.text = "Link guardado. Usa ACTUALIZAR para descargar el JSON completo."
            dialog.dismiss()
        }

        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            store.saveUrl(mainInput.text.toString())
            store.clearVariantsConfig()

            if (store.getUrl().isBlank()) {
                binding.tvStatus.text = "Link JSON vacío"
                binding.tvAnswer.text = "Pega un link JSON Raw antes de actualizar."
                return@setOnClickListener
            }

            val updateButton = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            val saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            updateButton.isEnabled = false
            saveButton.isEnabled = false
            binding.tvStatus.text = "Actualizando JSON..."
            binding.tvAnswer.text = "Descargando un solo JSON con preguntas, respuestas y variantes."

            Thread {
                val result = store.downloadJson()
                val newRepository = if (result.first) JsonKnowledgeRepository(this) else null
                val loadedCount = try { newRepository?.totalItems ?: 0 } catch (_: Exception) { 0 }

                runOnUiThread {
                    updateButton.isEnabled = true
                    saveButton.isEnabled = true

                    if (result.first && newRepository != null && loadedCount > 0) {
                        jsonRepository = newRepository
                        modeSettings.setMode(AnswerModeSettings.Mode.AUTO)
                        applyModeToUi()
                        binding.tvStatus.text = "JSON actualizado. Elementos: $loadedCount"
                        binding.tvAnswer.text = "JSON listo y precargado. En modo JSON responde solo desde este archivo."
                        dialog.dismiss()
                    } else if (result.first) {
                        binding.tvStatus.text = "JSON descargado pero no cargó"
                        binding.tvAnswer.text = "Revisa que el archivo tenga preguntas, respuestas y variantes válidas."
                    } else {
                        binding.tvStatus.text = result.second
                        binding.tvAnswer.text = "No se pudo actualizar. Revisa link Raw e internet."
                    }
                }
            }.start()
        }
    }

    private fun showJsonLinkDialog() {
        showJsonConfigDialog()
    }

    private fun showJsonVariantsLinkDialog() {
        showJsonConfigDialog()
    }

    private fun updateJsonFromGithub() {
        showJsonConfigDialog()
    }

    private fun showListenEngineDialog() {
        val options = arrayOf("Susurro Google recomendado", "Offline técnico Vosk", "Manos libres con comando")
        val current = when (appSettings.getListenEngine()) {
            AppSettings.ListenEngine.VOSK -> 1
            AppSettings.ListenEngine.HANDS_FREE -> 2
            else -> 0
        }

        AlertDialog.Builder(this)
            .setTitle("Motor de escucha")
            .setSingleChoiceItems(options, current) { dialog, which ->
                val engine = when (which) {
                    1 -> AppSettings.ListenEngine.VOSK
                    2 -> AppSettings.ListenEngine.HANDS_FREE
                    else -> AppSettings.ListenEngine.GOOGLE_INTERNAL
                }
                appSettings.setListenEngine(engine)
                binding.tvStatus.text = "Motor: ${appSettings.getListenEngineLabel()}"
                binding.tvAnswer.text = if (engine == AppSettings.ListenEngine.GOOGLE_INTERNAL) {
                    "Modo recomendado para susurro: espera frase completa, usa sesgo técnico y evita parciales."
                } else if (engine == AppSettings.ListenEngine.VOSK) {
                    "Offline técnico: útil para palabras del JSON, pero menos preciso con ruido."
                } else {
                    "Motor guardado."
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMicSensitivityDialog() {
        val options = arrayOf("Normal", "Susurro / voz baja")
        val checked = if (appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER) 1 else 0

        AlertDialog.Builder(this)
            .setTitle("Sensibilidad del micrófono")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = if (which == 1) AppSettings.MicSensitivity.WHISPER else AppSettings.MicSensitivity.NORMAL
                appSettings.setMicSensitivity(value)
                binding.tvStatus.text = "Micrófono: ${appSettings.getMicSensitivityLabel()}"
                binding.tvAnswer.text = "Usa el Zync cerca de la boca."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showNoiseCleanerDialog() {
        val options = arrayOf("Normal", "Fuerte")
        val checked = if (appSettings.getNoiseCleaner() == AppSettings.NoiseCleaner.STRONG) 1 else 0

        AlertDialog.Builder(this)
            .setTitle("Limpiador de ruido")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = if (which == 1) AppSettings.NoiseCleaner.STRONG else AppSettings.NoiseCleaner.NORMAL
                appSettings.setNoiseCleaner(value)
                binding.tvStatus.text = "Ruido: ${appSettings.getNoiseCleanerLabel()}"
                binding.tvAnswer.text = "Si estás susurrando, usa Fuerte."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showNetFocusDialog() {
        val options = arrayOf("General", "Minería / Explotación minera")
        val checked = if (appSettings.getNetFocus() == AppSettings.NetFocus.MINING) 1 else 0

        AlertDialog.Builder(this)
            .setTitle("Enfoque para Internet")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = if (which == 1) AppSettings.NetFocus.MINING else AppSettings.NetFocus.GENERAL
                appSettings.setNetFocus(value)
                binding.tvStatus.text = "Internet: ${appSettings.getNetFocusLabel()}"
                binding.tvAnswer.text = "Ajuste guardado."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showVoiceSpeedDialog() {
        val options = arrayOf("Lento", "Normal", "Rápido")
        val checked = when (appSettings.getVoiceSpeed()) {
            AppSettings.VoiceSpeed.SLOW -> 0
            AppSettings.VoiceSpeed.NORMAL -> 1
            AppSettings.VoiceSpeed.FAST -> 2
        }

        AlertDialog.Builder(this)
            .setTitle("Velocidad de la voz")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val value = when (which) {
                    0 -> AppSettings.VoiceSpeed.SLOW
                    2 -> AppSettings.VoiceSpeed.FAST
                    else -> AppSettings.VoiceSpeed.NORMAL
                }
                appSettings.setVoiceSpeed(value)
                tts?.setSpeechRate(appSettings.getVoiceRate())
                binding.tvStatus.text = "Voz: ${appSettings.getVoiceSpeedLabel()}"
                binding.tvAnswer.text = "Velocidad guardada."
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startListeningSmart() {
        requestIgnoreBatteryOptimizationOnce()
        val engine = appSettings.getListenEngine()
        pendingStartMode = when (engine) {
            AppSettings.ListenEngine.GOOGLE_INTERNAL -> "google_internal"
            AppSettings.ListenEngine.HANDS_FREE -> "wake"
            AppSettings.ListenEngine.GOOGLE -> "google"
            AppSettings.ListenEngine.VOSK -> "vosk"
        }

        when {
            !hasAudioPermission() -> audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission() ->
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            engine == AppSettings.ListenEngine.GOOGLE_INTERNAL -> startGoogleInternalService()
            engine == AppSettings.ListenEngine.HANDS_FREE -> {
                if (modelManager.isReady()) startVoskWakeService() else downloadOffline(startAfter = true)
            }
            engine == AppSettings.ListenEngine.GOOGLE -> launchGooglePrecise()
            else -> {
                if (modelManager.isReady()) startVoskService() else downloadOffline(startAfter = true)
            }
        }
    }

    private fun downloadOffline(startAfter: Boolean) {
        binding.tvStatus.text = "Preparando modelo offline..."
        binding.tvAnswer.text = "Se descargará una sola vez. Necesita internet estable."

        modelManager.downloadAndUnzip(
            onProgress = { msg -> runOnUiThread { binding.tvStatus.text = msg } },
            onDone = { ok, msg ->
                runOnUiThread {
                    binding.tvStatus.text = msg
                    binding.tvAnswer.text = if (ok) {
                        if (startAfter) "Modelo listo. Iniciando escucha..." else "Offline listo. Toca ESCUCHAR."
                    } else {
                        "No se pudo preparar offline. Revisa internet, espacio y vuelve a tocar ESCUCHAR."
                    }

                    if (ok && startAfter) {
                        if (pendingStartMode == "wake") startVoskWakeService() else startVoskService()
                    }
                }
            }
        )
    }

    private fun requestIgnoreBatteryOptimizationOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return

        val prefs = getSharedPreferences("geo_susu_memory", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_request_shown", false)) return

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return

        prefs.edit().putBoolean("battery_request_shown", true).apply()

        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
            binding.tvStatus.text = "Permite batería sin restricciones para pantalla apagada."
        } catch (_: Exception) {
            binding.tvStatus.text = "Quita restricción de batería manualmente."
        }
    }

    private fun setupUi() {
        binding.etCommandWord.setText(commandSettings.getCommandWord())
        applyModeToUi()

        binding.rgAnswerMode.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                binding.rbJson.id -> modeSettings.setMode(AnswerModeSettings.Mode.JSON)
                binding.rbInternet.id -> modeSettings.setMode(AnswerModeSettings.Mode.INTERNET)
                binding.rbAuto.id -> modeSettings.setMode(AnswerModeSettings.Mode.AUTO)
                else -> modeSettings.setMode(AnswerModeSettings.Mode.AUTO)
            }
            applyModeToUi()
            binding.tvStatus.text = "Modo: ${modeSettings.getLabel()}"
        }

        binding.btnOpenTxt.setOnClickListener { showJsonLinkDialog() }
        binding.btnImportText.setOnClickListener { showJsonLinkDialog() }
        binding.btnOpenQaFile.setOnClickListener { openQaFileLauncher.launch("text/*") }
        binding.btnOpenVarFile.setOnClickListener { openVarFileLauncher.launch("text/*") }
        binding.btnSettings.setOnClickListener { showSettingsDialog() }

        binding.btnDownloadModel.setOnClickListener {
            updateJsonFromGithub()
        }

        binding.btnSaveCommand.setOnClickListener {
            val saved = commandSettings.saveCommandWord(binding.etCommandWord.text.toString())
            binding.etCommandWord.setText(saved)
            binding.tvStatus.text = "Comando guardado: $saved"
            binding.tvAnswer.text = "Comando guardado para pausar o reanudar."
        }

        binding.btnStart.setOnClickListener {
            startListeningSmart()
        }

        binding.btnStop.setOnClickListener {
            googleLoopRunning = false
            stopService(Intent(this, GoogleInternalListenService::class.java))
            stopService(Intent(this, VoskListenService::class.java))
            binding.tvStatus.text = "Escucha detenida"
            binding.tvHeard.text = "Pregunta: ---"
            binding.tvAnswer.text = "Listo."
        }

    }

    private fun launchGooglePrecise() {
        googleLoopRunning = true
        stopService(Intent(this, GoogleInternalListenService::class.java))
        stopService(Intent(this, VoskListenService::class.java))

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            if (Build.VERSION.SDK_INT >= 33) {
                putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, arrayListOf(
                    "BM", "be eme", "banco de nivel", "cota", "nivelación",
                    "vista atrás", "vista adelante", "vista intermedia",
                    "altura de instrumento", "AI", "CP", "cambio de punto",
                    "replanteo topográfico", "levantamiento topográfico", "topografía superficial"
                ))
            }
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla o susurra cerca del micrófono")
        }

        try {
            binding.tvStatus.text = "Escucha precisa de Google..."
            binding.tvAnswer.text = "Habla cuando aparezca el micrófono."
            googleVoiceLauncher.launch(intent)
        } catch (_: Exception) {
            googleLoopRunning = false
            binding.tvStatus.text = "Google Speech no disponible"
            binding.tvAnswer.text = "Activa Speech Services by Google o cambia a Vosk."
        }
    }

    private fun reopenGooglePrecise(delayMs: Long = 650L) {
        if (!googleLoopRunning || appSettings.getListenEngine() != AppSettings.ListenEngine.GOOGLE) return
        binding.root.postDelayed({
            if (googleLoopRunning && appSettings.getListenEngine() == AppSettings.ListenEngine.GOOGLE) {
                launchGooglePrecise()
            }
        }, delayMs)
    }

    private fun startGoogleInternalService() {
        googleLoopRunning = false
        stopService(Intent(this, VoskListenService::class.java))
        val intent = Intent(this, GoogleInternalListenService::class.java)
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Susurro Google activo"
        binding.tvAnswer.text = "Escucha, corrige la pregunta y responde con JSON o NET según el modo."
    }

    private fun startVoskWakeService() {
        googleLoopRunning = false
        stopService(Intent(this, GoogleInternalListenService::class.java))
        stopService(Intent(this, VoskListenService::class.java))
        val intent = Intent(this, VoskListenService::class.java).apply {
            putExtra(VoskListenService.EXTRA_WAKE_ONLY, true)
        }
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Manos libres activo"
        binding.tvAnswer.text = "Di ${commandSettings.getCommandWord()}, luego pregunta."
    }

    private fun startVoskService() {
        googleLoopRunning = false
        stopService(Intent(this, GoogleInternalListenService::class.java))
        val intent = Intent(this, VoskListenService::class.java)
        ContextCompat.startForegroundService(this, intent)
        binding.tvStatus.text = "Escuchando offline..."
        binding.tvAnswer.text = "Escuchando según el modo elegido."
    }

    private fun processVoiceForRecognitionTest(rawQuestion: String) {
        val cleanQuestion = VoiceQuestionNormalizer.normalize(rawQuestion)
        binding.tvHeard.text = "Pregunta: $cleanQuestion"
        binding.tvStatus.text = "Reconocimiento listo"
        binding.tvAnswer.text = "Escuchado: ${rawQuestion.trim()}\nCorregido: $cleanQuestion\n\nNo se buscó en JSON ni NET."
    }

    private fun processQuestion(question: String, useOnlineFallback: Boolean, forceInternet: Boolean = false) {
        val cleanQuestion = VoiceQuestionNormalizer.normalize(question)
        binding.tvHeard.text = "Pregunta: $cleanQuestion"

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(cleanQuestion)) {
            showAndSpeak("No se detectó pregunta completa. Repite la pregunta.", "No se procesó")
            return
        }

        if (commandSettings.isToggleCommand(cleanQuestion)) {
            binding.tvStatus.text = "Comando detectado"
            binding.tvAnswer.text = "Comando de pausa, no se busca."
            return
        }

        val localAnswer = LocalAnswerProvider.findAnswer(cleanQuestion)
        if (localAnswer != null) {
            showAndSpeak(localAnswer, "Respuesta local")
            memory.saveLast(cleanQuestion, localAnswer, "local", 100)
            return
        }

        val mode = if (forceInternet) AnswerModeSettings.Mode.INTERNET else modeSettings.getMode()

        when (mode) {
            AnswerModeSettings.Mode.INTERNET -> {
                if (VoiceQuestionNormalizer.isUnsafeForNet(cleanQuestion)) {
                    showAndSpeak("No hay una pregunta clara para enviar a NET.", "NET bloqueado por texto vacío")
                } else {
                    searchOnline(cleanQuestion)
                }
            }

            AnswerModeSettings.Mode.JSON -> {
                binding.tvStatus.text = "Buscando en JSON..."
                binding.tvAnswer.text = "Procesando sin bloquear la app."
                Thread {
                    val jsonMatch = jsonRepository.findBest(cleanQuestion)
                    runOnUiThread {
                        if (jsonMatch.itemId != "none") {
                            showAndSpeak(jsonMatch.answer, "Respuesta JSON")
                            memory.saveLast(cleanQuestion, jsonMatch.answer, jsonMatch.itemId, jsonMatch.score)
                        } else {
                            showAndSpeak(jsonMatch.answer, "No encontrado en JSON")
                        }
                    }
                }.start()
            }

            AnswerModeSettings.Mode.AUTO -> {
                if (shouldForceNetForRepeatedAuto(cleanQuestion)) {
                    rememberAutoAnswer(cleanQuestion, "net")
                    searchOnline(cleanQuestion, "Repetida: buscando en NET...")
                    return
                }

                binding.tvStatus.text = "Buscando en JSON..."
                binding.tvAnswer.text = "Si no encuentra, pasará a NET."
                Thread {
                    val jsonMatch = jsonRepository.findBest(cleanQuestion)
                    runOnUiThread {
                        if (jsonMatch.itemId != "none") {
                            rememberAutoAnswer(cleanQuestion, "json")
                            showAndSpeak(jsonMatch.answer, "Respuesta JSON")
                            memory.saveLast(cleanQuestion, jsonMatch.answer, jsonMatch.itemId, jsonMatch.score)
                        } else {
                            if (VoiceQuestionNormalizer.isUnsafeForNet(cleanQuestion)) {
                                showAndSpeak("No hay una pregunta clara para enviar a NET.", "NET bloqueado por texto vacío")
                            } else {
                                rememberAutoAnswer(cleanQuestion, "net")
                                searchOnline(cleanQuestion)
                            }
                        }
                    }
                }.start()
            }
        }
    }

    private fun searchOnline(question: String, statusText: String = "Consultando NET...") {
        binding.tvStatus.text = statusText
        binding.tvAnswer.text = "Enviaré la pregunta por NET y leeré la respuesta en audio."

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontrado"
            }

            runOnUiThread {
                showAndSpeak(answer, "Respuesta NET")
                memory.saveLast(question, answer, "net", 0)
            }
        }.start()
    }

    private fun showAndSpeak(answer: String, status: String) {
        binding.tvStatus.text = status
        binding.tvAnswer.text = answer
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "geo_susu_answer")

        if (googleLoopRunning && appSettings.getListenEngine() == AppSettings.ListenEngine.GOOGLE) {
            val waitMs = (answer.length * 55L).coerceIn(1200L, 6500L)
            reopenGooglePrecise(waitMs)
        }
    }

    private fun rememberAutoAnswer(question: String, source: String) {
        lastAutoQuestionKey = repeatKey(question)
        lastAutoAnswerSource = source
        lastAutoAnswerTime = System.currentTimeMillis()
    }

    private fun shouldForceNetForRepeatedAuto(question: String): Boolean {
        if (lastAutoAnswerSource != "json") return false
        if (System.currentTimeMillis() - lastAutoAnswerTime > 2 * 60 * 1000L) return false
        return isSameRepeatQuestion(repeatKey(question), lastAutoQuestionKey)
    }

    private fun isSameRepeatQuestion(currentKey: String, previousKey: String): Boolean {
        if (currentKey.isBlank() || previousKey.isBlank()) return false
        if (currentKey == previousKey) return true
        val a = currentKey.split(" ").filter { it.isNotBlank() }.toSet()
        val b = previousKey.split(" ").filter { it.isNotBlank() }.toSet()
        if (a.isEmpty() || b.isEmpty()) return false
        val common = a.count { it in b }
        val minSize = minOf(a.size, b.size)
        val maxSize = maxOf(a.size, b.size)
        return common >= minSize && maxSize <= minSize + 2
    }

    private fun repeatKey(text: String): String {
        return ResponseRepository.normalize(text)
            .replace("\btipo de rocas\b".toRegex(), "tipos de roca")
            .replace("\btipo de roca\b".toRegex(), "tipos de roca")
            .replace("\btipos de rocas\b".toRegex(), "tipos de roca")
            .split(" ")
            .map { repeatCanonical(it.trim()) }
            .filter { it.length >= 3 && it !in repeatStopWords }
            .distinct()
            .joinToString(" ")
    }

    private fun repeatCanonical(word: String): String {
        return when (word) {
            "rocas" -> "roca"
            "minerales" -> "mineral"
            "tipos", "tipo" -> "tipos"
            "clases", "clase" -> "clases"
            else -> if (word.length > 6 && word.endsWith("s") && !word.endsWith("is")) word.dropLast(1) else word
        }
    }

    private fun warmJsonInBackground() {
        Thread {
            try {
                val count = jsonRepository.totalItems
                if (count > 0) {
                    runOnUiThread {
                        if (binding.tvStatus.text.toString().startsWith("Listo") || binding.tvStatus.text.toString().startsWith("Sin API")) {
                            binding.tvModeMini.text = "${modeSettings.getLabel()} | JSON $count"
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun refreshRepository() {
        repository = ResponseRepository(this)
        jsonRepository = JsonKnowledgeRepository(this)
        binding.tvModeMini.text = modeSettings.getLabel()
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(VoskListenService.ACTION_UPDATE)
            addAction(VoskListenService.ACTION_WAKE_GOOGLE)
            addAction(GoogleInternalListenService.ACTION_UPDATE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(updateReceiver, filter)
        }

        restoreLastVisibleAnswer()
    }

    private fun restoreLastVisibleAnswer() {
        val answer = memory.getLastAnswer().trim()
        val heard = memory.getLastHeard().trim()
        if (answer.isBlank()) return

        // v148: al salir y volver, la pantalla queda como la dejó el usuario.
        // No pisa el servicio activo; solo restaura lo visible.
        binding.tvAnswer.text = answer
        if (heard.isNotBlank()) binding.tvHeard.text = "Pregunta: $heard"
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(updateReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "PE")) ?: TextToSpeech.ERROR
            tts?.setSpeechRate(appSettings.getVoiceRate())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "La voz en español no está disponible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        googleLoopRunning = false
        // v148: no detener el servicio solo por salir de la pantalla.
        // La escucha se detiene únicamente con el botón DETENER.
        tts?.stop()
        tts?.shutdown()
    }
    companion object {
        const val EXTRA_START_GOOGLE = "start_google_precise"
        private const val KEY_TXT_QA = "txt_qa_raw"
        private const val KEY_TXT_VARIANTS = "txt_variants_raw"
        private val repeatStopWords = setOf(
            "que", "qué", "q", "ke", "k", "es", "son", "ser", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuál", "cuales", "cuáles",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa", "explica", "sobre"
        )
    }

}
