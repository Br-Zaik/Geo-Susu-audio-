Geo Susu v152

Corrección de compilación de v151: renderPanel declarado antes de uso. Mantiene API por pestañas y ajuste de susurro.
