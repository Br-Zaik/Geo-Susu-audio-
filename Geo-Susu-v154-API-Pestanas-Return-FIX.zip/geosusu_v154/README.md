Geo Susu v154

FIX: corrige el error de compilacion: return is not allowed here. Mantiene API por pestanas.
