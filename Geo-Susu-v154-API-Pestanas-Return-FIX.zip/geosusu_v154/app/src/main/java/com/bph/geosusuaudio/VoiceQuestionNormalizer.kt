package com.bph.geosusuaudio

import kotlin.math.min

object VoiceQuestionNormalizer {

    private val technicalContextWords = setOf(
        "topografia", "topografico", "topografica", "nivelacion", "nivel", "cota", "cotas", "altura",
        "terreno", "levantamiento", "replanteo", "banco", "instrumento", "mira", "vista",
        "mineria", "minera", "geologia", "mineral", "mina", "yacimiento", "exploracion", "prospeccion"
    )

    private val weakNoiseWords = setOf(
        "ruido", "musica", "ingles", "english", "hola", "eh", "ah", "mmm", "este", "esto",
        "cosa", "cosas", "algo", "alguien", "gente"
    )

    private val likelyBadSingleWords = setOf(
        "baby", "beibi", "barbie", "beybi", "beby", "babi", "bebey", "bebe", "beme",
        "ok", "okay", "google", "celular", "telefono"
    )

    private val stopWords = setOf(
        "que", "q", "ke", "es", "son", "un", "una", "el", "la", "los", "las", "de", "del",
        "en", "por", "para", "dime", "di", "define", "definicion", "concepto", "significa",
        "explica", "sobre", "pregunta", "oye"
    )

    private val clearShortCodes = setOf("bm", "cp", "va", "vi", "vf", "ai", "epp", "eia", "dia", "gps", "utm")

    private val knownTechnicalTerms = setOf(
        "mineria", "mineral", "mina", "roca", "mena", "ganga", "yacimiento", "veta", "manto",
        "cateo", "prospeccion", "exploracion", "explotacion", "geologia", "topografia", "nivelacion",
        "cota", "bm", "banco de nivel", "cp", "cambio de punto", "va", "vista atras", "vi",
        "vista intermedia", "vf", "vista adelante", "ai", "altura de instrumento", "azimut", "rumbo",
        "contra azimut", "distancia horizontal", "distancia inclinada", "distancia vertical",
        "estacion total", "mira", "teodolito", "gps", "utm", "curva de nivel", "perfil longitudinal",
        "muestreo", "muestra", "sondaje", "testigo", "perforacion", "voladura", "explosivo",
        "taladro", "burden", "espaciamiento", "chancado", "molienda", "flotacion", "relave",
        "lixiviacion", "cianuracion", "ventilacion", "sostenimiento", "shotcrete", "peligro",
        "riesgo", "incidente", "accidente", "pets", "ats", "iperc", "epp", "sctr",
        "petitorio", "concesion", "derecho minero", "canon", "canon minero", "regalia", "regalia minera", "regalias", "regalias mineras", "minero", "minera", "mineros", "mineras", "ingemmet", "oefa", "osinergmin",
        "drem", "senace", "eia", "dia", "cierre de minas", "formalizacion", "calcopirita",
        "pirita", "bornita", "galena", "esfalerita", "hematita", "magnetita", "cuarzo", "calcita",
        "granulometria", "densidad", "porosidad", "permeabilidad", "talud", "berma", "banco",
        "desmonte", "esteril", "dilucion"
    )

    private val nearTermTargets = listOf(
        "cateo", "cota", "bm", "banco de nivel", "nivelacion", "azimut", "rumbo", "topografia",
        "geologia", "mineria", "mineral", "mena", "ganga", "veta", "manto", "yacimiento",
        "prospeccion", "exploracion", "explotacion", "muestreo", "sondaje", "perforacion",
        "voladura", "chancado", "molienda", "flotacion", "relave", "talud", "berma",
        "iperc", "epp", "ats", "pets", "sctr", "gps", "utm", "eia", "dia"
    )

    private val genericContextWordsForConfirmation = setOf(
        "mineria", "minero", "minera", "mineros", "mineras",
        "geologia", "geologico", "geologica", "topografia", "topografico", "topografica"
    )

    private val strongKnownAnchorsForConfirmation = setOf(
        "canon", "canon minero", "regalia", "regalia minera", "regalias", "regalias mineras",
        "cateo", "prospeccion", "exploracion", "explotacion", "yacimiento", "veta", "manto",
        "cota", "bm", "banco de nivel", "epp", "iperc", "ats", "pets", "eia", "dia",
        "concesion", "petitorio", "derecho minero", "ingemmet", "oefa", "osinergmin", "drem", "senace"
    )

    data class ConfirmationSuggestion(
        val confirmedQuestion: String,
        val spokenLabel: String
    )

    fun confirmationSuggestion(raw: String, normalizedQuestion: String = normalize(raw)): ConfirmationSuggestion? {
        // v148: confirmacion si/no eliminada.
        // La app ya no se queda 3 segundos esperando confirmacion.
        // Si el texto reconocido es usable, busca directo en JSON o NET.
        return null
    }

    fun normalize(raw: String): String {
        var q = ResponseRepository.normalize(raw)
        if (q.isBlank()) return ""

        q = q.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()

        val hasContext = hasTechnicalContext(q)

        val phraseCorrections = linkedMapOf(
            "be eme" to "bm",
            "ve eme" to "bm",
            "baby" to "bm",
            "beibi" to "bm",
            "barbie" to "bm",
            "beybi" to "bm",
            "beby" to "bm",
            "babi" to "bm",
            "e pe pe" to "epp",
            "e p p" to "epp",
            "i pe pe" to "epp",
            "equipo proteccion personal" to "epp",
            "bi em" to "bm",
            "bee em" to "bm",
            "be me" to "bm",
            "b m" to "bm",
            "banco nivel" to "banco de nivel",
            "banco del nivel" to "banco de nivel",
            "cuota" to "cota",
            "cuotas" to "cotas",
            "ce pe" to "cp",
            "c p" to "cp",
            "ve a" to "va",
            "v a" to "va",
            "ve i" to "vi",
            "v i" to "vi",
            "ve efe" to "vf",
            "v f" to "vf",
            "a i" to "ai",
            "altura instrumental" to "altura de instrumento",
            "altura del instrumento" to "altura de instrumento",
            "vista final" to "vista adelante",
            "lectura final" to "vista adelante",
            "vista atras" to "vista atras",
            "mieria" to "mineria",
            "miniria" to "mineria",
            "menerea" to "mineria",
            "meneria" to "mineria",
            "topo grafia" to "topografia",
            "topogafia" to "topografia",
            "topografia superfacial" to "topografia superficial"
        )

        for ((bad, good) in phraseCorrections) {
            q = q.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }

        if (hasContext || q.contains("banco") || q.contains("nivel")) {
            val bmLike = listOf("bebe", "bebé", "pm", "p m", "bm.", "beme")
            for (bad in bmLike) {
                q = q.replace("\\b${Regex.escape(ResponseRepository.normalize(bad))}\\b".toRegex(), "bm")
            }
        }

        // Devuelve la pregunta completa corregida, sin agregar palabras ocultas.
        // La app debe responder a lo que el usuario preguntó, no a una palabra clave añadida.
        q = q.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()
        return q
    }

    fun isTooUnclearForJsonOrNet(question: String): Boolean {
        val q = normalize(question)
        if (q.isBlank()) return true
        val words = q.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }

        // v148: no bloquear preguntas reconocidas solo por ser cortas o raras.
        // "No entendi" queda solo para vacio o puro ruido sin contenido real.
        if (content.isEmpty()) return true

        val noiseHits = words.count { it in weakNoiseWords }
        return noiseHits >= 3 && content.size <= 1 && !hasTechnicalContext(q)
    }

    fun isUnsafeForNet(question: String): Boolean {
        val q = normalize(question)
        if (isTooUnclearForJsonOrNet(q)) return true

        // NET debe aceptar preguntas claras aunque tengan una sola palabra importante.
        // Ejemplo: "que es cateo" tiene un solo contenido (cateo), pero es una pregunta válida.
        // El bloqueo fuerte se deja solo para texto vacío, ruido o frases sin sentido.
        return false
    }

    private fun shouldConfirmRecognizedQuestion(
        q: String,
        qWords: List<String>,
        content: List<String>,
        hasQuestionIntent: Boolean
    ): Boolean {
        if (content.isEmpty()) return false
        if (content.any { it in likelyBadSingleWords }) return true

        val hasKnown = knownTechnicalTerms.any { term -> containsKnownTerm(q, term) }
        val hasClearCode = content.any { it in clearShortCodes }
        if (hasKnown || hasClearCode) return false

        // No confirmar preguntas claras solo por ser cortas.
        // Ejemplo: "que es cateo", "que es amor" o "cuantos dias tiene 2026"
        // deben pasar a JSON/NET, no quedarse esperando si/no.
        if (hasQuestionIntent) {
            val veryWeak = content.size == 1 && content.first().length <= 2
            val noisy = qWords.count { it in weakNoiseWords } >= 2
            return veryWeak || noisy
        }

        // Sin intencion de pregunta, una o dos palabras sueltas si son dudosas.
        return qWords.size <= 2 && content.size <= 1
    }

    private fun findNearTechnicalTerm(contentPhrase: String, content: List<String>): String? {
        if (content.isEmpty()) return null
        val candidates = buildList {
            if (contentPhrase.isNotBlank()) add(contentPhrase)
            content.forEach { add(it) }
        }

        for (candidate in candidates.distinct()) {
            if (candidate in knownTechnicalTerms || candidate in clearShortCodes) continue
            if (candidate in genericContextWordsForConfirmation) continue
            val best = nearTermTargets
                .filter { target -> target.length >= 3 }
                .map { target -> target to editDistance(candidate, target) }
                .minByOrNull { it.second }
                ?: continue

            val target = best.first
            val distance = best.second
            val limit = when {
                target.length <= 4 -> 1
                target.length <= 7 -> 2
                else -> 3
            }

            if (distance <= limit && hasUsefulOverlap(candidate, target)) {
                return target
            }
        }

        return null
    }

    private fun hasUsefulOverlap(a: String, b: String): Boolean {
        if (a.isBlank() || b.isBlank()) return false
        if (a.first() == b.first()) return true
        if (a.length >= 4 && b.length >= 4 && a.takeLast(3) == b.takeLast(3)) return true
        if (a.length >= 5 && b.length >= 5 && a.drop(1).take(3) == b.drop(1).take(3)) return true
        return false
    }

    private fun buildConfirmedQuestion(q: String, term: String, hasQuestionIntent: Boolean): String {
        if (!hasQuestionIntent) return "que es $term"
        val words = q.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }
        if (content.isEmpty()) return "que es $term"

        var fixed = q
        content.sortedByDescending { it.length }.forEach { bad ->
            fixed = fixed.replace("\\b${Regex.escape(bad)}\\b".toRegex(), term)
        }
        return fixed.replace("\\s+".toRegex(), " ").trim()
    }

    private fun containsKnownTerm(q: String, term: String): Boolean {
        return q == term || q.contains(" $term ") || q.startsWith("$term ") || q.endsWith(" $term")
    }

    private fun speakableLabel(text: String): String {
        return text
            .replace("bm", "BM")
            .replace("cp", "CP")
            .replace("va", "VA")
            .replace("vi", "VI")
            .replace("vf", "VF")
            .replace("ai", "AI")
            .replace("epp", "EPP")
            .replace("eia", "EIA")
            .replace("dia", "DIA")
            .replace("gps", "GPS")
            .replace("utm", "UTM")
            .replace("iperc", "IPERC")
            .replace("ats", "ATS")
            .replace("pets", "PETS")
            .replace("sctr", "SCTR")
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isBlank()) return b.length
        if (b.isBlank()) return a.length

        val previous = IntArray(b.length + 1) { it }
        val current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = min(
                    min(current[j - 1] + 1, previous[j] + 1),
                    previous[j - 1] + cost
                )
            }
            for (j in previous.indices) previous[j] = current[j]
        }

        return previous[b.length]
    }

    private fun hasTechnicalContext(q: String): Boolean {
        val words = q.split(" ").filter { it.isNotBlank() }.toSet()
        return words.any { it in technicalContextWords } ||
            q.contains("banco de nivel") ||
            q.contains("vista atras") ||
            q.contains("vista adelante") ||
            q.contains("vista intermedia") ||
            q.contains("altura de instrumento")
    }

    private fun strengthenTechnicalIntent(input: String): String {
        return input.replace("\\s+".toRegex(), " ").trim()
    }
}
