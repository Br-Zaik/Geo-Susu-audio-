Geo Susu v155

Interfaz API simplificada: pegar todas las APIs juntas, detectar proveedor automaticamente, importar y probar APIs funcionales. Base estable v148.
