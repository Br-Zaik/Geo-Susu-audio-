Geo Susu v155

Cambio puntual en APIs NET:
- Cada API guardada tiene botones PROBAR y BORRAR.
- PROBAR verifica únicamente esa API y actualiza su estado individual.
- PROBAR APIS sigue disponible para comprobar todas.
- Los errores del proveedor se muestran en español cuando se reconocen.

No se modificaron JSON, AUTO, NET, reconocimiento de voz ni el bucle de escucha.
