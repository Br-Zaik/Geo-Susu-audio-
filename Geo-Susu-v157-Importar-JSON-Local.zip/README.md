Geo Susu v157

Cambio puntual solicitado:
- Se retiro la configuracion por link Raw de la pantalla JSON.
- Al tocar el boton JSON se abre directamente el selector de archivos del celular.
- El archivo elegido se valida antes de reemplazar el JSON activo.
- Si el archivo esta vacio, es invalido o no contiene respuestas, se conserva el JSON anterior.
- La importacion funciona sin GitHub y sin internet.

Se conservaron sin cambios las APIs, el reconocimiento de voz, los tiempos de escucha, el bucle, los modos JSON/NET/AUTO y la lectura por voz.
