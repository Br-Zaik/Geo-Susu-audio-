package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class VoskListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var repository: ResponseRepository
    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var memory: MemoryStore
    private lateinit var modelManager: VoskModelManager
    private lateinit var commandSettings: CommandSettings
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var audioRecord: AudioRecord? = null
    private var listenThread: Thread? = null
    private var tts: TextToSpeech? = null
    private var acousticEchoCanceler: AcousticEchoCanceler? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizerLock = Any()

    @Volatile private var running = false
    @Volatile private var loading = false
    @Volatile private var isSpeaking = false
    @Volatile private var pausedByCommand = false
    @Volatile private var wakeOnly = false

    private var lastAnswered = ""
    private var lastAnswerTime = 0L
    private var lastLevelUpdate = 0L
    private var lastPartial = ""
    private var lastSpokenNormalized = ""
    private var lastAutoQuestionKey = ""
    private var lastAutoAnswerSource = ""
    private var lastAutoAnswerTime = 0L
    private val heardMemory = mutableListOf<String>()
    private val preRollBuffers = ArrayDeque<ByteArray>()
    private var ignoreUntil = 0L
    private var highPassPrevInput = 0f
    private var highPassPrevOutput = 0f
    private var noiseFloor = 5f
    private var vadActive = false
    private var vadStartedAt = 0L
    private var lastVoiceAt = 0L
    private var vadVoiceFrames = 0
    private var requestedInputLabel = "Automático"
    private var routedInputLabel = "Sin verificar"

    override fun onCreate() {
        super.onCreate()
        repository = ResponseRepository(this)
        jsonRepository = JsonKnowledgeRepository(this)
        memory = MemoryStore(this)
        modelManager = VoskModelManager(this)
        commandSettings = CommandSettings(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wakeOnly = intent?.getBooleanExtra(EXTRA_WAKE_ONLY, false) ?: false
        val label = if (wakeOnly) "Esperando comando ${commandSettings.getCommandWord()}" else "Preparando Vosk continuo"
        startForeground(NOTIFICATION_ID, buildNotification(label))
        if (!running) startVosk()
        return START_STICKY
    }

    private fun startVosk() {
        if (loading || running) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "", 0)
            stopSelf()
            return
        }

        if (!modelManager.isReady()) {
            sendUpdate("Falta descargar modelo Vosk", "", "Toca ESCUCHAR para descargar automático.", 0)
            stopSelf()
            return
        }

        loading = true
        Thread {
            try {
                sendUpdate("Cargando modelo Vosk...", "", "", 0)
                model = Model(modelManager.modelDir().absolutePath)
                resetRecognizer()
                startAudioLoop()
            } catch (e: Exception) {
                modelManager.deleteModel()
                sendUpdate("Modelo Vosk dañado", "", "Se borró. Toca ESCUCHAR para descargar de nuevo.", 0)
                stopSelf()
            } finally {
                loading = false
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun startAudioLoop() {
        val sampleRate = 16000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuffer, 4096)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            sendUpdate("No se pudo abrir el micrófono", "", "Revisa permisos o si otra app usa el micrófono.", 0)
            stopSelf()
            return
        }

        configureUsbInputIfPresent(audioRecord)
        setupAudioEffects(audioRecord?.audioSessionId ?: 0)

        try {
            running = true
            audioRecord?.startRecording()
            routedInputLabel = describeDevice(audioRecord?.routedDevice)
        } catch (_: Exception) {
            running = false
            sendUpdate("No inició micrófono", "", "Cierra otra app que use el micrófono y vuelve a intentar.", 0)
            stopSelf()
            return
        }

        val startStatus = if (wakeOnly) {
            "Manos libres activo. Di ${commandSettings.getCommandWord()} para preguntar."
        } else {
            "Susurro USB-C activo. Di ${commandSettings.getCommandWord()} para pausar."
        }
        sendUpdate(startStatus, "", "Entrada: $requestedInputLabel. Usando: $routedInputLabel. Salida: Bluetooth/media.", 0)

        listenThread = Thread {
            val buffer = ByteArray(bufferSize)

            while (running) {
                try {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read <= 0) {
                        Thread.sleep(60)
                        continue
                    }

                    cleanAndBoostAudio(buffer, read)
                    val level = calculateLevel(buffer, read)
                    val currentChunk = buffer.copyOf(read)
                    rememberPreRoll(currentChunk)
                    sendLevel(level)

                    if (isSpeaking || System.currentTimeMillis() < ignoreUntil) continue

                    val now = System.currentTimeMillis()
                    val voiceDetected = detectVoiceFrame(level)
                    var startedNow = false

                    if (!vadActive && !voiceDetected) {
                        updateNoiseFloor(level)
                        continue
                    }

                    if (!vadActive && voiceDetected) {
                        vadActive = true
                        startedNow = true
                        vadStartedAt = now
                        lastVoiceAt = now
                        lastPartial = ""
                        resetRecognizer()
                        feedPreRollToRecognizer()
                        sendUpdate("Susurro detectado. Termina tu pregunta...", "", "", level)
                    }

                    if (voiceDetected) lastVoiceAt = now

                    synchronized(recognizerLock) {
                        val rec = recognizer
                        if (rec != null && !startedNow) {
                            val becameFinal = rec.acceptWaveForm(buffer, read)
                            val json = if (becameFinal) rec.getResult() else rec.getPartialResult()
                            val heard = extractText(json)
                            if (heard.isNotBlank() && ResponseRepository.normalize(heard).length >= ResponseRepository.normalize(lastPartial).length) {
                                lastPartial = heard
                                rememberHeard(heard)
                            }
                        }
                    }

                    val duration = now - vadStartedAt
                    val silence = now - lastVoiceAt
                    val canFinish = duration >= MIN_QUESTION_MS && silence >= FINAL_SILENCE_MS
                    val mustFinish = duration >= MAX_QUESTION_MS

                    if (vadActive && (canFinish || mustFinish)) {
                        finishVadQuestion(level)
                    }
                } catch (_: Exception) {
                    sendUpdate("Recuperando micrófono...", "", "", -1)
                    resetVadState()
                    resetRecognizer()
                    Thread.sleep(180)
                }
            }
        }.apply {
            name = "GeoSusuVoskLoop"
            start()
        }
    }


    @Suppress("DEPRECATION")
    private fun configureUsbInputIfPresent(record: AudioRecord?) {
        val audioManager = getSystemService(AudioManager::class.java) ?: return
        try {
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.stopBluetoothSco()
            audioManager.isBluetoothScoOn = false
        } catch (_: Exception) {
        }

        val preferred = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .sortedWith(compareBy<AudioDeviceInfo> {
                when (it.type) {
                    AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> 0
                    AudioDeviceInfo.TYPE_WIRED_HEADSET -> 1
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 3
                    else -> 2
                }
            })
            .firstOrNull { device ->
                device.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                    device.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
            }

        requestedInputLabel = if (preferred == null) "Automático" else describeDevice(preferred)
        try {
            preferred?.let { record?.setPreferredDevice(it) }
        } catch (_: Exception) {
        }
    }

    private fun describeDevice(device: AudioDeviceInfo?): String {
        if (device == null) return "No verificado"
        val type = when (device.type) {
            AudioDeviceInfo.TYPE_USB_DEVICE -> "USB-C"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB-C headset"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Cable/headset"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth mic"
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Micrófono del teléfono"
            else -> "Audio ${device.type}"
        }
        val name = device.productName?.toString()?.takeIf { it.isNotBlank() }.orEmpty()
        return if (name.isBlank()) type else "$type: $name"
    }

    private fun setupAudioEffects(sessionId: Int) {
        if (sessionId <= 0) return

        try {
            if (AcousticEchoCanceler.isAvailable()) {
                acousticEchoCanceler = AcousticEchoCanceler.create(sessionId)?.apply {
                    enabled = true
                }
            }
        } catch (_: Exception) {
        }

        try {
            if (AutomaticGainControl.isAvailable()) {
                automaticGainControl = AutomaticGainControl.create(sessionId)?.apply {
                    enabled = true
                }
            }
        } catch (_: Exception) {
        }

        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                    enabled = true
                }
            }
        } catch (_: Exception) {
        }
    }


    private fun detectVoiceFrame(level: Int): Boolean {
        val whisper = appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER
        val baseThreshold = if (whisper) 8 else 12
        val dynamicThreshold = (noiseFloor + if (whisper) 7f else 10f).toInt()
        val threshold = maxOf(baseThreshold, dynamicThreshold).coerceAtMost(62)
        val candidate = if (vadActive) level >= threshold - 3 else level >= threshold

        vadVoiceFrames = if (candidate) {
            (vadVoiceFrames + 1).coerceAtMost(8)
        } else {
            (vadVoiceFrames - 1).coerceAtLeast(0)
        }

        return if (vadActive) vadVoiceFrames >= 1 else vadVoiceFrames >= 3
    }

    private fun updateNoiseFloor(level: Int) {
        if (level > 70) return
        noiseFloor = (noiseFloor * 0.96f + level.coerceIn(0, 55) * 0.04f).coerceIn(2f, 45f)
    }

    private fun finishVadQuestion(level: Int) {
        var finalJson: String? = null
        synchronized(recognizerLock) {
            try {
                finalJson = recognizer?.getFinalResult()
            } catch (_: Exception) {
            }
        }

        val finalText = extractText(finalJson)
        val bestFinal = chooseBetterQuestion(lastPartial, finalText)
        val confidence = extractConfidence(finalJson)
        val candidates = buildHeardCandidates(bestFinal, lastPartial)
        resetVadState()
        lastPartial = ""
        processText(bestFinal, confidence, candidates)
        sendLevel(level)
    }

    private fun resetVadState() {
        vadActive = false
        vadStartedAt = 0L
        lastVoiceAt = 0L
        vadVoiceFrames = 0
    }

    private fun cleanAndBoostAudio(buffer: ByteArray, read: Int) {
        val gain = appSettings.getMicGain()
        val cleaner = appSettings.getNoiseCleaner()
        val whisper = appSettings.getMicSensitivity() == AppSettings.MicSensitivity.WHISPER

        // No cortar el susurro: la puerta es suave y baja.
        val softGate = when {
            cleaner == AppSettings.NoiseCleaner.STRONG && whisper -> 55
            cleaner == AppSettings.NoiseCleaner.STRONG -> 75
            whisper -> 45
            else -> 65
        }
        val gateFactor = when {
            cleaner == AppSettings.NoiseCleaner.STRONG && whisper -> 0.72f
            cleaner == AppSettings.NoiseCleaner.STRONG -> 0.60f
            else -> 0.82f
        }
        val highPassAlpha = if (cleaner == AppSettings.NoiseCleaner.STRONG) 0.982f else 0.988f

        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()

            val highPassed = sample - highPassPrevInput + highPassAlpha * highPassPrevOutput
            highPassPrevInput = sample.toFloat()
            highPassPrevOutput = highPassed

            var cleaned = highPassed

            if (abs(cleaned) < softGate) {
                cleaned *= gateFactor
            }

            // Levanta voz baja sin destruir picos fuertes.
            var boosted = cleaned * gain
            val absBoosted = abs(boosted)
            if (absBoosted > 26000f) {
                boosted = if (boosted > 0) 26000f + (absBoosted - 26000f) * 0.18f
                else -26000f - (absBoosted - 26000f) * 0.18f
            }

            val out = boosted
                .toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()

            buffer[i] = (out.toInt() and 0xFF).toByte()
            buffer[i + 1] = ((out.toInt() shr 8) and 0xFF).toByte()
            i += 2
        }
    }

    private fun rememberPreRoll(chunk: ByteArray) {
        preRollBuffers.addLast(chunk)
        while (preRollBuffers.size > 5) {
            preRollBuffers.removeFirst()
        }
    }

    private fun feedPreRollToRecognizer() {
        synchronized(recognizerLock) {
            val rec = recognizer ?: return
            for (chunk in preRollBuffers) {
                try {
                    rec.acceptWaveForm(chunk, chunk.size)
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun rememberHeard(text: String) {
        val clean = ResponseRepository.normalize(text)
        if (clean.isBlank()) return
        if (heardMemory.lastOrNull() == clean) return

        heardMemory.add(clean)
        while (heardMemory.size > 8) {
            heardMemory.removeAt(0)
        }
    }

    private fun buildHeardCandidates(finalText: String, partialText: String): List<String> {
        val list = mutableListOf<String>()
        list.add(finalText)
        list.add(partialText)
        list.addAll(heardMemory.takeLast(8))
        return list
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun chooseBetterQuestion(previous: String, current: String): String {
        val old = previous.trim()
        val now = current.trim()
        if (old.isBlank()) return now
        if (now.isBlank()) return old
        return if (ResponseRepository.normalize(now).length >= ResponseRepository.normalize(old).length) now else old
    }

    private fun processText(rawText: String, confidence: Int = -1, heardCandidates: List<String> = listOf(rawText)) {
        val question = VoiceQuestionNormalizer.normalize(normalizeQuestion(rawText))
        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(question) || isIncompleteQuestion(question)) {
            if (!wakeOnly) {
                sendUpdate("No escuché la pregunta completa", question, "Repite la pregunta completa.", -1)
            }
            resetRecognizer()
            return
        }

        if (wakeOnly) {
            if (isWakeCommand(question)) {
                wakeOnly = false
                heardMemory.clear()
                lastPartial = ""
                sendUpdate("Geo detectado", question, "Pregunta ahora. Pantalla apagada activo.", -1)
                resetRecognizer()
                return
            } else {
                resetRecognizer()
            }
            return
        }

        val candidateInputs = (heardCandidates + question)
            .map { VoiceQuestionNormalizer.normalize(it) }
            .filter { it.isNotBlank() }
            .distinct()
        // v148: no bloquear una pregunta entendible solo por baja confianza de Vosk.
        // Si hay texto usable, se deja pasar a LOCAL/JSON/NET. "Repite" queda solo para voz vacía o rota.
        repository.findBestStrictFrom(candidateInputs)

        if (shouldIgnoreOwnVoice(question)) {
            resetRecognizer()
            sendUpdate("Ignorando eco. Listo para otra pregunta.", "", "", -1)
            return
        }

        if (commandSettings.isToggleCommand(question)) {
            togglePause()
            resetRecognizer()
            return
        }

        if (pausedByCommand) {
            sendUpdate("Pausado. Di ${commandSettings.getCommandWord()} para reanudar.", question, "Pausa activa.", -1)
            resetRecognizer()
            return
        }

        val now = System.currentTimeMillis()
        val mode = modeSettings.getMode()
        val repeatedForNet = mode == AnswerModeSettings.Mode.AUTO && shouldForceNetForRepeatedAuto(question)
        if (question == lastAnswered && now - lastAnswerTime < 6500 && !repeatedForNet) {
            resetRecognizer()
            return
        }

        lastAnswered = question
        lastAnswerTime = now

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            sendUpdate("Respuesta local", question, localAnswer, -1)
            speakAndReset(localAnswer)
            return
        }

        when (mode) {
            AnswerModeSettings.Mode.INTERNET -> {
                if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                    sendUpdate("NET bloqueado por texto vacío", question, "No hay una pregunta clara para enviar a NET.", -1)
                    speakAndReset("No hay una pregunta clara para enviar a NET.")
                } else {
                    answerOnline(question)
                }
            }

            AnswerModeSettings.Mode.JSON -> {
                val jsonMatch = jsonRepository.findBest(question)
                if (jsonMatch.itemId != "none") {
                    answerLocal(question, jsonMatch)
                } else {
                    val onlyJson = "No encontrado"
                    sendUpdate("No encontrado en JSON", question, onlyJson, -1)
                    speakAndReset(onlyJson)
                }
            }

            AnswerModeSettings.Mode.AUTO -> {
                if (OnlineAnswerProvider.requiresStructuredNetAnswer(question)) {
                    rememberAutoAnswer(question, "net")
                    answerOnline(question, "Ejercicio: buscando en NET...")
                    return
                }

                if (repeatedForNet) {
                    rememberAutoAnswer(question, "net")
                    answerOnline(question, "Repetida: buscando en NET...")
                    return
                }
                val jsonMatch = jsonRepository.findBest(question)
                if (jsonMatch.itemId != "none") {
                    rememberAutoAnswer(question, "json")
                    answerLocal(question, jsonMatch)
                } else {
                    if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                        sendUpdate("NET bloqueado por texto vacío", question, "No hay una pregunta clara para enviar a NET.", -1)
                        speakAndReset("No hay una pregunta clara para enviar a NET.")
                    } else {
                        rememberAutoAnswer(question, "net")
                        answerOnline(question)
                    }
                }
            }
        }
    }

    private fun isWakeCommand(question: String): Boolean {
        val q = ResponseRepository.normalize(question)
        val command = ResponseRepository.normalize(commandSettings.getCommandWord())
        val wakeVariants = setOf(command, "geo", "jeo", "gio", "eo")

        if (q in wakeVariants) return true
        if (q.startsWith("$command ")) return true
        return wakeVariants.any { q.contains(" $it ") || q.startsWith("$it ") || q.endsWith(" $it") }
    }

    private fun prepareMicForGoogle() {
        running = false
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null

        synchronized(recognizerLock) {
            try {
                recognizer?.close()
            } catch (_: Exception) {
            }
            recognizer = null
        }
    }

    private fun sendWakeGoogle() {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_START_GOOGLE, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            sendBroadcast(Intent(ACTION_WAKE_GOOGLE))
        }
    }

    private fun isIncompleteQuestion(question: String): Boolean {
        val normalized = ResponseRepository.normalize(question)
        val words = questionKeywords(normalized)
        if (words.isEmpty()) return true

        val incomplete = setOf(
            "que", "que es", "q", "q es", "dime", "define", "defineme",
            "la palabra", "palabra", "que significa", "significa"
        )
        return normalized in incomplete
    }

    private fun questionKeywords(normalized: String): List<String> {
        val stop = setOf(
            "q", "que", "es", "son", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "dime", "di", "define",
            "defineme", "concepto", "significa", "significado", "palabra"
        )
        return normalized.split(" ")
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stop }
            .distinct()
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val q = ResponseRepository.normalize(question)
        val a = lastSpokenNormalized
        if (q.isBlank() || a.isBlank()) return false
        if (a.contains(q) && q.length >= 8) return true

        val qWords = q.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val aWords = a.split(" ").toSet()
        val common = qWords.count { it in aWords }
        return common >= 2
    }

    private fun answerNotSure(question: String, score: Int) {
        val answer = "No encontrado."
        memory.saveLast(question, answer, "none", score)
        sendUpdate("No se responde por seguridad", question, answer, -1)
        speakAndReset(answer)
    }

    private fun answerLocal(question: String, match: ResponseRepository.MatchResult) {
        memory.saveLast(question, match.answer, match.itemId, match.score)
        sendUpdate("Respuesta local. Reiniciando escucha.", question, match.answer, -1)
        speakAndReset(match.answer)
    }

    private fun rememberAutoAnswer(question: String, source: String) {
        lastAutoQuestionKey = repeatKey(question)
        lastAutoAnswerSource = source
        lastAutoAnswerTime = System.currentTimeMillis()
    }

    private fun shouldForceNetForRepeatedAuto(question: String): Boolean {
        if (lastAutoAnswerSource != "json") return false
        if (System.currentTimeMillis() - lastAutoAnswerTime > 2 * 60 * 1000L) return false
        return isSameRepeatQuestion(repeatKey(question), lastAutoQuestionKey)
    }

    private fun isSameRepeatQuestion(currentKey: String, previousKey: String): Boolean {
        if (currentKey.isBlank() || previousKey.isBlank()) return false
        if (currentKey == previousKey) return true
        val a = currentKey.split(" ").filter { it.isNotBlank() }.toSet()
        val b = previousKey.split(" ").filter { it.isNotBlank() }.toSet()
        if (a.isEmpty() || b.isEmpty()) return false
        val common = a.count { it in b }
        val minSize = minOf(a.size, b.size)
        val maxSize = maxOf(a.size, b.size)
        return common >= minSize && maxSize <= minSize + 2
    }

    private fun repeatKey(text: String): String {
        return ResponseRepository.normalize(text)
            .replace("\btipo de rocas\b".toRegex(), "tipos de roca")
            .replace("\btipo de roca\b".toRegex(), "tipos de roca")
            .replace("\btipos de rocas\b".toRegex(), "tipos de roca")
            .split(" ")
            .map { repeatCanonical(it.trim()) }
            .filter { it.length >= 3 && it !in repeatStopWords }
            .distinct()
            .joinToString(" ")
    }

    private fun repeatCanonical(word: String): String {
        return when (word) {
            "rocas" -> "roca"
            "minerales" -> "mineral"
            "tipos", "tipo" -> "tipos"
            "clases", "clase" -> "clases"
            else -> if (word.length > 6 && word.endsWith("s") && !word.endsWith("is")) word.dropLast(1) else word
        }
    }

    private fun answerOnline(question: String, statusText: String = "Buscando online...") {
        isSpeaking = true
        stopRecordingSafely()
        sendUpdate(statusText, question, "Buscando definición concreta.", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (_: Exception) {
                "No encontré una definición clara. Guarda esta pregunta en TXT."
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                sendUpdate("Respuesta online. Reiniciando escucha.", question, answer, -1)
                speakTracked(answer)
            }
        }.start()
    }

    private fun speakAndReset(answer: String) {
        isSpeaking = true
        stopRecordingSafely()
        resetRecognizer()
        handler.post {
            speakTracked(answer)
        }
    }

    private fun speakTracked(answer: String) {
        lastSpokenNormalized = ResponseRepository.normalize(answer)
        ignoreUntil = System.currentTimeMillis() + 650L
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    private fun stopRecordingSafely() {
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
    }

    private fun startRecordingSafely() {
        try {
            if (running && audioRecord?.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                audioRecord?.startRecording()
            }
        } catch (_: Exception) {
        }
    }

    private fun togglePause() {
        pausedByCommand = !pausedByCommand
        val command = commandSettings.getCommandWord()
        val answer = if (pausedByCommand) "Pausado." else "Reanudado."
        val status = if (pausedByCommand) "Pausado. Di $command para reanudar." else "Reanudado. Listo para preguntar."
        sendUpdate(status, command, answer, -1)
        speakAndReset(answer)
    }

    private fun resetRecognizer() {
        synchronized(recognizerLock) {
            val currentModel = model ?: return
            recognizer?.close()

            recognizer = if (wakeOnly) {
                val command = ResponseRepository.normalize(commandSettings.getCommandWord()).ifBlank { "geo" }
                val grammar = org.json.JSONArray().apply {
                    put(command)
                    put("geo")
                    put("jeo")
                    put("gio")
                    put("eo")
                    put("oye geo")
                    put("pregunta")
                    put("[unk]")
                }.toString()
                Recognizer(currentModel, 16000.0f, grammar)
            } else {
                Recognizer(currentModel, 16000.0f, buildStudyGrammar()).apply {
                    try {
                        setWords(true)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private fun buildStudyGrammar(): String {
        val phrases = listOf(
            "que es bm en topografia", "que es bm", "bm", "be eme", "ve eme", "banco de nivel", "que es banco de nivel",
            "que es cota", "cota", "cuota", "cota conocida", "cota desconocida",
            "que es cp", "cp", "ce pe", "cambio de punto", "punto de cambio",
            "que es va", "va", "vista atras", "lectura atras",
            "que es vi", "vi", "vista intermedia", "lectura intermedia",
            "que es vf", "vf", "vista adelante", "lectura adelante",
            "que es ai", "ai", "altura de instrumento", "altura instrumental",
            "que es nivelacion", "nivelacion topografica", "nivelacion", "desnivel", "pendiente",
            "que es topografia", "topografia superficial", "levantamiento topografico", "levantamiento simple",
            "distancia", "distancia horizontal", "distancia inclinada", "distancia vertical",
            "replanteo", "replanteo topografico", "pasar plano al terreno", "limites del plano al terreno",
            "curvas de nivel", "perfil topografico", "mira topografica", "nivel optico", "estacion total",
            "rumbo", "azimut", "coordenadas", "este", "norte", "lindero", "area", "perimetro",
            "mineria", "geologia", "mineral", "roca", "tipos de roca", "escala de mohs", "antapaccay"
        )
        return org.json.JSONArray(phrases).toString()
    }

    private fun normalizeQuestion(text: String): String {
        var q = ResponseRepository.normalize(text)
        val command = commandSettings.getCommandWord()
        val wakeWords = listOf("pregunta", "oye", "dime")
        for (word in wakeWords) {
            if (q.startsWith("$word ")) q = q.removePrefix("$word ").trim()
        }
        if (q.startsWith("$command ") && q.split(" ").size > 1) {
            q = q.removePrefix("$command ").trim()
        }
        return q
    }

    private fun extractText(json: String?): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val obj = JSONObject(json)
            obj.optString("text").ifBlank { obj.optString("partial") }
        } catch (_: Exception) {
            ""
        }
    }

    private fun extractConfidence(json: String?): Int {
        if (json.isNullOrBlank()) return -1

        return try {
            val obj = JSONObject(json)
            val words = obj.optJSONArray("result") ?: return -1
            if (words.length() == 0) return -1

            var total = 0.0
            var count = 0
            for (i in 0 until words.length()) {
                val conf = words.optJSONObject(i)?.optDouble("conf", -1.0) ?: -1.0
                if (conf >= 0.0) {
                    total += conf
                    count++
                }
            }

            if (count == 0) -1 else ((total / count) * 100.0).toInt().coerceIn(0, 100)
        } catch (_: Exception) {
            -1
        }
    }

    private fun calculateLevel(buffer: ByteArray, read: Int): Int {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < read) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()
            sum += (sample * sample).toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0
        val rms = sqrt(sum / count)
        return ((rms / 32768.0) * 100.0 * 7.5).toInt().coerceIn(0, 100)
    }

    private fun sendLevel(level: Int) {
        val now = System.currentTimeMillis()
        if (now - lastLevelUpdate < 180) return
        lastLevelUpdate = now
        sendUpdate("", "", "", level)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)
        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Geo Susu Vosk", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Audio activo")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::VoskWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            ignoreUntil = System.currentTimeMillis() + 650L
                            if (appSettings.getListenEngine() == AppSettings.ListenEngine.HANDS_FREE && !pausedByCommand) {
                                wakeOnly = true
                                heardMemory.clear()
                                lastPartial = ""
                            }
                            resetRecognizer()
                            startRecordingSafely()
                            val status = if (pausedByCommand) {
                                "Pausado. Di ${commandSettings.getCommandWord()} para reanudar."
                            } else if (wakeOnly) {
                                "Manos libres activo. Di ${commandSettings.getCommandWord()} para preguntar."
                            } else {
                                "Listo. Pregunta de nuevo."
                            }
                            sendUpdate(status, "", "", -1)
                        }, 180)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    ignoreUntil = System.currentTimeMillis() + 650L
                    if (appSettings.getListenEngine() == AppSettings.ListenEngine.HANDS_FREE && !pausedByCommand) {
                        wakeOnly = true
                        heardMemory.clear()
                        lastPartial = ""
                    }
                    resetRecognizer()
                    startRecordingSafely()
                    val status = if (wakeOnly) {
                        "Manos libres activo. Di ${commandSettings.getCommandWord()} para preguntar."
                    } else {
                        "Listo. Pregunta de nuevo."
                    }
                    sendUpdate(status, "", "", -1)
                }
            })
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (running) {
            try {
                val restart = Intent(applicationContext, VoskListenService::class.java)
                ContextCompat.startForegroundService(applicationContext, restart)
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        audioRecord?.release()
        recognizer?.close()
        model?.close()
        acousticEchoCanceler?.release()
        automaticGainControl?.release()
        noiseSuppressor?.release()
        tts?.stop()
        tts?.shutdown()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.VOSK_UPDATE"
        const val ACTION_WAKE_GOOGLE = "com.bph.geosusuaudio.VOSK_WAKE_GOOGLE"
        const val EXTRA_WAKE_ONLY = "wake_only"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_vosk_channel"
        private const val NOTIFICATION_ID = 2001
        private const val UTTERANCE_ID = "geo_susu_vosk_answer"
        private const val MIN_QUESTION_MS = 3000L
        private const val FINAL_SILENCE_MS = 1900L
        private const val MAX_QUESTION_MS = 9500L
        private val repeatStopWords = setOf(
            "que", "qué", "q", "ke", "k", "es", "son", "ser", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuál", "cuales", "cuáles",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa", "explica", "sobre"
        )
    }
}
