Geo Susu v159

Correcciones aplicadas:
- NET acepta respuestas correctas y breves para verdadero/falso, completar frases, alternativas y fórmulas químicas.
- JSON, NET y AUTO usan una sola regla central en la pantalla, Google interno y Vosk.
- JSON responde solo desde el archivo; NET usa solo las API; AUTO usa JSON y pasa a NET cuando no hay coincidencia. Los ejercicios variables van directo a NET en AUTO.
- Se retiraron los comandos antiguos de voz “Geo” y el modo wakeOnly. Vosk se inicia y detiene manualmente.
- Google interno queda como motor predeterminado y se declara correctamente el servicio de reconocimiento en AndroidManifest.
- La importación local limita la lectura a 10 MB, valida cada registro y conserva el JSON anterior si el archivo falla.
- Se retiró código antiguo de enlaces Raw, bancos TXT y funciones sin uso confirmadas.
- Los errores importantes de JSON, voz y API quedan controlados y registrados sin exponer las claves.
- Groq no forma parte de los proveedores activos. Permanecen Gemini, OpenRouter, Mistral y Cohere.

No se modificaron la sensibilidad del micrófono, la limpieza de ruido ni los tiempos de escucha de la versión v158.
