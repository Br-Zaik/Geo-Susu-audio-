package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var questionRouter: QuestionRouter
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var isListening = false

    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var lastPartial = ""
    private var partialRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        jsonRepository = JsonKnowledgeRepository(this)
        questionRouter = QuestionRouter(jsonRepository)
        warmJsonInBackground()
        memory = MemoryStore(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Susurro Google activo"))
        running = true
        startInternalRecognition(delayMs = 350L)
        return START_STICKY
    }

    private fun startInternalRecognition(delayMs: Long = 300L) {
        if (!running || isSpeaking || isListening) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "Activa permiso de micrófono.", 0)
            stopSelf()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendUpdate("Google interno no disponible", "", "Actualiza Speech Services by Google o usa Google ventana.", 0)
            stopSelf()
            return
        }

        handler.postDelayed({
            if (!running || isSpeaking || isListening) return@postDelayed

            try {
                if (recognizer == null) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer?.setRecognitionListener(listener)
                }

                isListening = true
                lastPartial = ""
                cancelPartialRunnable()
                prepareAudioRouteForUsbMic()
                sendUpdate("Susurro Google: escuchando...", "", "", 0)
                recognizer?.startListening(buildIntent())
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo iniciar una sesión de Google interno", e)
                isListening = false
                sendUpdate("Reiniciando Google interno...", "", "", -1)
                restartRecognizer(900L)
            }
        }, delayMs)
    }

    private fun buildIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 5000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3200L)
            if (Build.VERSION.SDK_INT >= 33) {
                val hints = jsonRepository.recognitionHints(40)
                if (hints.isNotEmpty()) {
                    putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, hints)
                }
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            sendUpdate("Susurro Google listo", "", "", 0)
        }

        override fun onBeginningOfSpeech() {
            sendUpdate("Te estoy escuchando...", "", "", 25)
        }

        override fun onRmsChanged(rmsdB: Float) {
            val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
            sendUpdate("", "", "", level)
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() {
            sendUpdate("Procesando voz...", "", "", -1)
        }

        override fun onError(error: Int) {
            isListening = false
            cancelPartialRunnable()

            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    sendUpdate("No detecto voz", "", "", -1)
                    restartRecognizer(600L)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    restartRecognizer(900L)
                }
                else -> {
                    sendUpdate("Google interno error $error", "", "Reintentando escucha.", -1)
                    restartRecognizer(1200L)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            cancelPartialRunnable()

            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()

            val best = chooseBestSpeechCandidate(matches)

            if (best.isBlank()) {
                restartRecognizer(500L)
                return
            }

            processQuestion(best)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .trim()

            if (partial.isNotBlank()) {
                lastPartial = partial
                sendUpdate("Escuchando sin responder todavía...", partial, "Texto parcial. Esperando resultado final.", -1)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }


    private fun cancelPartialRunnable() {
        partialRunnable?.let { handler.removeCallbacks(it) }
        partialRunnable = null
    }









    private fun prepareAudioRouteForUsbMic() {
        try {
            val audioManager = getSystemService(AudioManager::class.java) ?: return
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.stopBluetoothSco()
            audioManager.isBluetoothScoOn = false
            audioManager.isSpeakerphoneOn = false
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo ajustar la ruta de audio; se usa la ruta actual", e)
        }
    }

    private fun chooseBestSpeechCandidate(matches: List<String>): String {
        val cleaned = matches
            .map { VoiceQuestionNormalizer.normalize(it.trim()) }
            .filter { it.isNotBlank() }
            .distinct()

        if (cleaned.isEmpty()) return ""

        // Elegir la frase completa más probable, no una palabra suelta.
        // Antes se priorizaba cualquier frase con "topografía" y eso podía recortar
        // preguntas como "qué es BM en topografía" a una respuesta genérica.
        return cleaned
            .filter { !VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(it) }
            .maxByOrNull { fullQuestionScore(it) }
            ?: cleaned.maxByOrNull { it.length }
            ?: ""
    }

    private fun fullQuestionScore(question: String): Int {
        val normalized = ResponseRepository.normalize(question)
        val stop = setOf(
            "q", "que", "es", "son", "sera", "seria", "el", "la", "los", "las",
            "un", "una", "unos", "unas", "de", "del", "en", "por", "para",
            "dime", "di", "define", "defineme", "explica", "explicame",
            "concepto", "significa", "significado", "sobre", "cual", "cuales"
        )
        val genericContext = setOf("topografia", "topografica", "topografico", "mineria", "geologia", "terreno")
        val specificCodes = setOf("bm", "cp", "va", "vi", "vf", "ai")
        val words = normalized.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stop }

        var score = 0
        score += content.size * 20
        score += normalized.length.coerceAtMost(120) / 3

        if (words.firstOrNull() in setOf("que", "dime", "define", "explica", "explicame")) score += 8
        if (content.any { it in specificCodes }) score += 35
        if (content.size == 1 && content.first() in genericContext) score -= 20
        if (content.size >= 2 && content.any { it !in genericContext }) score += 20

        return score
    }




    private fun processQuestion(raw: String) {
        val question = VoiceQuestionNormalizer.normalize(raw)

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(question)) {
            sendUpdate("No se detectó pregunta completa", question, "Repite la pregunta.", -1)
            restartRecognizer(650L)
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            restartRecognizer(350L)
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastHeard && now - lastHeardTime < 4500) {
            restartRecognizer(350L)
            return
        }

        lastHeard = question
        lastHeardTime = now

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            speakAnswer(question, localAnswer)
            return
        }

        val mode = modeSettings.getMode()
        if (mode == AnswerModeSettings.Mode.INTERNET) {
            if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                speakAnswer(question, "No hay una pregunta clara para enviar a NET.")
            } else {
                answerOnline(question)
            }
            return
        }

        answerRoutedInBackground(question, mode)
    }

    private fun answerRoutedInBackground(question: String, mode: AnswerModeSettings.Mode) {
        val status = if (mode == AnswerModeSettings.Mode.AUTO) {
            "Buscando en JSON; si no encuentra, pasa a NET..."
        } else {
            "Buscando solo en JSON..."
        }
        sendUpdate(status, question, "Procesando sin bloquear la app.", -1)

        Thread {
            val route = questionRouter.resolve(mode, question)
            if (!running) return@Thread

            when (route) {
                is QuestionRouter.Result.Json -> {
                    val match = route.match
                    memory.saveLast(question, match.answer, match.itemId, match.score)
                    handler.post { speakAnswer(question, match.answer) }
                }
                QuestionRouter.Result.JsonNotFound -> {
                    handler.post { speakAnswer(question, "No encontrado") }
                }
                QuestionRouter.Result.Net -> {
                    if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                        handler.post { speakAnswer(question, "No hay una pregunta clara para enviar a NET.") }
                    } else {
                        answerOnline(question)
                    }
                }
            }
        }.start()
    }

    private fun warmJsonInBackground() {
        Thread {
            try {
                jsonRepository.totalItems
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo precargar el JSON", e)
            }
        }.start()
    }

    private fun answerOnline(question: String, statusText: String = "Buscando NET...") {
        sendUpdate(statusText, question, "Buscando NET.", -1)

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (e: Exception) {
                Log.e(TAG, "Fallo inesperado al consultar NET", e)
                "NET no pudo responder. Revisa internet y el estado de tus API."
            }

            memory.saveLast(question, answer, "online", 0)
            handler.post {
                speakAnswer(question, answer)
            }
        }.start()
    }

    private fun speakAnswer(question: String, answer: String) {
        isSpeaking = true
        isListening = false
        cancelPartialRunnable()
        lastSpokenNormalized = ResponseRepository.normalize(answer)

        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            Log.d(TAG, "El reconocedor ya estaba detenido antes de hablar", e)
        }

        sendUpdate("Respuesta lista", question, answer, -1)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())

        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false
            restartRecognizer(500L)
        }
    }






    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val spoken = lastSpokenNormalized
        if (question.isBlank() || spoken.isBlank()) return false
        if (spoken.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = qWords.count { it in spokenWords }
        return common >= 3 && common >= qWords.size * 0.6
    }

    private fun restartRecognizer(delayMs: Long) {
        if (!running || isSpeaking) return

        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            Log.d(TAG, "El reconocedor ya estaba detenido durante el reinicio", e)
        }

        isListening = false
        startInternalRecognition(delayMs)
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Prueba de Voz")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GoogleInternalWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            isSpeaking = false
                            sendUpdate("Susurro Google escuchando...", "", "", -1)
                            restartRecognizer(550L)
                        }, 350L)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    restartRecognizer(550L)
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        cancelPartialRunnable()

        runCatching { recognizer?.cancel() }
            .onFailure { Log.d(TAG, "El reconocedor ya estaba detenido", it) }
        runCatching { recognizer?.destroy() }
            .onFailure { Log.w(TAG, "No se pudo destruir SpeechRecognizer", it) }

        recognizer = null
        tts?.stop()
        tts?.shutdown()

        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }.onFailure { Log.w(TAG, "No se pudo liberar WakeLock", it) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID = "geo_susu_google_internal_answer"
        private const val TAG = "GeoSusuGoogle"
    }
}
