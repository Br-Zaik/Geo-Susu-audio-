package com.bph.geosusuaudio

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class JsonKnowledgeRepository(private val context: Context) {

    data class KnowledgeItem(
        val id: String,
        val tema: String,
        val titulo: String,
        val contenido: String,
        val keywords: List<String>,
        val normalizedId: String,
        val normalizedTema: String,
        val normalizedTitulo: String,
        val normalizedContenido: String,
        val normalizedKeywords: List<String>,
        val normalizedPhrases: List<String>,
        val meta: String
    )

    private data class RepositoryData(
        val items: List<KnowledgeItem>,
        val exactIndex: Map<String, KnowledgeItem>,
        val invertedIndex: Map<String, List<KnowledgeItem>>
    )

    // Consulta la cache compartida en cada busqueda. Es barata cuando el archivo no
    // cambia y permite que MainActivity y los servicios vean un JSON recien actualizado.
    private fun currentData(): RepositoryData = loadDataCached()

    val totalItems: Int get() = currentData().items.size

    fun recognitionHints(limit: Int = 40): ArrayList<String> {
        if (limit <= 0) return arrayListOf()
        return try {
            val hints = linkedSetOf<String>()
            for (item in currentData().items) {
                if (item.titulo.isNotBlank()) hints.add(item.titulo)
                for (value in item.keywords) {
                    if (value.isNotBlank()) hints.add(value)
                    if (hints.size >= limit) break
                }
                if (hints.size >= limit) break
            }
            ArrayList(hints.take(limit))
        } catch (e: Exception) {
            Log.w(TAG, "No se pudieron preparar sugerencias de voz desde el JSON", e)
            arrayListOf()
        }
    }

    fun findBest(rawQuestion: String): ResponseRepository.MatchResult {
        return try {
            findBestInternal(rawQuestion)
        } catch (e: Exception) {
            Log.e(TAG, "Fallo al resolver una pregunta desde el JSON", e)
            ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }
    }

    private fun findBestInternal(rawQuestion: String): ResponseRepository.MatchResult {
        val question = normalizeForJson(rawQuestion)
        val repositoryData = currentData()
        val items = repositoryData.items
        if (question.length < 2 || items.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val qWords = keyWords(question)
        val forms = queryFormsForExact(question, qWords)

        // 1) Primero busca EXACTO en preguntas, variantes, aliases, keywords y titulos.
        // v148: no usar una frase protegida suelta como "canon minero" cuando
        // la pregunta trae una intencion mas especifica como "de donde proviene".
        for (form in forms) {
            repositoryData.exactIndex[form]?.let { item ->
                return ResponseRepository.MatchResult(buildAnswer(item), "json_${item.id}", 100)
            }
        }
        if (qWords.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        // Si el audio solo reconoce una palabra vaga como "tipo", no inventa respuesta.
        if (qWords.size == 1 && qWords.first() in vagueSingleWords) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val coreQuestion = qWords.joinToString(" ")
        repositoryData.exactIndex[coreQuestion]?.let { item ->
            return ResponseRepository.MatchResult(buildAnswer(item), "json_${item.id}", 99)
        }

        val candidates = candidateItems(qWords, repositoryData.invertedIndex)
        if (candidates.isEmpty()) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        var best: KnowledgeItem? = null
        var bestScore = -9999
        var secondScore = -9999

        for (item in candidates) {
            val score = scoreItem(question, forms, coreQuestion, qWords, item)
            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                best = item
            } else if (score > secondScore) {
                secondScore = score
            }
        }

        val item = best ?: return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)

        // Una bonificacion por intencion (por ejemplo "que es") nunca basta por si sola.
        // Deben coincidir las palabras reales del tema en titulo, id, preguntas,
        // variantes, aliases o keywords. Esto evita devolver el primer registro.
        if (!hasEnoughSubjectEvidence(qWords, item)) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", 0)
        }

        val minimum = when {
            qWords.size == 1 -> 120
            qWords.size == 2 -> 125
            else -> 130
        }

        // Si no hay una coincidencia real en preguntas/variantes/titulo, no responde cualquier cosa.
        if (bestScore < minimum) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        // Si dos respuestas son casi iguales, evita elegir al azar.
        if (bestScore < 250 && bestScore - secondScore < 12) {
            return ResponseRepository.MatchResult(JSON_NOT_FOUND, "none", bestScore.coerceAtLeast(0))
        }

        return ResponseRepository.MatchResult(
            buildAnswer(item),
            "json_${item.id}",
            bestScore.coerceIn(0, 100)
        )
    }

    private fun scoreItem(
        question: String,
        forms: List<String>,
        coreQuestion: String,
        qWords: List<String>,
        item: KnowledgeItem
    ): Int {
        var score = 0
        val qSet = qWords.toSet()

        // Frases exactas y variantes mandan. El contenido no decide solo.
        for (phrase in item.normalizedPhrases) {
            if (phrase.length < 3) continue
            if (phrase in forms) score += 2000

            val phraseCoreWords = keyWords(phrase)
            if (phraseCoreWords.isEmpty()) continue
            val phraseCore = phraseCoreWords.joinToString(" ")

            if (coreQuestion.isNotBlank() && coreQuestion == phraseCore) score += 1700
            if (phraseCoreWords.size >= 2 && phraseCoreWords.all { it in qSet } && qSet.all { it in phraseCoreWords }) {
                score += 1300
            }
            if (phraseCoreWords.size >= 2 && phraseCoreWords.all { it in qSet }) {
                score += 430
            }
        }


        if (coreQuestion.length >= 3) {
            if (containsTerm(item.normalizedTitulo, coreQuestion)) score += 420
            if (containsTerm(item.normalizedId, coreQuestion)) score += 330
            if (containsTerm(item.meta, coreQuestion)) score += 220
        }

        val titleWords = keyWords(item.normalizedTitulo).toSet()
        val idWords = keyWords(item.normalizedId).toSet()
        val keywordWords = item.normalizedKeywords.flatMap { keyWords(it) }.toSet()
        val metaWords = keyWords(item.meta).toSet()
        val contentWords = keyWords(item.normalizedContenido).toSet()

        var titleHits = 0
        var keywordHits = 0
        for (w in qWords) {
            if (w in titleWords) {
                score += 95
                titleHits++
            }
            if (w in idWords) score += 65
            if (w in keywordWords) {
                score += 80
                keywordHits++
            }
            if (w in metaWords) score += 22
            if (w in contentWords) score += 5
        }

        // Bonificacion solo cuando la mayoria de palabras reales aparece en titulo/variantes.
        if (qWords.isNotEmpty() && (titleHits + keywordHits) >= qWords.size) {
            score += 120
        }

        score += intentScore(question, "${item.meta} ${item.normalizedContenido}")
        return score
    }

    private fun buildExactIndex(source: List<KnowledgeItem>): Map<String, KnowledgeItem> {
        val map = LinkedHashMap<String, KnowledgeItem>()
        for (item in source) {
            for (candidate in item.normalizedPhrases) {
                val c = candidate.trim()
                if (c.length >= 2 && c !in vagueSingleWords) map.putIfAbsent(c, item)

                val coreWords = keyWords(c)
                val compactCore = coreWords.joinToString(" ")
                if (compactCore.length >= 3) {
                    if (coreWords.size >= 2 || compactCore !in vagueSingleWords) {
                        map.putIfAbsent(compactCore, item)
                    }
                }
            }
        }
        return map
    }

    private fun buildInvertedIndex(source: List<KnowledgeItem>): Map<String, List<KnowledgeItem>> {
        val map = LinkedHashMap<String, LinkedHashSet<KnowledgeItem>>()
        for (item in source) {
            val text = "${item.normalizedId} ${item.normalizedTema} ${item.normalizedTitulo} ${item.normalizedKeywords.joinToString(" ")}"
            for (word in keyWords(text)) {
                map.getOrPut(word) { linkedSetOf() }.add(item)
            }
        }
        return map.mapValues { it.value.toList() }
    }

    private fun candidateItems(
        qWords: List<String>,
        index: Map<String, List<KnowledgeItem>>
    ): List<KnowledgeItem> {
        val candidates = LinkedHashSet<KnowledgeItem>()
        val lookupWords = qWords.distinct()
        for (word in lookupWords) {
            index[word]?.let { candidates.addAll(it) }
        }

        if (candidates.isNotEmpty()) return candidates.toList()

        // Sin ninguna palabra indexada no existe evidencia tematica. No se compara
        // contra todo el archivo porque una intencion generica podia ganar por puntaje.
        return emptyList()
    }

    private fun hasEnoughSubjectEvidence(qWords: List<String>, item: KnowledgeItem): Boolean {
        val subjectWords = qWords.filter { it !in genericIntentWords }
        if (subjectWords.isEmpty()) return false

        val strongWords = (
            keyWords(item.normalizedId) +
                keyWords(item.normalizedTema) +
                keyWords(item.normalizedTitulo) +
                item.normalizedKeywords.flatMap { keyWords(it) } +
                item.normalizedPhrases.flatMap { keyWords(it) }
            ).toSet()
        val hits = subjectWords.count { it in strongWords }

        return when (subjectWords.size) {
            1 -> hits == 1
            2 -> hits == 2
            else -> hits >= 2 && hits * 3 >= subjectWords.size * 2
        }
    }

    private fun buildAnswer(item: KnowledgeItem): String {
        val clean = item.contenido
            .replace("\r", " ")
            .replace("\n", " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
        val limited = clean.take(540).trim()
        return if (clean.length > 540) "$limited..." else limited
    }


    private fun intentScore(question: String, meta: String): Int {
        var score = 0

        fun hasAny(text: String, words: List<String>): Boolean = words.any { text.contains(it) }

        val intentPairs = listOf(
            listOf("que es", "define", "definicion", "concepto", "significa", "explica que es") to
                listOf("que es", "definicion", "concepto", "significa", "es la", "es el"),
            listOf("de donde", "donde proviene", "proviene", "origen", "procede", "de que proviene", "de donde viene", "fuente") to
                listOf("proviene", "origen", "procede", "de donde", "viene", "fuente"),
            listOf("quien recibe", "quienes reciben", "a quien", "beneficiario", "beneficiarios", "destinatario", "destinatarios") to
                listOf("recibe", "reciben", "beneficiario", "beneficiarios", "destinatario", "destinatarios"),
            listOf("como se distribuye", "distribucion", "distribuye", "reparte", "reparticion", "porcentaje", "porcentajes") to
                listOf("distribuye", "distribucion", "reparte", "reparticion", "porcentaje", "porcentajes", "%"),
            listOf("diferencia", "diferenciar", "no es lo mismo", "comparacion", "comparar") to
                listOf("diferencia", "diferenciar", "comparacion", "mientras", "en cambio")
        )

        for ((questionTerms, answerTerms) in intentPairs) {
            if (hasAny(question, questionTerms)) {
                score += if (hasAny(meta, answerTerms)) 500 else -700
            }
        }

        val simplePairs = listOf(
            listOf("ejemplo", "menciona") to listOf("ejemplo", "ejemplos"),
            listOf("caracteristica", "propiedad") to listOf("caracteristica", "propiedad"),
            listOf("importancia", "importante") to listOf("importancia", "importante"),
            listOf("para que sirve", "funcion", "uso") to listOf("sirve", "funcion", "uso"),
            listOf("clasifica", "clasificacion", "clases", "tipos") to listOf("clasificacion", "clases", "tipos"),
            listOf("formula", "simbolo", "quimica") to listOf("formula", "simbolo", "quimica")
        )

        for ((questionTerms, answerTerms) in simplePairs) {
            if (hasAny(question, questionTerms) && hasAny(meta, answerTerms)) score += 120
        }

        return score
    }

    private fun containsTerm(text: String, term: String): Boolean {
        if (term.length < 3) return false
        val paddedText = " $text "
        val paddedTerm = " $term "
        return paddedText.contains(paddedTerm) || text.contains(term)
    }

    private fun loadDataCached(): RepositoryData {
        val store = JsonKnowledgeStore(context)
        val cacheKey = store.cacheKey()
        synchronized(cacheLock) {
            cachedData?.let { cached ->
                if (cachedKey == cacheKey) return cached
            }
        }

        val items = loadItems()
        val built = RepositoryData(
            items = items,
            exactIndex = buildExactIndex(items),
            invertedIndex = buildInvertedIndex(items)
        )

        synchronized(cacheLock) {
            cachedKey = cacheKey
            cachedData = built
        }

        return built
    }

    private fun loadItems(): List<KnowledgeItem> {
        val store = JsonKnowledgeStore(context)
        val raw = store.readJson()
        if (raw.isBlank()) return emptyList()

        return try {
            val trimmed = raw.trim()
            val array = when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> {
                    val obj = JSONObject(trimmed)
                    obj.optJSONArray("temas")
                        ?: obj.optJSONArray("items")
                        ?: obj.optJSONArray("data")
                        ?: JSONArray()
                }
            }

            val result = mutableListOf<KnowledgeItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val tema = obj.optString("tema", obj.optString("categoria", "General")).trim()
                val titulo = obj.optString(
                    "titulo",
                    obj.optString("pregunta", obj.optString("nombre", tema))
                ).trim()
                val contenido = obj.optString(
                    "contenido",
                    obj.optString("respuesta", obj.optString("texto", obj.optString("descripcion", "")))
                ).trim()

                if (contenido.isBlank()) continue

                val id = obj.optString("id", "item_$i").ifBlank { "item_$i" }
                val keywords = readStringArray(obj, "keywords") +
                    readStringArray(obj, "aliases") +
                    readStringArray(obj, "preguntas") +
                    readStringArray(obj, "variantes") +
                    readStringArray(obj, "palabrasClave")

                val cleanKeywords = keywords
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()

                val normalizedId = normalizeForJson(id.replace("_", " "))
                val normalizedTema = normalizeForJson(tema)
                val normalizedTitulo = normalizeForJson(titulo)
                val normalizedContenido = normalizeForJson(contenido.take(1200))
                val normalizedKeywords = cleanKeywords
                    .map { normalizeForJson(it) }
                    .filter { it.length >= 3 }
                    .distinct()

                val phraseSeed = listOf(normalizedId, normalizedTema, normalizedTitulo) + normalizedKeywords
                val normalizedPhrases = phraseSeed
                    .flatMap { queryForms(it) }
                    .filter { it.length >= 3 }
                    .distinct()

                val meta = "$normalizedId $normalizedTema $normalizedTitulo ${normalizedKeywords.joinToString(" ")}"

                result.add(
                    KnowledgeItem(
                        id = id,
                        tema = tema.ifBlank { "General" },
                        titulo = titulo.ifBlank { tema.ifBlank { "Tema $i" } },
                        contenido = contenido,
                        keywords = cleanKeywords,
                        normalizedId = normalizedId,
                        normalizedTema = normalizedTema,
                        normalizedTitulo = normalizedTitulo,
                        normalizedContenido = normalizedContenido,
                        normalizedKeywords = normalizedKeywords,
                        normalizedPhrases = normalizedPhrases,
                        meta = meta
                    )
                )
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo cargar el JSON activo", e)
            emptyList()
        }
    }

    private fun readStringArray(obj: JSONObject, key: String): List<String> {
        val value = obj.opt(key) ?: return emptyList()
        val list = mutableListOf<String>()

        if (value is JSONArray) {
            for (i in 0 until value.length()) {
                val text = value.optString(i).trim()
                if (text.isNotBlank()) list.add(text)
            }
            return list
        }

        val text = value.toString().trim()
        if (text.isBlank() || text == "null") return emptyList()

        return text
            .split("|", ";", ",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    private fun queryFormsForExact(text: String, qWords: List<String>): List<String> {
        val result = linkedSetOf<String>()
        val clean = normalizeForJson(text)
        if (clean.isNotBlank()) result.add(clean)

        val core = qWords.joinToString(" ")
        if (core.isNotBlank()) result.add(core)


        return result.toList()
    }

    private fun queryForms(text: String): List<String> {
        val result = linkedSetOf<String>()
        val clean = normalizeForJson(text)
        if (clean.isNotBlank()) result.add(clean)

        val core = keyWords(clean).joinToString(" ")
        if (core.isNotBlank()) result.add(core)


        return result.toList()
    }

    private fun keyWords(text: String): List<String> {
        return text.split(" ")
            .map { canonicalWord(it.trim()) }
            .filter { it.length >= 2 && it !in stopWords }
            .distinct()
            .take(12)
    }

    private fun normalizeForJson(text: String): String {
        return ResponseRepository.normalize(text)
    }

    private fun canonicalWord(word: String): String {
        return if (word.length > 6 && word.endsWith("s") && !word.endsWith("is")) {
            word.dropLast(1)
        } else {
            word
        }
    }

    companion object {
        private const val TAG = "GeoSusuJson"
        const val JSON_EMPTY = "No encontrado"
        const val JSON_NOT_FOUND = "No encontrado"

        private val cacheLock = Any()
        @Volatile private var cachedKey: String = ""
        @Volatile private var cachedData: RepositoryData? = null

        private val stopWords = setOf(
            "que", "qué", "q", "ke", "k", "es", "son", "ser", "un", "una", "el", "la", "los", "las",
            "de", "del", "en", "por", "para", "como", "cual", "cuál", "cuales", "cuáles",
            "dime", "di", "define", "definicion", "definición", "concepto", "significa",
            "internet", "net", "json", "tema", "sobre", "explica", "breve", "rapido", "rápido",
            "respuesta", "pregunta", "habla", "susurra"
        )

        private val vagueSingleWords = setOf(
            "tipo", "tipos", "clase", "clases", "tema", "pregunta", "respuesta", "ejemplo", "ejemplos",
            "actividad", "proceso", "cosa", "cosas"
        )

        private val genericIntentWords = setOf(
            "sirve", "funcion", "uso", "formula", "simbolo", "quimica", "ejemplo", "menciona",
            "caracteristica", "propiedad", "importancia", "importante", "clasifica", "clasificacion",
            "diferencia", "origen", "proviene", "recibe", "distribuye", "verdadero", "falso",
            "completa", "complete", "frase", "palabra", "alternativa", "opcion", "inciso", "correcta"
        )
    }
}

class JsonKnowledgeStore(private val context: Context) {

    fun cacheKey(): String {
        val jsonFile = File(context.filesDir, JSON_FILE)
        return listOf(
            jsonFile.length(),
            jsonFile.lastModified(),
            prefs().getLong(KEY_REVISION, 0L)
        ).joinToString(":")
    }

    fun readJson(): String {
        val file = File(context.filesDir, JSON_FILE)
        return if (file.exists()) file.readText() else ""
    }

    fun importJson(raw: String): Pair<Boolean, String> {
        val cleanRaw = raw.removePrefix("\uFEFF").trim()
        if (cleanRaw.isBlank()) return false to "El archivo JSON está vacío."

        val validation = validateItems(cleanRaw)
        if (!validation.ok) return false to validation.message

        val target = File(context.filesDir, JSON_FILE)
        val temp = File(context.filesDir, "$JSON_FILE.tmp")
        val backup = File(context.filesDir, "$JSON_FILE.bak")

        return try {
            temp.delete()
            backup.delete()
            temp.writeText(cleanRaw, Charsets.UTF_8)

            if (target.exists()) target.copyTo(backup, overwrite = true)
            if (target.exists() && !target.delete()) error("No se pudo reemplazar el JSON anterior.")

            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }

            val writtenValidation = validateItems(target.readText(Charsets.UTF_8))
            if (!writtenValidation.ok || writtenValidation.count != validation.count) {
                error("El JSON guardado no superó la verificación final.")
            }

            deleteLegacyRemoteFiles()
            val currentRevision = prefs().getLong(KEY_REVISION, 0L)
            val now = System.currentTimeMillis()
            val nextRevision = if (now > currentRevision) now else currentRevision + 1L
            prefs().edit()
                .remove(KEY_URL)
                .remove(KEY_VARIANTS_URL)
                .putLong(KEY_REVISION, nextRevision)
                .apply()
            backup.delete()
            true to "JSON importado. Elementos: ${validation.count}"
        } catch (e: Exception) {
            Log.e("GeoSusuJsonStore", "No se pudo guardar el JSON importado", e)
            runCatching { temp.delete() }
            runCatching {
                if (backup.exists()) {
                    target.delete()
                    backup.copyTo(target, overwrite = true)
                    backup.delete()
                }
            }
            false to "No se pudo guardar el archivo JSON. Se mantuvo el JSON anterior. ${e.message.orEmpty()}".trim()
        }
    }

    private data class ValidationResult(
        val ok: Boolean,
        val count: Int,
        val message: String
    )

    private fun validateItems(raw: String): ValidationResult {
        return try {
            val array = parseRootArray(raw)
            if (array.length() == 0) {
                return ValidationResult(false, 0, "El archivo no contiene registros.")
            }

            var validCount = 0
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i)
                    ?: return ValidationResult(false, validCount, "El registro ${i + 1} no es un objeto JSON válido.")

                val content = item.optString(
                    "contenido",
                    item.optString("respuesta", item.optString("texto", item.optString("descripcion", "")))
                ).trim()
                if (content.isBlank()) {
                    return ValidationResult(false, validCount, "El registro ${i + 1} no tiene contenido o respuesta.")
                }

                val searchableText = buildList {
                    add(item.optString("titulo", ""))
                    add(item.optString("pregunta", ""))
                    add(item.optString("nombre", ""))
                    addAll(readSearchValues(item, "preguntas"))
                    addAll(readSearchValues(item, "variantes"))
                    addAll(readSearchValues(item, "aliases"))
                    addAll(readSearchValues(item, "keywords"))
                    addAll(readSearchValues(item, "palabrasClave"))
                }.any { it.trim().isNotBlank() }

                if (!searchableText) {
                    return ValidationResult(
                        false,
                        validCount,
                        "El registro ${i + 1} tiene respuesta, pero no contiene pregunta, título, variantes, alias ni palabras clave."
                    )
                }
                validCount++
            }

            ValidationResult(true, validCount, "JSON válido. Elementos: $validCount")
        } catch (e: Exception) {
            ValidationResult(false, 0, "El archivo no contiene un JSON válido: ${e.message.orEmpty()}".trim())
        }
    }

    private fun parseRootArray(raw: String): JSONArray {
        val trimmed = raw.trim()
        if (trimmed.startsWith("[")) return JSONArray(trimmed)
        val obj = JSONObject(trimmed)
        return obj.optJSONArray("temas")
            ?: obj.optJSONArray("items")
            ?: obj.optJSONArray("data")
            ?: throw IllegalArgumentException("La raíz debe ser una lista o contener 'temas', 'items' o 'data'.")
    }

    private fun readSearchValues(obj: JSONObject, key: String): List<String> {
        val value = obj.opt(key) ?: return emptyList()
        if (value is JSONArray) {
            return (0 until value.length())
                .map { value.optString(it).trim() }
                .filter { it.isNotBlank() }
        }
        return value.toString()
            .split("|", ";", ",")
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "null" }
    }

    private fun deleteLegacyRemoteFiles() {
        File(context.filesDir, VARIANTS_FILE).delete()
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS = "geo_susu_json"
        private const val KEY_URL = "json_url"
        private const val KEY_VARIANTS_URL = "json_variants_url"
        private const val KEY_REVISION = "json_revision"
        private const val JSON_FILE = "temas_github.json"
        private const val VARIANTS_FILE = "variantes_github.json"
    }
}
