Geo Susu v161

Cambios aplicados en esta version:
- La busqueda JSON calcula una coincidencia real de 0 a 100 y solo responde cuando el resultado es seguro.
- Las frases cortas, incompletas o ambiguas ya no activan una respuesta solo por compartir palabras generales.
- En modo JSON, una coincidencia insegura muestra “No encontrado”.
- En modo AUTO, una coincidencia insegura o inexistente pasa automaticamente a NET.
- Google interno revisa todas las alternativas finales que devuelve el reconocedor.
- En JSON y AUTO, si una alternativa coincide de forma segura con el JSON cargado, se usa esa alternativa.
- En NET, o cuando ninguna alternativa coincide con JSON, se respeta la confianza entregada por Google y su orden original.
- El sistema no guarda preguntas ni incluye un banco fijo: trabaja exclusivamente con el JSON que el usuario cargue.
- Se conservaron los tiempos restaurados de Google interno: 4200 ms de minimo y 2600 ms de silencio.
- No se modificaron Vosk, las API, la interfaz, la voz de respuesta ni las demas funciones.

Geo Susu v162

Archivo de ejemplo agregado:
- `EJEMPLO_MINIMO_JSON_GEO_SUSU.json`
- Contiene 2 registros de muestra.
- Cada registro tiene exactamente 3 preguntas completas y 3 variantes breves.
- `contenido` contiene la unica respuesta que Geo Susu debe mostrar o leer.
- `aliases` y `keywords` ayudan a distinguir el tema, pero no reemplazan preguntas claras.
- Cada `id` debe ser unico.
- No se deben mezclar dos respuestas diferentes en un mismo registro.
- Evitar variantes demasiado generales como `porcentaje`, `tema` o `mineria` sin contexto.
- El ejemplo no se carga automaticamente ni agrega preguntas permanentes a la app; solo funciona si el usuario lo selecciona como cualquier otro JSON.
- No se modificaron el reconocimiento, JSON seguro, AUTO, NET, Vosk, API, interfaz ni las demas funciones.

Geo Susu v163

Gestión de APIs NET reforzada sin cambiar JSON, reconocimiento, Vosk ni la interfaz principal:
- NET y AUTO usan únicamente APIs que fueron probadas y quedaron en estado FUNCIONANDO.
- La última API que respondió bien se intenta primero en la siguiente consulta.
- Si una API llega a límite, se queda sin créditos, rechaza la clave, falla temporalmente, demora demasiado o devuelve una respuesta no útil, la app pasa a la siguiente API disponible.
- Los límites diarios, por minuto y temporales conservan sus tiempos de espera. Al terminar la espera, una API ya probada vuelve automáticamente a la rotación.
- Antes de recorrer las claves se comprueba que exista una conexión a Internet validada.
- Si se detectan fallos reales de red consecutivos, se detiene el recorrido para no hacer esperar con todas las APIs.
- Las respuestas claramente en inglés, vacías, incompletas, técnicas o con formato incorrecto se rechazan y se prueba otra API.
- El botón DETENER cancela la consulta NET activa e impide que una respuesta antigua aparezca o se lea después.
- Se redujeron los tiempos de espera de consultas normales a 6 segundos de conexión y 9 segundos de lectura. La prueba manual de APIs conserva sus tiempos anteriores para comprobar cada clave con mayor margen.
- PROBAR API individual y PROBAR APIS siguen verificando cada clave por separado y muestran FUNCIONANDO, LÍMITE, EN ESPERA, ERROR o NO PROBADA.
- Si no hay Internet durante una prueba, no se marca una clave válida como errónea ni se borra su estado anterior.
- Se añadió el permiso ACCESS_NETWORK_STATE para detectar la conexión antes de consultar.
- Versión: 16.3.0, código 163.

Geo Susu v164

Estabilidad de Google interno para uso prolongado con microfono USB-C y salida Bluetooth:
- Google ya no mantiene una sola sesion abierta durante horas.
- En espera usa un detector local ligero y abre Google solo cuando detecta voz.
- Cada pregunta crea una sesion nueva de SpeechRecognizer y destruye la anterior.
- Un watchdog renueva la sesion si Google no entrega resultado ni error en 18 segundos.
- Recuperacion automatica ante ocupado, error de audio, cliente, red, servidor desconectado y demasiadas solicitudes.
- Pausas progresivas para evitar bucles agresivos de error.
- Reconstruccion automatica al conectar o desconectar dispositivos USB-C o Bluetooth.
- Watchdog de TTS para que la escucha no quede bloqueada despues de una respuesta.
- WakeLock renovado cada dos horas para sesiones largas.
- Pulsar ESCUCHAR otra vez fuerza una reconstruccion limpia de audio y Google.
- No se modificaron JSON, AUTO, NET, APIs, prueba de APIs, Vosk ni la interfaz principal.
- Version: 16.4.0, codigo 164.

Geo Susu v165

Escucha persistente con una sola pulsacion:
- Pulsar ESCUCHAR una vez deja activo el servicio hasta que el usuario pulse DETENER.
- El detector de espera prefiere el microfono USB-C; si no existe, usa el microfono del celular.
- El microfono Bluetooth no se usa como entrada: se limpia la ruta de comunicacion y se desactiva Bluetooth SCO antes de escuchar.
- Los audifonos Bluetooth se mantienen como salida multimedia para oir las respuestas.
- Si el microfono deja de entregar muestras durante 8 segundos, la app reinicia automaticamente el detector.
- Se corrigio una condicion que podia impedir la recuperacion despues de un error real de `AudioRecord`; ahora el detector vuelve a iniciarse solo.
- El detector se renueva preventivamente cada 20 minutos para evitar que una sesion de audio envejecida quede congelada.
- Si el microfono esta conectado pero apagado con su boton, la app permanece esperando; al encenderlo y hablar, inicia una sesion nueva de Google.
- Si se desconecta el USB-C, la app reconstruye la ruta y queda disponible con el microfono interno como respaldo.
- Se elimino el salto de emergencia que abria Google sin haber detectado voz despues de varios fallos del detector; ahora siempre recupera primero la entrada de audio.
- NET no fue modificado porque no existia una llamada duplicada en una misma ruta.
- No se modificaron JSON, AUTO, rotacion de APIs, prueba de APIs, Vosk ni la logica de respuestas.
- Version: 16.5.0, codigo 165.
