# Validacion de Geo Susu v165

## Cambios revisados

- Servicio iniciado con `START_STICKY` y detenido solamente mediante el boton DETENER o por Android.
- Entrada preferida: USB headset, USB device, cableado y finalmente microfono interno.
- Entrada Bluetooth excluida de la lista preferida.
- Bluetooth SCO desactivado y dispositivo de comunicacion liberado en Android 12 o superior.
- Vigilante del detector cada 3 segundos.
- Recuperacion si no llegan muestras durante 8 segundos.
- Recuperacion corregida ante `AudioRecord.ERROR_DEAD_OBJECT`, `ERROR_INVALID_OPERATION` u otras interrupciones del detector.
- Renovacion preventiva del detector cada 20 minutos.
- Google interno solo se abre despues de detectar voz; no se abre a ciegas por fallos repetidos del detector.
- Watchdog de Google conservado en 18 segundos.
- Watchdog de TTS y renovacion de WakeLock conservados.
- JSON, AUTO, NET, APIs y Vosk sin cambios funcionales.

## Validaciones ejecutadas

- Balance lexico de llaves, parentesis y corchetes en `GoogleInternalListenService.kt`: correcto.
- XML del proyecto: parseo correcto.
- JSON incluido: parseo correcto.
- Version `165` y nombre `16.5.0`: correctos.
- Diferencia contra v164 limitada al servicio de escucha, textos de estado y version.
- Integridad del ZIP: comprobada con `unzip -t`, sin errores.

## Limite de validacion

No se pudo compilar localmente porque este entorno no incluye Gradle ni Android SDK. El proyecto conserva el flujo de GitHub Actions para compilar el APK. La prueba definitiva de cinco horas requiere el celular, el receptor USB-C y los audifonos Bluetooth reales.
