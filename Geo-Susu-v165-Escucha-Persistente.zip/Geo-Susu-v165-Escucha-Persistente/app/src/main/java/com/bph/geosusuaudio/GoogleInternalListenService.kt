package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var questionRouter: QuestionRouter
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var isListening = false
    @Volatile private var onlineRequestVersion = 0
    @Volatile private var engineState = EngineState.STOPPED

    private var activeSessionToken = 0
    private var consecutiveRecognizerErrors = 0
    private var detectorFailureCount = 0
    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var lastPartial = ""
    private var partialRunnable: Runnable? = null
    private var sessionWatchdog: Runnable? = null
    private var ttsWatchdog: Runnable? = null
    private var standbyStartRunnable: Runnable? = null
    private var recoveryRunnable: Runnable? = null
    private var wakeLockRenewRunnable: Runnable? = null
    private var standbyHealthRunnable: Runnable? = null

    @Volatile private var standbyDetectorRunning = false
    @Volatile private var standbyTriggerPending = false
    @Volatile private var standbyDetectorToken = 0
    @Volatile private var lastStandbyFrameAt = 0L
    @Volatile private var standbySessionStartedAt = 0L
    private var standbyRecorder: AudioRecord? = null
    private var standbyThread: Thread? = null
    private var lastLevelBroadcastAt = 0L

    private enum class EngineState {
        STOPPED,
        STANDBY,
        STARTING,
        LISTENING,
        PROCESSING,
        SPEAKING,
        RECOVERING
    }

    override fun onCreate() {
        super.onCreate()
        jsonRepository = JsonKnowledgeRepository(this)
        questionRouter = QuestionRouter(jsonRepository)
        warmJsonInBackground()
        memory = MemoryStore(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        audioManager = getSystemService(AudioManager::class.java)
        tts = TextToSpeech(this, this)
        createChannel()
        createWakeLock()
        registerAudioDeviceWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Geo Susu preparado"))
        val wasRunning = running
        running = true
        renewWakeLock()

        if (wasRunning) {
            hardResetAudioPipeline("Reiniciando escucha...", 300L)
        } else {
            enterStandby(250L, "Esperando voz del microfono...")
        }
        return START_STICKY
    }

    private fun enterStandby(delayMs: Long = 250L, status: String = "Esperando voz del microfono...") {
        if (!running || isSpeaking || engineState == EngineState.PROCESSING) return

        cancelSessionWatchdog()
        cancelRecoveryRunnable()
        cancelStandbyStartRunnable()
        isListening = false
        engineState = EngineState.STANDBY
        sendUpdate(status, "", "", 0)

        val task = Runnable {
            standbyStartRunnable = null
            if (!running || isSpeaking || engineState != EngineState.STANDBY) return@Runnable
            startStandbyDetector()
        }
        standbyStartRunnable = task
        handler.postDelayed(task, delayMs)
    }

    private fun startStandbyDetector() {
        if (!running || isSpeaking || engineState != EngineState.STANDBY || standbyDetectorRunning) return

        stopStandbyDetector()
        destroyRecognizer()
        prepareAudioRouteForUsbMic()

        val minBuffer = AudioRecord.getMinBufferSize(
            STANDBY_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        if (minBuffer <= 0) {
            onStandbyDetectorFailed("No se pudo abrir el detector de voz")
            return
        }

        val bufferSize = max(minBuffer * 2, STANDBY_FRAME_SAMPLES * 4)
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                STANDBY_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo crear AudioRecord de espera", e)
            onStandbyDetectorFailed("No se pudo preparar el microfono")
            return
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            runCatching { recorder.release() }
            onStandbyDetectorFailed("El microfono no pudo iniciar")
            return
        }

        preferredInputDevice()?.let { device ->
            runCatching { recorder.setPreferredDevice(device) }
                .onFailure { Log.w(TAG, "No se pudo fijar el microfono preferido", it) }
        }

        try {
            recorder.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar AudioRecord de espera", e)
            runCatching { recorder.release() }
            onStandbyDetectorFailed("No se pudo activar el microfono")
            return
        }

        standbyDetectorToken += 1
        val detectorToken = standbyDetectorToken
        standbyRecorder = recorder
        standbyDetectorRunning = true
        standbyTriggerPending = false
        engineState = EngineState.STANDBY
        val now = SystemClock.elapsedRealtime()
        lastStandbyFrameAt = now
        standbySessionStartedAt = now
        scheduleStandbyHealthCheck(detectorToken)
        sendUpdate(standbyReadyStatus(), "", "", 0)

        val thread = Thread({ runStandbyDetector(recorder, detectorToken) }, "GeoSusuVoiceStandby")
        standbyThread = thread
        thread.start()
    }

    private fun runStandbyDetector(recorder: AudioRecord, detectorToken: Int) {
        val buffer = ShortArray(STANDBY_FRAME_SAMPLES)
        var calibrationFrames = 0
        var noiseFloor = 80.0
        var voiceFrames = 0

        try {
            while (
                running &&
                standbyDetectorRunning &&
                detectorToken == standbyDetectorToken &&
                engineState == EngineState.STANDBY
            ) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    lastStandbyFrameAt = SystemClock.elapsedRealtime()
                }
                if (read <= 0) {
                    if (!running || !standbyDetectorRunning || detectorToken != standbyDetectorToken) break
                    if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION) {
                        throw IllegalStateException("AudioRecord error $read")
                    }
                    continue
                }

                var sum = 0.0
                for (index in 0 until read) {
                    val sample = buffer[index].toDouble()
                    sum += sample * sample
                }
                val rms = sqrt(sum / read.coerceAtLeast(1))
                publishStandbyLevel(rms)

                if (calibrationFrames < STANDBY_CALIBRATION_FRAMES) {
                    noiseFloor = if (calibrationFrames == 0) rms.coerceAtLeast(20.0) else {
                        (noiseFloor * 0.82) + (rms * 0.18)
                    }
                    calibrationFrames += 1
                    if (calibrationFrames == STANDBY_CALIBRATION_FRAMES) {
                        detectorFailureCount = 0
                    }
                    continue
                }

                val threshold = max(STANDBY_MIN_RMS, noiseFloor * STANDBY_NOISE_MULTIPLIER)
                if (rms < threshold * 1.15) {
                    noiseFloor = (noiseFloor * 0.995) + (rms * 0.005)
                }

                voiceFrames = if (rms >= threshold) {
                    voiceFrames + 1
                } else {
                    (voiceFrames - 1).coerceAtLeast(0)
                }

                if (voiceFrames >= STANDBY_TRIGGER_FRAMES && !standbyTriggerPending) {
                    standbyTriggerPending = true
                    handler.post {
                        if (
                            running &&
                            detectorToken == standbyDetectorToken &&
                            standbyDetectorRunning &&
                            engineState == EngineState.STANDBY
                        ) {
                            sendUpdate("Voz detectada. Iniciando Google...", "", "", -1)
                            stopStandbyDetector()
                            startInternalRecognition(120L)
                        }
                    }
                    break
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "El detector de espera se interrumpio", e)
            handler.post {
                if (
                    running &&
                    detectorToken == standbyDetectorToken &&
                    engineState == EngineState.STANDBY
                ) {
                    onStandbyDetectorFailed("Reconectando el microfono...")
                }
            }
        } finally {
            if (detectorToken == standbyDetectorToken) {
                if (standbyRecorder === recorder) standbyRecorder = null
                standbyDetectorRunning = false
                if (standbyThread === Thread.currentThread()) standbyThread = null
            }
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
        }
    }

    private fun publishStandbyLevel(rms: Double) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLevelBroadcastAt < LEVEL_UPDATE_INTERVAL_MS) return
        lastLevelBroadcastAt = now

        val safe = rms.coerceAtLeast(1.0)
        val db = 20.0 * (ln(safe / 32768.0) / ln(10.0))
        val level = (((db + 60.0) / 50.0) * 100.0).toInt().coerceIn(0, 100)
        sendUpdate("", "", "", level)
    }

    private fun onStandbyDetectorFailed(message: String) {
        stopStandbyDetector()
        detectorFailureCount += 1
        engineState = EngineState.RECOVERING
        val delay = when (detectorFailureCount) {
            1 -> 1000L
            2 -> 2500L
            3 -> 5000L
            else -> 10000L
        }
        sendUpdate(message, "", "La app seguira intentando sin abrir Google a ciegas.", -1)
        enterStandby(delay, "Reconectando el microfono...")
    }

    private fun scheduleStandbyHealthCheck(detectorToken: Int) {
        cancelStandbyHealthCheck()
        val task = object : Runnable {
            override fun run() {
                standbyHealthRunnable = null
                if (
                    !running ||
                    !standbyDetectorRunning ||
                    detectorToken != standbyDetectorToken ||
                    engineState != EngineState.STANDBY
                ) return

                val now = SystemClock.elapsedRealtime()
                val stalled = now - lastStandbyFrameAt > STANDBY_STALL_TIMEOUT_MS
                val recycleDue = now - standbySessionStartedAt > STANDBY_RECYCLE_MS

                if (stalled || recycleDue) {
                    val status = if (stalled) {
                        "El microfono dejo de entregar audio. Reconectando..."
                    } else {
                        "Renovando el microfono para mantener la escucha estable..."
                    }
                    stopStandbyDetector()
                    engineState = EngineState.RECOVERING
                    sendUpdate(status, "", "No necesitas tocar el celular.", -1)
                    enterStandby(500L, "Reconectando escucha...")
                    return
                }

                standbyHealthRunnable = this
                handler.postDelayed(this, STANDBY_HEALTH_CHECK_INTERVAL_MS)
            }
        }
        standbyHealthRunnable = task
        handler.postDelayed(task, STANDBY_HEALTH_CHECK_INTERVAL_MS)
    }

    private fun cancelStandbyHealthCheck() {
        standbyHealthRunnable?.let { handler.removeCallbacks(it) }
        standbyHealthRunnable = null
    }

    private fun standbyReadyStatus(): String {
        return when (preferredInputDevice()?.type) {
            AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE -> "Esperando voz por el microfono USB-C..."
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Esperando voz por el microfono conectado..."
            else -> "Esperando voz por el microfono del celular..."
        }
    }

    private fun stopStandbyDetector() {
        cancelStandbyHealthCheck()
        standbyDetectorToken += 1
        standbyDetectorRunning = false
        standbyTriggerPending = false
        val recorder = standbyRecorder
        standbyRecorder = null
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        standbyThread = null
    }

    private fun startInternalRecognition(delayMs: Long = 250L) {
        if (!running || isSpeaking || engineState == EngineState.PROCESSING) return

        cancelRecoveryRunnable()
        cancelStandbyStartRunnable()
        stopStandbyDetector()

        val task = Runnable {
            recoveryRunnable = null
            if (!running || isSpeaking || engineState == EngineState.PROCESSING) return@Runnable

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                sendUpdate("Falta permiso de microfono", "", "Activa el permiso de microfono.", 0)
                stopSelf()
                return@Runnable
            }

            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                consecutiveRecognizerErrors += 1
                sendUpdate("Google interno no disponible", "", "Se reintentara automaticamente.", 0)
                enterStandby(recognizerBackoffMs(), "Esperando que Google vuelva a estar disponible...")
                return@Runnable
            }

            destroyRecognizer()
            activeSessionToken += 1
            val token = activeSessionToken
            prepareAudioRouteForUsbMic()
            engineState = EngineState.STARTING
            isListening = true
            lastPartial = ""
            cancelPartialRunnable()

            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                    it.setRecognitionListener(buildRecognitionListener(token))
                }
                sendUpdate("Iniciando Google interno...", "", "", 0)
                recognizer?.startListening(buildIntent())
                scheduleSessionWatchdog(token)
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo iniciar una sesion de Google interno", e)
                isListening = false
                consecutiveRecognizerErrors += 1
                destroyRecognizer()
                recoverToStandby("Reiniciando Google interno...", recognizerBackoffMs())
            }
        }

        recoveryRunnable = task
        handler.postDelayed(task, delayMs)
    }

    private fun buildIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            if (Build.VERSION.SDK_INT >= 33) {
                val hints = jsonRepository.recognitionHints(40)
                if (hints.isNotEmpty()) {
                    putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, hints)
                }
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private fun buildRecognitionListener(token: Int): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (!isCurrentSession(token)) return
                engineState = EngineState.LISTENING
                sendUpdate("Susurro Google listo", "", "", 0)
            }

            override fun onBeginningOfSpeech() {
                if (!isCurrentSession(token)) return
                engineState = EngineState.LISTENING
                sendUpdate("Te estoy escuchando...", "", "", 25)
            }

            override fun onRmsChanged(rmsdB: Float) {
                if (!isCurrentSession(token)) return
                val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
                sendUpdate("", "", "", level)
            }

            override fun onBufferReceived(buffer: ByteArray?) = Unit

            override fun onEndOfSpeech() {
                if (!isCurrentSession(token)) return
                engineState = EngineState.PROCESSING
                sendUpdate("Procesando voz...", "", "", -1)
            }

            override fun onError(error: Int) {
                if (!isCurrentSession(token)) return
                finishRecognitionSession(token, destroy = true)

                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        consecutiveRecognizerErrors = 0
                        enterStandby(350L, "Esperando voz del microfono...")
                    }

                    SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> {
                        consecutiveRecognizerErrors += 1
                        recoverToStandby("Google necesita una pausa. Recuperando...", 15000L)
                    }

                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_AUDIO,
                    SpeechRecognizer.ERROR_CLIENT,
                    SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> {
                        consecutiveRecognizerErrors += 1
                        recoverToStandby(errorMessage(error), recognizerBackoffMs())
                    }

                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        sendUpdate("Permiso de microfono perdido", "", "Activa el permiso de microfono.", -1)
                        stopSelf()
                    }

                    SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                    SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                        consecutiveRecognizerErrors += 1
                        recoverToStandby("Idioma de Google no disponible. Reintentando...", 15000L)
                    }

                    else -> {
                        consecutiveRecognizerErrors += 1
                        recoverToStandby("Google interno se recupera del error $error", recognizerBackoffMs())
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                if (!isCurrentSession(token)) return
                finishRecognitionSession(token, destroy = true)
                consecutiveRecognizerErrors = 0

                val matches = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    .orEmpty()
                val confidenceScores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                val best = chooseBestSpeechCandidate(matches, confidenceScores)

                if (best.isBlank()) {
                    enterStandby(300L, "Esperando voz del microfono...")
                    return
                }

                processQuestion(best)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (!isCurrentSession(token)) return
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()

                if (partial.isNotBlank()) {
                    lastPartial = partial
                    sendUpdate("Escuchando sin responder todavia...", partial, "Esperando resultado final.", -1)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        }
    }

    private fun isCurrentSession(token: Int): Boolean {
        return running && token == activeSessionToken
    }

    private fun scheduleSessionWatchdog(token: Int) {
        cancelSessionWatchdog()
        val task = Runnable {
            sessionWatchdog = null
            if (!isCurrentSession(token)) return@Runnable
            if (engineState == EngineState.STARTING || engineState == EngineState.LISTENING || engineState == EngineState.PROCESSING) {
                finishRecognitionSession(token, destroy = true)
                consecutiveRecognizerErrors += 1
                recoverToStandby("Google no respondio. Sesion renovada.", recognizerBackoffMs())
            }
        }
        sessionWatchdog = task
        handler.postDelayed(task, RECOGNITION_WATCHDOG_MS)
    }

    private fun cancelSessionWatchdog() {
        sessionWatchdog?.let { handler.removeCallbacks(it) }
        sessionWatchdog = null
    }

    private fun finishRecognitionSession(token: Int, destroy: Boolean) {
        if (token != activeSessionToken) return
        cancelSessionWatchdog()
        cancelPartialRunnable()
        isListening = false
        if (destroy) destroyRecognizer()
    }

    private fun destroyRecognizer() {
        activeSessionToken += 1
        val current = recognizer
        recognizer = null
        runCatching { current?.cancel() }
            .onFailure { Log.d(TAG, "El reconocedor ya estaba detenido", it) }
        runCatching { current?.destroy() }
            .onFailure { Log.w(TAG, "No se pudo destruir SpeechRecognizer", it) }
        isListening = false
    }

    private fun recoverToStandby(message: String, delayMs: Long) {
        if (!running) return
        cancelSessionWatchdog()
        cancelPartialRunnable()
        stopStandbyDetector()
        destroyRecognizer()
        engineState = EngineState.RECOVERING
        sendUpdate(message, "", "Se recuperara sin tocar el celular.", -1)
        enterStandby(delayMs, "Reconectando escucha...")
    }

    private fun recognizerBackoffMs(): Long {
        return when (consecutiveRecognizerErrors) {
            0, 1 -> 1200L
            2 -> 3000L
            3 -> 7000L
            else -> 15000L
        }
    }

    private fun errorMessage(error: Int): String {
        return when (error) {
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Google estaba ocupado. Renovando sesion..."
            SpeechRecognizer.ERROR_AUDIO -> "Error de audio. Reconectando microfono..."
            SpeechRecognizer.ERROR_CLIENT -> "Sesion de Google danada. Creando otra..."
            SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "Google se desconecto. Recuperando..."
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Conexion inestable. Reintentando escucha..."
            SpeechRecognizer.ERROR_SERVER -> "Servidor de Google temporalmente ocupado..."
            else -> "Recuperando Google interno..."
        }
    }

    private fun cancelPartialRunnable() {
        partialRunnable?.let { handler.removeCallbacks(it) }
        partialRunnable = null
    }

    private fun cancelStandbyStartRunnable() {
        standbyStartRunnable?.let { handler.removeCallbacks(it) }
        standbyStartRunnable = null
    }

    private fun cancelRecoveryRunnable() {
        recoveryRunnable?.let { handler.removeCallbacks(it) }
        recoveryRunnable = null
    }

    private fun prepareAudioRouteForUsbMic() {
        try {
            val manager = audioManager ?: return
            manager.mode = AudioManager.MODE_NORMAL
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                manager.clearCommunicationDevice()
            }
            manager.stopBluetoothSco()
            manager.isBluetoothScoOn = false
            manager.isSpeakerphoneOn = false
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo ajustar la ruta de audio", e)
        }
    }

    private fun preferredInputDevice(): AudioDeviceInfo? {
        val devices = audioManager?.getDevices(AudioManager.GET_DEVICES_INPUTS).orEmpty()
        return devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
            ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_DEVICE }
            ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET }
            ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
    }

    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            if (!running) return
            handler.post { handleAudioRouteChanged() }
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            if (!running) return
            handler.post { handleAudioRouteChanged() }
        }
    }

    private fun registerAudioDeviceWatcher() {
        runCatching { audioManager?.registerAudioDeviceCallback(audioDeviceCallback, handler) }
            .onFailure { Log.w(TAG, "No se pudo vigilar cambios de audio", it) }
    }

    private fun handleAudioRouteChanged() {
        if (!running) return
        if (engineState == EngineState.PROCESSING) return

        if (isSpeaking) {
            runCatching { tts?.stop() }
            finishSpeakingAndReturnToStandby(1200L, "Salida de audio actualizada. Listo otra vez.")
        } else {
            hardResetAudioPipeline("Ruta de audio actualizada. Reconectando...", 1200L)
        }
    }

    private fun hardResetAudioPipeline(status: String, delayMs: Long) {
        if (!running) return
        cancelSessionWatchdog()
        cancelTtsWatchdog()
        cancelStandbyStartRunnable()
        cancelRecoveryRunnable()
        stopStandbyDetector()
        destroyRecognizer()
        isListening = false
        if (isSpeaking) {
            runCatching { tts?.stop() }
            isSpeaking = false
        }
        engineState = EngineState.RECOVERING
        sendUpdate(status, "", "La escucha se recupera automaticamente.", -1)
        enterStandby(delayMs, "Reconectando microfono y Google...")
    }

    private data class SpeechCandidate(
        val text: String,
        val originalIndex: Int,
        val googleConfidence: Float
    )

    private fun chooseBestSpeechCandidate(
        matches: List<String>,
        confidenceScores: FloatArray?
    ): String {
        val candidates = matches
            .mapIndexedNotNull { index, raw ->
                val normalized = VoiceQuestionNormalizer.normalize(raw.trim())
                if (normalized.isBlank()) return@mapIndexedNotNull null
                SpeechCandidate(
                    text = normalized,
                    originalIndex = index,
                    googleConfidence = confidenceScores?.getOrNull(index) ?: -1f
                )
            }
            .filter { !VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(it.text) }
            .distinctBy { it.text }

        if (candidates.isEmpty()) {
            return matches.firstNotNullOfOrNull { raw ->
                VoiceQuestionNormalizer.normalize(raw.trim()).takeIf { it.isNotBlank() }
            }.orEmpty()
        }

        val mode = modeSettings.getMode()
        if (mode != AnswerModeSettings.Mode.INTERNET && jsonRepository.totalItems > 0) {
            val jsonWinner = candidates
                .map { candidate -> candidate to jsonRepository.findBest(candidate.text) }
                .filter { (_, match) -> match.itemId != "none" }
                .maxWithOrNull(
                    compareBy<Pair<SpeechCandidate, ResponseRepository.MatchResult>> { it.second.score }
                        .thenBy { it.first.googleConfidence }
                        .thenBy { -it.first.originalIndex }
                )

            if (jsonWinner != null) return jsonWinner.first.text
        }

        val withConfidence = candidates.filter { it.googleConfidence >= 0f }
        return if (withConfidence.isNotEmpty()) {
            withConfidence.maxWithOrNull(
                compareBy<SpeechCandidate> { it.googleConfidence }
                    .thenBy { -it.originalIndex }
            )?.text.orEmpty()
        } else {
            candidates.minByOrNull { it.originalIndex }?.text.orEmpty()
        }
    }

    private fun processQuestion(raw: String) {
        engineState = EngineState.PROCESSING
        val question = VoiceQuestionNormalizer.normalize(raw)

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(question)) {
            sendUpdate("No se detecto pregunta completa", question, "Repite la pregunta.", -1)
            enterStandby(650L, "Esperando voz del microfono...")
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            enterStandby(350L, "Esperando voz del microfono...")
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastHeard && now - lastHeardTime < 4500) {
            enterStandby(350L, "Esperando voz del microfono...")
            return
        }

        lastHeard = question
        lastHeardTime = now

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            speakAnswer(question, localAnswer)
            return
        }

        val mode = modeSettings.getMode()
        if (mode == AnswerModeSettings.Mode.INTERNET) {
            if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                speakAnswer(question, "No hay una pregunta clara para enviar a NET.")
            } else {
                answerOnline(question)
            }
            return
        }

        answerRoutedInBackground(question, mode)
    }

    private fun answerRoutedInBackground(question: String, mode: AnswerModeSettings.Mode) {
        engineState = EngineState.PROCESSING
        val status = if (mode == AnswerModeSettings.Mode.AUTO) {
            "Buscando en JSON; si no encuentra, pasa a NET..."
        } else {
            "Buscando solo en JSON..."
        }
        sendUpdate(status, question, "Procesando sin bloquear la app.", -1)

        Thread {
            val route = questionRouter.resolve(mode, question)
            if (!running) return@Thread

            when (route) {
                is QuestionRouter.Result.Json -> {
                    val match = route.match
                    memory.saveLast(question, match.answer, match.itemId, match.score)
                    handler.post { speakAnswer(question, match.answer) }
                }
                QuestionRouter.Result.JsonNotFound -> {
                    handler.post { speakAnswer(question, "No encontrado") }
                }
                QuestionRouter.Result.Net -> {
                    if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                        handler.post { speakAnswer(question, "No hay una pregunta clara para enviar a NET.") }
                    } else {
                        answerOnline(question)
                    }
                }
            }
        }.start()
    }

    private fun warmJsonInBackground() {
        Thread {
            try {
                jsonRepository.totalItems
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo precargar el JSON", e)
            }
        }.start()
    }

    private fun answerOnline(question: String, statusText: String = "Buscando NET...") {
        engineState = EngineState.PROCESSING
        sendUpdate(statusText, question, "Buscando una API probada; si falla, pasa a la siguiente.", -1)
        val requestVersion = ++onlineRequestVersion

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (e: Exception) {
                Log.e(TAG, "Fallo inesperado al consultar NET", e)
                "NET no pudo responder. Revisa Internet y el estado de tus APIs."
            }

            if (!running || requestVersion != onlineRequestVersion) return@Thread
            memory.saveLast(question, answer, "online", 0)
            handler.post {
                if (running && requestVersion == onlineRequestVersion) {
                    speakAnswer(question, answer)
                }
            }
        }.start()
    }

    private fun speakAnswer(question: String, answer: String) {
        stopStandbyDetector()
        cancelSessionWatchdog()
        destroyRecognizer()
        isSpeaking = true
        isListening = false
        engineState = EngineState.SPEAKING
        cancelPartialRunnable()
        lastSpokenNormalized = ResponseRepository.normalize(answer)

        sendUpdate("Respuesta lista", question, answer, -1)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())

        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            finishSpeakingAndReturnToStandby(500L, "La voz no inicio. Escucha recuperada.")
        } else {
            scheduleTtsWatchdog(answer)
        }
    }

    private fun scheduleTtsWatchdog(answer: String) {
        cancelTtsWatchdog()
        val timeout = (8000L + answer.length * 115L).coerceIn(12000L, 60000L)
        val task = Runnable {
            ttsWatchdog = null
            if (!running || !isSpeaking) return@Runnable
            Log.w(TAG, "El TTS no informo finalizacion; se libera la escucha")
            runCatching { tts?.stop() }
            finishSpeakingAndReturnToStandby(700L, "Audio finalizado. Escucha recuperada.")
        }
        ttsWatchdog = task
        handler.postDelayed(task, timeout)
    }

    private fun cancelTtsWatchdog() {
        ttsWatchdog?.let { handler.removeCallbacks(it) }
        ttsWatchdog = null
    }

    private fun finishSpeakingAndReturnToStandby(delayMs: Long, status: String) {
        if (!running || !isSpeaking) return
        cancelTtsWatchdog()
        isSpeaking = false
        isListening = false
        engineState = EngineState.RECOVERING
        sendUpdate(status, "", "", -1)
        enterStandby(delayMs, "Esperando voz del microfono...")
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val spoken = lastSpokenNormalized
        if (question.isBlank() || spoken.isBlank()) return false
        if (spoken.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = qWords.count { it in spokenWords }
        return common >= 3 && common >= qWords.size * 0.6
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu JSON")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun createWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GoogleInternalWakeLock").apply {
            setReferenceCounted(false)
        }
    }

    private fun renewWakeLock() {
        wakeLockRenewRunnable?.let { handler.removeCallbacks(it) }
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
            wakeLock?.acquire(WAKE_LOCK_TIMEOUT_MS)
        }.onFailure { Log.w(TAG, "No se pudo renovar WakeLock", it) }

        val task = Runnable {
            wakeLockRenewRunnable = null
            if (running) renewWakeLock()
        }
        wakeLockRenewRunnable = task
        handler.postDelayed(task, WAKE_LOCK_RENEW_MS)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.post {
                            finishSpeakingAndReturnToStandby(450L, "Respuesta terminada. Esperando voz.")
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.post {
                        finishSpeakingAndReturnToStandby(700L, "Error de voz. Escucha recuperada.")
                    }
                }
            })
        } else {
            Log.e(TAG, "TextToSpeech no pudo iniciar: $status")
            isSpeaking = false
            if (running) enterStandby(500L, "Voz no disponible; escucha activa.")
        }
    }

    override fun onDestroy() {
        running = false
        engineState = EngineState.STOPPED
        onlineRequestVersion += 1
        onlineProvider.cancelActiveRequest()
        cancelPartialRunnable()
        cancelSessionWatchdog()
        cancelTtsWatchdog()
        cancelStandbyStartRunnable()
        cancelRecoveryRunnable()
        wakeLockRenewRunnable?.let { handler.removeCallbacks(it) }
        wakeLockRenewRunnable = null
        cancelStandbyHealthCheck()
        stopStandbyDetector()
        destroyRecognizer()

        runCatching { audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback) }
            .onFailure { Log.w(TAG, "No se pudo retirar el observador de audio", it) }

        tts?.stop()
        tts?.shutdown()

        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }.onFailure { Log.w(TAG, "No se pudo liberar WakeLock", it) }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"

        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID = "geo_susu_google_internal_answer"
        private const val TAG = "GeoSusuGoogle"

        private const val STANDBY_SAMPLE_RATE = 16000
        private const val STANDBY_FRAME_SAMPLES = 320
        private const val STANDBY_CALIBRATION_FRAMES = 24
        private const val STANDBY_TRIGGER_FRAMES = 2
        private const val STANDBY_MIN_RMS = 130.0
        private const val STANDBY_NOISE_MULTIPLIER = 2.35
        private const val LEVEL_UPDATE_INTERVAL_MS = 220L
        private const val STANDBY_HEALTH_CHECK_INTERVAL_MS = 3000L
        private const val STANDBY_STALL_TIMEOUT_MS = 8000L
        private const val STANDBY_RECYCLE_MS = 20 * 60 * 1000L
        private const val RECOGNITION_WATCHDOG_MS = 18000L
        private const val WAKE_LOCK_TIMEOUT_MS = 3 * 60 * 60 * 1000L
        private const val WAKE_LOCK_RENEW_MS = 2 * 60 * 60 * 1000L
    }
}
