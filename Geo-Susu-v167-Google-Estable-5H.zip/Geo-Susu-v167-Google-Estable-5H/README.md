Geo Susu v161

Cambios aplicados en esta version:
- La busqueda JSON calcula una coincidencia real de 0 a 100 y solo responde cuando el resultado es seguro.
- Las frases cortas, incompletas o ambiguas ya no activan una respuesta solo por compartir palabras generales.
- En modo JSON, una coincidencia insegura muestra “No encontrado”.
- En modo AUTO, una coincidencia insegura o inexistente pasa automaticamente a NET.
- Google interno revisa todas las alternativas finales que devuelve el reconocedor.
- En JSON y AUTO, si una alternativa coincide de forma segura con el JSON cargado, se usa esa alternativa.
- En NET, o cuando ninguna alternativa coincide con JSON, se respeta la confianza entregada por Google y su orden original.
- El sistema no guarda preguntas ni incluye un banco fijo: trabaja exclusivamente con el JSON que el usuario cargue.
- Se conservaron los tiempos restaurados de Google interno: 4200 ms de minimo y 2600 ms de silencio.
- No se modificaron Vosk, las API, la interfaz, la voz de respuesta ni las demas funciones.

Geo Susu v162

Archivo de ejemplo agregado:
- `EJEMPLO_MINIMO_JSON_GEO_SUSU.json`
- Contiene 2 registros de muestra.
- Cada registro tiene exactamente 3 preguntas completas y 3 variantes breves.
- `contenido` contiene la unica respuesta que Geo Susu debe mostrar o leer.
- `aliases` y `keywords` ayudan a distinguir el tema, pero no reemplazan preguntas claras.
- Cada `id` debe ser unico.
- No se deben mezclar dos respuestas diferentes en un mismo registro.
- Evitar variantes demasiado generales como `porcentaje`, `tema` o `mineria` sin contexto.
- El ejemplo no se carga automaticamente ni agrega preguntas permanentes a la app; solo funciona si el usuario lo selecciona como cualquier otro JSON.
- No se modificaron el reconocimiento, JSON seguro, AUTO, NET, Vosk, API, interfaz ni las demas funciones.

Geo Susu v163

Gestión de APIs NET reforzada sin cambiar JSON, reconocimiento, Vosk ni la interfaz principal:
- NET y AUTO usan únicamente APIs que fueron probadas y quedaron en estado FUNCIONANDO.
- La última API que respondió bien se intenta primero en la siguiente consulta.
- Si una API llega a límite, se queda sin créditos, rechaza la clave, falla temporalmente, demora demasiado o devuelve una respuesta no útil, la app pasa a la siguiente API disponible.
- Los límites diarios, por minuto y temporales conservan sus tiempos de espera. Al terminar la espera, una API ya probada vuelve automáticamente a la rotación.
- Antes de recorrer las claves se comprueba que exista una conexión a Internet validada.
- Si se detectan fallos reales de red consecutivos, se detiene el recorrido para no hacer esperar con todas las APIs.
- Las respuestas claramente en inglés, vacías, incompletas, técnicas o con formato incorrecto se rechazan y se prueba otra API.
- El botón DETENER cancela la consulta NET activa e impide que una respuesta antigua aparezca o se lea después.
- Se redujeron los tiempos de espera de consultas normales a 6 segundos de conexión y 9 segundos de lectura. La prueba manual de APIs conserva sus tiempos anteriores para comprobar cada clave con mayor margen.
- PROBAR API individual y PROBAR APIS siguen verificando cada clave por separado y muestran FUNCIONANDO, LÍMITE, EN ESPERA, ERROR o NO PROBADA.
- Si no hay Internet durante una prueba, no se marca una clave válida como errónea ni se borra su estado anterior.
- Se añadió el permiso ACCESS_NETWORK_STATE para detectar la conexión antes de consultar.
- Versión: 16.3.0, código 163.

Geo Susu v167

Estabilidad de Google interno sin cambiar la forma normal de escuchar:
- Se parte de la v163, anterior al detector AudioRecord de las versiones v164-v166.
- Al pulsar ESCUCHAR, Google interno funciona directamente como antes.
- Con un microfono USB-C conectado, Android usa esa entrada; sin USB-C, usa el microfono del celular.
- Los auriculares Bluetooth se mantienen como salida y se desactiva Bluetooth SCO para no usar su microfono.
- Si una sesion queda sin resultado ni error durante 30 segundos, se destruye y se crea otra automaticamente.
- Ante errores de audio, servicio ocupado, servidor desconectado, red o exceso de solicitudes, se recrea el reconocedor con espera progresiva.
- El reconocedor se renueva preventivamente cada 20 minutos o 80 sesiones para evitar reutilizar una instancia degradada durante horas.
- Los cambios de dispositivos de audio reinician solo la sesion de Google interno y conservan el resto de la app.
- Un vigilante de voz TTS evita que la app quede bloqueada en estado de respuesta si Bluetooth no informa el final.
- El WakeLock permanece activo hasta pulsar DETENER y se libera al cerrar el servicio.
- No se modificaron JSON, AUTO, NET, APIs, prueba de APIs, Vosk, coincidencias ni interfaz.
- Version: 16.7.0, codigo 167.
