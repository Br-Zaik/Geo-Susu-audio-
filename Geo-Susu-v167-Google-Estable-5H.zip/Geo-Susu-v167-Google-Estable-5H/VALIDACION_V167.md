# Validacion de Geo Susu v167

## Base usada
- Se uso Geo Susu v163 como base, porque es la version anterior a los detectores `AudioRecord` agregados en v164, v165 y v166.
- La forma de escucha vuelve a ser directa con `SpeechRecognizer` de Google interno.

## Comportamiento conservado
- Un toque en ESCUCHAR inicia Google interno directamente.
- Con USB-C conectado se conserva la ruta que Android asigna al microfono externo.
- Sin USB-C, Android usa el microfono del celular.
- Bluetooth SCO se desactiva para evitar usar el microfono del auricular; la respuesta sigue usando la salida multimedia Bluetooth.
- Se conservaron los tiempos 4200 / 2600 / 2600 ms.
- Se conservaron JSON, AUTO, NET, APIs, prueba de APIs, Vosk y la seleccion de alternativas de Google.

## Estabilidad agregada
- Vigilante de sesion de 30 segundos para recuperar una escucha congelada.
- Destruccion y creacion de un nuevo SpeechRecognizer ante errores graves.
- Espera progresiva ante ocupado, servidor desconectado, red, audio y exceso de solicitudes.
- Renovacion preventiva del reconocedor cada 20 minutos o 80 sesiones.
- Reinicio controlado cuando cambia un dispositivo de audio.
- Vigilante de TTS para evitar quedar bloqueado en estado de respuesta.
- WakeLock sin vencimiento automatico mientras el servicio esta activo; se libera con DETENER o al destruir el servicio.
- Runnables pendientes y respuestas antiguas se cancelan al detener el servicio.

## Comprobaciones automaticas
- JSON del proyecto analizado correctamente.
- XML del manifiesto, layouts y recursos analizado correctamente.
- Version 167 y nombre 16.7.0 verificados.
- No existen imports ni llamadas a AudioRecord o MediaRecorder en Google interno.
- Los archivos de JSON, AUTO, NET, APIs y Vosk son identicos a v163.
- Balance de llaves, parentesis y corchetes verificado.
- Kotlin analizado por kotlinc: no se detectaron errores de sintaxis; la compilacion Android completa requiere Android SDK.
- Integridad del ZIP verificada.

## Limite real
La estabilidad de cinco horas y la seleccion fisica entre el microfono USB-C y el microfono del celular deben probarse en el telefono. El codigo ahora recupera estados congelados sin cambiar el metodo de escucha que funcionaba antes.
