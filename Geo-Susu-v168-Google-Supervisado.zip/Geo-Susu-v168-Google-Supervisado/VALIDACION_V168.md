# Validacion Geo Susu v168

## Alcance modificado

Solo se modificaron:

1. `GoogleInternalListenService.kt`
2. `app/build.gradle` para subir la version a 168
3. `AndroidManifest.xml` para mostrar v168
4. Documentacion de la version

No se modificaron JSON, AUTO, NET, proveedores de API, prueba de APIs, Vosk, repositorio de coincidencias ni la interfaz.

## Correcciones verificadas en codigo

- Ya no existe el reinicio ciego cada 30 segundos.
- El vigilante principal corre en un ejecutor independiente del hilo de la interfaz.
- Se registra actividad en `onReadyForSpeech`, `onBeginningOfSpeech`, `onRmsChanged`, `onBufferReceived`, `onEndOfSpeech`, `onPartialResults`, `onResults`, `onError` y `onEvent`.
- Si no hay ningun evento del reconocedor durante 16 segundos, se solicita una reconstruccion completa.
- Si desaparece una sesion y no existe un inicio pendiente, la escucha se recupera en 12 segundos.
- El nivel de voz se limita a una emision cada 250 ms y solo cuando existe un cambio util o corresponde refrescarlo.
- Las consultas JSON/NET no son interrumpidas por el supervisor mientras estan procesando.
- El servicio sigue siendo `START_STICKY`, en primer plano y con `foregroundServiceType="microphone"`.
- Se mantiene `PARTIAL_WAKE_LOCK` hasta detener el servicio.
- No se incorporo `AudioRecord`, por lo que se conserva el comportamiento directo de Google interno que funcionaba antes.

## Validaciones automaticas realizadas

- Balance de llaves, parentesis y corchetes del servicio: correcto.
- Analisis de sintaxis con `kotlinc`: no se detectaron errores de sintaxis; las referencias Android no pueden resolverse sin Android SDK.
- XML del manifiesto y recursos: correcto.
- JSON incluidos en el proyecto: sintaxis valida.
- Comparacion contra v167: solo cambiaron los archivos declarados.
- Integridad del ZIP: correcta.

## Limite de la validacion

El entorno no contiene Android SDK ni el hardware del usuario. Por ello, la prueba definitiva debe realizarse en el celular con:

- microfono USB-C conectado y desconectado;
- auriculares Bluetooth como salida;
- ruido de fondo normal;
- una ejecucion prolongada de al menos cinco horas.

La v168 corrige los dos fallos concretos detectados en v167: saturacion por actualizaciones continuas de nivel y vigilante dependiente del hilo principal.
