package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var questionRouter: QuestionRouter
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private val supervisorExecutor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "GeoSusuRecognitionSupervisor").apply { isDaemon = true }
    }
    private val supervisorRecoveryQueued = AtomicBoolean(false)
    private var recognizer: SpeechRecognizer? = null
    private var recognizerGeneration = 0
    private var recognizerCreatedAt = 0L
    private var sessionsOnRecognizer = 0
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var isListening = false
    @Volatile private var onlineRequestVersion = 0
    @Volatile private var isProcessingQuestion = false
    @Volatile private var processingStartedAt = 0L
    @Volatile private var sessionStartedAt = 0L
    @Volatile private var lastRecognizerEventAt = 0L
    @Volatile private var lastStateActivityAt = 0L
    @Volatile private var lastLevelDispatchAt = 0L
    @Volatile private var lastDispatchedLevel = -1

    private var activeSessionId = 0
    private var consecutiveRecognizerErrors = 0
    private var pendingAudioRouteReset = false
    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var lastPartial = ""
    private var partialRunnable: Runnable? = null
    private var pendingStartRunnable: Runnable? = null
    private var sessionWatchdogRunnable: Runnable? = null
    private var ttsWatchdogRunnable: Runnable? = null
    private var audioRouteRunnable: Runnable? = null
    private var lastNotificationStatus = ""
    private var lastNotificationAt = 0L

    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            onAudioRouteChanged()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            onAudioRouteChanged()
        }
    }

    override fun onCreate() {
        super.onCreate()
        jsonRepository = JsonKnowledgeRepository(this)
        questionRouter = QuestionRouter(jsonRepository)
        warmJsonInBackground()
        memory = MemoryStore(this)
        modeSettings = AnswerModeSettings(this)
        appSettings = AppSettings(this)
        audioManager = getSystemService(AudioManager::class.java)
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
        registerAudioDeviceWatcher()
        lastStateActivityAt = SystemClock.elapsedRealtime()
        startRecognitionSupervisor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Susurro Google activo"))
        val wasRunning = running
        running = true
        lastStateActivityAt = SystemClock.elapsedRealtime()
        acquireWakeLock()

        if (wasRunning) {
            hardRestartRecognizer("Reiniciando Google interno...", 350L)
        } else {
            startInternalRecognition(delayMs = 350L)
        }
        return START_STICKY
    }

    private fun startInternalRecognition(delayMs: Long = 300L, forceRecreate: Boolean = false) {
        if (!running || isSpeaking || isProcessingQuestion) return
        cancelPendingStart()
        lastStateActivityAt = SystemClock.elapsedRealtime()

        val task = Runnable {
            pendingStartRunnable = null
            if (!running || isSpeaking || isProcessingQuestion || isListening) return@Runnable

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                sendUpdate("Falta permiso de microfono", "", "Activa permiso de microfono.", 0)
                stopSelf()
                return@Runnable
            }

            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                sendUpdate("Google interno no disponible", "", "Reintentando automaticamente.", 0)
                startInternalRecognition(delayMs = RECOGNIZER_UNAVAILABLE_RETRY_MS, forceRecreate = true)
                return@Runnable
            }

            try {
                val mustRecycle = forceRecreate || shouldRecycleRecognizer()
                if (mustRecycle || recognizer == null) {
                    createRecognizer()
                }

                activeSessionId += 1
                val sessionId = activeSessionId
                sessionsOnRecognizer += 1
                isListening = true
                sessionStartedAt = SystemClock.elapsedRealtime()
                lastRecognizerEventAt = sessionStartedAt
                lastStateActivityAt = sessionStartedAt
                lastPartial = ""
                cancelPartialRunnable()
                prepareAudioRouteForUsbMic()
                sendUpdate("Susurro Google: escuchando...", "", "", 0)
                scheduleSessionWatchdog(sessionId)
                recognizer?.startListening(buildIntent())
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo iniciar una sesion de Google interno", e)
                isListening = false
                cancelSessionWatchdog()
                consecutiveRecognizerErrors += 1
                hardRestartRecognizer("Recuperando Google interno...", recoveryDelayForError(SpeechRecognizer.ERROR_CLIENT))
            }
        }

        pendingStartRunnable = task
        handler.postDelayed(task, delayMs)
    }

    private fun createRecognizer() {
        destroyRecognizer()
        val generation = recognizerGeneration
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(createRecognitionListener(generation))
        }
        recognizerCreatedAt = SystemClock.elapsedRealtime()
        sessionsOnRecognizer = 0
    }

    private fun destroyRecognizer() {
        recognizerGeneration += 1
        val current = recognizer
        recognizer = null
        runCatching { current?.cancel() }
            .onFailure { Log.d(TAG, "El reconocedor ya estaba detenido", it) }
        runCatching { current?.destroy() }
            .onFailure { Log.w(TAG, "No se pudo destruir SpeechRecognizer", it) }
    }

    private fun shouldRecycleRecognizer(): Boolean {
        if (recognizer == null) return true
        val age = SystemClock.elapsedRealtime() - recognizerCreatedAt
        return age >= RECOGNIZER_MAX_AGE_MS || sessionsOnRecognizer >= RECOGNIZER_MAX_SESSIONS
    }

    private fun buildIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            if (Build.VERSION.SDK_INT >= 33) {
                val hints = jsonRepository.recognitionHints(40)
                if (hints.isNotEmpty()) {
                    putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, hints)
                }
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private fun createRecognitionListener(generation: Int) = object : RecognitionListener {
        private fun isCurrent(): Boolean {
            return running && generation == recognizerGeneration
        }

        override fun onReadyForSpeech(params: Bundle?) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            consecutiveRecognizerErrors = 0
            sendUpdate("Susurro Google listo", "", "", 0)
        }

        override fun onBeginningOfSpeech() {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            sendUpdate("Te estoy escuchando...", "", "", 25)
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
            dispatchVoiceLevel(level)
        }

        override fun onBufferReceived(buffer: ByteArray?) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
        }

        override fun onEndOfSpeech() {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            sendUpdate("Procesando voz...", "", "", -1)
        }

        override fun onError(error: Int) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            isListening = false
            cancelPartialRunnable()
            cancelSessionWatchdog()

            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    consecutiveRecognizerErrors = 0
                    sendUpdate("No detecto voz", "", "", -1)
                    restartRecognizer(700L)
                }

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    sendUpdate("Falta permiso de microfono", "", "Activa permiso de microfono.", 0)
                    stopSelf()
                }

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    consecutiveRecognizerErrors += 1
                    hardRestartRecognizer("Reconectando Google interno...", recoveryDelayForError(error))
                }

                SpeechRecognizer.ERROR_TOO_MANY_REQUESTS,
                SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
                SpeechRecognizer.ERROR_SERVER,
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_AUDIO,
                SpeechRecognizer.ERROR_CLIENT,
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                    consecutiveRecognizerErrors += 1
                    hardRestartRecognizer(errorStatus(error), recoveryDelayForError(error))
                }

                else -> {
                    consecutiveRecognizerErrors += 1
                    hardRestartRecognizer("Recuperando Google interno...", recoveryDelayForError(error))
                }
            }
        }

        override fun onResults(results: Bundle?) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            isListening = false
            consecutiveRecognizerErrors = 0
            cancelPartialRunnable()
            cancelSessionWatchdog()

            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()

            val confidenceScores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            val best = chooseBestSpeechCandidate(matches, confidenceScores)

            if (best.isBlank()) {
                restartRecognizer(500L)
                return
            }

            processQuestion(best)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .trim()

            if (partial.isNotBlank()) {
                lastPartial = partial
                sendUpdate("Escuchando sin responder todavia...", partial, "Texto parcial. Esperando resultado final.", -1)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {
            if (!isCurrent() || isSpeaking) return
            markRecognizerEvent()
        }
    }

    private fun markRecognizerEvent() {
        val now = SystemClock.elapsedRealtime()
        lastRecognizerEventAt = now
        lastStateActivityAt = now
    }

    private fun dispatchVoiceLevel(level: Int) {
        val now = SystemClock.elapsedRealtime()
        val enoughTime = now - lastLevelDispatchAt >= LEVEL_BROADCAST_INTERVAL_MS
        val meaningfulChange = lastDispatchedLevel < 0 || abs(level - lastDispatchedLevel) >= LEVEL_CHANGE_THRESHOLD
        val forcedRefresh = now - lastLevelDispatchAt >= LEVEL_FORCE_REFRESH_MS
        if (!enoughTime || (!meaningfulChange && !forcedRefresh)) return

        lastLevelDispatchAt = now
        lastDispatchedLevel = level
        sendUpdate("", "", "", level)
    }

    private fun startRecognitionSupervisor() {
        supervisorExecutor.scheduleAtFixedRate(
            {
                try {
                    runSupervisorCheck()
                } catch (error: Throwable) {
                    Log.e(TAG, "Fallo el supervisor de Google interno", error)
                }
            },
            SUPERVISOR_INITIAL_DELAY_MS,
            SUPERVISOR_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun runSupervisorCheck() {
        if (!running || isSpeaking) return
        val now = SystemClock.elapsedRealtime()

        if (isProcessingQuestion) {
            if (processingStartedAt > 0L && now - processingStartedAt >= PROCESSING_STALL_MS) {
                queueSupervisorRecovery("La respuesta demoro demasiado. Recuperando escucha...", cancelOnline = true)
            }
            return
        }

        if (isListening) {
            val callbackSilence = now - lastRecognizerEventAt
            val sessionAge = now - sessionStartedAt
            when {
                callbackSilence >= RECOGNIZER_CALLBACK_STALL_MS -> {
                    queueSupervisorRecovery("Google dejo de responder. Reconectando...")
                }
                sessionAge >= RECOGNIZER_SESSION_MAX_AGE_MS -> {
                    queueSupervisorRecovery("Renovando Google interno para mantenerlo estable...")
                }
            }
            return
        }

        val startPending = pendingStartRunnable != null
        if (!startPending && now - lastStateActivityAt >= MISSING_SESSION_RECOVERY_MS) {
            queueSupervisorRecovery("La escucha se detuvo. Reiniciando automaticamente...")
        }
    }

    private fun queueSupervisorRecovery(status: String, cancelOnline: Boolean = false) {
        if (!supervisorRecoveryQueued.compareAndSet(false, true)) return
        handler.post {
            try {
                if (!running || isSpeaking) return@post
                if (cancelOnline) {
                    onlineRequestVersion += 1
                    onlineProvider.cancelActiveRequest()
                    isProcessingQuestion = false
                    processingStartedAt = 0L
                }
                hardRestartRecognizer(status, SUPERVISOR_RESTART_DELAY_MS)
            } finally {
                supervisorRecoveryQueued.set(false)
            }
        }
    }

    private fun scheduleSessionWatchdog(sessionId: Int) {
        cancelSessionWatchdog()
        val task = Runnable {
            sessionWatchdogRunnable = null
            if (!running || isSpeaking || !isListening || sessionId != activeSessionId) return@Runnable
            val now = SystemClock.elapsedRealtime()
            val callbackSilence = now - lastRecognizerEventAt
            val sessionAge = now - sessionStartedAt
            if (callbackSilence >= RECOGNIZER_CALLBACK_STALL_MS || sessionAge >= RECOGNIZER_SESSION_MAX_AGE_MS) {
                isListening = false
                consecutiveRecognizerErrors += 1
                hardRestartRecognizer("La escucha se recupera automaticamente.", WATCHDOG_RESTART_DELAY_MS)
            } else {
                scheduleSessionWatchdog(sessionId)
            }
        }
        sessionWatchdogRunnable = task
        handler.postDelayed(task, SESSION_WATCHDOG_MS)
    }

    private fun cancelSessionWatchdog() {
        sessionWatchdogRunnable?.let { handler.removeCallbacks(it) }
        sessionWatchdogRunnable = null
    }

    private fun scheduleTtsWatchdog(answer: String) {
        cancelTtsWatchdog()
        val estimated = 10_000L + answer.length.toLong() * 90L
        val timeout = min(TTS_MAX_WATCHDOG_MS, max(TTS_MIN_WATCHDOG_MS, estimated))
        val task = Runnable {
            ttsWatchdogRunnable = null
            if (!running || !isSpeaking) return@Runnable
            runCatching { tts?.stop() }
            isSpeaking = false
            hardRestartRecognizer("Recuperando escucha...", 600L)
        }
        ttsWatchdogRunnable = task
        handler.postDelayed(task, timeout)
    }

    private fun cancelTtsWatchdog() {
        ttsWatchdogRunnable?.let { handler.removeCallbacks(it) }
        ttsWatchdogRunnable = null
    }

    private fun cancelPendingStart() {
        pendingStartRunnable?.let { handler.removeCallbacks(it) }
        pendingStartRunnable = null
    }

    private fun cancelPartialRunnable() {
        partialRunnable?.let { handler.removeCallbacks(it) }
        partialRunnable = null
    }

    private fun restartRecognizer(delayMs: Long) {
        if (!running || isSpeaking || isProcessingQuestion) return
        cancelSessionWatchdog()
        isListening = false
        lastStateActivityAt = SystemClock.elapsedRealtime()
        startInternalRecognition(delayMs)
    }

    private fun hardRestartRecognizer(status: String, delayMs: Long) {
        if (!running) return
        cancelPendingStart()
        cancelSessionWatchdog()
        isListening = false
        lastStateActivityAt = SystemClock.elapsedRealtime()
        destroyRecognizer()
        if (status.isNotBlank()) sendUpdate(status, "", "", -1)
        if (!isSpeaking) startInternalRecognition(delayMs, forceRecreate = true)
    }

    private fun recoveryDelayForError(error: Int): Long {
        val step = consecutiveRecognizerErrors.coerceIn(1, 5)
        return when (error) {
            SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> min(60_000L, 8_000L * step)
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> min(12_000L, 1_500L * step)
            SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
            SpeechRecognizer.ERROR_SERVER,
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> min(30_000L, 3_000L * step)
            SpeechRecognizer.ERROR_AUDIO,
            SpeechRecognizer.ERROR_CLIENT -> min(15_000L, 2_000L * step)
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> 15_000L
            else -> min(15_000L, 1_500L * step)
        }
    }

    private fun errorStatus(error: Int): String {
        return when (error) {
            SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> "Google interno en espera; se recupera solo..."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Google interno ocupado; reconectando..."
            SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
            SpeechRecognizer.ERROR_SERVER -> "Reconectando Google interno..."
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Esperando conexion para Google interno..."
            SpeechRecognizer.ERROR_AUDIO -> "Recuperando el microfono..."
            SpeechRecognizer.ERROR_CLIENT -> "Reiniciando la escucha..."
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "Reintentando idioma espanol..."
            else -> "Recuperando Google interno..."
        }
    }

    private fun registerAudioDeviceWatcher() {
        runCatching {
            audioManager?.registerAudioDeviceCallback(audioDeviceCallback, handler)
        }.onFailure { Log.w(TAG, "No se pudo registrar el observador de audio", it) }
    }

    private fun unregisterAudioDeviceWatcher() {
        runCatching {
            audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback)
        }.onFailure { Log.w(TAG, "No se pudo quitar el observador de audio", it) }
    }

    private fun onAudioRouteChanged() {
        if (!running) return
        audioRouteRunnable?.let { handler.removeCallbacks(it) }
        audioRouteRunnable = null
        if (isSpeaking) {
            pendingAudioRouteReset = true
            return
        }
        val task = Runnable {
            audioRouteRunnable = null
            if (running && !isSpeaking) {
                hardRestartRecognizer("Actualizando entrada de audio...", 800L)
            }
        }
        audioRouteRunnable = task
        handler.postDelayed(task, AUDIO_ROUTE_SETTLE_MS)
    }

    private fun prepareAudioRouteForUsbMic() {
        try {
            val manager = audioManager ?: getSystemService(AudioManager::class.java) ?: return
            manager.mode = AudioManager.MODE_NORMAL
            manager.stopBluetoothSco()
            manager.isBluetoothScoOn = false
            manager.isSpeakerphoneOn = false
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo ajustar la ruta de audio; se usa la ruta actual", e)
        }
    }

    private data class SpeechCandidate(
        val text: String,
        val originalIndex: Int,
        val googleConfidence: Float
    )

    private fun chooseBestSpeechCandidate(
        matches: List<String>,
        confidenceScores: FloatArray?
    ): String {
        val candidates = matches
            .mapIndexedNotNull { index, raw ->
                val normalized = VoiceQuestionNormalizer.normalize(raw.trim())
                if (normalized.isBlank()) return@mapIndexedNotNull null
                SpeechCandidate(
                    text = normalized,
                    originalIndex = index,
                    googleConfidence = confidenceScores?.getOrNull(index) ?: -1f
                )
            }
            .filter { !VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(it.text) }
            .distinctBy { it.text }

        if (candidates.isEmpty()) {
            return matches.firstNotNullOfOrNull { raw ->
                VoiceQuestionNormalizer.normalize(raw.trim()).takeIf { it.isNotBlank() }
            }.orEmpty()
        }

        val mode = modeSettings.getMode()

        if (mode != AnswerModeSettings.Mode.INTERNET && jsonRepository.totalItems > 0) {
            val jsonWinner = candidates
                .map { candidate -> candidate to jsonRepository.findBest(candidate.text) }
                .filter { (_, match) -> match.itemId != "none" }
                .maxWithOrNull(
                    compareBy<Pair<SpeechCandidate, ResponseRepository.MatchResult>> { it.second.score }
                        .thenBy { it.first.googleConfidence }
                        .thenBy { -it.first.originalIndex }
                )

            if (jsonWinner != null) return jsonWinner.first.text
        }

        val withConfidence = candidates.filter { it.googleConfidence >= 0f }
        return if (withConfidence.isNotEmpty()) {
            withConfidence.maxWithOrNull(
                compareBy<SpeechCandidate> { it.googleConfidence }
                    .thenBy { -it.originalIndex }
            )?.text.orEmpty()
        } else {
            candidates.minByOrNull { it.originalIndex }?.text.orEmpty()
        }
    }

    private fun processQuestion(raw: String) {
        val question = VoiceQuestionNormalizer.normalize(raw)

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(question)) {
            sendUpdate("No se detecto pregunta completa", question, "Repite la pregunta.", -1)
            restartRecognizer(650L)
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            restartRecognizer(350L)
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastHeard && now - lastHeardTime < 4500) {
            restartRecognizer(350L)
            return
        }

        lastHeard = question
        lastHeardTime = now
        isProcessingQuestion = true
        processingStartedAt = SystemClock.elapsedRealtime()
        lastStateActivityAt = processingStartedAt

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            speakAnswer(question, localAnswer)
            return
        }

        val mode = modeSettings.getMode()
        if (mode == AnswerModeSettings.Mode.INTERNET) {
            if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                speakAnswer(question, "No hay una pregunta clara para enviar a NET.")
            } else {
                answerOnline(question)
            }
            return
        }

        answerRoutedInBackground(question, mode)
    }

    private fun answerRoutedInBackground(question: String, mode: AnswerModeSettings.Mode) {
        val status = if (mode == AnswerModeSettings.Mode.AUTO) {
            "Buscando en JSON; si no encuentra, pasa a NET..."
        } else {
            "Buscando solo en JSON..."
        }
        sendUpdate(status, question, "Procesando sin bloquear la app.", -1)

        Thread {
            val route = questionRouter.resolve(mode, question)
            if (!running) return@Thread

            when (route) {
                is QuestionRouter.Result.Json -> {
                    val match = route.match
                    memory.saveLast(question, match.answer, match.itemId, match.score)
                    handler.post { speakAnswer(question, match.answer) }
                }
                QuestionRouter.Result.JsonNotFound -> {
                    handler.post { speakAnswer(question, "No encontrado") }
                }
                QuestionRouter.Result.Net -> {
                    if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                        handler.post { speakAnswer(question, "No hay una pregunta clara para enviar a NET.") }
                    } else {
                        answerOnline(question)
                    }
                }
            }
        }.start()
    }

    private fun warmJsonInBackground() {
        Thread {
            try {
                jsonRepository.totalItems
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo precargar el JSON", e)
            }
        }.start()
    }

    private fun answerOnline(question: String, statusText: String = "Buscando NET...") {
        sendUpdate(statusText, question, "Buscando una API probada; si falla, pasa a la siguiente.", -1)
        val requestVersion = ++onlineRequestVersion

        Thread {
            val answer = try {
                onlineProvider.fetchShortAnswer(question)
            } catch (e: Exception) {
                Log.e(TAG, "Fallo inesperado al consultar NET", e)
                "NET no pudo responder. Revisa Internet y el estado de tus APIs."
            }

            if (!running || requestVersion != onlineRequestVersion) return@Thread
            memory.saveLast(question, answer, "online", 0)
            handler.post {
                if (running && requestVersion == onlineRequestVersion) {
                    speakAnswer(question, answer)
                }
            }
        }.start()
    }

    private fun speakAnswer(question: String, answer: String) {
        isProcessingQuestion = false
        processingStartedAt = 0L
        isSpeaking = true
        isListening = false
        cancelPartialRunnable()
        cancelPendingStart()
        cancelSessionWatchdog()
        lastSpokenNormalized = ResponseRepository.normalize(answer)

        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            Log.d(TAG, "El reconocedor ya estaba detenido antes de hablar", e)
        }

        sendUpdate("Respuesta lista", question, answer, -1)
        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        scheduleTtsWatchdog(answer)

        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            cancelTtsWatchdog()
            isSpeaking = false
            hardRestartRecognizer("Recuperando escucha...", 500L)
        }
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val spoken = lastSpokenNormalized
        if (question.isBlank() || spoken.isBlank()) return false
        if (spoken.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = qWords.count { it in spokenWords }
        return common >= 3 && common >= qWords.size * 0.6
    }

    private fun sendUpdate(status: String, heard: String, answer: String, level: Int) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            val now = SystemClock.elapsedRealtime()
            val shouldNotify = status != lastNotificationStatus || now - lastNotificationAt >= NOTIFICATION_REFRESH_MS
            if (shouldNotify) {
                lastNotificationStatus = status
                lastNotificationAt = now
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIFICATION_ID, buildNotification(status))
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu Prueba de Voz")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "GeoSusuAudio::GoogleInternalWakeLock"
            ).apply { setReferenceCounted(false) }
        }
        runCatching {
            if (wakeLock?.isHeld != true) wakeLock?.acquire()
        }.onFailure { Log.w(TAG, "No se pudo adquirir WakeLock", it) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID) {
                        handler.postDelayed({
                            cancelTtsWatchdog()
                            isSpeaking = false
                            sendUpdate("Susurro Google escuchando...", "", "", -1)
                            if (pendingAudioRouteReset) {
                                pendingAudioRouteReset = false
                                hardRestartRecognizer("Actualizando entrada de audio...", 700L)
                            } else {
                                restartRecognizer(550L)
                            }
                        }, 350L)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.post {
                        cancelTtsWatchdog()
                        isSpeaking = false
                        hardRestartRecognizer("Recuperando escucha...", 550L)
                    }
                }
            })
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (running && !isSpeaking && !isListening) {
            startInternalRecognition(500L)
        }
    }

    override fun onDestroy() {
        running = false
        isProcessingQuestion = false
        processingStartedAt = 0L
        onlineRequestVersion += 1
        onlineProvider.cancelActiveRequest()
        cancelPartialRunnable()
        cancelPendingStart()
        cancelSessionWatchdog()
        cancelTtsWatchdog()
        audioRouteRunnable?.let { handler.removeCallbacks(it) }
        audioRouteRunnable = null
        unregisterAudioDeviceWatcher()
        supervisorExecutor.shutdownNow()
        destroyRecognizer()

        tts?.stop()
        tts?.shutdown()

        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }.onFailure { Log.w(TAG, "No se pudo liberar WakeLock", it) }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID = "geo_susu_google_internal_answer"
        private const val TAG = "GeoSusuGoogle"

        private const val SESSION_WATCHDOG_MS = 20_000L
        private const val WATCHDOG_RESTART_DELAY_MS = 900L
        private const val RECOGNIZER_MAX_AGE_MS = 20 * 60 * 1000L
        private const val RECOGNIZER_MAX_SESSIONS = 80
        private const val RECOGNIZER_UNAVAILABLE_RETRY_MS = 10_000L
        private const val AUDIO_ROUTE_SETTLE_MS = 350L
        private const val TTS_MIN_WATCHDOG_MS = 20_000L
        private const val TTS_MAX_WATCHDOG_MS = 90_000L
        private const val LEVEL_BROADCAST_INTERVAL_MS = 250L
        private const val LEVEL_FORCE_REFRESH_MS = 1_000L
        private const val LEVEL_CHANGE_THRESHOLD = 4
        private const val NOTIFICATION_REFRESH_MS = 5_000L
        private const val SUPERVISOR_INITIAL_DELAY_MS = 4_000L
        private const val SUPERVISOR_INTERVAL_MS = 4_000L
        private const val RECOGNIZER_CALLBACK_STALL_MS = 16_000L
        private const val RECOGNIZER_SESSION_MAX_AGE_MS = 8 * 60 * 1000L
        private const val MISSING_SESSION_RECOVERY_MS = 12_000L
        private const val PROCESSING_STALL_MS = 90_000L
        private const val SUPERVISOR_RESTART_DELAY_MS = 900L
    }
}
