# Validación Geo Susu v176

## Cambio realizado
- Botón de tuerca añadido junto a VELOCIDAD y API.
- Ajuste persistente `Sonido de Google`: activado o desactivado.
- El valor predeterminado es activado.
- Al desactivarlo, el servicio silencia temporalmente los canales de audio usados por los tonos del reconocedor durante el inicio, cierre y reinicio, y los restaura antes de reproducir la respuesta.

## Elementos conservados
- Bucle y tiempos de Google interno.
- JSON, AUTO y NET.
- APIs y prueba de APIs.
- Vosk.
- Preguntas largas y cuadros desplazables.
- Velocidad y voz de respuesta.

## Comprobaciones estáticas
- XML de recursos analizado correctamente.
- Archivos JSON analizados correctamente.
- Identificador del botón y ViewBinding coinciden.
- Preferencia de sonido definida con valor predeterminado activado.
- Restauración del audio ejecutada antes del TTS y al destruir el servicio.
- Integridad del ZIP comprobada.

## Límite de la comprobación
No se compiló un APK en este entorno porque no dispone de Android SDK/Gradle. El efecto exacto del tono debe verificarse en el teléfono, ya que el proveedor de reconocimiento de cada fabricante puede usar un canal de audio diferente.
