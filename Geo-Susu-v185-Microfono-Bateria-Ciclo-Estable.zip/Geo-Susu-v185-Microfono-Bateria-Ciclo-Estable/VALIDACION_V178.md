# Validación Geo Susu v178

## Alcance

Se modificaron únicamente la lógica de Google interno, la detección de preguntas incompletas, la validación/formato de respuestas NET, el número de versión y la documentación. No se cambiaron la sensibilidad del micrófono, los tiempos base 4200/2600/2600, Vosk, la interfaz, el formato JSON ni la configuración de audio.

## Correcciones verificadas

- Preguntas especiales y largas: acumulación de fragmentos entre sesiones.
- Cierre por comando `fin` y por 3 segundos sin texto nuevo.
- El resultado final repetido por Google no reinicia artificialmente el contador si no añadió palabras nuevas.
- Preguntas normales cortas mantienen su envío automático.
- Frases incompletas no llegan a JSON ni NET y pueden continuar acumulándose.
- Casos comprobados como incompletos: `recibe el`, `comprende únicamente`, `se paga por la` y `la regalía minera comprende`.
- Casos comprobados como completos: `qué comprende`, `qué es la regalía minera` y `la regalía minera se paga por el valor del concentrado`.
- Estado `isProcessing`: bloquea cualquier reinicio del reconocedor durante JSON/NET.
- El reconocedor se destruye antes de iniciar la consulta y solo vuelve después del TTS.
- Verdadero/falso acepta `true`, `false`, `Verdadero.`, `La afirmación es verdadera` y equivalentes, mostrando únicamente `Verdadero` o `Falso`.
- NET conserva la rotación automática si una respuesta es vacía, incompleta, inglesa, técnica o de formato inválido.
- El prompt NET exige español, respuesta breve, precisión académica y terminología técnica correcta.
- Versión confirmada: `versionCode 178`, `versionName 17.8.0`.

## Validaciones técnicas

- Archivos JSON analizados correctamente.
- Archivos XML analizados correctamente.
- Prueba aislada de `VoiceQuestionNormalizer` compilada y ejecutada correctamente.
- Prueba aislada del normalizador verdadero/falso: `true`, `false` y frases equivalentes se convierten correctamente.
- Prueba aislada del detector de respuestas API cortadas: rechazó `Se paga por la.`, `Comprende únicamente.` y `Recibe el.`.
- `kotlinc` no reportó errores de sintaxis en los tres archivos modificados; las referencias Android no están disponibles en este entorno.

## Limitación

No se generó el APK localmente porque el entorno no incluye Android SDK ni Gradle. El ZIP conserva el flujo de GitHub Actions incluido en el proyecto para compilar `app-debug.apk`.
