# Validacion Geo Susu v179

## Cambios aplicados

- No se modificaron la sensibilidad, los tiempos 4200/2600/2600, la interfaz, Vosk ni el formato JSON.
- Los parciales de una misma sesion de Google se tratan como revisiones y ya no se concatenan.
- Los fragmentos confirmados de sesiones distintas se acumulan sin duplicar expresiones como `que institucion que instituciones`.
- Completar frases funciona con el espacio al inicio, en medio o al final.
- Las preguntas de completar no se bloquean por terminar en `por`, `de`, `para`, `con` u otra palabra de enlace.
- Las respuestas NET terminadas por limite de tokens se descartan y provocan rotacion de API.
- Las respuestas directas largas sin cierre final se consideran cortadas y no se muestran ni se leen.
- Gemini, OpenAI compatibles y Cohere revisan el motivo de finalizacion.
- La app ya no fabrica un cierre recortando a mitad de palabra y agregando un punto.
- Margen de salida NET aumentado a 320 tokens, manteniendo respuestas breves.

## Version

- `versionCode 179`
- `versionName 17.9.0`
