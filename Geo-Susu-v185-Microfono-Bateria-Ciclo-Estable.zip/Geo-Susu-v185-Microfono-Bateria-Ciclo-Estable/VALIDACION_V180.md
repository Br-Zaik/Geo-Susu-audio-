# Validacion Geo Susu v180

## Problemas corregidos

- Cierre anticipado de preguntas antes de terminar la frase.
- Perdida del inicio en preguntas largas cuando Google reemplazaba el parcial por una cola.
- Preguntas incompletas enviadas a NET por terminar en palabras como `bajo`, `entre`, `mas`, `por` o `para`.
- Comando `fin` incluido dentro de la pregunta.
- Ejercicios de completar enviados con contexto insuficiente.
- Respuestas NET demasiado cortas para comparaciones o preguntas con varios requisitos.
- Respuestas cortadas como `(p.` o terminadas sin cerrar una oracion.
- Respuestas irrelevantes para precios actuales y comparaciones incompletas.
- APIs marcadas en espera durante 10 minutos solo por dar una respuesta deficiente.

## Comportamiento esperado

- Pregunta normal corta: espera una ventana breve y responde automáticamente.
- Pregunta larga o especial: acumula sesiones, conserva el inicio y cierra con `fin` o 3 segundos de silencio.
- Si la frase sigue incompleta: no consulta JSON/NET y mantiene el texto para continuar.
- Respuesta NET inválida o truncada: se descarta y se prueba la siguiente API.
- Respuesta compleja: puede usar varias oraciones y debe cubrir los elementos solicitados.

## Sin cambios

- Sensibilidad y reconocimiento base del micrófono.
- Tiempos `4200/2600/2600`.
- Interfaz, JSON, Vosk y velocidad de voz.

## Version

- `versionCode 180`
- `versionName 18.0.0`
