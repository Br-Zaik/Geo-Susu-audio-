# Geo Susu v182 - Diccionario y escucha simplificada

Base utilizada: Geo Susu v181.

## Cambios aplicados

- Diccionario técnico general de minería y topografía.
- Diccionario dinámico construido desde tema, título, preguntas, variantes, aliases y keywords del JSON activo.
- Sesgo de vocabulario para Google en Android compatible y corrección posterior cautelosa para Google y Vosk.
- El diccionario actúa antes del enrutamiento, por lo que beneficia JSON, NET y AUTO.
- Eliminada la clasificación especial de verdadero/falso.
- Eliminada la clasificación especial de alternativas u opción múltiple.
- Eliminado el comando de voz `fin` y toda su detección en parciales y resultados finales.
- AUTO busca primero en JSON y solo pasa a NET cuando no existe coincidencia segura.
- Espera dinámica por ausencia de palabras nuevas: corta para preguntas simples y mayor para comparaciones o explicaciones.
- Las frases claramente incompletas conservan lo escuchado y permiten continuar.
- Se mantuvieron el ciclo automático, limpieza después del TTS, sesiones aisladas, botón PEGAR, rotación NET, Vosk, sensibilidad y tiempos base 4200/2600/2600.

## Validación realizada

- Compilación con `kotlinc` de las clases puras: ResponseRepository, SpeechDictionary, VoiceQuestionNormalizer y SpeechTranscriptMerger.
- Pruebas del diccionario:
  - `canon menor` -> `canon minero`
  - `regalia manera` -> `regalia minera`
  - `derecho de vivencia` -> `derecho de vigencia`
  - `ingen met` -> `ingemmet`
  - `consecion minera` -> `concesion minera`
- Búsqueda estática sin referencias a los métodos retirados de `fin`, verdadero/falso ni alternativas especiales.
- No se generó APK local porque el proyecto no incluye Gradle Wrapper y el entorno no tiene Android SDK.
