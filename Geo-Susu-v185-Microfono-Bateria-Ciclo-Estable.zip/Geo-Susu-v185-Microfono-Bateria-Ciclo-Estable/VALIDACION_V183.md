# Geo Susu v183 - Ciclo automático corregido

Base utilizada: Geo Susu v182.

## Cambios aplicados

- La pregunta y la respuesta se borran de la pantalla al terminar el TTS.
- También se borra la memoria usada para restaurar los cuadros, por lo que la respuesta anterior no reaparece al salir y volver a la aplicación.
- El historial total de respuestas no se borra.
- El filtro contra la propia voz del TTS ahora funciona únicamente durante una ventana breve de 2.5 segundos después de terminar la lectura.
- El filtro de eco se evalúa inmediatamente al recibir la transcripción y solo descarta coincidencias casi literales; una nueva pregunta que reutiliza palabras de la respuesta anterior no queda bloqueada.
- El texto usado por el filtro de eco se elimina automáticamente al terminar la ventana de protección.
- Durante la confirmación de una pregunta, una palabra aislada o una frase corta sin relación clara ya no se agrega automáticamente como continuación.
- Las continuaciones reales se conservan cuando la pregunta estaba claramente incompleta, contienen varias palabras relacionadas o completan términos técnicos como `canon minero` y `regalía minera`.
- Se mantienen el ciclo automático, el diccionario, JSON, NET, AUTO, Vosk, botones PEGAR, rotación de API, sensibilidad y tiempos base 4200/2600/2600.

## Flujo esperado

`ESCUCHANDO -> CONFIRMANDO -> PROCESANDO -> RESPONDIENDO -> LIMPIANDO -> ESCUCHANDO`

Al terminar de leer una respuesta:

1. se borran pregunta y respuesta;
2. se limpia el estado de la pregunta anterior;
3. se abre una sesión nueva de Google;
4. los callbacks de sesiones antiguas siguen siendo ignorados.

## Validación realizada

- Compilación con `kotlinc` de las clases puras: `ResponseRepository`, `SpeechDictionary`, `VoiceQuestionNormalizer` y `SpeechTranscriptMerger`.
- Pruebas de continuación:
  - `hola` después de una pregunta completa -> descartado.
  - `buenas tardes` después de una pregunta completa -> descartado.
  - `regalía minera` después de una frase terminada en `y` -> aceptado.
  - `minera` después de `regalía` -> aceptado como sufijo técnico.
  - `en el Perú` -> aceptado como continuación.
  - `indicando quién paga` -> aceptado en una pregunta comparativa.
- Pruebas del filtro de eco: texto literal y fragmento literal -> descartados; una pregunta nueva que reutiliza `canon minero` -> aceptada.
- Revisión estática de la limpieza persistente y del límite temporal del filtro de eco.
- No se generó APK local porque el proyecto no incluye Gradle Wrapper y el entorno no tiene Android SDK.
