# Geo Susu v184 - Ciclo Google interno estable

## Problema corregido

La v183 podía entrar en un bucle de recuperación cuando Google interno se desconectaba o agotaba una sesión sin texto útil:

`escuchando -> reconectando -> texto conservado vacío -> escuchando`

En ese estado no se procesaban preguntas simples como la hora o el día siguiente, y el cuadro de respuesta podía mostrar un mensaje interno en vez de permanecer vacío.

## Correcciones aplicadas

- Un estado de continuación sin palabras reales se elimina antes de iniciar otra sesión.
- Si ya existe una pregunta corta estable y Google se desconecta, da timeout o no añade palabras, la pregunta se procesa en lugar de quedar esperando.
- El watchdog y el supervisor usan la misma recuperación segura y no conservan buffers vacíos.
- Las consultas locales de hora, fecha, día relativo y año se confirman en 850 ms y no dependen de una segunda reconexión de Google.
- El cierre normal continúa dependiendo de palabras nuevas reconocidas, no del nivel RMS ni del ruido ambiental.
- Los tiempos de cierre permanecen por debajo de 3 segundos: 1.5-2.3 s para preguntas normales y hasta 2.7-2.8 s para comparaciones o continuaciones.
- La sesión dura como máximo 12 segundos antes de una recuperación dura, reduciendo el tiempo de congelamiento.
- Los mensajes internos de recuperación ya no se escriben en el cuadro de respuesta.
- Al iniciar una sesión limpia se vacían pregunta y respuesta; si existe una continuación real, solo se conserva esa pregunta.
- Se mantuvieron el diccionario, JSON, NET, AUTO, Vosk, TTS, botones PEGAR, rotación de APIs y los tiempos base 4200/2600/2600.

## Validaciones realizadas

- Compilación de las clases puras de normalización, diccionario, unión de fragmentos y respuestas locales mediante `kotlinc`.
- Verificación de que `que hora es` y `que dia es manana` no se clasifiquen como preguntas incompletas y tengan respuesta local.
- Verificación de que los tiempos dinámicos de silencio no superen 3000 ms.
- Verificación de unión de `diferencia entre canon minero` + `y regalia minera`.
- Revisión estática del servicio: sin mensajes `El texto se conserva. Puedes continuar.` y sin ramas que conserven una pregunta larga vacía.

## Versión

- versionCode: 184
- versionName: 18.4.0
