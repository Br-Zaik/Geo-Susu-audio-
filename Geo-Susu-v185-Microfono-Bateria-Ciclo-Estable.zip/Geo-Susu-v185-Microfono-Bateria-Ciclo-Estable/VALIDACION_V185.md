# Geo Susu v185 - Micrófono, batería y ciclo estable

## Problemas corregidos

1. La app mostraba “escuchando” antes de que Google confirmara que el reconocedor estaba listo.
2. La ruta de audio se modificaba antes de cada sesión y podía desconectar o ignorar un micrófono externo.
3. La solicitud de batería se lanzaba antes de los permisos de micrófono/notificaciones y podía quedar tapada.
4. Se guardaba `battery_request_shown=true` antes de comprobar que la pantalla de batería hubiera aparecido.

## Cambios comprobados en código

- Google interno no usa `stopBluetoothSco()`, `isBluetoothScoOn=false`, `MODE_NORMAL` ni `isSpeakerphoneOn=false`.
- Android mantiene automáticamente la entrada activa: USB-C, Bluetooth, cable o micrófono del teléfono.
- La sesión empieza con `Abriendo micrófono de Google...`.
- `Susurro Google: escuchando...` solo aparece al recibir `onReadyForSpeech`, `onRmsChanged`, `onBufferReceived` u otro callback real de audio.
- Existe un watchdog de apertura de 4500 ms que reinicia solo la sesión que no llegó a estar lista.
- Los callbacks tardíos siguen filtrados por `sessionId`.
- El orden de inicio es: RECORD_AUDIO -> POST_NOTIFICATIONS -> batería -> motor de escucha.
- No se usa la preferencia persistente `battery_request_shown` para bloquear futuras solicitudes.
- Si falla la pantalla directa de batería, se abre `ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS`.
- La escucha comienza al volver de la configuración, aunque el usuario no haya aceptado la excepción.

## Funciones preservadas

- JSON, NET y AUTO.
- Diccionario técnico y vocabulario del JSON.
- Cierre dinámico por ausencia de palabras nuevas, máximo aproximado de 3 segundos.
- Ruido RMS sin palabras no prolonga la pregunta.
- Ciclo escuchar -> procesar -> leer -> limpiar -> volver a escuchar.
- Vosk, TTS, rotación de APIs y botones PEGAR.
- Tiempos de Google interno 4200/2600/2600.

## Validaciones realizadas

- Pruebas puras de hora, día de mañana, fecha, preguntas incompletas y unión de fragmentos: OK.
- Revisión sintáctica de Kotlin: no se detectaron errores de sintaxis; las referencias Android requieren compilar con Android SDK.
- Integridad ZIP: comprobada con `unzip -t`.

## Versión

- versionName: 18.5.0
- versionCode: 185
