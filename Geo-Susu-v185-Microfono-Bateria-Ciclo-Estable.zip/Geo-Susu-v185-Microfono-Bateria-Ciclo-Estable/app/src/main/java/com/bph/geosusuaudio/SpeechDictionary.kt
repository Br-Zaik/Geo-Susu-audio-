package com.bph.geosusuaudio

/**
 * Diccionario de apoyo para el reconocimiento de voz.
 *
 * No contiene respuestas ni cambia la sensibilidad del micrófono. Solo:
 * 1) aporta términos técnicos al reconocedor de Google;
 * 2) corrige con mucha cautela palabras que Google/Vosk ya transcribieron.
 */
object SpeechDictionary {

    private val generalHints = listOf(
        "minería", "minería superficial", "minería subterránea", "mina a cielo abierto",
        "canon minero", "regalía minera", "derecho de vigencia", "concesión minera",
        "petitorio minero", "titular de concesión", "recursos minerales",
        "mineral metálico", "mineral no metálico", "yacimiento mineral", "depósito mineral",
        "cateo", "prospección", "exploración minera", "explotación minera",
        "perforación", "voladura", "chancado", "molienda", "flotación", "lixiviación",
        "concentrado de mineral", "planta concentradora", "relave", "presa de relaves",
        "socavón", "galería", "rampa", "chimenea", "banco de explotación",
        "ley de mineral", "ganga", "mena", "estéril", "desmonte",
        "cierre de mina", "plan de cierre", "impacto ambiental", "pasivo ambiental minero",
        "Ministerio de Energía y Minas", "INGEMMET", "SUNAT", "SENACE", "OEFA",
        "gobierno regional", "municipalidad distrital", "municipalidad provincial",
        "topografía", "nivelación", "cota", "banco de nivel", "levantamiento topográfico",
        "replanteo", "vista atrás", "vista intermedia", "vista adelante",
        "altura de instrumento", "BM", "CP", "VA", "VI", "VF", "AI"
    )

    private val phraseCorrections = linkedMapOf(
        "cañon minero" to "canon minero",
        "canon menor" to "canon minero",
        "canon dinero" to "canon minero",
        "regalia manera" to "regalia minera",
        "regalia minero" to "regalia minera",
        "regalias manera" to "regalias mineras",
        "derecho de vivencia" to "derecho de vigencia",
        "consecion minera" to "concesion minera",
        "concesion manera" to "concesion minera",
        "petitorio dinero" to "petitorio minero",
        "ingen met" to "ingemmet",
        "inge met" to "ingemmet",
        "ingemet" to "ingemmet",
        "ingemec" to "ingemmet",
        "senase" to "senace",
        "o e f a" to "oefa",
        "s u n a t" to "sunat",
        "chancador" to "chancado",
        "chancao" to "chancado",
        "relabe" to "relave",
        "yacimento" to "yacimiento",
        "socabon" to "socavon",
        "mina cielo abierto" to "mina a cielo abierto",
        "mineria cielo abierto" to "mineria a cielo abierto"
    )

    private val protectedCommonWords = setOf(
        "antes", "ahora", "donde", "cuando", "cuanto", "cuales", "quienes", "porque",
        "explica", "define", "diferencia", "principal", "principales", "proceso", "procesos",
        "empresa", "empresas", "estado", "recurso", "recursos", "trabajo", "trabajos",
        "respuesta", "pregunta", "ejemplo", "ejemplos", "forma", "formas", "parte", "partes"
    )

    fun buildRecognitionHints(dynamicHints: Collection<String>, limit: Int): ArrayList<String> {
        if (limit <= 0) return arrayListOf()

        val result = linkedSetOf<String>()
        val cleanDynamic = dynamicHints.asSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .toList()

        // Se reservan espacios para ambos grupos: el JSON activo y el vocabulario
        // técnico permanente. Así el diccionario funciona también en NET y AUTO.
        val dynamicBudget = (limit * 2 / 3).coerceAtLeast(1)
        cleanDynamic.take(dynamicBudget).forEach { result.add(it) }
        generalHints.take((limit - result.size).coerceAtLeast(0)).forEach { result.add(it) }
        cleanDynamic.drop(dynamicBudget).forEach { result.add(it) }
        generalHints.forEach { result.add(it) }
        return ArrayList(result.take(limit))
    }

    fun correct(raw: String, dynamicTerms: Collection<String> = emptyList()): String {
        var text = ResponseRepository.normalize(raw)
        if (text.isBlank()) return ""

        for ((badRaw, goodRaw) in phraseCorrections) {
            val bad = ResponseRepository.normalize(badRaw)
            val good = ResponseRepository.normalize(goodRaw)
            text = text.replace(Regex("(?:^| )${Regex.escape(bad)}(?= |$)")) { match ->
                val prefix = if (match.value.startsWith(" ")) " " else ""
                prefix + good
            }
        }

        val vocabulary = buildTokenVocabulary(dynamicTerms)
        if (vocabulary.isEmpty()) return text.replace(Regex("\\s+"), " ").trim()

        val corrected = text.split(" ").map { token -> correctToken(token, vocabulary) }
        return corrected.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun buildTokenVocabulary(dynamicTerms: Collection<String>): List<String> {
        val terms = linkedSetOf<String>()
        (generalHints.asSequence() + dynamicTerms.asSequence())
            .map { ResponseRepository.normalize(it) }
            .flatMap { it.split(" ").asSequence() }
            .map { it.trim() }
            .filter { it.length >= 5 && it !in protectedCommonWords }
            .forEach { terms.add(it) }
        return terms.take(900)
    }

    private fun correctToken(token: String, vocabulary: List<String>): String {
        if (token.length < 5 || token in protectedCommonWords || token in vocabulary) return token

        val maxDistance = when {
            token.length <= 6 -> 1
            token.length <= 10 -> 2
            else -> 3
        }

        val scored = vocabulary.asSequence()
            .filter { candidate ->
                kotlin.math.abs(candidate.length - token.length) <= 2 &&
                    (candidate.firstOrNull() == token.firstOrNull() || token.length >= 8)
            }
            .map { candidate -> candidate to levenshteinDistance(token, candidate) }
            .filter { (_, distance) -> distance <= maxDistance }
            .sortedBy { it.second }
            .take(2)
            .toList()

        val best = scored.firstOrNull() ?: return token
        val bestSimilarity = similarity(token, best.first, best.second)
        if (bestSimilarity < 0.86) return token

        val second = scored.getOrNull(1)
        if (second != null) {
            val secondSimilarity = similarity(token, second.first, second.second)
            if (bestSimilarity - secondSimilarity < 0.08 && best.second >= second.second) return token
        }
        return best.first
    }

    private fun similarity(a: String, b: String, distance: Int): Double {
        return 1.0 - distance.toDouble() / maxOf(a.length, b.length).coerceAtLeast(1)
    }

    private fun levenshteinDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in a.indices) {
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + cost
                )
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
