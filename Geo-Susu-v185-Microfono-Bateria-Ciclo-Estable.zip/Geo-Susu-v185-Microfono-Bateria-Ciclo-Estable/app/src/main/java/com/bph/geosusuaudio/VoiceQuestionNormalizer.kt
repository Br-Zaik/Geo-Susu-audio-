package com.bph.geosusuaudio

object VoiceQuestionNormalizer {

    private val technicalContextWords = setOf(
        "topografia", "topografico", "topografica", "nivelacion", "nivel", "cota", "cotas", "altura",
        "terreno", "levantamiento", "replanteo", "banco", "instrumento", "mira", "vista",
        "mineria", "minera", "geologia", "mineral", "mina", "yacimiento", "exploracion", "prospeccion",
        "canon", "regalia", "concesion", "petitorio", "chancado", "molienda", "flotacion", "relave"
    )

    private val weakNoiseWords = setOf(
        "ruido", "musica", "ingles", "english", "hola", "eh", "ah", "mmm", "este", "esto",
        "cosa", "cosas", "algo", "alguien", "gente"
    )

    private val stopWords = setOf(
        "que", "q", "ke", "es", "son", "un", "una", "el", "la", "los", "las", "de", "del",
        "en", "por", "para", "dime", "di", "define", "definicion", "concepto", "significa",
        "explica", "sobre", "pregunta", "oye"
    )

    private val danglingEndWords = setOf(
        "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "por", "para",
        "con", "sin", "en", "a", "al", "que", "como", "cuando", "donde", "y", "o", "entre",
        "mas", "menos", "mayor", "menor", "principal", "principales", "siguiente", "siguientes",
        "segun", "respecto", "versus", "bajo", "sobre", "desde", "hasta", "hacia", "durante",
        "mediante", "contra", "tras", "porque", "si", "tambien", "ademas"
    )

    private val incompleteEndings = listOf(
        "recibe el", "recibe la", "recibe los", "recibe las",
        "comprende unicamente", "comprende solamente", "comprende solo",
        "se paga por el", "se paga por la", "se paga por los", "se paga por las",
        "consiste en el", "consiste en la", "consiste en los", "consiste en las",
        "se define como el", "se define como la", "se define como los", "se define como las",
        "corresponde al", "corresponde a la", "corresponde a los", "corresponde a las",
        "incluye el", "incluye la", "incluye los", "incluye las",
        "se aplica al", "se aplica a la", "se aplica a los", "se aplica a las",
        "equivale al", "equivale a la", "equivale a los", "equivale a las"
    )

    private val complementRequiredEndings = listOf(
        "comprende", "incluye", "recibe", "contiene", "abarca", "consiste en", "se paga por",
        "se calcula con", "se calcula mediante", "se define como", "corresponde a", "equivale a",
        "depende de", "se obtiene de", "esta formado por", "esta compuesta por", "esta compuesto por"
    )

    private val completionCues = listOf(
        "completa la frase", "completar la frase", "complete la frase",
        "completa la oracion", "completar la oracion", "complete la oracion",
        "completa el espacio", "complete el espacio", "rellena la frase", "rellene la frase",
        "rellena la oracion", "rellene la oracion", "continua la frase", "continue la frase",
        "palabra que falta", "frase que falta", "que palabra falta", "que frase falta",
        "espacio en blanco", "linea en blanco", "guion en blanco", "puntos suspensivos"
    )

    private val completionInstructionPatterns = listOf(
        Regex("^(completa|complete|completar|rellena|rellene|continua|continue) (la |el )?(frase|oracion|espacio)( en blanco)?"),
        Regex("^(indica|dime) (la |el )?(palabra|frase) que falta")
    )

    private val complexCues = listOf(
        "explica", "explique", "explicar", "describe", "describa", "desarrolla", "desarrolle",
        "analiza", "analice", "compara", "compare", "comparacion", "diferencia entre",
        "diferencias entre", "principales diferencias", "indica", "indique", "indicando",
        "incluyendo", "menciona", "mencione", "enumera", "enumere", "señala", "senala",
        "cuales son", "quienes son", "quienes reciben", "como se", "de que manera",
        "justifica", "justifique", "causas y consecuencias", "ventajas y desventajas",
        "semejanzas y diferencias"
    )

    fun normalize(raw: String): String {
        var question = SpeechDictionary.correct(raw)
        if (question.isBlank()) return ""

        question = question.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()
        val hasContext = hasTechnicalContext(question)

        // Correcciones históricas de topografía. Solo corrigen la transcripción.
        val phraseCorrections = linkedMapOf(
            "be eme" to "bm",
            "ve eme" to "bm",
            "baby" to "bm",
            "beibi" to "bm",
            "barbie" to "bm",
            "beybi" to "bm",
            "beby" to "bm",
            "babi" to "bm",
            "e pe pe" to "epp",
            "e p p" to "epp",
            "i pe pe" to "epp",
            "equipo proteccion personal" to "epp",
            "bi em" to "bm",
            "bee em" to "bm",
            "be me" to "bm",
            "b m" to "bm",
            "banco nivel" to "banco de nivel",
            "banco del nivel" to "banco de nivel",
            "cuota" to "cota",
            "cuotas" to "cotas",
            "ce pe" to "cp",
            "c p" to "cp",
            "ve a" to "va",
            "v a" to "va",
            "ve i" to "vi",
            "v i" to "vi",
            "ve efe" to "vf",
            "v f" to "vf",
            "a i" to "ai",
            "altura instrumental" to "altura de instrumento",
            "altura del instrumento" to "altura de instrumento",
            "vista final" to "vista adelante",
            "lectura final" to "vista adelante",
            "vista atras" to "vista atras",
            "mieria" to "mineria",
            "miniria" to "mineria",
            "menerea" to "mineria",
            "meneria" to "mineria",
            "topo grafia" to "topografia",
            "topogafia" to "topografia",
            "topografia superfacial" to "topografia superficial"
        )

        for ((bad, good) in phraseCorrections) {
            question = question.replace("\\b${Regex.escape(bad)}\\b".toRegex(), good)
        }

        if (hasContext || question.contains("banco") || question.contains("nivel")) {
            val bmLike = listOf("bebe", "bebé", "pm", "p m", "bm.", "beme")
            for (bad in bmLike) {
                question = question.replace(
                    "\\b${Regex.escape(ResponseRepository.normalize(bad))}\\b".toRegex(),
                    "bm"
                )
            }
        }

        return question.replace("\u00bf", " ").replace("\\s+".toRegex(), " ").trim()
    }

    fun isTooUnclearForJsonOrNet(question: String): Boolean {
        val normalized = normalize(question)
        if (normalized.isBlank()) return true
        val words = normalized.split(" ").filter { it.isNotBlank() }
        val content = words.filter { it.length >= 2 && it !in stopWords && it !in weakNoiseWords }
        if (content.isEmpty()) return true

        val noiseHits = words.count { it in weakNoiseWords }
        return noiseHits >= 3 && content.size <= 1 && !hasTechnicalContext(normalized)
    }

    /** Pregunta explicativa o moderadamente larga; solo ajusta la espera, no activa modos especiales. */
    fun requiresExtendedListening(question: String): Boolean = isModeratelyComplex(question)

    fun isModeratelyComplex(question: String): Boolean {
        val normalized = normalize(question)
        if (normalized.isBlank()) return false
        val words = normalized.split(" ").filter { it.isNotBlank() }
        return complexCues.any { cue ->
            normalized == cue || normalized.startsWith("$cue ") || normalized.contains(" $cue ")
        } || words.size >= 11 || normalized.length >= 78
    }

    /**
     * Cierre dinámico: preguntas cortas responden rápido; comparaciones y explicaciones
     * reciben una ventana mayor. El ruido no interviene porque el contador depende del texto.
     */
    fun confirmationDelayMs(question: String): Long {
        val normalized = normalize(question)
        if (normalized.isBlank()) return 1800L
        if (isClearlyIncomplete(normalized)) return 3000L
        val words = normalized.split(" ").count { it.isNotBlank() }
        return when {
            isModeratelyComplex(normalized) -> 2700L
            words <= 5 -> 1500L
            words <= 9 -> 1900L
            else -> 2300L
        }
    }

    fun continuationSilenceMs(question: String): Long {
        val normalized = normalize(question)
        return if (isModeratelyComplex(normalized)) 2800L else 2200L
    }

    /**
     * Decide si un texto reconocido en la sesión de confirmación parece una
     * continuación real. Evita que una palabra aislada de televisión, tráfico
     * o conversación de fondo se añada a una pregunta que ya estaba completa.
     *
     * No modifica la sensibilidad del micrófono: solo evalúa texto que Google
     * ya consiguió reconocer.
     */
    /** Coincidencia casi literal usada únicamente dentro de la ventana anti-eco. */
    fun isLikelyEcho(spokenAnswer: String, recognizedQuestion: String): Boolean {
        val spoken = ResponseRepository.normalize(spokenAnswer)
        val question = ResponseRepository.normalize(recognizedQuestion)
        if (spoken.isBlank() || question.isBlank()) return false
        if (spoken == question) return true

        val questionWords = question.split(" ").filter { it.isNotBlank() }
        if (question.length >= 12 && questionWords.size >= 3 && spoken.contains(question)) {
            return true
        }

        // Solo para textos largos casi idénticos. No bloquea preguntas nuevas que
        // simplemente reutilizan conceptos de la respuesta anterior.
        if (questionWords.size < 8) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = questionWords.count { it in spokenWords }
        return common >= 7 && common * 100 >= questionWords.size * 95
    }

    fun isLikelyContinuation(previousQuestion: String, continuation: String): Boolean {
        val previous = normalize(previousQuestion)
        val next = normalize(continuation)
        if (previous.isBlank() || next.isBlank()) return false
        if (isTooUnclearForJsonOrNet(next)) return false

        if (next == previous || previous.contains(next)) return false
        if (next.contains(previous) && next.length > previous.length) return true

        val nextWords = next.split(" ").filter { it.isNotBlank() }
        val usefulWords = nextWords.filter {
            it.length >= 2 && it !in stopWords && it !in weakNoiseWords
        }
        if (usefulWords.isEmpty()) return false

        // Una frase realmente cortada debe aceptar incluso una continuación breve.
        if (isClearlyIncomplete(previous)) return true

        // Tres o más palabras con contenido constituyen una continuación razonable.
        if (nextWords.size >= 3 && usefulWords.size >= 2) return true

        val continuationStarters = setOf(
            "y", "e", "o", "ademas", "tambien", "en", "de", "del", "con",
            "sin", "para", "por", "que", "como", "cuando", "donde", "segun"
        )
        if (nextWords.size >= 2 && nextWords.first() in continuationStarters) return true
        if (nextWords.size >= 2 && hasTechnicalContext(next)) return true
        if (nextWords.size >= 2 && isModeratelyComplex(previous)) return true

        if (nextWords.size == 1) {
            val token = nextWords.first()
            val technicalSuffixes = setOf(
                "minero", "minera", "mineros", "mineras", "mineral", "minerales",
                "vigencia", "concesion", "petitorio", "subterranea", "superficial",
                "abierto", "regional", "distrital", "provincial", "concentradora",
                "ambiental", "chancado", "molienda", "flotacion", "relave",
                "ingemmet", "sunat", "senace", "oefa"
            )
            val previousLast = previous.substringAfterLast(" ")
            if (previousLast in danglingEndWords) return true
            if (token in technicalSuffixes) return true
        }

        return false
    }

    fun isClearlyIncomplete(question: String): Boolean {
        val normalized = normalize(question)
        if (normalized.isBlank()) return true

        if (isCompletionExercise(normalized)) {
            val payloadWords = completionPayloadWordCount(normalized)
            val hasExplicitBlank = completionCues.any { cue -> normalized.contains(cue) }
            return if (hasExplicitBlank) payloadWords < 5 else payloadWords < 3
        }

        val words = normalized.split(" ").filter { it.isNotBlank() }
        if (words.size < 2) return false

        val lastWord = words.last()
        val legitimateArticleEnding = normalized.endsWith("cada una") ||
            normalized.endsWith("cada uno") ||
            normalized.endsWith("cada unos") ||
            normalized.endsWith("cada unas")
        if (lastWord in danglingEndWords && !legitimateArticleEnding) return true
        if (incompleteEndings.any { normalized.endsWith(it) }) return true
        if (normalized.endsWith(" unicamente") || normalized.endsWith(" solamente")) return true

        val startsAsQuestion = normalized.startsWith("que ") ||
            normalized.startsWith("cual ") ||
            normalized.startsWith("cuales ") ||
            normalized.startsWith("como ") ||
            normalized.startsWith("cuando ") ||
            normalized.startsWith("donde ") ||
            normalized.startsWith("quien ") ||
            normalized.startsWith("quienes ") ||
            normalized.startsWith("cuanto ") ||
            normalized.startsWith("cuantos ") ||
            normalized.startsWith("por que ")

        return !startsAsQuestion && complementRequiredEndings.any { normalized.endsWith(it) }
    }

    fun isUnsafeForNet(question: String): Boolean {
        val normalized = normalize(question)
        return isTooUnclearForJsonOrNet(normalized) || isClearlyIncomplete(normalized)
    }

    /** Solo conserva texto entre sesiones cuando la frase está claramente cortada. */
    fun shouldWaitForContinuation(question: String): Boolean {
        val normalized = normalize(question)
        return normalized.isBlank() || isClearlyIncomplete(normalized)
    }

    fun isCompletionExercise(question: String): Boolean {
        val normalized = normalize(question)
        return completionCues.any { normalized.contains(it) } ||
            normalized.startsWith("completa ") ||
            normalized.startsWith("complete ") ||
            normalized.startsWith("rellena ") ||
            normalized.startsWith("rellene ")
    }

    private fun completionPayloadWordCount(normalized: String): Int {
        var payload = normalized
        for (pattern in completionInstructionPatterns) {
            payload = payload.replace(pattern, " ")
        }
        completionCues.forEach { cue -> payload = payload.replace(cue, " ") }
        return payload
            .replace(Regex("\\s+"), " ")
            .trim()
            .split(" ")
            .count { it.isNotBlank() }
    }

    private fun hasTechnicalContext(question: String): Boolean {
        val words = question.split(" ").filter { it.isNotBlank() }.toSet()
        return words.any { it in technicalContextWords } ||
            question.contains("banco de nivel") ||
            question.contains("vista atras") ||
            question.contains("vista adelante") ||
            question.contains("vista intermedia") ||
            question.contains("altura de instrumento")
    }
}
