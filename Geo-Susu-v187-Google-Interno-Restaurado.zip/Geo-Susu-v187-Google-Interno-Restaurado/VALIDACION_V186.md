# Geo Susu v186 - Google interno y ciclo prolongado

## Problema corregido

La v185 podía quedarse mostrando **Abriendo micrófono de Google...** porque reiniciaba la sesión si el proveedor de reconocimiento no enviaba `onReadyForSpeech` en 4,5 segundos. En algunos dispositivos ese callback no aparece hasta que existe voz, por lo que el propio watchdog impedía una escucha estable.

## Cambios

1. Se eliminó el watchdog basado exclusivamente en `onReadyForSpeech`.
2. La sesión se marca como disponible inmediatamente después de `startListening`.
3. El watchdog de sesión ahora mide inactividad real desde el último callback y se vuelve a programar si siguen llegando eventos.
4. Se restableció la ruta estable para micrófonos Zync/USB-C/cable.
5. Si se detecta una entrada Bluetooth, no se apaga Bluetooth SCO.
6. Los errores `NO_MATCH`, `BUSY`, demasiadas solicitudes y red usan pausas distintas para evitar ciclos agresivos.
7. El supervisor renueva el WakeLock y recupera sesiones detenidas.
8. Se mantuvieron intactos JSON, NET, AUTO, diccionario, TTS, APIs y botones PEGAR.

## Límites de recuperación

- Watchdog por inactividad real: 25 segundos.
- Supervisor: cada 4 segundos.
- Sesión considerada estancada: 30 segundos sin eventos.
- WakeLock: 8 horas, renovado por el supervisor si Android lo libera.

## Versión

- versionCode: 186
- versionName: 18.6.0
