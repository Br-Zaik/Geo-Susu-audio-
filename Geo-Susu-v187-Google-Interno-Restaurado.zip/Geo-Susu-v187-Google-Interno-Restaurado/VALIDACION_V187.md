# Geo Susu v187 - restauracion de Google interno

## Cambio principal

Se restauraron sin modificaciones experimentales estos dos archivos desde Geo Susu v182, la ultima base con diccionario y escucha simple anterior a los cambios v183-v186:

- `GoogleInternalListenService.kt`
- `VoiceQuestionNormalizer.kt`

Esto elimina del Google interno los cambios posteriores que alteraban la apertura del microfono, la ruta de audio, la espera de `onReadyForSpeech`, la recuperacion agresiva y los nuevos controles anti-eco.

## Funciones conservadas de versiones posteriores

- Permisos en orden: microfono, notificaciones y bateria sin restricciones.
- Diccionario tecnico general y vocabulario extraido del JSON activo.
- Modos JSON, NET y AUTO.
- Botones PEGAR para las APIs.
- Limpieza visible de pregunta y respuesta al reiniciar el ciclo.
- Rotacion y validacion de APIs.
- TTS, Vosk e interfaz.

## Configuracion restaurada de Google

- Duracion minima: 4200 ms.
- Silencio completo: 2600 ms.
- Silencio posiblemente completo: 2600 ms.
- Apertura directa con `startListening()`.
- Sonido y callbacks normales del servicio de Google.
- Ruta de audio igual a la base v182.

## Validaciones realizadas

- El archivo de Google interno de v187 coincide byte por byte con el de v182.
- El normalizador de v187 coincide byte por byte con el de v182.
- Prueba Kotlin superada para diccionario, espera dinamica y union de fragmentos.
- Verificado que no existen en el servicio restaurado los marcadores experimentales `recognizerReady`, `AudioDeviceInfo`, `prepareAudioRouteForActiveMic` ni `lastSpokenFinishedAt`.
- `versionCode 187`, `versionName 18.7.0` y etiqueta `Geo Susu JSON v187`.

## Limitacion de validacion

No se genero APK ni se realizo una prueba fisica de seis horas porque este entorno no dispone de Android SDK ni del microfono Zync. La comprobacion final debe hacerse al compilar e instalar en el telefono.
