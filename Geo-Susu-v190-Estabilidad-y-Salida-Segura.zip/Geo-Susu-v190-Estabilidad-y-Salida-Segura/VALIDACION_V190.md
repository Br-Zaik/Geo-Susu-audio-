# Geo Susu v190 - Estabilidad y salida segura

## Base

- Construida sobre `Geo-Susu-v188-Restauracion-Exacta-v181`.
- El archivo `GoogleInternalListenService.kt` permanece byte por byte igual que en v188/v181.
- No se cambiaron reconocimiento, sensibilidad, tiempos 4200/2600/2600, JSON, NET, AUTO, TTS, Vosk ni rotación de API.

## Estabilidad externa

- La actividad vigila las actualizaciones del servicio sin modificar el motor de Google.
- Si el servicio deja de emitir actualizaciones durante 45 segundos en fase de escucha o recuperación, se detiene y se crea nuevamente tras 1.5 segundos. Como límite absoluto, cualquier estado sin actualizaciones durante 120 segundos también se recupera.
- Si queda en un bucle de recuperación durante 90 segundos, se reinicia solo el servicio.
- Si permanece en reposo durante 30 minutos, se renueva preventivamente.
- Como límite adicional, el servicio se renueva cada 60 minutos cuando los cuadros están vacíos.
- Existe un enfriamiento de 90 segundos para impedir reinicios repetidos.
- Los servicios tienen `stopWithTask=false` y siguen siendo servicios en primer plano.

## Protección de salida

- La pantalla permanece encendida mientras el modo estudio está activo.
- Se solicita pantalla fijada mediante `startLockTask()` para bloquear Inicio y Recientes.
- Atrás y el botón DETENER abren dos confirmaciones consecutivas.
- Primera: `¿Deseas salir de Geo Susu?`.
- Segunda: `¿Realmente deseas salir?`.
- Solo `DETENER Y SALIR` detiene Google, Vosk, TTS, libera la fijación y cierra la tarea.
- Se eliminó la salida mediante cinco pulsaciones.

## Permisos

- Orden: micrófono, notificaciones y batería sin restricciones.
- La escucha inicia después de volver de la autorización de batería, evitando que la pantalla del sistema interfiera con el inicio del ciclo.

## Comprobaciones realizadas

- `AndroidManifest.xml` válido como XML.
- Llaves, paréntesis y corchetes de `MainActivity.kt` balanceados.
- ZIP verificado con `unzip -t`.
- Hash SHA-256 de `GoogleInternalListenService.kt`: `1660051748ad0eaf...`, igual a v188/v181.

## Limitación de verificación

No se generó ni instaló el APK en este entorno porque no contiene Android SDK/Gradle Wrapper. La prueba física de pantalla fijada, micrófono externo y funcionamiento prolongado debe realizarse en el celular.
