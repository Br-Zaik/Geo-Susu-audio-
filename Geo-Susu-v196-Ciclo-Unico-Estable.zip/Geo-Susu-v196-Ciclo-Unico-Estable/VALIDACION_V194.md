# Geo Susu v194 - ciclo simple sin comando "fin"

## Alcance aplicado

- Se eliminó del código ejecutable el comando de voz `fin` y toda su detección, eliminación y cierre especial.
- Se retiró el estado antiguo de pregunta larga (`longQuestionActive`, buffers, temporizadores de 3 segundos y máximo de 90 segundos).
- Se retiraron los tratamientos especiales de alternativas y verdadero/falso en NET; ahora se procesan como consultas normales.
- Se reemplazó el modo largo por un único `continuationBuffer`, usado solamente cuando una frase termina claramente incompleta.
- Si no existe texto, la app limpia la ruta de continuación y abre una sesión nueva; ya no puede mostrar `Pregunta: ---` con “texto conservado”.
- Si existe texto completo, se confirma y procesa antes de cualquier reconexión.
- Los callbacks tardíos siguen protegidos por el identificador de sesión y el guard atómico de despacho.
- La respuesta local para fecha, día y hora se mantiene antes de JSON/NET.
- La solicitud de exclusión de batería ya no queda marcada como atendida antes de abrirse. Al volver de Ajustes, continúa el arranque sin bucle de pantallas.

## Comportamiento esperado

1. Google reconoce texto parcial o final.
2. Si la frase está completa, se confirma automáticamente:
   - pregunta normal: 1.8 segundos;
   - pregunta explicativa o comparativa: 2.7 segundos.
3. Si la frase está claramente incompleta, se conserva únicamente esa frase y se abre otra sesión para continuar.
4. No existe comando especial para cerrar: la palabra `fin` se trata como contenido normal.
5. Después de responder, limpia el ciclo y vuelve a escuchar.

## Verificaciones realizadas

- Código Kotlin: llaves, cadenas y comentarios balanceados en todos los archivos.
- Búsqueda estática: no quedan referencias ejecutables a `longQuestion`, `hasExplicitEndCommand`, `removeExplicitEndCommand`, `shouldWaitForContinuation` ni mensajes “puedes continuar o decir fin”.
- Pruebas Kotlin puras superadas:
  - `qué día es hoy` se considera pregunta completa;
  - `cuál es la diferencia entre canon y` se considera incompleta;
  - la continuación `regalía minera` se une sin perder el inicio;
  - `fin` permanece como palabra normal;
  - fecha de hoy y mañana producen respuesta local.
- `versionCode`: 194.
- `versionName`: 19.4.0.

## Límite de la validación

No se generó APK ni se realizó una prueba física prolongada porque el entorno no dispone de Android SDK ni del micrófono Zync. La compilación final y la prueba en el teléfono siguen siendo necesarias.
