# Validación Geo Susu v195

## Alcance

Corrección del caso en que la pantalla mostraba `Susurro Google: escuchando...` con nivel 0 %, sin transcripción, incluso sin Zync, sin JSON y sin APIs.

## Cambios comprobados en código

1. Se eliminó de Google interno toda llamada a:
   - `AudioManager.mode = MODE_NORMAL`
   - `stopBluetoothSco()`
   - `isBluetoothScoOn = false`
   - `isSpeakerphoneOn = false`
2. `SpeechRecognizer` se crea sin forzar la ruta de audio; Android decide la entrada activa.
3. La UI no declara escucha confirmada antes de `startListening()`: muestra `Abriendo micrófono de Google...`.
4. Se añadió una comprobación de arranque a los 7.5 segundos basada en:
   - callbacks reales del `RecognitionListener`; o
   - una configuración de grabación de voz activa informada por `AudioManager`.
5. Una sesión sin callbacks y sin captura activa se cancela y destruye antes de crear otra.
6. Tras tres arranques muertos consecutivos se reinicia solo `GoogleInternalListenService`.
7. Se conservan identificadores de sesión y se ignoran callbacks tardíos.
8. Al iniciar Google interno se limpian los cuadros y el nivel visual.
9. No se restauró el comando `fin` ni el modo especial de preguntas largas.

## Revisiones estáticas

- `versionCode`: 195
- `versionName`: 19.5.0
- Etiqueta: Geo Susu v195
- No hay referencias activas a `prepareAudioRouteForUsbMic` en Google interno.
- No hay errores de sintaxis Kotlin detectados por el compilador fuera de las referencias Android no disponibles en este entorno.
- El ZIP final se valida con `unzip -t`.

## Límite de validación

Este entorno no contiene Android SDK ni el teléfono/Zync, por lo que no puede ejecutar una prueba física del micrófono. La comprobación definitiva es instalar el APK compilado y probar primero sin micrófono externo y luego conectando el Zync.
