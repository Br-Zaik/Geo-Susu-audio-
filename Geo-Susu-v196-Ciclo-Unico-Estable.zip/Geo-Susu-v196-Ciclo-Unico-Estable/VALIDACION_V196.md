# Geo Susu v196 - Ciclo unico por estados

## Objetivo

Eliminar la competencia entre watchdogs, verificadores de audio y reinicios del servicio. Google interno queda gobernado por una sola maquina de estados:

`ESCUCHANDO -> PROCESANDO -> HABLANDO -> LIMPIANDO -> ESCUCHANDO`

## Cambios verificados en codigo

- Una sola instancia activa de `SpeechRecognizer`.
- Cada sesion tiene identificador; callbacks antiguos se ignoran.
- El microfono se destruye antes de JSON, NET o TTS.
- AUTO busca primero en JSON y solo pasa a NET si no encuentra coincidencia.
- El TTS mantiene el microfono apagado y al finalizar abre una sesion nueva.
- El ruido sin palabras no confirma preguntas.
- Una sesion sin palabras se renueva sin conservar texto vacio.
- Si existe texto reconocido, se procesa antes de cualquier recuperacion.
- Eliminados: comando `fin`, modo largo, verificadores de grabacion activa, supervisor paralelo, reinicio automatico del servicio y manipulacion de rutas de audio.
- Android decide si usa microfono interno, USB o Bluetooth.
- WakeLock sin vencimiento mientras el servicio esta activo.
- Solicitud real de exclusion de optimizacion de bateria, con comprobacion al volver de Ajustes.
- Pantalla encendida y doble confirmacion para detener y salir se conservan.

## Controles estaticos realizados

- Balance de llaves, parentesis y corchetes: correcto.
- No quedan referencias a `longQuestion`, `fin`, `prepareAudioRoute`, `activeRecordingConfigurations`, supervisores paralelos o reinicio propio del servicio.
- `versionCode`: 196.
- `versionName`: 19.6.0.

## Limite de validacion

El entorno no incluye Android SDK ni un dispositivo fisico, por lo que no se genero APK ni se pudo ejecutar una prueba real de varias horas. El proyecto mantiene el flujo de GitHub Actions para compilar.
