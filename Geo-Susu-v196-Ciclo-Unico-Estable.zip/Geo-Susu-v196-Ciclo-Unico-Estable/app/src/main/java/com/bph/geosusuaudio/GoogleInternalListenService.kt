package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Ciclo unico de Google interno.
 *
 * ESCUCHANDO -> PROCESANDO -> HABLANDO -> LIMPIANDO -> ESCUCHANDO
 *
 * Solo esta clase controla SpeechRecognizer. No hay supervisores paralelos,
 * verificadores de RMS ni reinicios del servicio compitiendo entre si.
 */
class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private enum class LoopState {
        STOPPED,
        STARTING,
        LISTENING,
        PROCESSING,
        SPEAKING,
        RECOVERING
    }

    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var questionRouter: QuestionRouter
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private val backgroundLock = Any()
    private val routeExecutor: ExecutorService = Executors.newSingleThreadExecutor { task ->
        Thread(task, "GeoSusu-JSON").apply { isDaemon = true }
    }
    private val netExecutor: ExecutorService = Executors.newSingleThreadExecutor { task ->
        Thread(task, "GeoSusu-NET").apply { isDaemon = true }
    }
    @Volatile private var routeFuture: Future<*>? = null
    @Volatile private var netFuture: Future<*>? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    @Volatile private var state = LoopState.STOPPED
    @Volatile private var onlineRequestVersion = 0
    private val questionDispatchInFlight = AtomicBoolean(false)

    private var sessionSerial = 0L
    private var activeSessionId = 0L
    private var sessionPartial = ""
    private var continuationBuffer = ""
    private var lastTextChangeAt = 0L
    private var lastRecognizerEventAt = 0L

    private var startSessionRunnable: Runnable? = null
    private var stableTextRunnable: Runnable? = null
    private var sessionDeadlineRunnable: Runnable? = null
    private var ttsDeadlineRunnable: Runnable? = null

    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var ignoreEchoUntil = 0L

    private var activeUtteranceId: String? = null
    private var speechSerial = 0L
    private var ttsReady = false
    private var ttsStartRetryRunnable: Runnable? = null

    private var lastLevelDispatchAt = 0L
    private var lastLevelSent = -1

    private val languagePreferences by lazy {
        getSharedPreferences(LANGUAGE_PREFS_NAME, MODE_PRIVATE)
    }
    private var recognitionLanguageCandidates: List<String> = emptyList()
    private var recognitionLanguageIndex = 0

    override fun onCreate() {
        super.onCreate()
        val appContext = applicationContext
        jsonRepository = JsonKnowledgeRepository(appContext)
        questionRouter = QuestionRouter(jsonRepository)
        memory = MemoryStore(appContext)
        modeSettings = AnswerModeSettings(appContext)
        appSettings = AppSettings(appContext)
        initializeRecognitionLanguages()
        warmJsonInBackground()
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Susurro Google activo"))
        ensureWakeLock()
        running = true

        if (state == LoopState.STOPPED || state == LoopState.RECOVERING) {
            requestNewListeningSession(250L, "inicio del servicio")
        }
        return START_STICKY
    }

    /** Unico punto que programa la apertura de una nueva sesion de Google. */
    private fun requestNewListeningSession(delayMs: Long, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { requestNewListeningSession(delayMs, reason) }
            return
        }
        if (!running || state == LoopState.PROCESSING || state == LoopState.SPEAKING) return

        cancelListeningTimers()
        cancelStartRunnable()
        closeRecognizer()
        state = LoopState.RECOVERING

        val runnable = Runnable {
            startSessionRunnable = null
            if (!running || state == LoopState.PROCESSING || state == LoopState.SPEAKING) {
                return@Runnable
            }
            openListeningSession(reason)
        }
        startSessionRunnable = runnable
        handler.postDelayed(runnable, delayMs.coerceAtLeast(RECOGNIZER_SETTLE_DELAY_MS))
        logState("schedule_session", "reason=$reason delay=$delayMs")
    }

    private fun cancelStartRunnable() {
        startSessionRunnable?.let { handler.removeCallbacks(it) }
        startSessionRunnable = null
    }

    private fun openListeningSession(reason: String) {
        if (!running || state == LoopState.PROCESSING || state == LoopState.SPEAKING) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            state = LoopState.STOPPED
            sendUpdate("Falta permiso de microfono", "", "Activa el permiso de microfono.", 0)
            stopSelf()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            state = LoopState.RECOVERING
            sendUpdate("Google interno no disponible", "", "Reintentando automaticamente.", 0)
            requestNewListeningSession(SERVICE_UNAVAILABLE_RETRY_MS, "servicio de voz no disponible")
            return
        }

        cancelListeningTimers()
        closeRecognizer()

        val sessionId = ++sessionSerial
        activeSessionId = sessionId
        sessionPartial = ""
        lastTextChangeAt = 0L
        lastRecognizerEventAt = SystemClock.elapsedRealtime()
        lastLevelSent = -1
        lastLevelDispatchAt = 0L
        state = LoopState.STARTING

        try {
            val newRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            newRecognizer.setRecognitionListener(createRecognitionListener(sessionId))
            recognizer = newRecognizer

            sendUpdate("Abriendo microfono de Google...", "", "", 0)
            newRecognizer.startListening(buildRecognitionIntent())
            state = LoopState.LISTENING
            sendUpdate("Google interno activo; esperando voz...", "", "", 0)
            scheduleSessionDeadline(sessionId)
            logState("session_open", "session=$sessionId reason=$reason")
        } catch (error: Throwable) {
            Log.e(TAG, "No se pudo abrir SpeechRecognizer", error)
            invalidateSession(sessionId, LoopState.RECOVERING)
            sendUpdate("Recuperando Google interno...", "", "", 0)
            requestNewListeningSession(ERROR_RETRY_MS, "fallo al abrir")
        }
    }

    private fun buildRecognitionIntent(): Intent {
        val languageTag = currentRecognitionLanguage()
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            if (Build.VERSION.SDK_INT >= 33) {
                val hints = jsonRepository.recognitionHints(40)
                if (hints.isNotEmpty()) {
                    putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, hints)
                }
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private fun createRecognitionListener(sessionId: Long): RecognitionListener {
        return object : RecognitionListener {
            private fun isCurrent(): Boolean {
                return running && state == LoopState.LISTENING && activeSessionId == sessionId
            }

            private fun markEvent() {
                if (isCurrent()) lastRecognizerEventAt = SystemClock.elapsedRealtime()
            }

            override fun onReadyForSpeech(params: Bundle?) {
                if (!isCurrent()) return
                markEvent()
                rememberWorkingRecognitionLanguage()
                sendUpdate("Susurro Google listo", "", "", 0)
            }

            override fun onBeginningOfSpeech() {
                if (!isCurrent()) return
                markEvent()
                sendUpdate("Te estoy escuchando...", "", "", 20)
            }

            override fun onRmsChanged(rmsdB: Float) {
                if (!isCurrent()) return
                markEvent()
                val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
                val now = SystemClock.elapsedRealtime()
                if (
                    now - lastLevelDispatchAt >= LEVEL_UPDATE_INTERVAL_MS ||
                    lastLevelSent < 0 ||
                    abs(level - lastLevelSent) >= 8
                ) {
                    lastLevelDispatchAt = now
                    lastLevelSent = level
                    sendUpdate("", "", "", level)
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {
                if (!isCurrent()) return
                markEvent()
            }

            override fun onEndOfSpeech() {
                if (!isCurrent()) return
                markEvent()
                sendUpdate("Cerrando pregunta...", currentQuestionPreview(), "", -1)
            }

            override fun onError(error: Int) {
                if (!isCurrent()) return
                markEvent()
                val fallback = currentQuestionPreview()
                invalidateSession(sessionId, LoopState.RECOVERING)
                logState("recognizer_error", "session=$sessionId error=$error text=${fallback.take(100)}")

                if (fallback.isNotBlank()) {
                    handleRecognizedText(fallback, "error $error")
                    return
                }

                if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ||
                    error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE
                ) {
                    languagePreferences.edit().remove(KEY_WORKING_LANGUAGE).apply()
                    val rejected = currentRecognitionLanguage()
                    val next = advanceRecognitionLanguage()
                    if (next != null) {
                        sendUpdate("Ajustando idioma de Google...", "", "", 0)
                        requestNewListeningSession(700L, "idioma $rejected rechazado")
                    } else {
                        resetRecognitionLanguageCycle()
                        requestNewListeningSession(SERVICE_UNAVAILABLE_RETRY_MS, "reinicio de idiomas")
                    }
                    return
                }

                val delay = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> SILENCE_RECYCLE_DELAY_MS
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> BUSY_RETRY_MS
                    SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> RATE_LIMIT_RETRY_MS
                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
                    SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> NETWORK_RETRY_MS
                    else -> ERROR_RETRY_MS
                }

                val status = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Esperando una pregunta..."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Google ocupado; reabriendo..."
                    SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> "Pausa breve de Google..."
                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
                    SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Reconectando Google interno..."
                    else -> "Recuperando Google interno..."
                }
                sendUpdate(status, "", "", 0, clearFields = true)
                requestNewListeningSession(delay, "error $error sin texto")
            }

            override fun onResults(results: Bundle?) {
                if (!isCurrent()) return
                markEvent()
                val matches = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    .orEmpty()
                val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                val finalCandidate = chooseBestSpeechCandidate(matches, scores)
                val merged = when {
                    finalCandidate.isBlank() -> currentQuestionPreview()
                    sessionPartial.isBlank() -> mergeWithContinuation(finalCandidate)
                    else -> mergeWithContinuation(
                        SpeechTranscriptMerger.mergePartialWithFinal(sessionPartial, finalCandidate)
                    )
                }

                invalidateSession(sessionId, LoopState.RECOVERING)
                if (merged.isBlank()) {
                    requestNewListeningSession(SILENCE_RECYCLE_DELAY_MS, "resultado vacio")
                } else {
                    handleRecognizedText(merged, "resultado final")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (!isCurrent()) return
                markEvent()
                val incoming = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()
                if (incoming.isBlank()) return

                val previous = ResponseRepository.normalize(sessionPartial)
                sessionPartial = SpeechTranscriptMerger.selectSessionHypothesis(sessionPartial, incoming)
                val current = ResponseRepository.normalize(sessionPartial)
                if (current != previous) {
                    lastTextChangeAt = SystemClock.elapsedRealtime()
                    sendUpdate("Escuchando...", currentQuestionPreview(), "", -1)
                    scheduleStableTextCommit(sessionId, current)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {
                if (!isCurrent()) return
                markEvent()
            }
        }
    }

    /**
     * Si Google entrega palabras y dejan de cambiar, la pregunta se confirma.
     * El ruido sin palabras no reinicia este temporizador.
     */
    private fun scheduleStableTextCommit(sessionId: Long, normalizedSnapshot: String) {
        cancelStableTextRunnable()
        val delay = confirmationDelayMs(currentQuestionPreview())
        val runnable = Runnable {
            stableTextRunnable = null
            if (!running || state != LoopState.LISTENING || activeSessionId != sessionId) {
                return@Runnable
            }
            val currentNormalized = ResponseRepository.normalize(sessionPartial)
            if (currentNormalized.isBlank() || currentNormalized != normalizedSnapshot) return@Runnable

            val text = currentQuestionPreview()
            invalidateSession(sessionId, LoopState.RECOVERING)
            handleRecognizedText(text, "texto estable")
        }
        stableTextRunnable = runnable
        handler.postDelayed(runnable, delay)
    }

    /**
     * Unica recuperacion de escucha. Una sesion silenciosa se recicla; si ya hay
     * palabras, se procesan antes de abrir otra sesion.
     */
    private fun scheduleSessionDeadline(sessionId: Long) {
        cancelSessionDeadline()
        val runnable = Runnable {
            sessionDeadlineRunnable = null
            if (!running || state != LoopState.LISTENING || activeSessionId != sessionId) {
                return@Runnable
            }

            val text = currentQuestionPreview()
            invalidateSession(sessionId, LoopState.RECOVERING)
            if (text.isNotBlank()) {
                handleRecognizedText(text, "limite de sesion")
            } else {
                sendUpdate("Renovando escucha...", "", "", 0, clearFields = true)
                requestNewListeningSession(SILENCE_RECYCLE_DELAY_MS, "sesion sin palabras")
            }
        }
        sessionDeadlineRunnable = runnable
        handler.postDelayed(runnable, LISTENING_SESSION_MAX_MS)
    }

    private fun currentQuestionPreview(): String {
        return mergeWithContinuation(sessionPartial).trim()
    }

    private fun mergeWithContinuation(raw: String): String {
        val current = raw.trim()
        return when {
            continuationBuffer.isBlank() -> current
            current.isBlank() -> continuationBuffer.trim()
            else -> SpeechTranscriptMerger.mergeCommitted(continuationBuffer, current).trim()
        }
    }

    private fun invalidateSession(sessionId: Long, nextState: LoopState) {
        if (activeSessionId != sessionId) return
        activeSessionId = 0L
        cancelListeningTimers()
        closeRecognizer()
        state = nextState
    }

    private fun closeRecognizer() {
        val old = recognizer
        recognizer = null
        if (old != null) {
            runCatching { old.cancel() }
            runCatching { old.destroy() }
                .onFailure { Log.w(TAG, "No se pudo destruir SpeechRecognizer", it) }
        }
    }

    private fun cancelListeningTimers() {
        cancelStableTextRunnable()
        cancelSessionDeadline()
    }

    private fun cancelStableTextRunnable() {
        stableTextRunnable?.let { handler.removeCallbacks(it) }
        stableTextRunnable = null
    }

    private fun cancelSessionDeadline() {
        sessionDeadlineRunnable?.let { handler.removeCallbacks(it) }
        sessionDeadlineRunnable = null
    }

    private fun handleRecognizedText(raw: String, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { handleRecognizedText(raw, reason) }
            return
        }
        if (!running || state == LoopState.PROCESSING || state == LoopState.SPEAKING) return

        val candidate = VoiceQuestionNormalizer.normalize(mergeWithContinuation(raw)).trim()
        sessionPartial = ""

        if (candidate.isBlank() || VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(candidate)) {
            continuationBuffer = ""
            sendUpdate("No se detecto una pregunta clara", "", "", 0, clearFields = true)
            requestNewListeningSession(SILENCE_RECYCLE_DELAY_MS, "$reason sin pregunta")
            return
        }

        if (VoiceQuestionNormalizer.isClearlyIncomplete(candidate)) {
            continuationBuffer = candidate
            sendUpdate("Continua la pregunta...", candidate, "", 0)
            requestNewListeningSession(CONTINUATION_REOPEN_MS, "$reason incompleto")
            return
        }

        continuationBuffer = ""
        dispatchQuestion(candidate, reason)
    }

    private fun dispatchQuestion(questionRaw: String, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { dispatchQuestion(questionRaw, reason) }
            return
        }
        if (!running || state == LoopState.PROCESSING || state == LoopState.SPEAKING) return

        val question = VoiceQuestionNormalizer.normalize(questionRaw).trim()
        if (question.isBlank()) {
            requestNewListeningSession(SILENCE_RECYCLE_DELAY_MS, "pregunta vacia")
            return
        }

        if (!questionDispatchInFlight.compareAndSet(false, true)) return

        state = LoopState.PROCESSING
        cancelStartRunnable()
        cancelListeningTimers()
        activeSessionId = 0L
        closeRecognizer()
        sessionPartial = ""
        continuationBuffer = ""
        sendUpdate("Procesando...", question, "", -1)
        logState("dispatch", "reason=$reason text=${question.take(120)}")

        try {
            processQuestion(question)
        } catch (error: Throwable) {
            Log.e(TAG, "Fallo procesando pregunta", error)
            questionDispatchInFlight.set(false)
            state = LoopState.RECOVERING
            sendUpdate(
                "No se pudo procesar la pregunta",
                question,
                "La escucha continuara automaticamente.",
                -1
            )
            requestNewListeningSession(ERROR_RETRY_MS, "excepcion al procesar")
        }
    }

    private fun processQuestion(question: String) {
        if (shouldIgnoreRecentEcho(question)) {
            questionDispatchInFlight.set(false)
            state = LoopState.RECOVERING
            requestNewListeningSession(SILENCE_RECYCLE_DELAY_MS, "eco del lector")
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastHeard && now - lastHeardTime < DUPLICATE_QUESTION_WINDOW_MS) {
            questionDispatchInFlight.set(false)
            state = LoopState.RECOVERING
            requestNewListeningSession(SILENCE_RECYCLE_DELAY_MS, "pregunta duplicada")
            return
        }
        lastHeard = question
        lastHeardTime = now

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            speakAnswer(question, localAnswer)
            return
        }

        when (val mode = modeSettings.getMode()) {
            AnswerModeSettings.Mode.INTERNET -> {
                if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                    speakAnswer(question, "No hay una pregunta clara para enviar a NET.")
                } else {
                    answerOnline(question)
                }
            }
            AnswerModeSettings.Mode.JSON,
            AnswerModeSettings.Mode.AUTO -> answerRoutedInBackground(question, mode)
        }
    }

    private fun answerRoutedInBackground(question: String, mode: AnswerModeSettings.Mode) {
        val status = if (mode == AnswerModeSettings.Mode.AUTO) {
            "Buscando en JSON; si no encuentra, pasa a NET..."
        } else {
            "Buscando solo en JSON..."
        }
        sendUpdate(status, question, "", -1)

        synchronized(backgroundLock) {
            routeFuture?.cancel(true)
            routeFuture = routeExecutor.submit {
                val route = try {
                    questionRouter.resolve(mode, question)
                } catch (error: Throwable) {
                    Log.e(TAG, "Fallo en JSON/AUTO", error)
                    handler.post {
                        if (running) speakAnswer(question, "No se pudo procesar la pregunta. Intentalo nuevamente.")
                    }
                    return@submit
                }
                if (!running || Thread.currentThread().isInterrupted) return@submit

                when (route) {
                    is QuestionRouter.Result.Json -> {
                        val match = route.match
                        memory.saveLast(question, match.answer, match.itemId, match.score)
                        handler.post { if (running) speakAnswer(question, match.answer) }
                    }
                    QuestionRouter.Result.JsonNotFound -> {
                        handler.post { if (running) speakAnswer(question, "No encontrado") }
                    }
                    QuestionRouter.Result.Net -> {
                        if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                            handler.post { if (running) speakAnswer(question, "No hay una pregunta clara para enviar a NET.") }
                        } else {
                            answerOnline(question)
                        }
                    }
                }
            }
        }
    }

    private fun answerOnline(question: String, statusText: String = "Buscando NET...") {
        sendUpdate(statusText, question, "", -1)
        val requestVersion = ++onlineRequestVersion

        synchronized(backgroundLock) {
            netFuture?.cancel(true)
            onlineProvider.cancelActiveRequest()
            netFuture = netExecutor.submit {
                val answer = try {
                    onlineProvider.fetchShortAnswer(question)
                } catch (error: Throwable) {
                    Log.e(TAG, "Fallo NET", error)
                    "NET no pudo responder. Revisa Internet y el estado de tus APIs."
                }
                if (!running || requestVersion != onlineRequestVersion || Thread.currentThread().isInterrupted) {
                    return@submit
                }
                memory.saveLast(question, answer, "online", 0)
                handler.post {
                    if (running && requestVersion == onlineRequestVersion) {
                        speakAnswer(question, answer)
                    }
                }
            }
        }
    }

    private fun speakAnswer(question: String, answer: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { speakAnswer(question, answer) }
            return
        }
        if (!running) return

        val finalAnswer = OnlineAnswerProvider.canonicalizeAnswerForQuestion(question, answer)
            .ifBlank { answer.trim() }

        state = LoopState.SPEAKING
        cancelStartRunnable()
        cancelListeningTimers()
        activeSessionId = 0L
        closeRecognizer()
        sendUpdate("Respuesta lista", question, finalAnswer, -1)
        lastSpokenNormalized = ResponseRepository.normalize(finalAnswer)

        val utteranceId = "${UTTERANCE_ID_PREFIX}_${++speechSerial}"
        activeUtteranceId = utteranceId
        startTtsPlayback(utteranceId, finalAnswer, 0)
    }

    private fun startTtsPlayback(utteranceId: String, answer: String, attempt: Int) {
        if (!running || state != LoopState.SPEAKING || activeUtteranceId != utteranceId) return
        cancelTtsStartRetry()

        if (!ttsReady || tts == null) {
            if (attempt >= MAX_TTS_START_ATTEMPTS) {
                Log.w(TAG, "TTS no termino de iniciar; continuando el ciclo")
                finishSpeakingAndResume(utteranceId, "TTS no disponible")
                return
            }
            val retry = Runnable {
                ttsStartRetryRunnable = null
                startTtsPlayback(utteranceId, answer, attempt + 1)
            }
            ttsStartRetryRunnable = retry
            handler.postDelayed(retry, TTS_START_RETRY_MS)
            return
        }

        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())
        val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            if (attempt < MAX_TTS_START_ATTEMPTS) {
                val retry = Runnable {
                    ttsStartRetryRunnable = null
                    startTtsPlayback(utteranceId, answer, attempt + 1)
                }
                ttsStartRetryRunnable = retry
                handler.postDelayed(retry, TTS_START_RETRY_MS)
            } else {
                finishSpeakingAndResume(utteranceId, "error al iniciar TTS")
            }
            return
        }
        scheduleTtsDeadline(utteranceId, answer)
    }

    private fun cancelTtsStartRetry() {
        ttsStartRetryRunnable?.let { handler.removeCallbacks(it) }
        ttsStartRetryRunnable = null
    }

    private fun scheduleTtsDeadline(utteranceId: String, answer: String) {
        cancelTtsDeadline()
        val rate = appSettings.getVoiceRate().coerceIn(0.35f, 2.5f)
        val words = answer.trim().split(Regex("\\s+")).count { it.isNotBlank() }.coerceAtLeast(1)
        val estimated = ((words * 760L) / rate).toLong() + 9000L
        val timeout = estimated.coerceIn(15000L, 120000L)
        val runnable = Runnable {
            ttsDeadlineRunnable = null
            if (!running || state != LoopState.SPEAKING || activeUtteranceId != utteranceId) {
                return@Runnable
            }
            Log.w(TAG, "TTS no notifico final; liberando ciclo")
            runCatching { tts?.stop() }
            finishSpeakingAndResume(utteranceId, "limite TTS")
        }
        ttsDeadlineRunnable = runnable
        handler.postDelayed(runnable, timeout)
    }

    private fun cancelTtsDeadline() {
        ttsDeadlineRunnable?.let { handler.removeCallbacks(it) }
        ttsDeadlineRunnable = null
    }

    private fun finishSpeakingAndResume(utteranceId: String, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { finishSpeakingAndResume(utteranceId, reason) }
            return
        }
        if (activeUtteranceId != utteranceId) return

        cancelTtsStartRetry()
        cancelTtsDeadline()
        activeUtteranceId = null
        questionDispatchInFlight.set(false)
        state = LoopState.RECOVERING
        ignoreEchoUntil = SystemClock.elapsedRealtime() + POST_TTS_ECHO_GUARD_MS
        resetQuestionState()
        sendUpdate("Volviendo a escuchar...", "", "", 0, clearFields = true)
        requestNewListeningSession(POST_TTS_REOPEN_MS, reason)
    }

    private fun resetQuestionState() {
        sessionPartial = ""
        continuationBuffer = ""
        lastTextChangeAt = 0L
        lastHeard = ""
        lastHeardTime = 0L
    }

    private fun shouldIgnoreRecentEcho(question: String): Boolean {
        if (SystemClock.elapsedRealtime() > ignoreEchoUntil) return false
        val spoken = lastSpokenNormalized
        val heard = ResponseRepository.normalize(question)
        if (spoken.isBlank() || heard.isBlank()) return false
        if (spoken.contains(heard) && heard.length >= 10) return true

        val heardWords = heard.split(" ").filter { it.length >= 4 }
        if (heardWords.size < 3) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = heardWords.count { it in spokenWords }
        return common >= 4 && common.toDouble() / heardWords.size >= 0.80
    }

    private fun confirmationDelayMs(question: String): Long {
        return if (VoiceQuestionNormalizer.requiresExtendedListening(question)) {
            COMPLEX_QUESTION_STABLE_MS
        } else {
            NORMAL_QUESTION_STABLE_MS
        }
    }

    private data class SpeechCandidate(
        val text: String,
        val originalIndex: Int,
        val confidence: Float
    )

    private fun chooseBestSpeechCandidate(matches: List<String>, scores: FloatArray?): String {
        val candidates = matches.mapIndexedNotNull { index, raw ->
            val normalized = VoiceQuestionNormalizer.normalize(raw.trim())
            if (normalized.isBlank()) null else SpeechCandidate(
                normalized,
                index,
                scores?.getOrNull(index) ?: -1f
            )
        }.filter { !VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(it.text) }
            .distinctBy { it.text }

        if (candidates.isEmpty()) {
            return matches.firstNotNullOfOrNull { raw ->
                VoiceQuestionNormalizer.normalize(raw.trim()).takeIf { it.isNotBlank() }
            }.orEmpty()
        }

        return candidates.maxWithOrNull(
            compareBy<SpeechCandidate> { transcriptionCompletenessScore(it.text) }
                .thenBy { it.confidence }
                .thenBy { -it.originalIndex }
        )?.text.orEmpty()
    }

    private fun transcriptionCompletenessScore(text: String): Int {
        val normalized = VoiceQuestionNormalizer.normalize(text)
        val words = normalized.split(" ").count { it.isNotBlank() }
        var score = words * 10
        if (!VoiceQuestionNormalizer.isClearlyIncomplete(normalized)) score += 5
        if (VoiceQuestionNormalizer.requiresExtendedListening(normalized)) score += 4
        return score
    }

    private fun initializeRecognitionLanguages() {
        val saved = languagePreferences.getString(KEY_WORKING_LANGUAGE, null)
            ?.trim()?.takeIf { it.isNotBlank() }
        val phoneLanguage = Locale.getDefault().toLanguageTag()
            .trim().takeIf { Locale.getDefault().language.equals("es", ignoreCase = true) }
        recognitionLanguageCandidates = listOfNotNull(
            saved,
            "es-PE",
            "es-419",
            "es-ES",
            phoneLanguage,
            "es"
        ).distinctBy { it.lowercase(Locale.ROOT) }
        recognitionLanguageIndex = 0
    }

    private fun currentRecognitionLanguage(): String {
        if (recognitionLanguageCandidates.isEmpty()) initializeRecognitionLanguages()
        return recognitionLanguageCandidates.getOrElse(recognitionLanguageIndex) { "es" }
    }

    private fun advanceRecognitionLanguage(): String? {
        if (recognitionLanguageCandidates.isEmpty()) initializeRecognitionLanguages()
        val next = recognitionLanguageIndex + 1
        if (next >= recognitionLanguageCandidates.size) return null
        recognitionLanguageIndex = next
        return currentRecognitionLanguage()
    }

    private fun resetRecognitionLanguageCycle() {
        languagePreferences.edit().remove(KEY_WORKING_LANGUAGE).apply()
        recognitionLanguageIndex = 0
    }

    private fun rememberWorkingRecognitionLanguage() {
        val current = currentRecognitionLanguage()
        if (!languagePreferences.getString(KEY_WORKING_LANGUAGE, null).equals(current, true)) {
            languagePreferences.edit().putString(KEY_WORKING_LANGUAGE, current).apply()
        }
    }

    private fun warmJsonInBackground() {
        synchronized(backgroundLock) {
            routeFuture = routeExecutor.submit {
                runCatching { jsonRepository.totalItems }
                    .onFailure { Log.e(TAG, "No se pudo precargar JSON", it) }
            }
        }
    }

    private fun sendUpdate(
        status: String,
        heard: String,
        answer: String,
        level: Int,
        clearFields: Boolean = false
    ) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
            putExtra(EXTRA_CLEAR_FIELDS, clearFields)
        }
        sendBroadcast(intent)
        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val manager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = manager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "GeoSusuAudio::GoogleInternalWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun ensureWakeLock() {
        if (wakeLock?.isHeld == true) return
        runCatching { acquireWakeLock() }
            .onFailure { Log.w(TAG, "No se pudo activar WakeLock", it) }
    }

    private fun logState(event: String, extra: String = "") {
        Log.i(
            TAG,
            "GSU_LOOP event=$event state=$state session=$activeSessionId " +
                "dispatch=${questionDispatchInFlight.get()} partial=\"${sessionPartial.take(60)}\" " +
                "continuation=\"${continuationBuffer.take(60)}\" lastEvent=$lastRecognizerEventAt $extra"
        )
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (!ttsReady) return
        tts?.setLanguage(Locale("es", "PE"))
        tts?.setSpeechRate(appSettings.getVoiceRate())
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                if (utteranceId != null) {
                    handler.post { finishSpeakingAndResume(utteranceId, "respuesta terminada") }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId != null) {
                    handler.post { finishSpeakingAndResume(utteranceId, "error de TTS") }
                }
            }
        })
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            JsonKnowledgeRepository.clearMemoryCache()
            Log.i(TAG, "Memoria baja: indice JSON liberado")
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        JsonKnowledgeRepository.clearMemoryCache()
    }

    override fun onDestroy() {
        running = false
        state = LoopState.STOPPED
        onlineRequestVersion += 1
        onlineProvider.cancelActiveRequest()
        synchronized(backgroundLock) {
            routeFuture?.cancel(true)
            netFuture?.cancel(true)
            routeFuture = null
            netFuture = null
        }
        routeExecutor.shutdownNow()
        netExecutor.shutdownNow()

        cancelStartRunnable()
        cancelListeningTimers()
        cancelTtsStartRetry()
        cancelTtsDeadline()
        activeSessionId = 0L
        closeRecognizer()
        questionDispatchInFlight.set(false)
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_CLEAR_FIELDS = "clear_fields"

        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID_PREFIX = "geo_susu_google_internal_answer"
        private const val TAG = "GeoSusuGoogle"

        private const val RECOGNIZER_SETTLE_DELAY_MS = 650L
        private const val SILENCE_RECYCLE_DELAY_MS = 500L
        private const val CONTINUATION_REOPEN_MS = 450L
        private const val ERROR_RETRY_MS = 1200L
        private const val BUSY_RETRY_MS = 1800L
        private const val NETWORK_RETRY_MS = 2800L
        private const val RATE_LIMIT_RETRY_MS = 6000L
        private const val SERVICE_UNAVAILABLE_RETRY_MS = 5000L
        private const val LISTENING_SESSION_MAX_MS = 22000L
        private const val NORMAL_QUESTION_STABLE_MS = 2100L
        private const val COMPLEX_QUESTION_STABLE_MS = 2900L
        private const val LEVEL_UPDATE_INTERVAL_MS = 250L
        private const val POST_TTS_REOPEN_MS = 650L
        private const val POST_TTS_ECHO_GUARD_MS = 1200L
        private const val DUPLICATE_QUESTION_WINDOW_MS = 4500L
        private const val TTS_START_RETRY_MS = 350L
        private const val MAX_TTS_START_ATTEMPTS = 10
        private const val LANGUAGE_PREFS_NAME = "google_internal_language_preferences"
        private const val KEY_WORKING_LANGUAGE = "working_language_tag"
    }
}
