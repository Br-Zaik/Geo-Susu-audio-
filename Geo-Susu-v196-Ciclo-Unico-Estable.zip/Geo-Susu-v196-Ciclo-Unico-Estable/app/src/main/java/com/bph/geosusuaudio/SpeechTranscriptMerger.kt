package com.bph.geosusuaudio

import java.util.Locale

/**
 * Separa dos problemas distintos del reconocimiento de Google:
 * 1) los parciales de una misma sesion son revisiones de la misma frase;
 * 2) los resultados confirmados de sesiones distintas si deben acumularse.
 */
object SpeechTranscriptMerger {

    fun selectSessionHypothesis(previousRaw: String, currentRaw: String): String {
        val previous = previousRaw.trim()
        val current = currentRaw.trim()
        if (previous.isBlank()) return current
        if (current.isBlank()) return previous

        val previousNormalized = ResponseRepository.normalize(previous)
        val currentNormalized = ResponseRepository.normalize(current)
        if (previousNormalized == currentNormalized) {
            return if (current.length >= previous.length) current else previous
        }
        if (currentNormalized.contains(previousNormalized)) return current
        if (previousNormalized.contains(currentNormalized)) return previous

        val previousWords = words(previous)
        val currentWords = words(current)
        val boundaryMerged = mergeByBoundaryOverlap(previousWords, currentWords)
        if (boundaryMerged != null) return boundaryMerged

        val previousHasInstruction = hasInstructionPrefix(previousNormalized)
        val currentHasInstruction = hasInstructionPrefix(currentNormalized)

        // Algunos telefonos conservan el inicio en un parcial y despues entregan
        // solo la cola de la misma frase. Si el primer texto trae la instruccion
        // (explica, completa, verdadero/falso, etc.), nunca se descarta ese inicio.
        if (previousHasInstruction && !currentHasInstruction) {
            if (VoiceQuestionNormalizer.isClearlyIncomplete(previous) || currentWords.size >= 3) {
                return (previousWords + currentWords).joinToString(" ")
            }
            return previous
        }
        if (currentHasInstruction && !previousHasInstruction) return current

        val sharedRatio = fuzzySharedRatio(previousWords, currentWords)

        // Los parciales de SpeechRecognizer normalmente son revisiones de la
        // misma frase. Se conserva la hipotesis mas informativa; solo se unen
        // cuando existe una continuacion clara en el borde.
        return when {
            sharedRatio >= 0.40 && currentWords.size >= previousWords.size - 1 -> current
            sharedRatio >= 0.40 -> previous
            currentWords.size > previousWords.size + 2 -> current
            currentWords.size < previousWords.size -> previous
            else -> richerHypothesis(previous, current)
        }
    }

    fun mergePartialWithFinal(partialRaw: String, finalRaw: String): String {
        val partial = partialRaw.trim()
        val finalText = finalRaw.trim()
        if (partial.isBlank()) return finalText
        if (finalText.isBlank()) return partial

        val partialNormalized = ResponseRepository.normalize(partial)
        val finalNormalized = ResponseRepository.normalize(finalText)
        if (partialNormalized == finalNormalized) {
            return if (finalText.length >= partial.length) finalText else partial
        }
        if (finalNormalized.contains(partialNormalized)) return finalText
        if (partialNormalized.contains(finalNormalized)) return partial

        val partialWords = words(partial)
        val finalWords = words(finalText)
        val boundaryMerged = mergeByBoundaryOverlap(partialWords, finalWords)
        if (boundaryMerged != null) return boundaryMerged

        val selected = selectSessionHypothesis(partial, finalText)
        if (selected.isNotBlank()) return selected
        return richerHypothesis(partial, finalText)
    }

    fun mergeCommitted(previousRaw: String, currentRaw: String): String {
        val previous = previousRaw.trim()
        val current = currentRaw.trim()
        if (previous.isBlank()) return current
        if (current.isBlank()) return previous

        val previousNormalized = ResponseRepository.normalize(previous)
        val currentNormalized = ResponseRepository.normalize(current)
        if (previousNormalized == currentNormalized) {
            return if (current.length >= previous.length) current else previous
        }
        if (currentNormalized.contains(previousNormalized)) return current
        if (previousNormalized.contains(currentNormalized)) return previous

        val previousWords = words(previous)
        val currentWords = words(current)
        val boundaryMerged = mergeByBoundaryOverlap(previousWords, currentWords)
        if (boundaryMerged != null) return boundaryMerged

        // Si ambos textos parecen dos revisiones de la misma oracion completa,
        // conservar la hipotesis mas informativa en vez de duplicarla.
        val sharedRatio = fuzzySharedRatio(previousWords, currentWords)
        val commonPrefix = commonPrefixSize(previousWords, currentWords)
        if (sharedRatio >= 0.66 || commonPrefix >= 2) {
            return if (currentWords.size >= previousWords.size) current else previous
        }

        return (previousWords + currentWords).joinToString(" ")
    }

    fun preview(committedRaw: String, sessionRaw: String): String {
        return mergeCommitted(committedRaw, sessionRaw)
    }

    private fun mergeByBoundaryOverlap(leftWords: List<String>, rightWords: List<String>): String? {
        val maxOverlap = minOf(leftWords.size, rightWords.size, 18)
        for (size in maxOverlap downTo 1) {
            val left = leftWords.takeLast(size)
            val right = rightWords.take(size)
            if (left.indices.all { tokensEquivalent(left[it], right[it]) }) {
                return (leftWords + rightWords.drop(size)).joinToString(" ")
            }
        }
        return null
    }

    private fun richerHypothesis(left: String, right: String): String {
        val leftNormalized = ResponseRepository.normalize(left)
        val rightNormalized = ResponseRepository.normalize(right)
        val leftScore = informationScore(leftNormalized)
        val rightScore = informationScore(rightNormalized)
        return if (rightScore > leftScore) right else left
    }

    private fun informationScore(normalized: String): Int {
        val wordCount = normalized.split(" ").count { it.isNotBlank() }
        val instructionBonus = if (hasInstructionPrefix(normalized)) 12 else 0
        val completeBonus = if (!VoiceQuestionNormalizer.isClearlyIncomplete(normalized)) 4 else 0
        return wordCount * 10 + instructionBonus + completeBonus
    }

    private fun hasInstructionPrefix(normalized: String): Boolean {
        return normalized.startsWith("explica ") ||
            normalized.startsWith("explique ") ||
            normalized.startsWith("completa ") ||
            normalized.startsWith("complete ") ||
            normalized.startsWith("compara ") ||
            normalized.startsWith("describe ") ||
            normalized.startsWith("cual ") ||
            normalized.startsWith("que ") ||
            normalized.startsWith("por que ")
    }

    private fun words(text: String): List<String> {
        return text.split(Regex("\\s+")).filter { it.isNotBlank() }
    }

    private fun commonPrefixSize(left: List<String>, right: List<String>): Int {
        val count = minOf(left.size, right.size)
        var shared = 0
        for (index in 0 until count) {
            if (!tokensEquivalent(left[index], right[index])) break
            shared += 1
        }
        return shared
    }

    private fun fuzzySharedRatio(left: List<String>, right: List<String>): Double {
        if (left.isEmpty() || right.isEmpty()) return 0.0
        val used = BooleanArray(right.size)
        var shared = 0
        for (token in left) {
            val index = right.indices.firstOrNull { !used[it] && tokensEquivalent(token, right[it]) }
            if (index != null) {
                used[index] = true
                shared += 1
            }
        }
        return shared.toDouble() / minOf(left.size, right.size).coerceAtLeast(1).toDouble()
    }

    private fun tokensEquivalent(leftRaw: String, rightRaw: String): Boolean {
        val left = ResponseRepository.normalize(leftRaw).lowercase(Locale.ROOT)
        val right = ResponseRepository.normalize(rightRaw).lowercase(Locale.ROOT)
        if (left == right) return true
        if (left.isBlank() || right.isBlank()) return false

        val shorter = if (left.length <= right.length) left else right
        val longer = if (left.length > right.length) left else right
        if (shorter.length >= 5 && longer.startsWith(shorter)) return true

        return singularStem(left) == singularStem(right) && singularStem(left).length >= 4
    }

    private fun singularStem(token: String): String {
        return when {
            token.length > 6 && token.endsWith("es") -> token.dropLast(2)
            token.length > 5 && token.endsWith("s") -> token.dropLast(1)
            else -> token
        }
    }
}
