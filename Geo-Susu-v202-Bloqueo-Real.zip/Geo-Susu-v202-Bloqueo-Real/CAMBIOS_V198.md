# Geo Susu v198 — modo ESCUCHAR protegido

- Al comenzar la escucha se bloquean toques sobre todos los controles excepto DETENER.
- DETENER requiere tres toques dentro de cuatro segundos entre toques; al tercero detiene los servicios y desbloquea la interfaz.
- ATRÁS no cierra Geo Susu durante la escucha.
- Fuera de la escucha, ATRÁS y DETENER mantienen su comportamiento previo.
- No se modifican proveedores de API ni la lógica de pago de v197.
- Límite de Android: no puede bloquear botones del sistema ni la UI de un reconocedor externo lanzado por Google.
