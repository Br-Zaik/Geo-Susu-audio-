Geo Susu v201 — DETENER con un toque

- Base: v200.
- DETENER detiene la escucha con un solo toque cuando los controles están desbloqueados.
- BLOQUEAR continúa ignorando toques sobre DETENER y otros controles.
- DESBLOQUEAR continúa exigiendo 3 toques rápidos y confirmación; no interrumpe la escucha.
- Sin cambios a las APIs, servicios, permisos o demás opciones.
- versionCode 201; versionName 20.1.0.
- Pendiente: compilación y prueba en dispositivo.
