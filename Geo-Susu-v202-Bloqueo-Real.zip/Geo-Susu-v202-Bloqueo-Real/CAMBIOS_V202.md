Geo Susu v202 — Bloqueo manual real de controles

- Base: v201. Única corrección funcional: proteger los controles al pulsar BLOQUEAR.
- El bloqueo interno se activa inmediatamente y NO depende de que Android haya activado la fijación de pantalla (confirmación asíncrona).
- DETENER, ESCUCHAR, JSON, NET/AUTO, velocidad y API se ignoran mientras está bloqueado.
- Solo DESBLOQUEAR acepta 3 toques rápidos y confirmación; al desbloquear la escucha sigue.
- Se conserva DETENER a un toque una vez desbloqueado.
- Se conserva la petición de Fijar pantalla para restringir botones INICIO/RECIENTES cuando Android lo permita.
- En recreaciones de Activity se recupera el estado de bloqueo; onResume ya no lo sobreescribe por el estado de pinning.
- APIs, motor de escucha, batería y demás funciones: sin cambios.
- VersionCode 202; versionName 20.2.0. Compilación Android y prueba en teléfono pendientes.
