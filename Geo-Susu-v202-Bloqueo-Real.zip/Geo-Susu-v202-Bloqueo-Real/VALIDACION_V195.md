# VALIDACION V195 — Fin del congelamiento en "Procesando..."

Solo se tocó GoogleInternalListenService.kt y el número de versión.
No se modificó ningún otro archivo.

## Qué NO se tocó

- Google interno (SpeechRecognizer) funciona igual que en v194.
- Tiempos del micrófono: 4200 / 2600 / 2600 sin cambios.
- Sensibilidad y ganancia del susurro: sin cambios.
- Modos JSON, NET y AUTO: sin cambios.
- Rotación de APIs, umbrales del JSON, filtros de pregunta: sin cambios.
- Bluetooth, USB-C, TTS, notificación, WakeLock: sin cambios.
- Interfaz: sin cambios (solo un aviso nuevo cuando hay recuperación).

## Cambio 1 — Los hilos de fondo ya no pueden morir en silencio

El problema: el hilo de JSON y el de NET atrapaban `Exception`.
Un `Error` (memoria agotada, fallo nativo) NO es `Exception`, así que
se escapaba, el hilo moría y `isProcessing` quedaba encendido para
siempre. La app se quedaba en "Procesando..." hasta DETENER + ESCUCHAR.

Lo que se hizo:

- Los dos hilos (`GeoSusu-JSON` y `GeoSusu-NET`) ahora atrapan `Throwable`,
  que incluye `Error`.
- Cada hilo tiene un bloque `finally` que se ejecuta pase lo que pase.
- Se añadió una marca `handedOff`: es verdadera solo cuando el hilo
  entregó de verdad una respuesta a `speakAnswer`. Si el hilo termina
  sin entregar nada, el `finally` libera el ciclo y reabre la escucha.
- Se añadió `processingSerial`, un número que sube en cada pregunta
  nueva. Un hilo viejo o cancelado no puede tocar el estado de una
  pregunta nueva.

Efecto: si algo revienta dentro del hilo, la recuperación es inmediata,
no hay que esperar a ningún temporizador.

## Cambio 2 — Watchdog global que no depende de isProcessing

El problema: el supervisor de bucle solo actuaba si `!isProcessing`.
Justo en el caso en que esa bandera se quedaba trabada, el supervisor
se apagaba solo. Nada rescataba la app.

Lo que se hizo:

- Se añadió un bloque nuevo AL INICIO del supervisor, fuera de esa
  condición. Ese bloque sí mira el caso `isProcessing == true`.
- El supervisor lleva la cuenta de cuánto tiempo lleva el estado
  atascado con `stuckStateSince`. No depende de ninguna otra bandera,
  así que no se puede desincronizar.
- Si el estado lleva más de 60 segundos atascado, llama a
  `recoverFromStuckProcessing()`.
- Esa función cancela los futuros, cancela la petición NET en curso,
  apaga `isProcessing`, libera el dispatch, destruye el reconocedor,
  avisa en pantalla y programa una sesión nueva a los 400 ms.
- El supervisor sigue corriendo cada 5 segundos como antes.

## Por qué 60 segundos y no 20

Una rotación de APIs NET puede tardar de verdad: 6 s de conexión más
9 a 15 s de lectura por cada API, y son cuatro. Un watchdog de 20 s
cortaría respuestas buenas que sí iban a llegar.

El watchdog es la última red, no el mecanismo principal. El Cambio 1
resuelve el caso real (hilo que revienta) al instante. El watchdog solo
cubre lo que el Cambio 1 no puede ver, como un hilo colgado en código
nativo.

Si prefieres que corte antes, es un solo número:
`PROCESSING_HARD_TIMEOUT_MS` en las constantes del final del archivo.

## Cómo saber si funcionó

En pantalla, cuando antes se quedaba muerta, ahora debe aparecer
"Reiniciando escucha..." y volver sola a escuchar.

En el log (`adb logcat -s GeoSusuGoogle`), las líneas nuevas son:

- `stuck_processing_recovered` — se activó la recuperación.
- `Error grave en el hilo JSON/AUTO` o `Error grave en el hilo NET` —
  se atrapó un `Error` que antes congelaba la app.

Si nunca ves esas líneas, es buena señal: significa que no hubo atascos.

## Lo que sigue igual de limitado

Esto arregla el congelamiento. No arregla:

- Los huecos y pitidos entre sesiones de Google interno.
- Los susurros que el filtro de voz de Google descarta.
- Que EMUI mate la app pasada una hora si no configuras el arranque
  manual y quitas la optimización de batería.

## Nota honesta

No compilé el proyecto: no tengo el SDK de Android ni red en este
entorno, y soy una IA, no puedo probar la app en tu teléfono. Lo que
sí hice fue leer el archivo completo, comprobar que las llaves y
paréntesis quedan balanceados y revisar cada cambio en su contexto.
La compilación real la hace GitHub Actions.
