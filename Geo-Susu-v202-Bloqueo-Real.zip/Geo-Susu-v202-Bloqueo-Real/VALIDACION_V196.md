# Geo Susu v19.6.0

- API de pago Cheaper Inference / DeepSeek añadida (`ir_live_` / `ci_live_`).
- Bloqueo/salida cambiado al estilo GI X: 3 pulsaciones ATRÁS + confirmación.
- Anclaje de pantalla ahora es opcional mediante casilla.
- DETENER solo detiene escucha; no cierra la app.
- Package/applicationId sin cambios.
