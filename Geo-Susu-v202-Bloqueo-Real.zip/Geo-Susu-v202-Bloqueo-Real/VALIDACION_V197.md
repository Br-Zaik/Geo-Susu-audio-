# Geo Susu v197 - API de pago sin bloqueo falso

Cambios solo para Cheaper Inference (PAGO):

- Un timeout, 5xx, 429 temporal o respuesta temporal ya no guarda `EN ESPERA (10m)`.
- Un `WAIT` viejo de v196 para Cheaper Inference se limpia automáticamente al abrir/consultar el estado.
- La siguiente pregunta puede volver a usar la API de pago inmediatamente.
- Si hay un 5xx o respuesta vacía puntual, hace un segundo intento automático corto en la misma pregunta.
- Se aumentó únicamente el timeout de Cheaper Inference: 60 s en preguntas normales, 90 s en complejas y 45 s al probar la API.
- Clave inválida, modelo rechazado o falta real de créditos siguen mostrando el error real; no se ocultan.
- Gemini, OpenRouter, Mistral y Cohere conservan su lógica de espera existente.

Versión: `versionCode 197`, `versionName 19.7.0`.
