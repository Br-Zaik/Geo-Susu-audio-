# Geo Susu v199 — Estabilidad prolongada

Base: Geo-Susu-v198-Escucha-Protegida.zip. Conserva applicationId, las APIs NET, el modo ESCUCHAR protegido y DETENER con tres toques.

## Cambios implementados
- Google interno: el watchdog del procesamiento pasó de 60 s a 110 s; cuando hay Cheaper Inference configurada, NET dispone de hasta 210 s para conectar, leer, reintentar y pasar a la siguiente API antes de recuperar la escucha. El temporizador se reinicia al pasar de JSON a NET. No se modifica el timeout de HTTP de las demás APIs.
- Vosk: solicita START_STICKY para poder ser recreado por Android tras una terminación por recursos cuando el sistema lo permita. Si falla al inicializar, ya no borra el modelo de lenguaje sin evidencia de corrupción.
- Vosk: si AudioRecord deja de dar lecturas o falla al reanudar después de TTS, intenta reabrir la entrada y restablecer el reconocedor; si muere el hilo de audio, se intenta recrearlo.
- Vosk: control de TTS para devolver la escucha si Android no reporta fin de voz o rechaza la reproducción. Se descartan callbacks de TTS antiguos.
- Vosk: supervisor de petición NET de 110 s, o 210 s si existe Cheaper Inference configurada, para que una petición sin respuesta no deje la escucha bloqueada indefinidamente.
- Vosk: renovación de WakeLock mientras el servicio continúa activo y liberación en onDestroy.
- Mantiene KEEP_SCREEN_ON mientras escucha y el bloqueo de 3 toques existente; NO se creó modo de pantalla apagada.
- Nombre de versión 19.9.0, code 199; se mantiene el applicationId y el sistema de compilación del ZIP.

## Límites y pruebas necesarias
- Fuente Kotlin revisada estáticamente. NO es una APK compilada ni se ha probado aún durante horas en hardware real.
- START_STICKY y WakeLock no pueden evitar cierres forzados, restricciones térmicas, falta grave de memoria, ni restricciones de Android para reabrir el micrófono desde segundo plano; el permiso de exclusión de batería sigue siendo opcional.
- Probar en el celular Google interno y Vosk por 2–4 h, con pantalla encendida, batería/cargador adecuados, contestación por voz, toques accidentales, DETENER 3 veces, cambio de datos móviles, y reconexión de micrófono externo. Verificar que la primera pregunta se responda y que las siguientes no entren en un falso bloqueo de pago.
