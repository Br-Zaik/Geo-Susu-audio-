Geo Susu v200 — bloqueo independiente de la escucha.

- ESCUCHAR ya no deshabilita los demás controles automáticamente.
- BLOQUEAR solo funciona tras iniciar la escucha; invoca startLockTask (fijación de pantalla de Android) y bloquea controles de Geo Susu salvo DESBLOQUEAR.
- DESBLOQUEAR requiere 3 toques en 2 segundos y confirmación; conserva la escucha y restablece los controles.
- DETENER se cambia a 1 toque en v201; el bloqueo manual sigue protegiéndolo.
- Si Android no permite fijación de pantalla, se informa y no se declara protegido.
- Android mantiene su método de salida de seguridad; no se puede suprimir por una app común.
- No se modifican proveedores API, voz, permisos, ni servicios de escucha.
