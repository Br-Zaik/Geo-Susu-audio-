Geo Susu v203 — API de pago siempre disponible y escucha sin pausas

API de pago (Cheaper Inference):
- Espera hasta 200 s la respuesta (antes cortaba a 60/90 s y se perdía una respuesta ya cobrada).
- Ya no se reintenta sola: se evita el cobro doble.
- Siempre participa en NET/AUTO, aunque PROBAR API haya salido lenta o con aviso.
- Un aviso de créditos, límite o rechazo puntual ya no la bloquea 24 horas ni hasta volver a probar.
- Sin límite de tokens: la respuesta no llega cortada. La instrucción pide ir directo al grano
  (1 o 2 oraciones en preguntas normales, máximo 4 en explicativas).
- Una respuesta pagada ya no se tira por larga o cortada: se recorta en oraciones completas.
- Se quitan bloques <think> de modelos que razonan.
- PROBAR API: si el servidor está lento, la marca DISPONIBLE (LENTA) en vez de sin probar.
- Preguntas repetidas se responden al instante desde lo ya guardado, sin volver a pagar
  (excepto preguntas de fecha, hora o precios).
- Ya no exige red "validada" por Android para consultar.

Escucha (Google interno):
- Mientras NET busca, el micrófono sigue escuchando. Se muestra "NET buscando N s".
- Repetir la misma pregunta durante la búsqueda no la vuelve a pagar.
- Una pregunta nueva reemplaza a la anterior.
- Tope total de NET según las APIs configuradas; si se supera, avisa por voz y sigue escuchando.
- Micrófono USB-C: si está conectado al iniciar (o se conecta después), se usa SOLO ese.
  Si se desconecta, la escucha se pausa (no pasa al micrófono del celular) y sigue al reconectarlo.
- Bluetooth: se apaga también el micrófono del auricular en Android 12+; el auricular solo recibe audio.
- Tras 2 errores de red, Google interno intenta el modo sin conexión.
- Voz de respuesta con respaldo si el teléfono no tiene voz es-PE.

Vosk: tope de NET de pago ajustado a 230 s.
versionCode 203; versionName 20.3.0. Compilación y prueba en teléfono pendientes.
