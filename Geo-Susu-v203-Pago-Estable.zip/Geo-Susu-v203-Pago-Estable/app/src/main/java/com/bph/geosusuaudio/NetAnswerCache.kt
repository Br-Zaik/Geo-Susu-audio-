package com.bph.geosusuaudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * v203: respuestas NET que ya llegaron bien (y ya se pagaron).
 * Si repites la misma pregunta, se responde al instante sin volver a pagar.
 * No guarda preguntas que dependen de la fecha, la hora o precios actuales.
 */
class NetAnswerCache(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun get(question: String): String? {
        val key = keyFor(question) ?: return null
        return try {
            val items = JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]")
            for (i in items.length() - 1 downTo 0) {
                val item = items.optJSONObject(i) ?: continue
                if (item.optString("q") == key) {
                    val answer = item.optString("a").trim()
                    return answer.ifBlank { null }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    fun put(question: String, answer: String) {
        val key = keyFor(question) ?: return
        val clean = answer.trim()
        if (clean.isBlank()) return
        try {
            val old = JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]")
            val next = JSONArray()
            for (i in 0 until old.length()) {
                val item = old.optJSONObject(i) ?: continue
                if (item.optString("q") != key) next.put(item)
            }
            next.put(JSONObject().put("q", key).put("a", clean))
            val start = (next.length() - MAX_ITEMS).coerceAtLeast(0)
            val trimmed = JSONArray()
            for (i in start until next.length()) trimmed.put(next.get(i))
            prefs.edit().putString(KEY_ITEMS, trimmed.toString()).apply()
        } catch (_: Exception) {
            // La caché es una ayuda: si falla, la app sigue igual.
        }
    }

    private fun keyFor(question: String): String? {
        val key = ResponseRepository.normalize(question)
        if (key.length < 6) return null
        val words = key.split(" ").toSet()
        if (TIME_WORDS.any { it in words }) return null
        if (key.contains("precio") || key.contains("cotizacion") || key.contains("tipo de cambio")) return null
        return key
    }

    companion object {
        private const val PREFS_NAME = "net_answer_cache"
        private const val KEY_ITEMS = "items"
        private const val MAX_ITEMS = 300
        private val TIME_WORDS = setOf(
            "hoy", "ahora", "fecha", "hora", "ayer", "manana", "actual", "actualmente",
            "semana", "mes", "ano", "dia", "ultimo", "ultima", "reciente"
        )
    }
}
