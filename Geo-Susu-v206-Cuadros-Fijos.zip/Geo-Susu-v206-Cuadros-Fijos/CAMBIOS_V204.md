Geo Susu v204 — una pregunta, una respuesta (flujo de antes)

Se vuelve al flujo de v202:
- Haces la pregunta; 3 s sin palabras nuevas la terminan.
- El micrófono se apaga y queda en espera mientras la API busca.
- Apenas la API responde, se lee la respuesta completa de inmediato.
- Recién al terminar de leerla, el micrófono se vuelve a prender.

Se quitan de v203:
- Escuchar mientras NET busca.
- Respuestas guardadas (caché): cada pregunta va a la API.
- Nada en cola: siempre una pregunta y una respuesta.

Corrección nueva:
- Los 3 s se cuentan desde la última palabra NUEVA. Si por el ruido Google repite
  el mismo texto, el contador ya no se reinicia ni alarga la pregunta.

Se conservan de v203:
- API de pago siempre disponible, espera hasta 200 s, sin reintento (sin cobro doble),
  sin límite de tokens, respuestas directas y no se tiran respuestas pagadas.
- El vigilante de la escucha espera el tiempo real de la API antes de rescatarla.
- Solo micrófono USB-C cuando está conectado; auricular Bluetooth solo como salida.
- Modo sin conexión tras errores de red; voz de respuesta con respaldo.

versionCode 204; versionName 20.4.0. Compilación y prueba en teléfono pendientes.
