Geo Susu v205 — solo la API de pago cuando existe

- Si hay una API de pago (Cheaper Inference) configurada, NET/AUTO usa SOLO esa.
  Las APIs gratis se ignoran aunque estén guardadas.
- Si no hay API de pago, las gratis funcionan exactamente como antes:
  límite de tokens, rotación, límites diarios/por minuto, esperas y red validada.
- La API de pago conserva lo de v203/v204: siempre disponible, espera hasta 200 s,
  sin reintento (sin cobro doble), sin límite de tokens y respuestas directas.
- El vigilante de la escucha usa el tiempo de la API de pago cuando existe, y el de siempre si no.
- Se mantiene el flujo de v204: una pregunta, micrófono en espera, respuesta completa,
  micrófono otra vez. Sin respuestas guardadas ni cola.
versionCode 205; versionName 20.5.0. Compilación y prueba en teléfono pendientes.
