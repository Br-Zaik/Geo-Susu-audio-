Geo Susu v206 — la pregunta y la respuesta se quedan en pantalla

- Después de leer la respuesta, los cuadros de Pregunta y Respuesta ya no se vacían.
- El cuadro de Pregunta cambia recién cuando empiezas a decir una pregunta nueva.
- El cuadro de Respuesta conserva la última respuesta hasta que llega la nueva.
- Los avisos de proceso ("Pregunta confirmada", "Buscando una API...", "Reintentando...",
  entrada de micrófono, etc.) ahora solo salen en la barra de estado de arriba y ya no
  borran la respuesta anterior.
- Al tocar DETENER también se queda la última pregunta y respuesta.
- Los errores que sí responden a tu pregunta (por ejemplo "No llegó respuesta a tiempo")
  siguen saliendo en el cuadro de Respuesta.
- Texto de PROBAR API corregido: la de pago espera hasta 60 s.
- Todo lo demás igual que v205.
versionCode 206; versionName 20.6.0. Compilación y prueba en teléfono pendientes.
