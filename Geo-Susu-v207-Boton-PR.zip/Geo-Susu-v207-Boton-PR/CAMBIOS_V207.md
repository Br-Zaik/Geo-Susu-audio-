Geo Susu v207 — botón P/R: ON / OFF

- Nuevo botón "P/R" al lado de VELOCIDAD y API.
- P/R: ON (por defecto): la pregunta y la respuesta se quedan en pantalla hasta la siguiente,
  también al tocar DETENER. Los avisos de proceso salen solo en la barra de estado.
- P/R: OFF: como antes. Los cuadros se borran al volver a escuchar y al tocar DETENER,
  y los avisos ("Pregunta confirmada", "Buscando una API...") salen en el cuadro de respuesta.
- La opción se guarda y se aplica al momento, incluso con la escucha activa.
- Con BLOQUEAR activo, el botón no responde (igual que los demás).
- Todo lo demás igual que v206.
versionCode 207; versionName 20.7.0. Compilación y prueba en teléfono pendientes.
