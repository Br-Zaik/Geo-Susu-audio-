# Geo Susu v211 — susurro estable sin cortar preguntas

- Google interno conserva el ciclo continuo existente: escucha, procesa, responde y vuelve a escuchar.
- Se unificó el cierre de la pregunta en una sola espera de 3 segundos desde la última palabra nueva.
- El ruido, el nivel RMS y los textos repetidos de Google no reinician el contador.
- Si llegan palabras nuevas, la espera se reinicia y los fragmentos se unen antes de consultar JSON o NET.
- Durante la espera se abre otra sesión de Google para no perder una continuación después de una pausa.
- Las frases terminadas en «de», «en», «la», «para» u otros enlaces se envían completas tras los 3 segundos de silencio.
- Una señal sin palabras o formada solo por ruido nunca se envía a la API.
- No se modificaron la API pagada, DeepSeek, JSON/NET/AUTO, contexto IA, TTS, Vosk, interfaz ni micrófono USB-C.
