Geo Susu v208 — mejor detección y corrección con IA

Escucha (Google interno):
- Se guardan las versiones que oyó Google (hasta 5) en cada resultado.
- Si la pregunta se formó en varias partes, solo se cambia la parte del último resultado.
- Las palabras de tu JSON siguen como pistas para Google (Android 13+).

JSON (modos JSON y AUTO):
- Primero busca con la pregunta elegida, igual que antes.
- Solo si no coincide, prueba las otras versiones de Google (gratis, sin internet).
- Nunca usa una versión recortada: debe tener al menos el 70 % de las palabras.
- Se mantiene la misma exigencia de coincidencia del JSON.

API de pago (NET y AUTO):
- Manda hasta 3 versiones distintas de lo escuchado (sin repetidas) en UNA sola consulta.
- La IA reconstruye la pregunta real y la responde (formato PREGUNTA / RESPUESTA).
- En el cuadro de Pregunta se ve lo escuchado y debajo "Entendí: ...".
- Si no se puede reconstruir, responde "No entendí bien la pregunta. Repítela, por favor."
- AUTO: si la pregunta corregida está en tu JSON, se lee tu respuesta del JSON.
- Si el modelo no respeta el formato, se usa su texto como respuesta normal.
- PROBAR API, las APIs gratis, Vosk y la búsqueda por texto no cambian.

versionCode 208; versionName 20.8.0. Compilación y prueba en teléfono pendientes.
