Geo Susu v209 — la pregunta ya no se queda esperando

Escucha:
- Si la pregunta termina en "en", "de", "la"... y te callas, antes esperaba para siempre
  que la completaras. Ahora, tras 4 s sin palabras nuevas, se envía igual.
- En NET y AUTO, la IA de pago la corrige y la completa.
- Mientras la API busca, la barra de estado muestra "Buscando NET... N s".

API de pago:
- Al corregir, conserva todos los detalles de la pregunta (cada mes, qué fecha, en qué diario...).
  Antes podía resumirla ("¿Cuándo se publican...?") y perder lo importante.
- Contexto de minería en el Perú (normativa, INGEMMET, El Peruano).
- Si no conoce el dato exacto, da la respuesta más probable empezando con "Probablemente".
  Solo dice "No tengo una respuesta segura" si no tiene ninguna idea.

Las APIs gratis, JSON, Vosk y lo demás no cambian.
versionCode 209; versionName 20.9.0. Compilación y prueba en teléfono pendientes.
