# Geo Susu v210 — Contexto IA

- Se agregó **CONTEXTO IA** con tres opciones persistentes: **AUTO / GENERAL / MINERÍA**.
- Es independiente de **Modo de respuesta: JSON / NET / AUTO**.
- **AUTO** deja que la IA determine si la consulta es minera/topográfica o general y evita forzar contexto minero en preguntas normales.
- **GENERAL** elimina el sesgo minero salvo que la propia pregunta mencione el tema.
- **MINERÍA** prioriza minería peruana, geología, explotación minera y topografía; además ayuda a reconstruir términos técnicos mal escuchados por voz.
- El contexto se aplica a las consultas NET de todos los proveedores configurados, incluida la API de pago.
- Se conserva el resto del flujo, bloqueo, JSON, escucha y configuración de APIs.
