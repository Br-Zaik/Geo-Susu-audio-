package com.bph.geosusuaudio

import android.content.Context

/**
 * Contexto que se envía a la IA cuando Geo Susu consulta NET.
 * Es independiente del modo de respuesta JSON / NET / AUTO.
 */
class ContextModeSettings(context: Context) {
    private val prefs = context.getSharedPreferences("geo_susu_settings", Context.MODE_PRIVATE)

    enum class Mode {
        AUTO,
        GENERAL,
        MINING
    }

    fun getMode(): Mode {
        return when (prefs.getString(KEY_CONTEXT_MODE, Mode.AUTO.name)) {
            Mode.GENERAL.name -> Mode.GENERAL
            Mode.MINING.name -> Mode.MINING
            else -> Mode.AUTO
        }
    }

    fun setMode(mode: Mode) {
        prefs.edit().putString(KEY_CONTEXT_MODE, mode.name).apply()
    }

    fun getLabel(): String {
        return when (getMode()) {
            Mode.AUTO -> "AUTO"
            Mode.GENERAL -> "GENERAL"
            Mode.MINING -> "MINERÍA"
        }
    }

    companion object {
        private const val KEY_CONTEXT_MODE = "ai_context_mode"
    }
}
