package com.bph.geosusuaudio

import android.util.Log

/**
 * Centraliza la regla de los modos de respuesta para que la pantalla,
 * Google interno y Vosk se comporten exactamente igual.
 */
class QuestionRouter(
    private val jsonRepository: JsonKnowledgeRepository
) {
    sealed class Result {
        data class Json(val match: ResponseRepository.MatchResult) : Result()
        data object Net : Result()
        data object JsonNotFound : Result()
    }

    fun resolve(
        mode: AnswerModeSettings.Mode,
        question: String,
        alternatives: List<String> = emptyList()
    ): Result {
        return when (mode) {
            AnswerModeSettings.Mode.INTERNET -> Result.Net
            AnswerModeSettings.Mode.JSON -> {
                val match = jsonMatchWithAlternatives(question, alternatives)
                if (match.itemId != "none") Result.Json(match) else Result.JsonNotFound
            }
            AnswerModeSettings.Mode.AUTO -> {
                // Los ejercicios variables se resuelven por API en AUTO. El JSON queda
                // como apoyo para preguntas de estudio y respuestas de mayor profundidad.
                if (OnlineAnswerProvider.requiresStructuredNetAnswer(question)) {
                    Result.Net
                } else {
                    val match = jsonMatchWithAlternatives(question, alternatives)
                    if (match.itemId != "none") Result.Json(match) else Result.Net
                }
            }
        }
    }

    /**
     * v208: primero la pregunta elegida (igual que antes). Solo si NO coincide, se prueban
     * las otras versiones que oyó Google. Nunca se usa una versión recortada: debe tener
     * al menos el 70 % de las palabras de la pregunta, para no confundir preguntas.
     */
    private fun jsonMatchWithAlternatives(
        question: String,
        alternatives: List<String>
    ): ResponseRepository.MatchResult {
        val main = safeJsonMatch(question)
        if (main.itemId != "none" || alternatives.isEmpty()) return main

        val mainKey = ResponseRepository.normalize(question)
        val mainWords = wordCount(mainKey)
        var best: ResponseRepository.MatchResult? = null
        for (alternative in alternatives.take(MAX_JSON_ALTERNATIVES)) {
            val key = ResponseRepository.normalize(alternative)
            if (key.isBlank() || key == mainKey) continue
            val words = wordCount(key)
            if (words < 2 || words * 10 < mainWords * 7) continue
            val match = safeJsonMatch(alternative)
            if (match.itemId == "none") continue
            val current = best
            if (current == null || match.score > current.score) best = match
        }
        return best ?: main
    }

    private fun wordCount(text: String): Int = text.split(" ").count { it.isNotBlank() }

    private fun safeJsonMatch(question: String): ResponseRepository.MatchResult {
        return try {
            jsonRepository.findBest(question)
        } catch (e: Exception) {
            Log.e(TAG, "Fallo al buscar en el JSON", e)
            ResponseRepository.MatchResult(JsonKnowledgeRepository.JSON_NOT_FOUND, "none", 0)
        }
    }

    companion object {
        private const val TAG = "GeoSusuRouter"
        private const val MAX_JSON_ALTERNATIVES = 4
    }
}
